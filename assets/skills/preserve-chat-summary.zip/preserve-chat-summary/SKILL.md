---
name: preserve-chat-summary
description: Save or update a concise conversation record when the user requests file-based preservation. A plain summary is answered in chat; ending, archiving, or context compression alone does not trigger a file.
---

# Preserve Chat Summary

## When to use

- Use when the user requests a saved conversation record or explicitly invokes this skill to preserve the chat.
- Answer a plain summary request in chat. Do not create files merely because a conversation is long, ending, being archived, or approaching context compression.
- For an explicit transfer to another task, use `task-handoff` instead of also producing a separate summary.
- Suggest preservation only when it would materially reduce future reconstruction work. Do not ask on every turn.

## Save one record

Use the user's requested path. Otherwise save in the active project's `chat_summaries/`, or `C:\Users\User\.codex\chat_summaries\` for work without a project. Do not save a second global or project copy unless requested.

Reuse an existing record for the same task when identifiable. Otherwise use `YYYY-MM-DD_topic.md`; if the name belongs to another task, choose a distinct name. Preserve unrelated records and any history outside the section being updated.

Keep only the information needed to resume: decisions and constraints, current state and validation results, relevant paths or links, unresolved issues, and the next action. Omit empty sections, transcript repetition, and detailed procedures already available in the source files. Mark unknown or unverified facts.

Verify the saved record once and provide its path. Do not perform archive, deletion, or other unrelated actions as part of saving a record. This skill does not control the application's internal context compaction.

## Read only when needed

Read an existing record only when continuing earlier work and the current conversation and relevant files lack necessary context. Start with the latest relevant section of one record; expand only to resolve a specific gap. Do not reread content still available in context.
