# UT 환경과 실행 규칙

이 문서는 로컬 프로젝트의 진입 경로다. 실제 작업 시 최신 파일·Editor 상태를 다시 확인한다.

- Git 루트: `C:/Users/User/Documents/unity/gyeongil/ProjectUT_Unity`
- 실제 Unity 루트: 위 경로의 `ProjectUT/`
- 프로젝트 행동 지침: `C:/Users/User/Documents/unity/gyeongil/AGENTS.md`
- 파일 소유권·공유 Editor 검증: 같은 폴더의 `docs/WORKFLOW.md` 6·7절
- 공통 아트 기준: `global/art/psd-layered-authoring` (`0ff99df0-0ac5-4d41-81f3-73b6008652d3`), `global/art/layer-separation-reference-policy` (`f21d1e70-169c-4a0d-9e12-e49aec04d9e8`). 실제 DB 조회·원문·조건 검토는 judgment-harness를 따른다.

## 프로젝트 변경 보호

프로젝트 파일을 수정하기 전에 실제 session_id:turn_id로 정확한 파일 소유권을 확보한다. asset과 .meta는 같은 소유 단위다. 폴더 전체를 잠그거나 다른 채팅의 소유권을 가져오지 않는다. Opaque 쓰기는 실제 절대 파일을 declare 또는 write-set으로 명시한다. `[]`는 프로젝트 파일에 쓰지 않는 작업이다. 수정 묶음과 백그라운드 쓰기가 끝난 뒤 해당 턴의 소유권을 해제한다.

기존 미커밋 scene/prefab/clip과 다른 채팅의 작업을 보존한다. `Assets/_Imports`는 서브모듈이다. 로컬 제외와 Git 추적 파일은 `git check-ignore`/`git status`로 확인하고 과거 인계의 제외 상태를 고정 규칙으로 사용하지 않는다. 2026-10-22에 LocalRigging의 로컬 제외 규칙이 해제됐으며 패키지 manifest/lock은 추적 파일이다. 이 사실이 커밋/푸시 권한을 의미하지는 않는다.

## 공유 Editor

Editor를 사용하기 전 최신 WORKFLOW 6절의 Request/Status/Preflight와 owner 계약을 확인한다. 큐의 선두만 검증을 시작한다. queued 요청을 나중에 자동 실행하지 않는다. 미저장 씬·Prefab Mode·busy 상태를 자동 저장/폐기하거나 다른 채팅을 정지하지 않는다.

Unity 대기가 다음 승인 단계를 막고 정상 진행인지 확인하기 어려우면 [총괄 확인·상태 회신 절차](../../unity-mcp-skill/references/projectut-queue-coordination.md)를 따른다. 실제 owner·순서·막힌 단계·관측 시각을 총괄 채팅에 보내고 상황을 회신받는다. 같은 지연의 중복 연락을 피하고 회신 뒤에도 실제 진입 전 Status/Preflight를 다시 확인한다. 이 절차는 리깅 중단이나 서브 에이전트 제한 해제가 아니다.

숨은 프리뷰는 기존 격리 PreviewScene에서 수행하고, 형식적 NUnit EditMode 검사는 `UTValidationQueue.RunEditModeTests(owner, explicitPlainNUnitNames)` 경로와 `Assets/Scenes/Test/VFX_PreviewValidation.unity`를 사용한다. 런타임 확인은 요청된 경우에만 저장된 작업별 QA 씬으로 `EnterPlayMode(owner, savedQaScenePath)`를 사용한다. 직접 Play/Stop·Test Runner API/UI로 우회하지 않는다. Play Mode 종료·원래 씬 복원 후 `Finish(owner)`로 반환한다. 지원되는 것은 일반 동기 NUnit뿐이며 UnityTest/비동기 전체 스위트 통과를 주장하지 않는다.

프리뷰 도구의 렌더가 게임 Play Mode 증거는 아니다. 기존 도구와 정책이 실제 작업에 맞지 않으면 필요한 최소 수정 또는 막힌 범위를 제시하며, 다른 씬에 몰래 인스턴스를 배치하지 않는다. VFX 외형 수정은 해당 VFX 절차를 별도로 따르며 리깅 작업이라는 이유로 VFX revision job을 만들지 않는다.

## 현재 재사용 가능한 도구와 한계

`ProjectUT/Assets/Editor/LocalRigging/UTLocalRiggingPreview.cs`

- 메뉴: `Tools > Project UT > Local Rigging Preview`
- WhitehairGown 전용 prefab/clip 경로와 13 SpriteSkin/각 28본 검사가 하드코딩된 실험 도구다. 임의 캐릭터에 그대로 쓰는 범용 도구가 아니다.
- 숨은 PreviewScene의 복제본에서 CPU deformation과 임시 `Sprites/Default` 재질을 사용한다. 실제 prefab/전역 GPU 설정을 변경하는 대안이 아니다.
- `CaptureFrame(absolutePath, seconds)`는 기존 출력 폴더를 요구한다. `RenderFrameSequence(absoluteDirectory)`는 기존의 빈 출력 폴더를 요구하고 Repaint 시 요청을 처리한다. 호출 반환만으로 저장 완료를 주장하지 말고 결과 파일 수/완료 로그를 확인한다.
- 현재 시퀀스는 1080×1920, 30fps, clip 길이 기반이며 `frame0000.png`부터 생성한다. 다른 규격·캐릭터를 요청하면 기존 코드와 아트를 관찰한 뒤 승인된 범위만 조정한다. 6초/180프레임은 특정 clip의 결과다.
- 샘플링 → 스킨 변형 갱신 → 렌더 → 픽셀 읽기 순서다. GPU 경로를 사용하는 다른 도구에서는 실제 업데이트 완료 시점을 따로 확인한다.

신규 출력/검토 자료는 `D:/CodexData/projectut/outputs/<YYYYMMDD>/<작업>/`에 둔다. 기존 원본·실패 영상·다른 결과를 자동 삭제/이동/덮어쓰지 않는다. FFmpeg는 기존 `D:/CodexData/rigging/tools/ffmpeg-win-x86_64-v7.1.exe`가 있으나 매번 존재/실행 가능 여부를 확인한다. 새 패키지 설치나 실행 파일 다운로드를 자동 수행하지 않는다.
