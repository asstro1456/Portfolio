# 전신 메시 프레임 진단

`scripts/export_frame_mesh.cs` → `scripts/audit_frame_mesh.py`를 사용한다. 전신 파츠의 뒤집힘·붕괴 시점과 삼각형을 찾는 **기하 진단**이다. 자연스러운 움직임·아트 승인·최종 SpriteSkin 렌더링 검사를 대신하지 않는다. 기존 `verify_video.py`와 목적이 다르다.

## 실행 경계

- 저장된 authoring rig prefab과 Transform AnimationClip만 지원한다. 이벤트·sprite 교체·Transform 이외 곡선·임의 MonoBehaviour가 있으면 중단한다. 다른 제작을 재개하거나 사용자 원본을 고치지 않는다.
- 실제 ProjectUT Editor 경로와 공유 큐를 확인한다. 현재 chat:turn으로 `UTValidationQueue.Request`한 뒤 선두이고 active owner가 없으며 Preflight가 비어 있을 때만 실행한다. 끝나거나 실패하면 **자신의 pending 요청만** Cancel한다. Play Mode/Test Runner/빌드나 게임 씬 연결은 필요 없다.
- PNG·meta·prefab·clip의 해시를 실행 전후 대조한다. 도구 내부 dependency hash도 검사한다. 기존 dirty scene·다른 채팅 변경·미저장 상태는 저장/폐기하지 않는다.
- exporter는 Assets에 넣지 않는다. UTF-8 원문을 읽어 아래 CommandScript를 **동일 namespace의 마지막 닫는 중괄호 바로 앞에** 붙인 후 기존 공식 Editor C# command runner의 Code로 컴파일·실행한다. 별도 namespace를 추가하면 runner의 namespace 변환으로 참조가 깨질 수 있다. read-only 선언 `// ProjectUT write-set: []`도 적용한다.

```csharp
internal class CommandScript : IRunCommand
{
    public void Execute(ExecutionResult result)
    {
        result.Log(Exporter.Export(new Request {
            owner = "<실제 chat:turn>",
            prefabPath = "Assets/Editor/LocalRigging/<대상>/<rig>.prefab",
            clipPath = "Assets/Editor/LocalRigging/<대상>/<idle>.anim",
            outputPath = "D:/CodexData/projectut/outputs/<이번 검증>/mesh-snapshot.json",
            variant = "<소스 버전과 후보>",
            sampleRate = 0,
            alphaThreshold = 0
        }));
    }
}
```

`sampleRate=0`은 clip.frameRate를 사용한다. 0초와 종료 시점을 포함하며 최대 10,000구간이다. `partPaths`를 생략하면 활성 SpriteSkin 전부, 지정하면 rig 기준 상대 경로만 검사한다. 경로 오기·비활성 대상은 누락시키지 않고 실패한다. `alphaThreshold`는 0 이상 1 미만이며 목적에 맞게 정한다. 과거 사례의 16/255를 보편 합격값으로 쓰지 않는다. outputPath는 프로젝트 밖의 **새 파일**이어야 한다. 중단된 불완전 JSON은 성공 산출물이 아니며 덮어쓰지 않고 새 경로로 재검증한다.

exporter는 숨은 PreviewScene의 복제본에서 Unity가 clip을 샘플링하고, Sprite의 실제 vertices/weights/bind poses/bone transforms를 임시 SkinnedMeshRenderer에 연결해 CPU BakeMesh를 읽는다. 매 포즈에서 renderer-local LBS 계산과의 오차를 대조하고 전체 시점을 재탐색해 A/A 재현 오차도 검사한다. 임시 Mesh·복제본·PreviewScene과 alpha readback 자원은 성공/실패 모두 정리한다. 원본 sprite/importer 설정은 바꾸지 않는다. `configureClone` callback은 도구 검증용 임시 fixture에만 쓰며 원본 에셋 수정 권한이 아니다.

## 보고서 읽기

```powershell
py -3 -B -X utf8 C:/Users/User/.codex/skills/ut-fullbody-rigging-harness/scripts/audit_frame_mesh.py D:/CodexData/projectut/outputs/<이번 검증>/mesh-snapshot.json
```

Python 표준 라이브러리만 사용하고 입력 파일을 수정하지 않는다. JSON을 stdout에 반환한다. exit 0은 `NO_CANDIDATES_IN_SAMPLES`, 1은 `CANDIDATES_FOUND`, 2는 `INVALID_INPUT`이다. 1을 도구 실행 실패로 오인하지 않는다. 반대로 0을 아트/동작 PASS로 올리지 않는다.

- `worstTriangle`/`largestTriangle`: rest 대비 부호 있는 면적비, frame/time, 삼각형·정점 ID, source sprite-local pixel 좌표. 전체 캔버스나 화면 좌표를 추정하지 않는다.
- `candidateFrames`: 뒤집힘·수치상 붕괴. 선택적으로 `--min-area-ratio`/`--max-area-ratio`를 주면 압축/늘어짐도 표시한다. 예술적 허용치는 자동 설정하지 않는다.
- `geometryMethod`, `maxLbsReferenceError`, `repeatSampleMaxError`: 측정 경로와 유효성 근거. 마지막 두 오차는 각각 1e-4/1e-5 Unity 단위 이하인 수치 일치 검사다. 메시 평면성·유효 삼각형·표본 누락·NaN 등의 오류는 판정을 차단한다.

알파 선별은 원본 텍스처 **삼각형 UV 중심 한 점**이며 삼각형 전체 가시성, 가림·합성·material/shader·SpriteRenderer flip·GPU 변형을 증명하지 않는다. 투명 영역 제외로 경계 결함이 빠질 수 있고 샘플 사이 결함도 남는다. 복잡한 비평면 변형은 이 2D 면적 검사 범위 밖이다. 결함 후보의 실제 화면과 정상 속도 루프는 별도로 확인한다.

## 확인된 범위와 재검증

2026-10-25 Unity 6000.3.9f1 / 설치 2D Animation에서 검증했다. Whitehair 15파트·64본/4본, 30fps·6초(181포즈), 역사적 오른쪽 뒷머리 웨이트의 접힘 8프레임(최저 4.2초)과 수정 웨이트 0프레임을 대조했다. 별도 임시 64×32/pivot(16,24)/PPU37/2본/7fps fixture도 검사했다. 이것은 다른 실제 캐릭터의 품질 승인이나 전체 Unity 버전 호환성 증거가 아니다.

실제 SpriteSkin `OnPreviewUpdate`와 `GetDeformedVertexPositionData`는 이 패키지에서 다른 버퍼 경로를 사용해 PreviewScene의 공개 getter가 가용하지 않았다. 같은 경로를 반복하거나 reflection/패키지 수정으로 우회하지 않는다. CPU BakeMesh 측정으로 명시하며 최종 render buffer 일치를 주장하지 않는다. 근거: 설치 패키지 SpriteSkin.cs / SpriteSkinUtility.cs, [Unity BakeMesh 공식 API](https://docs.unity3d.com/6000.0/Documentation/ScriptReference/SkinnedMeshRenderer.BakeMesh.html).

도구 변경 시 `python -B -X utf8 -m unittest -v test_audit_frame_mesh.py`를 scripts 폴더에서 실행하고 영향받은 실제 fixture/회귀를 다시 검사한다. 단위 테스트만으로 Unity 측정 경로가 검증됐다고 하지 않는다.
