// Compile outside Assets with the Editor command runner; do not import this into a game assembly.
using System;
using System.IO;
using System.Linq;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.U2D;
using UnityEngine.U2D.Animation;
using UnityEngine.Rendering;
using UnityEditor;
using UnityEditor.SceneManagement;

namespace CodexRiggingMeshAudit
{
    [Serializable] public sealed class Request
    {
        public string owner, prefabPath, clipPath, outputPath, variant = "saved-assets";
        public float sampleRate, alphaThreshold;
        public string[] partPaths;
    }
    [Serializable] public sealed class Frame { public Vector3[] vertices; }
    [Serializable] public sealed class Part
    {
        public string path;
        public float pixelsPerUnit, pivotX, pivotY, rectWidth, rectHeight;
        public int boneCount, textureWidth, textureHeight;
        public Vector3[] restVertices;
        public int[] indices;
        public bool[] visibleTriangles;
        [NonSerialized] public Frame[] frames;
    }
    [Serializable] public sealed class Snapshot
    {
        public int schema = 1;
        public string source, variant, unityVersion, dependencyHash;
        public string geometryMethod = "Unity CPU BakeMesh of Sprite vertices/weights/bind poses; not SpriteSkin render buffer";
        public double clipLength, sampleRate;
        public double[] sampleTimes;
        public float repeatSampleMaxError, maxLbsReferenceError, alphaThreshold;
        [NonSerialized] public Part[] parts;
    }

    public static class Exporter
    {
        // Verification may configure only the disposable clone (e.g. historical weights).
        public static string Export(Request request, Action<GameObject> configureClone = null)
        {
            var queue = JsonUtility.FromJson<UTValidationQueueState>(UTValidationQueue.Status());
            queue.RequireHead(request.owner);
            if (!string.IsNullOrEmpty(queue.activeOwner)) throw new InvalidOperationException("Another validation is active.");
            string blocked = UTValidationQueue.Preflight();
            if (blocked != null) throw new InvalidOperationException(blocked);
            var prefab = AssetDatabase.LoadAssetAtPath<GameObject>(request.prefabPath);
            var clip = AssetDatabase.LoadAssetAtPath<AnimationClip>(request.clipPath);
            if (prefab == null || clip == null || clip.length <= 0) throw new ArgumentException("Saved rig prefab and nonempty clip are required.");
            if (prefab.GetComponentsInChildren<MonoBehaviour>(true).Any(c => c == null || !(c is SpriteSkin)))
                throw new ArgumentException("Only a SpriteSkin authoring rig is supported; arbitrary behaviours are not executed.");
            if (AnimationUtility.GetAnimationEvents(clip).Length != 0 || AnimationUtility.GetObjectReferenceCurveBindings(clip).Length != 0 ||
                AnimationUtility.GetCurveBindings(clip).Any(b => b.type != typeof(Transform)))
                throw new ArgumentException("Only Transform curves without events or sprite swaps are supported.");
            double rate = request.sampleRate == 0 ? clip.frameRate : request.sampleRate;
            if (double.IsNaN(rate) || double.IsInfinity(rate) || rate <= 0 || rate * clip.length > 10000 ||
                float.IsNaN(request.alphaThreshold) || request.alphaThreshold < 0 || request.alphaThreshold >= 1)
                throw new ArgumentException("Invalid cadence or alpha threshold (maximum 10000 intervals).");
            string output = Path.GetFullPath(request.outputPath);
            string project = Path.GetFullPath(Path.Combine(Application.dataPath, "..")).TrimEnd(Path.DirectorySeparatorChar) + Path.DirectorySeparatorChar;
            if (output.StartsWith(project, StringComparison.OrdinalIgnoreCase) || File.Exists(output) || Directory.Exists(output))
                throw new ArgumentException("Use a new external snapshot path; existing files and project paths are protected.");
            string before = Dependencies(request);
            var scene = EditorSceneManager.NewPreviewScene();
            GameObject rig = null;
            var nativeMeshes = new List<UnityEngine.Mesh>();
            try
            {
                rig = (GameObject)PrefabUtility.InstantiatePrefab(prefab, scene);
                foreach (var animator in rig.GetComponentsInChildren<Animator>(true)) animator.enabled = false;
                configureClone?.Invoke(rig);
                var skins = rig.GetComponentsInChildren<SpriteSkin>(true).Where(s => s.enabled && s.gameObject.activeInHierarchy &&
                    (request.partPaths == null || request.partPaths.Length == 0 || request.partPaths.Contains(AnimationUtility.CalculateTransformPath(s.transform, rig.transform)))).ToArray();
                if (skins.Length == 0 || (request.partPaths != null && request.partPaths.Length != 0 && skins.Length != request.partPaths.Distinct().Count()))
                    throw new ArgumentException("Selected SpriteSkin parts were not found or are inactive.");
                var bakers = new List<SkinnedMeshRenderer>();
                foreach (var skin in skins)
                {
                    if (skin.SetBoneTransforms(skin.boneTransforms) != SpriteSkinState.Ready)
                        throw new InvalidOperationException("Invalid SpriteSkin mapping: " + skin.name);
                    var sprite = skin.GetComponent<SpriteRenderer>().sprite;
                    var mesh = new UnityEngine.Mesh { name = "Disposable Sprite mesh audit" };
                    nativeMeshes.Add(mesh);
                    mesh.vertices = sprite.vertices.Select(v => new Vector3(v.x, v.y, 0)).ToArray();
                    mesh.triangles = sprite.triangles.Select(i => (int)i).ToArray();
                    mesh.boneWeights = sprite.GetVertexAttribute<BoneWeight>(VertexAttribute.BlendWeight).ToArray();
                    mesh.bindposes = sprite.GetBindPoses().ToArray();
                    if (mesh.boneWeights.Length != mesh.vertexCount || mesh.bindposes.Length != skin.boneTransforms.Length ||
                        mesh.boneWeights.Any(w => w.weight0 < 0 || w.weight1 < 0 || w.weight2 < 0 || w.weight3 < 0 ||
                            Mathf.Abs(w.weight0 + w.weight1 + w.weight2 + w.weight3 - 1) > 0.0001f ||
                            new[] { w.boneIndex0, w.boneIndex1, w.boneIndex2, w.boneIndex3 }.Any(b => b < 0 || b >= mesh.bindposes.Length)))
                        throw new InvalidOperationException("Invalid vertex weights/bind poses: " + skin.name);
                    var child = new GameObject("Disposable CPU bake");
                    child.transform.SetParent(skin.transform, false);
                    var baker = child.AddComponent<SkinnedMeshRenderer>();
                    baker.enabled = false;
                    baker.quality = SkinQuality.Bone4;
                    baker.sharedMesh = mesh;
                    baker.bones = skin.boneTransforms;
                    baker.rootBone = skin.rootBone;
                    bakers.Add(baker);
                }
                var snapshot = new Snapshot
                {
                    source = request.prefabPath + " | " + request.clipPath, variant = request.variant,
                    unityVersion = Application.unityVersion, dependencyHash = before,
                    clipLength = clip.length, sampleRate = rate, alphaThreshold = request.alphaThreshold,
                    sampleTimes = Enumerable.Range(0, (int)Math.Ceiling(clip.length * rate) + 1).Select(i => Math.Min(i / rate, clip.length)).ToArray(),
                    parts = skins.Select(s => Describe(s, rig, request.alphaThreshold)).ToArray()
                };
                foreach (var part in snapshot.parts) part.frames = new Frame[snapshot.sampleTimes.Length];
                var baked = new UnityEngine.Mesh();
                nativeMeshes.Add(baked);
                for (int f = 0; f < snapshot.sampleTimes.Length; f++)
                {
                    float time = (float)snapshot.sampleTimes[f];
                    Sample(rig, clip, time);
                    for (int p = 0; p < skins.Length; p++)
                    {
                        var vertices = Read(bakers[p], baked);
                        snapshot.maxLbsReferenceError = Mathf.Max(snapshot.maxLbsReferenceError, ReferenceError(bakers[p], vertices));
                        snapshot.parts[p].frames[f] = new Frame { vertices = vertices };
                    }
                }
                // A/A replay after seeking away detects stale buffers and nondeterministic sampling.
                for (int f = 0; f < snapshot.sampleTimes.Length; f++)
                {
                    Sample(rig, clip, (float)snapshot.sampleTimes[f]);
                    for (int p = 0; p < skins.Length; p++)
                    {
                        var replay = Read(bakers[p], baked);
                        for (int v = 0; v < replay.Length; v++) snapshot.repeatSampleMaxError = Mathf.Max(snapshot.repeatSampleMaxError,
                            Vector3.Distance(replay[v], snapshot.parts[p].frames[f].vertices[v]));
                    }
                }
                if (snapshot.repeatSampleMaxError > 0.00001f) throw new InvalidOperationException("Repeated CPU samples differ.");
                if (snapshot.maxLbsReferenceError > 0.0001f) throw new InvalidOperationException("Native bake differs from renderer-local Sprite LBS; unsupported transform or data.");
                if (Dependencies(request) != before) throw new InvalidOperationException("Source dependencies changed during sampling; discard the comparison.");
                Directory.CreateDirectory(Path.GetDirectoryName(output));
                using (var stream = new FileStream(output, FileMode.CreateNew, FileAccess.Write))
                using (var writer = new StreamWriter(stream, new System.Text.UTF8Encoding(false))) WriteSnapshot(writer, snapshot);
                return output;
            }
            finally
            {
                if (rig != null) UnityEngine.Object.DestroyImmediate(rig);
                foreach (var mesh in nativeMeshes) UnityEngine.Object.DestroyImmediate(mesh);
                EditorSceneManager.ClosePreviewScene(scene);
            }
        }

        static string Dependencies(Request request) => AssetDatabase.GetAssetDependencyHash(request.prefabPath) + ":" + AssetDatabase.GetAssetDependencyHash(request.clipPath);

        static void WriteSnapshot(TextWriter writer, Snapshot snapshot)
        {
            // Dynamic Editor assemblies omit nested custom DTOs in JsonUtility; serialize each leaf explicitly.
            string header = JsonUtility.ToJson(snapshot);
            writer.Write(header.Substring(0, header.Length - 1) + ",\"parts\":[");
            for (int p = 0; p < snapshot.parts.Length; p++)
            {
                if (p > 0) writer.Write(",");
                string part = JsonUtility.ToJson(snapshot.parts[p]);
                writer.Write(part.Substring(0, part.Length - 1) + ",\"frames\":[");
                for (int f = 0; f < snapshot.parts[p].frames.Length; f++)
                {
                    if (f > 0) writer.Write(",");
                    writer.Write(JsonUtility.ToJson(snapshot.parts[p].frames[f]));
                }
                writer.Write("]}");
            }
            writer.Write("]}");
        }

        static void Sample(GameObject rig, AnimationClip clip, float time)
        {
            clip.SampleAnimation(rig, time < clip.length / 2 ? clip.length : 0);
            clip.SampleAnimation(rig, time);
        }

        static Vector3[] Read(SkinnedMeshRenderer baker, UnityEngine.Mesh baked)
        {
            // shortcut: audits CPU LBS geometry, not the SpriteSkin render buffer or shader deformation.
            baked.Clear();
            baker.BakeMesh(baked, false);
            return baked.vertices;
        }

        static float ReferenceError(SkinnedMeshRenderer baker, Vector3[] actual)
        {
            var mesh = baker.sharedMesh;
            var rest = mesh.vertices;
            var weights = mesh.boneWeights;
            var bind = mesh.bindposes;
            if (actual.Length != rest.Length) throw new InvalidOperationException("Baked vertex count changed.");
            var matrices = baker.bones.Select((bone, i) => baker.transform.worldToLocalMatrix * bone.localToWorldMatrix * bind[i]).ToArray();
            float error = 0;
            for (int v = 0; v < rest.Length; v++)
            {
                var w = weights[v];
                Vector3 expected = matrices[w.boneIndex0].MultiplyPoint3x4(rest[v]) * w.weight0 +
                    matrices[w.boneIndex1].MultiplyPoint3x4(rest[v]) * w.weight1 +
                    matrices[w.boneIndex2].MultiplyPoint3x4(rest[v]) * w.weight2 +
                    matrices[w.boneIndex3].MultiplyPoint3x4(rest[v]) * w.weight3;
                error = Mathf.Max(error, Vector3.Distance(expected, actual[v]));
            }
            return error;
        }

        static Part Describe(SpriteSkin skin, GameObject rig, float threshold)
        {
            var sprite = skin.GetComponent<SpriteRenderer>().sprite;
            if (sprite == null || sprite.GetBindPoses().Length != skin.boneTransforms.Length)
                throw new InvalidOperationException("Sprite/bind pose count mismatch: " + skin.name);
            var vertices = sprite.vertices.Select(v => new Vector3(v.x, v.y, 0)).ToArray();
            var indices = sprite.triangles.Select(i => (int)i).ToArray();
            var uv = sprite.uv;
            var texture = sprite.texture;
            var visible = new bool[indices.Length / 3];
            RenderTexture old = RenderTexture.active;
            var rt = RenderTexture.GetTemporary(texture.width, texture.height, 0, RenderTextureFormat.ARGB32, RenderTextureReadWrite.Linear);
            Texture2D copy = null;
            try
            {
                Graphics.Blit(texture, rt);
                RenderTexture.active = rt;
                copy = new Texture2D(texture.width, texture.height, TextureFormat.RGBA32, false, true);
                copy.ReadPixels(new Rect(0, 0, texture.width, texture.height), 0, 0);
                copy.Apply();
                var pixels = copy.GetPixels32();
                for (int t = 0; t < visible.Length; t++)
                {
                    Vector2 center = (uv[indices[t * 3]] + uv[indices[t * 3 + 1]] + uv[indices[t * 3 + 2]]) / 3;
                    int x = Mathf.Clamp((int)(center.x * texture.width), 0, texture.width - 1);
                    int y = Mathf.Clamp((int)(center.y * texture.height), 0, texture.height - 1);
                    visible[t] = pixels[y * texture.width + x].a / 255f > threshold;
                }
            }
            finally
            {
                RenderTexture.active = old;
                if (copy != null) UnityEngine.Object.DestroyImmediate(copy);
                RenderTexture.ReleaseTemporary(rt);
            }
            return new Part
            {
                path = AnimationUtility.CalculateTransformPath(skin.transform, rig.transform),
                pixelsPerUnit = sprite.pixelsPerUnit, pivotX = sprite.pivot.x, pivotY = sprite.pivot.y,
                rectWidth = sprite.rect.width, rectHeight = sprite.rect.height,
                textureWidth = texture.width, textureHeight = texture.height, boneCount = skin.boneTransforms.Length,
                restVertices = vertices, indices = indices, visibleTriangles = visible
            };
        }
    }
}
