import copy
import importlib.util
import json
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest

spec = importlib.util.spec_from_file_location('mesh_audit', Path(__file__).with_name('audit_frame_mesh.py'))
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)


def v(x, y, z=0):
    return {'x': x, 'y': y, 'z': z}


def fixture():
    points = [v(0, 0), v(1, 0), v(0, 1)]
    return {'schema': 1, 'sampleRate': 2, 'clipLength': 1, 'sampleTimes': [0, .5, 1],
            'repeatSampleMaxError': 0, 'variant': 'synthetic-test',
            'maxLbsReferenceError': 0,
            'parts': [{'path': 'body', 'pixelsPerUnit': 17, 'pivotX': 3, 'pivotY': 8, 'boneCount': 2,
                       'restVertices': points, 'indices': [0, 1, 2], 'visibleTriangles': [True],
                       'frames': [{'vertices': copy.deepcopy(points)} for _ in range(3)]}]}


class MeshAuditTests(unittest.TestCase):
    def test_identity_is_not_art_or_motion_approval(self):
        result = module.audit(fixture())
        self.assertEqual(result['status'], 'NO_CANDIDATES_IN_SAMPLES')
        self.assertEqual(result['normalSpeedMotion'], 'NOT_RUN')
        self.assertEqual(result['parts'][0]['worstTriangle']['ratio'], 1)

    def test_detects_flip_at_exact_frame_and_triangle(self):
        data = fixture(); data['parts'][0]['frames'][1]['vertices'][2] = v(0, -1)
        p = module.audit(data)['parts'][0]
        self.assertEqual(p['flippedFrameCount'], 1)
        self.assertEqual(p['candidateFrames'][0]['time'], .5)
        self.assertEqual(p['candidateFrames'][0]['flipped'], [0])

    def test_detects_collapse(self):
        data = fixture(); data['parts'][0]['frames'][2]['vertices'][2] = v(0, 0)
        self.assertEqual(module.audit(data)['parts'][0]['collapsedFrameCount'], 1)

    def test_compression_stretch_require_explicit_thresholds(self):
        data = fixture(); data['parts'][0]['frames'][1]['vertices'][2] = v(0, .2)
        data['parts'][0]['frames'][2]['vertices'][2] = v(0, 4)
        self.assertEqual(module.audit(data)['status'], 'NO_CANDIDATES_IN_SAMPLES')
        frames = module.audit(data, minimum=.3, maximum=3)['parts'][0]['candidateFrames']
        self.assertEqual(frames[0]['compressed'], [0]); self.assertEqual(frames[1]['stretched'], [0])

    def test_alternate_dimensions_counts_and_pivot(self):
        data = fixture(); p = data['parts'][0]; p['pixelsPerUnit'] = 31; p['pivotX'] = 21
        p['path'] = 'different-layout'; p['boneCount'] = 7
        data['parts'].append(copy.deepcopy(p)); data['parts'][1]['path'] = 'another-part'
        r = module.audit(data)
        self.assertEqual(len(r['parts']), 2)
        self.assertAlmostEqual(r['parts'][0]['worstTriangle']['spriteLocalPixels'][0], 21+31/3)

    def test_different_clip_rate_and_endpoint(self):
        data = fixture(); data.update(sampleRate=3, clipLength=.5, sampleTimes=[0, 1/3, .5])
        self.assertEqual(module.audit(data)['sampleCount'], 3)

    def test_rejects_unreliable_or_incomplete_samples(self):
        for changes in [{'sampleTimes': [0, .5, .9]}, {'repeatSampleMaxError': .01}, {'clipLength': 0}]:
            with self.subTest(changes=changes):
                data = fixture(); data.update(changes)
                with self.assertRaises(ValueError): module.audit(data)

    def test_rejects_malformed_mesh(self):
        for field, value in [('indices', [0, 1, 90]), ('indices', [0, 1]), ('visibleTriangles', [1]),
                             ('frames', []), ('pixelsPerUnit', 0)]:
            with self.subTest(field=field, value=value):
                data = fixture(); data['parts'][0][field] = value
                with self.assertRaises(ValueError): module.audit(data)

    def test_rejects_nonfinite_degenerate_and_nonplanar(self):
        for case in ('nan', 'degenerate', 'nonplanar'):
            with self.subTest(case=case):
                data = fixture(); p = data['parts'][0]
                if case == 'nan': p['frames'][0]['vertices'][0]['x'] = float('nan')
                if case == 'degenerate': p['restVertices'][2] = v(0, 0)
                if case == 'nonplanar': p['frames'][0]['vertices'][2]['z'] = 1
                with self.assertRaises(ValueError): module.audit(data)

    def test_rejects_empty_invisible_and_duplicate_parts(self):
        for case in ('empty', 'invisible', 'duplicate'):
            with self.subTest(case=case):
                data = fixture()
                if case == 'empty': data['parts'] = []
                if case == 'invisible': data['parts'][0]['visibleTriangles'] = [False]
                if case == 'duplicate': data['parts'].append(copy.deepcopy(data['parts'][0]))
                with self.assertRaises(ValueError): module.audit(data)

    def test_rejects_bad_containers_and_reference(self):
        for field, value in [('parts', [None]), ('schema', True), ('maxLbsReferenceError', .01),
                             ('maxLbsReferenceError', float('nan')), ('sampleRate', 10001)]:
            with self.subTest(field=field):
                data = fixture(); data[field] = value
                with self.assertRaises(ValueError): module.audit(data)
        for field, value in [('frames', [None]*3), ('restVertices', None)]:
            data = fixture(); data['parts'][0][field] = value
            with self.assertRaises(ValueError): module.audit(data)

    def test_cli_status_exit_codes_and_preservation(self):
        with tempfile.TemporaryDirectory() as folder:
            path = Path(folder) / 'snapshot.json'
            for expected, kind in [(0, 'valid'), (1, 'flip'), (2, 'invalid')]:
                data = fixture()
                if kind == 'flip': data['parts'][0]['frames'][1]['vertices'][2] = v(0, -1)
                if kind == 'invalid': data['parts'][0]['indices'] = [0, 1, 99]
                original = json.dumps(data).encode('utf8'); path.write_bytes(original)
                run = subprocess.run([sys.executable, '-B', '-X', 'utf8', str(Path(module.__file__)), str(path)], capture_output=True)
                self.assertEqual(run.returncode, expected, run.stderr)
                self.assertEqual(path.read_bytes(), original)
                self.assertIn('status', json.loads(run.stdout))


if __name__ == '__main__':
    unittest.main()
