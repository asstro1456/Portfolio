"""Read-only, fixed-cadence PNG/MP4 technical checks. Requires existing FFmpeg."""

import argparse
from fractions import Fraction
import hashlib
import json
from pathlib import Path
import struct
import subprocess


def inspect_frames(ffmpeg, inputs, width, height, fps, count):
    command = [str(ffmpeg), "-v", "error", "-xerror", "-err_detect", "explode"]
    command += inputs + ["-map", "0:v:0", "-an", "-pix_fmt", "rgb24",
                         "-fps_mode", "passthrough", "-f", "framehash", "-hash", "sha256", "-"]
    process = subprocess.run(command, capture_output=True, text=True, encoding="utf-8", errors="strict")
    if process.returncode or process.stderr.strip():
        raise ValueError("FFmpeg decode failed: " + process.stderr[-1500:])
    timebase, dimensions, rows = None, None, []
    for line in process.stdout.splitlines():
        if line.startswith("#tb 0:"):
            timebase = Fraction(line.split(":", 1)[1].strip())
        elif line.startswith("#dimensions 0:"):
            dimensions = tuple(map(int, line.split(":", 1)[1].strip().split("x")))
        elif line and not line.startswith("#"):
            fields = [field.strip() for field in line.split(",")]
            if len(fields) != 6 or fields[0] != "0":
                raise ValueError("Unexpected FFmpeg framehash row")
            rows.append((int(fields[2]), int(fields[3]), fields[5]))
    if dimensions != (width, height) or timebase is None or len(rows) != count:
        raise ValueError(f"Decoded size/count mismatch: {dimensions}, {len(rows)} frames")
    for i, (pts, duration, _) in enumerate(rows):
        if (pts - rows[0][0]) * timebase != Fraction(i, 1) / fps or duration * timebase != 1 / fps:
            raise ValueError(f"Unexpected frame timing at index {i}")
    hashes = [row[2] for row in rows]
    return {"frame_count": len(rows), "unique_frames": len(set(hashes)),
            "size_px": list(dimensions), "fps": str(fps),
            "duration_seconds": float(Fraction(count, 1) / fps),
            "ordered_pixel_hash_sha256": hashlib.sha256("\n".join(hashes).encode("ascii")).hexdigest()}


def verify(ffmpeg, video, frames, width, height, fps, count):
    fps = Fraction(fps)
    if min(width, height, count) <= 0 or fps <= 0:
        raise ValueError("Size, fps and count must be positive")
    video, frames = Path(video).resolve(), Path(frames).resolve()
    if not video.is_file() or not frames.is_dir():
        raise ValueError("Video and PNG directory must exist")
    expected = {f"frame{i:04d}.png" for i in range(count)}
    actual = {path.name for path in frames.glob("frame*.png")}
    if actual != expected:
        raise ValueError(f"PNG sequence mismatch: {len(expected - actual)} missing, {len(actual - expected)} extra")
    for name in sorted(expected):
        with (frames / name).open("rb") as source:
            header = source.read(24)
        if (len(header) != 24 or header[:8] != b"\x89PNG\r\n\x1a\n"
                or header[12:16] != b"IHDR" or struct.unpack(">II", header[16:24]) != (width, height)):
            raise ValueError("Invalid PNG header/dimensions: " + name)
    source_info = inspect_frames(ffmpeg, ["-framerate", str(fps), "-start_number", "0",
                                        "-i", str(frames / "frame%04d.png")], width, height, fps, count)
    video_info = inspect_frames(ffmpeg, ["-i", str(video)], width, height, fps, count)
    if source_info["unique_frames"] > 1 and video_info["unique_frames"] == 1:
        raise ValueError("Moving PNG source became a fully static video")
    digest = hashlib.sha256()
    with video.open("rb") as source:
        for block in iter(lambda: source.read(1024 * 1024), b""):
            digest.update(block)
    return {"technical_status": "PASS", "visual_comparison_status": "NOT_RUN",
            "motion_review_status": "NOT_RUN", "strict_decode_errors": 0,
            "video": str(video), "video_sha256": digest.hexdigest(), "frames": str(frames),
            "source": source_info, "decoded_video": video_info,
            "limits": "Fixed cadence; first video stream; no audio, art, pose or color-match approval."}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--ffmpeg", required=True)
    parser.add_argument("--video", required=True)
    parser.add_argument("--frames", required=True)
    parser.add_argument("--width", type=int, required=True)
    parser.add_argument("--height", type=int, required=True)
    parser.add_argument("--fps", required=True)
    parser.add_argument("--count", type=int, required=True)
    args = parser.parse_args()
    try:
        result = verify(args.ffmpeg, args.video, args.frames, args.width, args.height, args.fps, args.count)
    except (OSError, ValueError, ZeroDivisionError, UnicodeError) as error:
        print(json.dumps({"technical_status": "FAIL", "visual_comparison_status": "NOT_RUN",
                          "motion_review_status": "NOT_RUN", "error": str(error)}, ensure_ascii=False))
        return 1
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
