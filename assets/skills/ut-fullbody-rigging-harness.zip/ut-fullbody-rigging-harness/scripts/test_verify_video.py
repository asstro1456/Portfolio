"""Integration checks with tiny generated PNGs; no Unity, network or extra packages."""

import argparse
import binascii
from fractions import Fraction
from pathlib import Path
import struct
import subprocess
import tempfile
import unittest
import zlib

from verify_video import verify


def png(path, color, width=32, height=32):
    def chunk(kind, data):
        return struct.pack(">I", len(data)) + kind + data + struct.pack(">I", binascii.crc32(kind + data))
    pixels = (b"\0" + bytes(color) * width) * height
    path.write_bytes(b"\x89PNG\r\n\x1a\n" + chunk(b"IHDR", struct.pack(">IIBBBBB", width, height, 8, 2, 0, 0, 0))
                     + chunk(b"IDAT", zlib.compress(pixels)) + chunk(b"IEND", b""))


class VideoChecks(unittest.TestCase):
    ffmpeg = None

    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(prefix="ut-video-check-")
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)
        self.frames = self.root / "frames"
        self.frames.mkdir()
        for i, color in enumerate([(220, 30, 20), (220, 30, 20), (20, 200, 50), (30, 40, 220)]):
            png(self.frames / f"frame{i:04d}.png", color)
        self.video = self.root / "test.mp4"
        self.encode()

    def encode(self, fps="4"):
        subprocess.run([self.ffmpeg, "-v", "error", "-y", "-framerate", fps, "-i",
                        str(self.frames / "frame%04d.png"), "-c:v", "libx264", "-pix_fmt", "yuv420p",
                        str(self.video)], check=True, capture_output=True)

    def check_video(self, **changes):
        values = dict(ffmpeg=self.ffmpeg, video=self.video, frames=self.frames,
                      width=32, height=32, fps="4", count=4)
        values.update(changes)
        return verify(**values)

    def test_valid_video_with_intentional_hold(self):
        result = self.check_video()
        self.assertEqual(result["technical_status"], "PASS")
        self.assertEqual(result["source"]["unique_frames"], 3)
        self.assertEqual(result["motion_review_status"], "NOT_RUN")
        self.assertEqual(result["visual_comparison_status"], "NOT_RUN")

    def test_missing_png(self):
        (self.frames / "frame0001.png").unlink()
        with self.assertRaisesRegex(ValueError, "sequence mismatch"):
            self.check_video()

    def test_extra_png(self):
        png(self.frames / "frame0004.png", (0, 0, 0))
        with self.assertRaisesRegex(ValueError, "sequence mismatch"):
            self.check_video()

    def test_wrong_png_dimensions(self):
        png(self.frames / "frame0002.png", (0, 0, 0), width=16)
        with self.assertRaisesRegex(ValueError, "dimensions"):
            self.check_video()

    def test_corrupt_video(self):
        self.video.write_bytes(b"invalid mp4")
        with self.assertRaisesRegex(ValueError, "decode failed"):
            self.check_video()

    def test_wrong_video_timing(self):
        self.encode(fps="8")
        with self.assertRaisesRegex(ValueError, "timing"):
            self.check_video()

    def test_static_video_from_moving_source(self):
        still = self.root / "still"
        still.mkdir()
        for i in range(4):
            png(still / f"frame{i:04d}.png", (100, 100, 100))
        subprocess.run([self.ffmpeg, "-v", "error", "-y", "-framerate", "4", "-i",
                        str(still / "frame%04d.png"), "-c:v", "libx264", "-pix_fmt", "yuv420p",
                        str(self.video)], check=True, capture_output=True)
        with self.assertRaisesRegex(ValueError, "static video"):
            self.check_video()

    def test_rational_fps(self):
        self.encode(fps="30000/1001")
        result = self.check_video(fps="30000/1001")
        self.assertEqual(result["decoded_video"]["duration_seconds"], float(4 / Fraction(30000, 1001)))


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--ffmpeg", required=True)
    args, remaining = parser.parse_known_args()
    VideoChecks.ffmpeg = args.ffmpeg
    unittest.main(argv=[__file__] + remaining)
