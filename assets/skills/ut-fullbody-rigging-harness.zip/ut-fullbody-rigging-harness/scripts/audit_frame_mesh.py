"""Read a Unity SpriteSkin snapshot; report geometric candidates, never art approval."""
import argparse
import hashlib
import json
import math
from pathlib import Path


def number(value, label):
    if isinstance(value, bool) or not isinstance(value, (int, float)) or not math.isfinite(value):
        raise ValueError(label + ': expected a finite number')
    return value


def vector(value):
    if not isinstance(value, dict) or not all(k in value for k in ('x', 'y', 'z')):
        raise ValueError('vertices must be x/y/z objects')
    return tuple(number(value[k], 'vertex ' + k) for k in ('x', 'y', 'z'))


def area(a, b, c):
    return (b[0]-a[0])*(c[1]-a[1]) - (b[1]-a[1])*(c[0]-a[0])


def audit(snapshot, minimum=None, maximum=None):
    if not isinstance(snapshot, dict) or type(snapshot.get('schema')) is not int or snapshot['schema'] != 1:
        raise ValueError('unsupported snapshot schema')
    if minimum is not None and number(minimum, 'minimum') <= 0:
        raise ValueError('minimum area ratio must be positive')
    if maximum is not None and number(maximum, 'maximum') <= 0:
        raise ValueError('maximum area ratio must be positive')
    if minimum is not None and maximum is not None and minimum >= maximum:
        raise ValueError('minimum must be smaller than maximum')
    length = number(snapshot.get('clipLength'), 'clipLength')
    rate = number(snapshot.get('sampleRate'), 'sampleRate')
    times = snapshot.get('sampleTimes')
    if length <= 0 or rate <= 0 or length*rate > 10000 or not isinstance(times, list) or len(times) < 2:
        raise ValueError('positive clip length/rate and endpoint samples are required')
    times = [number(t, 'sample time') for t in times]
    expected = [min(i/rate, length) for i in range(math.ceil(length*rate)+1)]
    if len(times) != len(expected) or any(abs(a-b) > 1e-5 for a, b in zip(times, expected)):
        raise ValueError('sample times do not cover the declared cadence and endpoint')
    if not isinstance(snapshot.get('parts'), list) or not snapshot['parts']:
        raise ValueError('snapshot has no parts')
    repeat = number(snapshot.get('repeatSampleMaxError'), 'repeatSampleMaxError')
    if repeat < 0 or repeat > 1e-5:
        raise ValueError('repeated sampling is inconsistent; inspect preview updates')
    reference = number(snapshot.get('maxLbsReferenceError'), 'maxLbsReferenceError')
    if reference < 0 or reference > 1e-4:
        raise ValueError('native bake differs from renderer-local LBS; inspect transforms/data')
    paths, reports = set(), []
    for part in snapshot['parts']:
        if not isinstance(part, dict):
            raise ValueError('parts must be objects')
        path = part.get('path')
        if not isinstance(path, str) or not path or path in paths:
            raise ValueError('part paths must be nonempty and unique')
        paths.add(path)
        ppu = number(part.get('pixelsPerUnit'), 'pixelsPerUnit')
        if ppu <= 0:
            raise ValueError('pixelsPerUnit must be positive')
        pivot = (number(part.get('pivotX'), 'pivotX'), number(part.get('pivotY'), 'pivotY'))
        if not isinstance(part.get('restVertices'), list):
            raise ValueError(path + ': restVertices must be an array')
        rest = [vector(v) for v in part['restVertices']]
        indices, visible, frames = part.get('indices'), part.get('visibleTriangles'), part.get('frames')
        if len(rest) < 3 or not isinstance(indices, list) or not indices or len(indices) % 3:
            raise ValueError(path + ': invalid triangle topology')
        if max(v[2] for v in rest)-min(v[2] for v in rest) > 1e-5:
            raise ValueError(path + ': nonplanar rest mesh is outside this 2D audit')
        if any(isinstance(i, bool) or not isinstance(i, int) or not 0 <= i < len(rest) for i in indices):
            raise ValueError(path + ': triangle index out of range')
        if not isinstance(visible, list) or len(visible) != len(indices)//3 or any(type(v) is not bool for v in visible):
            raise ValueError(path + ': invalid triangle visibility mask')
        if not isinstance(frames, list) or len(frames) != len(times):
            raise ValueError(path + ': missing frame samples')
        triangles = [(n, indices[n*3:n*3+3]) for n, enabled in enumerate(visible) if enabled]
        if not triangles:
            raise ValueError(path + ': no alpha-selected triangles; cannot assess this part')
        base = {n: area(*(rest[i] for i in tri)) for n, tri in triangles}
        # Numerical tolerance only, not an artistic compression or stretch budget.
        if any(abs(a) <= 1e-12 for a in base.values()):
            raise ValueError(path + ': degenerate visible rest triangle')
        samples, worst, largest, displacement = [], None, None, 0.0
        for frame, (time, data) in enumerate(zip(times, frames)):
            if not isinstance(data, dict) or not isinstance(data.get('vertices'), list):
                raise ValueError(path + ': frames require vertex arrays')
            vertices = [vector(v) for v in data.get('vertices', [])]
            if len(vertices) != len(rest):
                raise ValueError(path + ': vertex count changed during sampling')
            if max(v[2] for v in vertices)-min(v[2] for v in vertices) > 1e-5:
                raise ValueError(path + ': nonplanar deformation is outside this 2D audit')
            displacement = max(displacement, max(math.dist(a, b)*ppu for a, b in zip(rest, vertices)))
            flags = {'flipped': [], 'collapsed': [], 'compressed': [], 'stretched': []}
            ratios = []
            for n, tri in triangles:
                ratio = area(*(vertices[i] for i in tri))/base[n]
                ratios.append(ratio)
                point = {'ratio': ratio, 'frame': frame, 'time': time, 'triangle': n,
                         'vertexIndices': tri,
                         'spriteLocalPixels': [sum(rest[i][axis] for i in tri)/3*ppu+pivot[axis] for axis in (0, 1)]}
                if worst is None or ratio < worst['ratio']:
                    worst = point
                if largest is None or ratio > largest['ratio']:
                    largest = point
                if ratio < -1e-10:
                    flags['flipped'].append(n)
                elif abs(ratio) <= 1e-10:
                    flags['collapsed'].append(n)
                elif minimum is not None and ratio < minimum:
                    flags['compressed'].append(n)
                if maximum is not None and ratio > maximum:
                    flags['stretched'].append(n)
            samples.append({'frame': frame, 'time': time, 'minAreaRatio': min(ratios),
                            'maxAreaRatio': max(ratios), **flags})
        flagged = [s for s in samples if any(s[k] for k in ('flipped', 'collapsed', 'compressed', 'stretched'))]
        reports.append({'part': path, 'vertices': len(rest), 'testedTriangles': len(triangles),
                        'excludedTriangles': len(visible)-len(triangles),
                        'boneCount': part.get('boneCount'), 'pixelsPerUnit': ppu,
                        'worstTriangle': worst, 'largestTriangle': largest,
                        'maxDisplacementSpritePx': displacement,
                        'flippedFrameCount': sum(bool(s['flipped']) for s in samples),
                        'collapsedFrameCount': sum(bool(s['collapsed']) for s in samples),
                        'candidateFrames': flagged})
    return {'schema': 1, 'status': 'CANDIDATES_FOUND' if any(p['candidateFrames'] for p in reports) else 'NO_CANDIDATES_IN_SAMPLES',
            'source': snapshot.get('source'), 'variant': snapshot.get('variant'),
            'geometryMethod': snapshot.get('geometryMethod', 'unspecified snapshot producer'),
            'sampleRate': rate, 'clipLength': length, 'sampleCount': len(times),
            'repeatSampleMaxError': repeat, 'maxLbsReferenceError': reference,
            'thresholds': {'minAreaRatio': minimum, 'maxAreaRatio': maximum}, 'parts': reports,
            'scope': '2D snapshot geometry at declared samples; alpha sampled at triangle centroids; inspect geometryMethod',
            'art': 'NOT_RUN', 'normalSpeedMotion': 'NOT_RUN', 'playMode': 'NOT_RUN',
            'limits': 'Not a visibility/rendering certificate. No candidates does not establish natural motion or exclude between-sample defects.'}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('snapshot', type=Path)
    parser.add_argument('--min-area-ratio', type=float)
    parser.add_argument('--max-area-ratio', type=float)
    args = parser.parse_args()
    try:
        raw = args.snapshot.read_bytes()
        result = audit(json.loads(raw), args.min_area_ratio, args.max_area_ratio)
        result['snapshotSha256'] = hashlib.sha256(raw).hexdigest()
        print(json.dumps(result, ensure_ascii=False, allow_nan=False))
        return 1 if result['status'] == 'CANDIDATES_FOUND' else 0
    except (OSError, ValueError, KeyError, TypeError) as error:
        print(json.dumps({'status': 'INVALID_INPUT', 'error': str(error)}, ensure_ascii=False))
        return 2


if __name__ == '__main__':
    raise SystemExit(main())
