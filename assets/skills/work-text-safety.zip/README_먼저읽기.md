공통 업무용 스킬 원본입니다. 전체 설치 절차·출처는 work-skills-portable-20261104.zip의 core 또는 support 안내를 확인하세요. 외부 도구는 별도이며 현재 사용자의 요청 범위를 우선합니다.
