---
name: codex-idle-cleanup
description: >-
  Use when the user says `cpu 정리` or when Codex should clean up, stop, close,
  or audit unused Codex-related running resources such as dev servers,
  background shell jobs, browser sessions, local preview helpers, or temporary
  tool sessions. Treat anything not used for the current task for 1 hour or more
  as an idle cleanup candidate.
---


# Codex Idle Cleanup

## Trigger
Use this skill when the user says `cpu 정리`, asks to close unused Codex features, clean up idle work, reduce CPU or memory usage, stop background helpers, end unused sessions, or before finishing long-running work where Codex may have started local servers, preview helpers, browser sessions, or shell processes.

## Purpose
The purpose is CPU and memory optimization. Prefer stopping idle Codex-started resources that keep Node, Python, browser, watcher, crawler, Playwright, dev-server, or preview processes resident in memory or consuming CPU.

## Idle Rule
A Codex-started resource is idle if it has not been used for the current task for 1 hour or more.

## Cleanup Scope
Candidate resources, prioritized by likely CPU/memory impact:
- Local dev servers started by Codex, especially Node/Vite/Next/React preview servers.
- Background shell jobs started by Codex.
- Browser preview/test sessions opened by Codex, especially Chromium/Playwright sessions.
- Temporary helper processes for screenshots, Playwright, local previews, crawlers, or build watchers.
- Stale temporary command sessions no longer needed for the active task.

Do not automatically stop:
- User-owned processes not clearly started by Codex.
- Production services.
- Scheduled automations or reminders unless the user explicitly asks.
- Active builds, tests, uploads, deployments, or crawlers that are still needed.
- Anything where stopping it could lose unsaved work.


## Lazy Tool Connection Rule
- Do not proactively keep optional tool connections open.
- Open Figma, GitHub, Google Drive, Unity MCP, browser automation, Playwright, local dev servers, or other connector/helper processes only when the current user request needs them.
- After the related task is complete, treat those connector/helper processes as cleanup candidates unless they are still needed for the active task.
- Unity MCP should be closed when Unity Editor is not running or when Unity work is not currently requested.
- Do not close Codex core processes required for the active chat unless the user explicitly approves.
## Required Workflow
1. Identify resources Codex started or is responsible for in the current thread/task.
2. Determine whether each resource has been unused for at least 1 hour in the current task.
3. Prioritize stopping safe idle resources with noticeable CPU or memory impact.
4. If ownership or safety is unclear, ask before stopping.
5. Report what was stopped, what was left running, and why.

## Safety Rules
- Prefer graceful termination over force kill.
- Never use destructive cleanup commands for files as part of this skill.
- Do not stop unrelated system processes.
- Do not claim cleanup succeeded unless verified.
- When possible, mention CPU/memory impact qualitatively, for example: dev server stopped, browser session left open, no heavy Codex-started process found.
- If no idle resources are found, say so briefly.

## Suggested Final Report
Use this concise format:

```markdown
## Codex Idle Cleanup
- Stopped:
- Left running:
- Needs user confirmation:
- CPU/memory impact:
- Notes:
```

## Limitations

This skill is procedural guidance. It does not run as a background daemon by itself. If fully automatic time-based cleanup is required, create a separate Codex automation or system-level scheduled task with explicit user approval.

## Shared Standard

- Keep cleanup scope narrow, preserve unrelated resources, and report what was inspected and what was not.

