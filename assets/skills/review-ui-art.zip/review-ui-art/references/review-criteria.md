# UI Art Review Criteria

## Visual dimensions

Assess each dimension against the asset's functional group and intended hierarchy.

| Dimension | Inspect | Typical mismatch |
|---|---|---|
| Palette | dominant hues, accent colors, saturation | one asset uses clean neon color inside an aged muted set |
| Value | light/dark range and focal contrast | support decoration attracts more attention than content |
| Materials | wood, metal, paper, glass, cloth, digital surfaces | glossy new gold beside matte aged brass |
| Rendering | painterly, vector, pixel, 3D, photoreal, cel-shaded | crisp flat icon mixed with textured rendering without role justification |
| Edge language | hard/soft edges, outlines, bevels, anti-aliasing | thick white stroke among fine engraved edges |
| Shape language | angular, rounded, gothic, industrial, organic | theatrical arches inside a strictly rectilinear utility system |
| Ornament | density, motif family, symmetry, repetition | secondary panel has a crest, scrolls, rails, and filigree competing at once |
| Motifs | celestial, floral, mechanical, religious, geometric | unrelated symbol family with no narrative or system purpose |
| Detail scale | frequency and size of texture/detail | micro-detail disappears or becomes noise at runtime scale |
| Lighting | direction, highlight width, roughness, shadow depth | one component appears newly polished under a different light source |
| Icons | stroke weight, enclosure, fill ratio, semantic clarity | mixed icon families within one control cluster |
| Typography | type family, weight, casing, baked text | modern baked labels on an otherwise diegetic antique screen |
| Composition | margins, framing, hierarchy, content occupancy | frame consumes more visual area than the four items it supports |
| Technical finish | alpha edges, halos, clipping, resolution | black fringe on transparent edges or inconsistent source density |

## Context checks before declaring a mismatch

1. Determine whether assets appear on the same screen at the same time.
2. Separate active assets from legacy, unused, alternate, and state variants.
3. Determine whether the asset is background, utility, content, focus, popup, or transition.
4. Confirm whether detail contrast is intentional. Narrative UI may be deliberately minimal while system UI is detailed.
5. Confirm whether color shifts encode scene, faction, rarity, time, lock state, or character identity.
6. Judge at expected display size. Source-resolution detail is not automatically visible detail.
7. For popups, inspect backdrop dimming and separation from the underlying screen before reducing ornament.

## Severity

- **Blocker:** broken transparency, unreadable content, severe clipping, or identity/style drift in a core repeated asset.
- **Major:** a clearly conflicting render style, material system, or focal hierarchy in active same-screen assets.
- **Minor:** highlight intensity, saturation, ornament density, stroke weight, or texture frequency needs tuning.
- **Observation:** unused/legacy inconsistency, integration status, or conditional concern requiring composition evidence.

## Verdict guidance

- **PASS:** differences are role-driven and shared anchors keep the experience coherent.
- **REVISE:** one or more active mismatches materially disturb hierarchy or visual identity, but localized changes can fix them.
- **FAIL:** the active set lacks a stable art direction or has multiple fundamental cross-screen conflicts.

Always state confidence. Reduce confidence when composed screens, runtime scale, intended role, or reference target is unknown.
