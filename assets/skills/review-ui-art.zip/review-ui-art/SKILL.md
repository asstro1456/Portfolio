---
name: review-ui-art
description: Review UI image assets for art-direction consistency, illustration style, rendering detail, materials, ornament, icon language, and contextual fit. Use when Codex is asked to inspect UI art tone, drawing style, visual cohesion, newly imported UI resources, game UI sprites, panels, icons, popups, galleries, or Unity UI asset sets and provide an evidence-backed PASS/REVISE verdict without changing the assets.
---

# Review UI Art

Assess visual consistency in the role and screen context where each asset is actually used. Do not treat every visual difference as a defect.

## Workflow

1. Read applicable `AGENTS.md` files and preserve unrelated or uncommitted work.
2. Locate the requested asset scope from the workspace before asking the user. If several projects are plausible, state the best-supported assumption and invite correction while continuing read-only inspection.
3. Inspect recent changes and asset directories. Group resources by screen or function, not only by file type:
   - narrative/dialogue
   - configuration and common controls
   - inventory/deck/editor
   - battle/HUD
   - gallery/collection
   - popup/modal
   - legacy, alternatives, and unused candidates
4. Record filenames, dimensions, aspect ratios, formats, alpha presence, and import status. Use `scripts/build_contact_sheets.py` when a group has more than about eight images.
5. Visually inspect the contact sheets and open original-resolution assets for suspected mismatches. Prefer composed screen captures when available because scale, layering, dimming, and neighboring elements can change the verdict.
6. Establish which resources are active:
   - For Unity, run `scripts/find_unity_image_refs.py` and inspect relevant prefab/scene references. Treat missing `.meta` files or zero references as integration context, not automatic art failure.
   - For web UI, search HTML/CSS/JS references and inspect a rendered page when composition matters.
   - Exclude explicitly legacy or unused alternatives from the active-set verdict, but mention risky candidates separately.
7. Ask only questions that can materially reverse the judgment. Useful questions include:
   - Is low detail intentional for narrative focus?
   - Is the asset a focal popup or a nested/repeated support panel?
   - Is the variation a state, faction, scene, rarity, or character identity?
   - Which screen is the visual reference target?
8. Evaluate using `references/review-criteria.md`. Compare new or changed assets primarily with their active functional group and secondarily with the global art direction.
9. Separate the result into:
   - art-tone/style verdict
   - contextual hierarchy verdict
   - technical/integration observations
10. Do not edit, regenerate, import, or reconfigure assets unless the user explicitly asks for changes.

## Judgment Rules

- Accept deliberate detail contrast between low-detail narrative UI and high-detail system UI when it supports attention and readability.
- Allow a popup or showcase to be more ornate than background panels when it does not visually nest or compete with another frame.
- Allow scene-specific sub-palettes when material, motif, edge treatment, or shape language provides a shared anchor.
- Do not penalize disabled, legacy, experimental, or unreferenced variants as if they appear together in production.
- Flag an asset when the mismatch remains after accounting for role, state, hierarchy, and composition.
- Prefer a conditional finding over a confident false positive when placement is unknown.

## Output

Lead with the outcome. Keep the report concise and include:

1. Scope inspected and important assumptions
2. Overall `PASS`, `REVISE`, or `FAIL` with confidence
3. Cohesive visual anchors
4. Specific mismatches, each tied to filenames or functional groups
5. Minimal, prioritized recommendations
6. Validation limits such as missing composed screens, missing references, or unimported assets

When a clarification changes the role or hierarchy, explicitly revise the earlier verdict rather than defending it.

## Bundled Resources

- `scripts/build_contact_sheets.py`: generate labeled, transparency-aware contact sheets from image directories.
- `scripts/find_unity_image_refs.py`: map Unity image `.meta` GUIDs to serialized prefab, scene, and asset references.
- `references/review-criteria.md`: detailed visual dimensions, contextual exceptions, and severity guidance.

## Shared QA Standard

- Keep the verdict evidence-based, state confidence or limits, and do not edit assets unless requested.
