#!/usr/bin/env python3
"""Build labeled contact sheets for visual UI asset review."""

from __future__ import annotations

import argparse
import math
import re
from pathlib import Path

try:
    from PIL import Image, ImageDraw, ImageFont
except ImportError as exc:  # pragma: no cover
    raise SystemExit("Pillow is required: install it or use the bundled Codex Python runtime.") from exc


DEFAULT_EXTS = {".png", ".jpg", ".jpeg", ".webp", ".tga", ".bmp"}
DEFAULT_EXCLUDES = {"library", "temp", "logs", "obj", "node_modules", ".git"}


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("root", type=Path, help="Root directory containing UI images")
    parser.add_argument("--output", type=Path, required=True, help="Output directory")
    parser.add_argument("--group-depth", type=int, default=1, help="Relative directory depth used for grouping")
    parser.add_argument("--columns", type=int, default=4)
    parser.add_argument("--rows", type=int, default=4)
    parser.add_argument("--cell-width", type=int, default=420)
    parser.add_argument("--cell-height", type=int, default=330)
    parser.add_argument("--extensions", default=",".join(sorted(DEFAULT_EXTS)))
    return parser.parse_args()


def font(size: int) -> ImageFont.ImageFont:
    candidates = [Path(r"C:\Windows\Fonts\malgun.ttf"), Path("/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf")]
    for candidate in candidates:
        if candidate.exists():
            return ImageFont.truetype(str(candidate), size)
    return ImageFont.load_default()


def checker(size: tuple[int, int], tile: int = 18) -> Image.Image:
    image = Image.new("RGB", size, (83, 87, 94))
    draw = ImageDraw.Draw(image)
    for y in range(0, size[1], tile):
        for x in range(0, size[0], tile):
            if (x // tile + y // tile) % 2:
                draw.rectangle((x, y, x + tile - 1, y + tile - 1), fill=(57, 61, 67))
    return image


def safe_group_name(parts: tuple[str, ...]) -> str:
    value = "__".join(parts) if parts else "root"
    return re.sub(r"[^A-Za-z0-9._-]+", "-", value).strip("-") or "root"


def collect(root: Path, output: Path, extensions: set[str], depth: int) -> dict[tuple[str, ...], list[Path]]:
    groups: dict[tuple[str, ...], list[Path]] = {}
    output_resolved = output.resolve()
    for path in root.rglob("*"):
        if not path.is_file() or path.suffix.lower() not in extensions:
            continue
        if any(part.lower() in DEFAULT_EXCLUDES for part in path.parts):
            continue
        try:
            path.resolve().relative_to(output_resolved)
            continue
        except ValueError:
            pass
        relative_parent = path.parent.relative_to(root).parts
        key = relative_parent[: max(depth, 0)]
        groups.setdefault(key, []).append(path)
    for files in groups.values():
        files.sort(key=lambda item: str(item).lower())
    return groups


def render_page(
    output_path: Path,
    title: str,
    files: list[Path],
    columns: int,
    rows: int,
    cell_width: int,
    cell_height: int,
) -> None:
    padding, label_height = 18, 58
    canvas = Image.new("RGB", (columns * cell_width, rows * cell_height), (31, 34, 39))
    draw = ImageDraw.Draw(canvas)
    label_font, title_font = font(14), font(18)
    for index, path in enumerate(files):
        column, row = index % columns, index // columns
        x0, y0 = column * cell_width, row * cell_height
        view_size = (cell_width - padding * 2, cell_height - padding * 2 - label_height)
        panel = checker(view_size)
        dimensions = "unreadable"
        try:
            with Image.open(path) as opened:
                dimensions = f"{opened.width}x{opened.height} · {opened.mode}"
                source = opened.convert("RGBA")
            source.thumbnail((view_size[0] - 16, view_size[1] - 16), Image.Resampling.LANCZOS)
            panel.paste(source, ((view_size[0] - source.width) // 2, (view_size[1] - source.height) // 2), source)
        except Exception as exc:  # keep the sheet usable when one file is malformed
            dimensions = f"ERROR: {exc}"
        canvas.paste(panel, (x0 + padding, y0 + padding))
        name = path.name if len(path.name) <= 48 else path.name[:45] + "..."
        draw.text((x0 + padding, y0 + cell_height - label_height + 4), name, font=label_font, fill=(244, 246, 248))
        draw.text((x0 + padding, y0 + cell_height - 25), dimensions, font=label_font, fill=(174, 181, 190))
        draw.rectangle((x0, y0, x0 + cell_width - 1, y0 + cell_height - 1), outline=(68, 73, 81))
    draw.rectangle((0, 0, min(canvas.width - 1, 430), 34), fill=(31, 34, 39))
    draw.text((12, 8), title, font=title_font, fill=(255, 206, 110))
    canvas.save(output_path, quality=90)


def main() -> int:
    args = parse_args()
    root, output = args.root.resolve(), args.output.resolve()
    if not root.is_dir():
        raise SystemExit(f"Root directory does not exist: {root}")
    if args.columns < 1 or args.rows < 1 or args.cell_width < 160 or args.cell_height < 140:
        raise SystemExit("Invalid grid or cell dimensions")
    extensions = {item.strip().lower() for item in args.extensions.split(",") if item.strip()}
    extensions = {item if item.startswith(".") else f".{item}" for item in extensions}
    output.mkdir(parents=True, exist_ok=True)
    groups = collect(root, output, extensions, args.group_depth)
    page_size = args.columns * args.rows
    total = 0
    for group, files in sorted(groups.items()):
        group_name = safe_group_name(group)
        page_count = math.ceil(len(files) / page_size)
        for page_index in range(page_count):
            page_files = files[page_index * page_size : (page_index + 1) * page_size]
            target = output / f"{group_name}-{page_index + 1:02}.jpg"
            render_page(target, f"{group_name} · {page_index + 1}/{page_count}", page_files, args.columns, args.rows, args.cell_width, args.cell_height)
        total += len(files)
        print(f"{group_name}: {len(files)} image(s), {page_count} page(s)")
    print(f"Total: {total} image(s) across {len(groups)} group(s)")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
