#!/usr/bin/env python3
"""Map Unity image GUIDs to serialized prefab, scene, and asset references."""

from __future__ import annotations

import argparse
import re
from pathlib import Path


IMAGE_EXTS = {".png", ".jpg", ".jpeg", ".webp", ".tga", ".psd", ".bmp"}
SERIALIZED_EXTS = {".prefab", ".unity", ".asset", ".controller", ".overridecontroller", ".mat"}
EXCLUDED_DIRS = {"library", "temp", "logs", "obj", ".git"}


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("project_root", type=Path, help="Unity project directory containing Assets")
    parser.add_argument("--asset-root", type=Path, help="Image subtree; defaults to <project>/Assets")
    parser.add_argument("--path-filter", help="Case-insensitive substring required in image paths, for example UI")
    parser.add_argument("--only-referenced", action="store_true", help="Hide zero-reference images")
    parser.add_argument("--output", type=Path, help="Optional TSV output file")
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    project = args.project_root.resolve()
    assets = project / "Assets"
    asset_root = args.asset_root.resolve() if args.asset_root else assets
    if not assets.is_dir():
        raise SystemExit(f"Unity Assets directory not found: {assets}")
    if not asset_root.is_dir():
        raise SystemExit(f"Asset root not found: {asset_root}")

    guid_to_image: dict[str, Path] = {}
    missing_meta: list[Path] = []
    path_filter = args.path_filter.lower() if args.path_filter else None
    for image in asset_root.rglob("*"):
        if not image.is_file() or image.suffix.lower() not in IMAGE_EXTS:
            continue
        if any(part.lower() in EXCLUDED_DIRS for part in image.parts):
            continue
        if path_filter and path_filter not in str(image).lower():
            continue
        meta = Path(str(image) + ".meta")
        if not meta.exists():
            missing_meta.append(image)
            continue
        match = re.search(r"^guid:\s*([0-9a-f]+)\s*$", meta.read_text(encoding="utf-8", errors="ignore"), re.MULTILINE)
        if match:
            guid_to_image[match.group(1)] = image

    counts = {guid: 0 for guid in guid_to_image}
    examples: dict[str, list[Path]] = {guid: [] for guid in guid_to_image}
    pattern = re.compile("|".join(re.escape(guid) for guid in guid_to_image)) if guid_to_image else None
    if pattern:
        for source in assets.rglob("*"):
            if not source.is_file() or source.suffix.lower() not in SERIALIZED_EXTS:
                continue
            if any(part.lower() in EXCLUDED_DIRS for part in source.parts):
                continue
            text = source.read_text(encoding="utf-8", errors="ignore")
            for guid in set(pattern.findall(text)):
                counts[guid] += text.count(guid)
                if len(examples[guid]) < 3:
                    examples[guid].append(source)

    lines = ["references\timage\texamples"]
    rows = sorted(guid_to_image.items(), key=lambda item: str(item[1]).lower())
    for guid, image in rows:
        count = counts[guid]
        if args.only_referenced and count == 0:
            continue
        example_text = " | ".join(str(path.relative_to(project)) for path in examples[guid])
        lines.append(f"{count}\t{image.relative_to(asset_root)}\t{example_text}")
    for image in sorted(missing_meta, key=lambda item: str(item).lower()):
        lines.append(f"NO_META\t{image.relative_to(asset_root)}\t")

    output = "\n".join(lines) + "\n"
    if args.output:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(output, encoding="utf-8")
        print(f"Wrote {args.output}")
    else:
        print(output, end="")
    print(f"Images with GUID: {len(guid_to_image)}; missing .meta: {len(missing_meta)}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
