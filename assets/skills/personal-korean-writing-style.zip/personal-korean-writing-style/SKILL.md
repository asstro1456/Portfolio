---
name: personal-korean-writing-style
description: Draft or revise Korean job materials, work messages, and game-planning prose in the user's natural, concrete style. Use when preserving the user's voice matters; do not use for code, formal policy, or source-only summaries.
---

# Personal Korean Writing Style

Write in a grounded, working style: explain what happened, why it matters, and what should change. Keep the user's claims intact; do not invent experience, outcomes, metrics, or emotions.

## Voice

- Begin with the concrete situation, action, or observed problem. Follow with the reason or expected player/work impact.
- Prefer a clear chain: observation → concern or constraint → suggested handling. State a confirmed fact directly; use `것 같습니다`, `좋겠습니다`, or `제안드립니다` only for a judgment or proposal.
- Name operational details when useful: the trigger, state, exception, owner, or result. This voice becomes persuasive through specificity, not through slogans.
- Use short paragraphs and bullets for notes, QA, and collaboration messages. For applications or longer prose, connect the same concrete details into a natural narrative instead of turning every point into a list.
- Keep an occasional plain spoken phrase when it fits the audience, but correct spacing and spelling in deliverables.

## Avoid

- Generic claims such as `성장`, `열정`, `시너지`, `고도화`, `역량을 발휘` without a concrete event or action.
- Overly polished parallel lists, ceremonial openings, and conclusion-first summaries that hide the actual observation.
- In Korean prose, avoid middle dots (`·`) and similar decorative separators for compressed word lists; the user finds this style AI-generated. Prefer natural particles, conjunctions, commas, or separate sentences, such as `전략과 턴제, 퍼즐` instead of `전략·턴제·퍼즐`. Preserve exact quotations, official names, and notation where the symbol is necessary; this is a prose preference, not a ban on useful Markdown lists.
- Invented certainty. If evidence is incomplete, say what is known, what is unclear, and the next check or decision needed.
- Turning raw notes into stiff report language unless the user asks for a formal document.

## Revision check

Before delivering, confirm that the text still answers: what was seen or done, why it mattered, and what changed or should happen next. Remove sentences that repeat a claim without adding a detail, condition, or consequence.
