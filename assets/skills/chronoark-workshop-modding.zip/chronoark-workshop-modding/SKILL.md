---
name: chronoark-workshop-modding
description: Diagnose, implement, validate, package, and upload Chrono Ark Workshop mods. Use for Chrono Ark Mod Editor source lists, gdata Add/Replace data, mod DLL builds and deployment, runtime-versus-editor mismatches, or Workshop release work.
---

# Chrono Ark Workshop Modding

Before editing, identify the consumer and report the target paths, verification plan, and risk.

## Decide where the behavior belongs

- **Game runtime:** C# DLL under `Assemblies/`; rebuild and deploy it.
- **Mod Editor `Mod` source:** persisted JSON under `gdata/Add/` only. Runtime `CustomGDE` registration does not populate this list.
- **Original data override:** persisted JSON under `gdata/Replace/`.
- **Editor project source:** use `ChronoArkModEditor.json` to find and synchronize the referenced project.

## Required checks

1. Read `ChronoArkModEditor.json`: `CSProjectPath`, `AssemblyName`, `KeyIDWithModID`.
2. Inspect `gdata/Add` and `gdata/Replace` separately.
3. Read recent `output_log.txt` for load, initialization errors, and reload cycles.
4. After deployment, compare SHA-256 hashes of workspace and live DLL.

## Source-list failure procedure

When a card is absent from the editor's `Mod` source:

1. Confirm a JSON file exists directly in `gdata/Add`.
2. Confirm each card has `_gdeSchema: "Skill"` and a unique non-game key.
3. Restart after a runtime extractor creates JSON; the editor caches `gdata/Add` on load.
4. Do not use `PlusSkillView` for editor grouping; it is an in-game related-skill link.
5. For mod-editable replacements, save mod-owned cards in `gdata/Add` and redirect the character's `FixedBasicSkill` / `Skills` through `gdata/Replace`.

## Build and release

1. Build the workspace DLL.
2. Build the referenced editor project when it was changed.
3. Deploy only after successful builds; verify hashes.
4. Fully restart the game before testing runtime changes.
5. For an approved Workshop release, increment the version, confirm source data and local loading, then upload.

## Report separately

- saved-data presence and schema;
- editor source visibility;
- runtime behavior;
- DLL hash and Workshop version/upload state.
