# 준비된 PNG를 PSD로 저장

`scripts/pack_psd.py`는 의미 분리·재도색 없이 입력 PNG를 PSD 레이어로 저장한다. Python 3.10+와 설치된 Pillow가 필요하다. 입력과 출력을 덮어쓰지 않는다. 출력 경로와 같은 줄기의 `.preview.png`가 하나라도 존재하면 중단한다.

manifest의 상대 경로는 manifest가 있는 폴더 기준이다. 예시는 아래와 같으며 실제 파일을 준비해야 한다. `layers`는 **아래에서 위로** 쌓는 순서다.

```json
{
  "canvas": [1024, 1024],
  "layers": [
    {"name": "SOURCE", "file": "source.png", "role": "REFERENCE", "origin": "existing", "visible": false},
    {"name": "hair/BASE_COLOR", "file": "hair_base.png", "role": "BASE_COLOR", "origin": "reconstructed"},
    {"name": "hair/SHADOW", "file": "hair_shadow.png", "role": "SHADOW", "origin": "reconstructed"},
    {"name": "hair/LINE", "file": "hair_line.png", "role": "LINE", "origin": "reconstructed"}
  ]
}
```

모든 PNG는 공통 캔버스 크기의 8비트 RGBA PNG여야 한다. 원점은 좌상단이며 크롭/리사이즈/재배치는 하지 않는다. 색은 입력 전에 합의한 sRGB로 정리한다. 내장 ICC 프로파일이 있는 PNG는 조용히 프로파일을 제거하지 않고 거절한다. 팔레트·16비트·RGB·회색조 입력은 자동 변환하지 않는다. 같은 명칭이나 입력 파일 중복, 비어 있는 층은 오류다. 하나의 완성본 복제를 여러 층으로 위장하는지까지 도구가 판단하지는 못하므로 사람이 확인한다.

APNG처럼 여러 프레임이 있는 파일도 거절한다. 첫 프레임만 조용히 고르는 대신 사용자가 원하는 정지 프레임을 별도로 준비해야 한다.

`name`, `file`, `role`, `origin`은 필수다. `visible`은 실제 JSON 불리언이고 생략 시 true다. origin은 `existing`, `extracted`, `reconstructed`, `new` 중 하나다. role은 실제 역할을 설명하는 이름이며 특별한 합성 기능을 부여하지 않는다. 빈 문자열·알 수 없는 키는 거절한다. 가령 `blend_mode`를 추가해도 지원되는 기능이 되지 않는다.

지원: RGB 8비트 PSD v1, 원본 RGBA 픽셀, Normal 혼합, 표시/숨김, 유니코드 이름, 투명 합성 미리보기. 모든 표시층은 개별 불투명도 100%이며 PNG 자체 알파는 보존한다. PSD 한계는 가로/세로 30,000 이하와 레이어 32,767 이하이며 무압축이므로 파일 크기와 메모리 사용이 클 수 있다. PSB·그룹·마스크·클리핑·혼합 모드·조정층·문자·프로파일 등 미지원 기능이 필요하면 편집 앱을 사용한다. `/`는 그룹 구조를 만들지 않는다.

```text
python scripts/pack_psd.py layers.json output.psd
python scripts/check_pack_psd.py
```

첫 명령은 PSD와 `output.preview.png`를 만든다. 두 번째는 임시 폴더의 합성용 작은 테스트 픽셀로 저장/재개방, 유니코드·숨김·순서·알파·국소 편집 및 입력 거절을 검사한다. 실제 그림을 분리하는 테스트가 아니다. 기본 self-check는 Pillow의 PSD 합성 읽기를 사용하며 네이티브 앱 검사를 대신하지 않는다. manifest는 PSD와 함께 전달한다. 경로가 개인 환경을 노출하지 않도록 공유 전 필요한 상대 경로와 실제 공개 가능한 파일만 포함한다.

파일 구조는 [Adobe 공식 PSD 명세](https://www.adobe.com/devnet-apps/photoshop/fileformatashtml/)의 RGB/레이어/채널/유니코드 이름 부분을 참고한다. 명세의 모든 기능을 구현한 도구는 아니다. 실제 수행한 검사와 복잡한 이미지 테스트의 한계는 [검증 범위](validation.md)를 읽는다.
