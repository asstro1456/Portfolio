"""Small offline regression check using synthetic pixels, not artwork."""
import json
from pathlib import Path
import struct
import tempfile

from PIL import Image

from pack_psd import composite_layers, load_layers, pack


def read_raw_layers(path):
    """Read this writer's raw PSD subset independently of its serialization."""
    data = path.read_bytes()
    position = 26

    def take(count):
        nonlocal position
        value = data[position:position + count]
        assert len(value) == count
        position += count
        return value

    def number(fmt):
        return struct.unpack(">" + fmt, take(struct.calcsize(">" + fmt)))[0]

    assert data[:6] == b"8BPS\0\1"
    take(number("I"))
    take(number("I"))
    block_length = number("I")
    block_end = position + block_length
    info_length = number("I")
    info_end = position + info_length
    count = number("h")
    assert count < 0
    layers = []
    for _ in range(-count):
        top, left, bottom, right = struct.unpack(">4i", take(16))
        channels = [(number("h"), number("I")) for _ in range(number("H"))]
        assert take(8) == b"8BIMnorm"
        opacity, clipping, flags, filler = take(4)
        assert (opacity, clipping, filler) == (255, 0, 0)
        extra_length = number("I")
        extra_end = position + extra_length
        take(number("I"))
        take(number("I"))
        legacy_length = number("B")
        take(legacy_length)
        take(-(legacy_length + 1) % 4)
        assert take(8) == b"8BIMluni"
        tag_length = number("I")
        units = number("I")
        name = take(units * 2).decode("utf-16-be")
        assert tag_length == units * 2 + 4
        take(tag_length % 2)
        assert position == extra_end
        layers.append({"name": name, "visible": not flags & 2,
                       "size": (right - left, bottom - top), "channels": channels})
        assert (top, left) == (0, 0)
    for layer in layers:
        planes = {}
        for channel_id, length in layer["channels"]:
            assert take(2) == b"\0\0"
            raw = take(length - 2)
            planes[channel_id] = Image.frombytes("L", layer["size"], raw)
        layer["image"] = Image.merge("RGBA", [planes[c] for c in (0, 1, 2, -1)])
    assert position <= info_end
    position = block_end
    assert take(2) == b"\0\0"
    width, height = layers[0]["size"]
    cache = Image.merge("RGBA", [Image.frombytes("L", (width, height), take(width * height))
                                  for _ in range(4)])
    assert position == len(data)
    return list(reversed(layers)), cache


def main():
    with tempfile.TemporaryDirectory(prefix="layered-psd-check-") as folder:
        root = Path(folder)
        base = Image.new("RGBA", (3, 2), (60, 90, 120, 255))
        shadow = Image.new("RGBA", (3, 2))
        shadow.putpixel((1, 0), (0, 0, 20, 100))
        line = Image.new("RGBA", (3, 2))
        line.putpixel((2, 1), (20, 10, 0, 200))
        reference = Image.new("RGBA", (3, 2), (255, 0, 0, 255))
        entries = []
        for name, image, visible in [("밑색", base, True), ("음영", shadow, True),
                                     ("선😀", line, True), ("원본", reference, False)]:
            filename = f"{len(entries)}.png"
            image.save(root / filename)
            entries.append({"name": name, "file": filename, "role": name,
                            "origin": "new", "visible": visible})
        spec = {"canvas": [3, 2], "layers": entries}
        manifest = root / "layers.json"

        def save_spec():
            manifest.write_text(json.dumps(spec, ensure_ascii=False), encoding="utf-8")

        save_spec()
        output = root / "result.psd"
        pack(manifest, output)
        canvas, originals = load_layers(manifest)
        parsed, cache = read_raw_layers(output)
        assert [l["name"] for l in parsed] == [l["name"] for l in originals]
        assert [l["visible"] for l in parsed] == [l["visible"] for l in originals]
        assert all(a["image"].tobytes() == b["image"].tobytes()
                   for a, b in zip(parsed, originals))
        expected = composite_layers(canvas, originals)
        assert cache.tobytes() == expected.tobytes()
        assert composite_layers(canvas, parsed).tobytes() == expected.tobytes()
        with Image.open(output) as reopened:
            assert reopened.size == canvas
            assert reopened.convert("RGB").tobytes() == expected.convert("RGB").tobytes()
        with Image.open(output.with_suffix(".preview.png")) as preview:
            assert preview.tobytes() == expected.tobytes()
        edited = [{**l, "image": l["image"].copy()} for l in parsed]
        edited[0]["image"].putpixel((0, 0), (200, 50, 50, 255))
        changed = composite_layers(canvas, edited)
        expected_pixels = list(zip(*[iter(expected.tobytes())] * 4))
        changed_pixels = list(zip(*[iter(changed.tobytes())] * 4))
        differences = [i for i, pair in enumerate(zip(expected_pixels, changed_pixels))
                       if pair[0] != pair[1]]
        assert differences == [0]
        assert all(a["image"].tobytes() == b["image"].tobytes()
                   for a, b in zip(parsed[1:], edited[1:]))
        for index, layer in enumerate(parsed):
            if not layer["visible"]:
                continue
            toggled = [dict(item) for item in parsed]
            toggled[index]["visible"] = False
            hidden_composite = composite_layers(canvas, toggled)
            assert hidden_composite.tobytes() != expected.tobytes()
            assert all(a["image"].tobytes() == b["image"].tobytes()
                       for a, b in zip(parsed, toggled))
        # The cached transparency channel must survive even with no opaque base.
        transparent_layers = originals[1:3]
        spec["layers"] = entries[1:3]
        save_spec()
        transparent_output = root / "transparent.psd"
        pack(manifest, transparent_output)
        transparent_parsed, transparent_cache = read_raw_layers(transparent_output)
        assert transparent_cache.tobytes() == composite_layers(canvas, transparent_layers).tobytes()
        assert any(a < 255 for a in transparent_cache.getchannel("A").tobytes())
        assert composite_layers(canvas, transparent_parsed).tobytes() == transparent_cache.tobytes()
        spec["layers"] = entries
        save_spec()
        original_bytes = output.read_bytes()
        try:
            pack(manifest, output)
            raise AssertionError("Overwrite was accepted")
        except FileExistsError:
            assert output.read_bytes() == original_bytes

        def rejects():
            save_spec()
            try:
                pack(manifest, root / "invalid.psd")
                raise AssertionError("Invalid manifest was accepted")
            except (ValueError, FileNotFoundError):
                assert not (root / "invalid.psd").exists()

        entries[0]["visible"] = "false"
        rejects()
        entries[0]["visible"] = True
        entries[0]["blend_mode"] = "multiply"
        rejects()
        del entries[0]["blend_mode"]
        entries[1]["file"] = entries[0]["file"]
        rejects()
        entries[1]["file"] = "1.png"
        spec["canvas"] = [4, 2]
        rejects()
        spec["canvas"] = [3, 2]
        Image.new("RGBA", (3, 2)).save(root / "0.png")
        rejects()
        base.save(root / "0.png", icc_profile=b"test-profile")
        rejects()
        base.convert("RGB").save(root / "0.png")
        rejects()
        base.save(root / "0.png", save_all=True, append_images=[shadow], duration=100, loop=0)
        rejects()
        base.save(root / "0.png")
        entries[0]["file"] = "missing.png"
        rejects()
    print("PASS: PSD raw layers/cache, Pillow reopen, Unicode, order, alpha, hidden reference, local edit, no-overwrite, input rejection")


if __name__ == "__main__":
    main()
