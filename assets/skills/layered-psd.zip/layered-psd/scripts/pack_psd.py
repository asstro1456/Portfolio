"""Package already separated full-canvas RGBA PNGs; no semantic separation."""
import argparse
import io
import json
from pathlib import Path
import struct
import sys

from PIL import Image


def u32(value):
    return struct.pack(">I", value)


def load_layers(manifest_path):
    manifest_path = Path(manifest_path)
    spec = json.loads(manifest_path.read_text(encoding="utf-8-sig"))
    if not isinstance(spec, dict) or set(spec) != {"canvas", "layers"}:
        raise ValueError("Manifest requires only canvas and layers")
    canvas = spec["canvas"]
    if (not isinstance(canvas, list) or len(canvas) != 2
            or any(type(n) is not int or not 1 <= n <= 30000 for n in canvas)):
        raise ValueError("canvas must be two integers in 1..30000")
    entries = spec["layers"]
    if not isinstance(entries, list) or not 1 <= len(entries) <= 32767:
        raise ValueError("layers must contain 1..32767 entries")
    layers, names, files = [], set(), set()
    for entry in entries:
        required = {"name", "file", "role", "origin"}
        if (not isinstance(entry, dict) or not required <= entry.keys()
                or entry.keys() - required - {"visible"}):
            raise ValueError("Layer requires name/file/role/origin and optional visible")
        if any(not isinstance(entry[k], str) or not entry[k].strip() for k in required):
            raise ValueError("Layer text fields must be nonempty strings")
        if "\x00" in entry["name"] or len(entry["name"].encode("utf-16-be")) > 510:
            raise ValueError("Layer name must be NUL-free and <=255 UTF-16 units")
        if entry["origin"] not in {"existing", "extracted", "reconstructed", "new"}:
            raise ValueError("Unsupported origin")
        visible = entry.get("visible", True)
        if type(visible) is not bool:
            raise ValueError("visible must be a JSON boolean")
        path = (manifest_path.parent / entry["file"]).resolve(strict=True)
        if entry["name"] in names or path in files:
            raise ValueError("Duplicate layer name or input file")
        with path.open("rb") as source:
            header = source.read(26)
        if header[:8] != b"\x89PNG\r\n\x1a\n" or header[24:26] != bytes([8, 6]):
            raise ValueError(f"Expected 8-bit RGBA PNG: {path.name}")
        with Image.open(path) as image:
            if image.size != tuple(canvas) or image.mode != "RGBA":
                raise ValueError(f"Canvas/mode mismatch: {path.name}")
            if getattr(image, "n_frames", 1) != 1:
                raise ValueError(f"Animated PNG requires explicit frame selection: {path.name}")
            if image.info.get("icc_profile"):
                raise ValueError(f"ICC profile requires a color-managed editor: {path.name}")
            image.load()
            image = image.copy()
        if image.getchannel("A").getbbox() is None:
            raise ValueError(f"Empty layer: {entry['name']}")
        layers.append({**entry, "visible": visible, "image": image, "path": path})
        names.add(entry["name"])
        files.add(path)
    return tuple(canvas), layers


def composite_layers(canvas, layers):
    composite = Image.new("RGBA", canvas)
    for layer in layers:
        if layer["visible"]:
            composite = Image.alpha_composite(composite, layer["image"])
    return composite


def psd_bytes(canvas, layers):
    width, height = canvas
    size = width * height
    records, streams = [], []
    # PSD layer records use top-to-bottom order; manifest is bottom-to-top.
    for layer in reversed(layers):
        name = layer["name"]
        legacy = name.encode("ascii", errors="replace")[:255]
        pascal = bytes([len(legacy)]) + legacy
        pascal += bytes(-len(pascal) % 4)
        unicode_name = name.encode("utf-16-be")
        luni = u32(len(unicode_name) // 2) + unicode_name
        tag = b"8BIMluni" + u32(len(luni)) + luni + bytes(len(luni) % 2)
        extra = u32(0) + u32(0) + pascal + tag
        record = struct.pack(">4iH", 0, 0, height, width, 4)
        record += b"".join(struct.pack(">hI", channel, size + 2) for channel in (0, 1, 2, -1))
        record += b"8BIMnorm" + bytes([255, 0, 0 if layer["visible"] else 2, 0])
        records.append(record + u32(len(extra)) + extra)
        streams.extend(b"\0\0" + channel.tobytes() for channel in layer["image"].split())
    # Negative count declares the fourth merged channel as transparency.
    info = struct.pack(">h", -len(layers)) + b"".join(records) + b"".join(streams)
    info += bytes(len(info) % 2)
    layer_mask = u32(len(info)) + info + u32(0)
    composite = composite_layers(canvas, layers)
    header = b"8BPS" + struct.pack(">H6sHIIHH", 1, bytes(6), 4, height, width, 8, 3)
    data = header + u32(0) + u32(0) + u32(len(layer_mask)) + layer_mask
    data += b"\0\0" + b"".join(channel.tobytes() for channel in composite.split())
    return data, composite


def pack(manifest, output):
    canvas, layers = load_layers(manifest)
    output = Path(output)
    if output.suffix.lower() != ".psd":
        raise ValueError("Output must use .psd")
    preview = output.with_suffix(".preview.png")
    # Exclusive creation also prevents overwriting inputs and racing another writer.
    if output.exists() or preview.exists():
        raise FileExistsError("PSD or preview already exists; choose a new output name")
    data, composite = psd_bytes(canvas, layers)
    buffer = io.BytesIO()
    composite.save(buffer, format="PNG")
    created = []
    try:
        for path, payload in ((output, data), (preview, buffer.getvalue())):
            with path.open("xb") as destination:
                created.append(path)
                destination.write(payload)
    except BaseException:
        for path in created:
            path.unlink(missing_ok=True)
        raise
    return {"psd": str(output), "preview": str(preview), "layers": len(layers),
            "validation": "packaged_only; art/native-app checks not performed"}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("manifest", type=Path)
    parser.add_argument("output", type=Path)
    args = parser.parse_args()
    try:
        print(json.dumps(pack(args.manifest, args.output), ensure_ascii=False))
    except (ValueError, OSError, struct.error) as error:
        print(f"ERROR: {error}", file=sys.stderr)
        return 1
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
