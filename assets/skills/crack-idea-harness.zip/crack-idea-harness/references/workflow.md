# 역할과 산출물 계약

## 입력 명세

아이디어 원문을 보존한다. 유형, 핵심 관계·장르·비틀기, 플레이어의 역할, 작품 등급, 참고 자료, 원하는 생성 범위를 필요한 만큼 정리한다. 사용자 확정·에이전트 제안·미정인 항목을 구분한다.

새 아이디어의 이름·세부 장면·관계의 작은 빈칸은 초안 제안으로 생성할 수 있다. 기존 작품의 미정인 신의 목적이나 결말처럼 의도적으로 비워 둔 항목은 새 사실로 메우지 않는다. 사용자 선택권과 민감한 과거를 고정하는 설정은 자동 추가하지 않는다. 결정이 실제 저장을 막을 때 질문 하나를 한다.

작업 폴더는 `work/runs/<slug>/`다. 최소 산출물은 아래 `run.json`과 필요한 이미지다. 실제 입력된 명세와 생성 프롬프트를 보존하며 대화 전문·일반 채팅 요약은 저장하지 않는다.

기존 설정은 `sources/<작품명>/설정.md`와 그 문서가 가리키는 원문 파일을 우선한다. 에이전트에는 설정 전문 대신 파일 경로와 해당 항목을 전달한다. 원문이 없거나 최신 변경 확인이 필요할 때만 설정을 브라우저에서 읽어 같은 폴더에 날짜·URL과 함께 저장한다. 새 캐릭터 제안은 확정 전까지 기존 작품 원문과 분리한다.

<a id="intent-and-learning"></a>
## 목표 확인·질문·판단 축적

핵심 역할·능력·경험을 설계하거나 바꿀 때 기존 `brief.design`에 **사용자 원문의 목표 → 막는 조건 → 제안하는 개입 → 새로 가능해지는 행동 → 남는 제약**을 짧게 연결한다. 별도 명세를 늘리지 않고 기존 필드 위치를 가리켜도 된다. 사용자가 인물·기능의 필요성을 요구했다면 그것을 빼도 같은 목적을 달성하는지 확인한다. 작은 기술 시연이나 눈에 보이는 변화만으로 원래 목표의 달성을 대신하지 않는다.

자료의 상태는 확정된 제약, 의도적 미정, 새 제안을 허용한 범위로 구분한다. 핵심 기능이 미정에 걸리면 무엇을 정해야 하며 각 답이 경험과 기존 규칙에 어떤 차이를 만드는지 설명하고 사용자에게 묻는다. 사용자가 답하기 전에는 해당 결정에 의존하는 원고·입력·저장을 진행하지 않으며 독립 작업은 계속할 수 있다. 일상 문구·사소한 연출처럼 목표와 규칙을 바꾸지 않는 선택은 위임 범위 안에서 판단한다. 미정을 일괄 금지로 해석하거나 쉬운 다른 기능으로 목표를 축소하지 않는다.

수정 검수는 제안한 해결책의 실행 여부와 함께 원래 결함이 해소됐는지를 다시 판정한다. 총괄은 핵심 목표와 직결된 부분까지 검수에서 제외하거나 이전 `pass`로 대체하지 않는다. 검수자가 제시한 예시 해법도 새 제안이며, 그 예시를 구현했다는 이유로 통과시키지 않는다. 사용자가 핵심 전제를 거부하면 현재 작업의 통과·입력 준비 상태를 무효화하고, 이전 검수·저장 기록은 역사적 근거로 보존한다.

사용자가 프로젝트의 창작 판단을 축적·재사용하도록 요청한 경우에는 `C:/Users/User/.codex/skills/judgment-harness/SKILL.md`의 공통 DB를 사용한다. Crack은 이미 승인된 연결 프로젝트다. 새 판단은 DB에 한 번만 기록하고 기존 `창작_판단기준.md`는 원문 근거로 보존한다. 이 문서가 변경되면 참고 색인을 갱신한다. 그 외 프로젝트는 이번 `brief`의 확정·제안·미정만 관리하며 무단 수집하지 않는다. 축적할 항목은 판단, 실제 사용자 발언·답변, 확인일, 사용자가 밝힌 이유, 적용 범위, 상태다. 이유를 말하지 않았으면 미확인으로 두고 에이전트의 해석은 가설로 표시한다. 한 작품의 결정을 다른 작품이나 사용자 전체 성격으로 일반화하지 않는다. 대화 전문·불필요한 사적 정보는 별도 요청 없이 저장하지 않는다.

다음 작업에서는 관련 기준을 불러와 제안의 근거로 사용하고, 충돌하거나 미정인 핵심 부분만 질문한다. 최신 명시 요청이 우선이며, 기준이 바뀌면 이전 판단과 바뀐 이유를 필요한 만큼 보존한다. 미응답·침묵·제안에 대한 단순 반응은 확정 근거가 아니다. 잘못 예측한 판단은 수정·폐기하고 그 원인을 기록한다. 이 과정은 문서에 축적한 판단을 다음 작업에 반영하는 방식이며 모델 자체의 재학습이나 사용자의 완전한 복제를 의미하지 않는다.

## 역할별 요청문

모델은 `agents/roles.json`을 읽어 선택한다. 작성·검수·브라우저 담당은 각각 별도 에이전트로 실행한다. 모델을 지정하는 호출은 `fork_turns="none"`을 사용한다. 총괄만 최종 `run.json`을 합친다. 각 에이전트에는 출력할 파일 경로 하나를 지정한다.

<a id="communication-language"></a>
### 공통 언어 지시문

아래 지시문을 최초 위임, 추가 작업, 에이전트 간 메시지에 항상 포함한다. 내부 요청·진행 보고·최종 반환·검수 JSON의 설명문은 영어로 작성한다. 사용자용 진행 안내와 최종 결과는 총괄이 한국어로 전달한다.

```text
Use concise English for all internal requests, progress reports, final returns, and explanatory text in review JSON. Preserve the original language of creative prose, dialogue, actual input field values, user quotations, UI labels, proper names, and paths. Do not translate these source materials merely to satisfy the internal communication language. Return your report to the coordinator in English; the coordinator will present the user-facing result in Korean.
```

아래 역할별 요청문에도 이 지시문을 붙인다. 한국어 내부 보고를 받으면 이 지시문과 함께 영어 재보고를 요청하며, 언어 수정 때문에 작품 원고나 실제 관찰값을 바꾸지 않는다.

### 작성 — Sol

전달: 아이디어 원문, 명세, 승인된 원본, 작품 유형, 화면에서 확인한 필드와 한도, 이번에 쓸 참고 자료만.

요청: "Create field-by-field Crack drafts and an image plan from this specification. Separate user-confirmed facts from proposals; respect knowledge boundaries and player agency. Include distinct practical, everyday, and boundary-case responses without repeating stock dialogue. Return fields, media plans, open questions, and proposals in the assigned output file. Do not operate the browser or generate images."

사용자 원문과 명세, 관련 창작 판단 기준을 함께 준다. 명세만 주면 총괄이 잘못 정리한 내용을 그대로 확대할 수 있다. 목표를 충족하는 핵심 개입과 아직 결정할 수 없는 규칙을 명시한다. 스토리 내부 비밀과 각 NPC가 아는 정보를 구분한다. 설정 설명만 길게 늘리지 말고 첫 장면에서 사용자가 바로 반응할 수 있게 한다.

설정·원고를 제작할 때는 [설정·세계관·캐릭터 검수](design-and-play-review.md)를 함께 전달한다. 경험·역할·반복 상호작용·핵심 한계는 필요한 경우 `brief.design`에서 기존 필드를 가리키게 한다. 항목을 채우려고 새 과거·로맨스·스탯·엔딩을 추가하지 않는다.

### 독립 검수 — Astra

전달: 원문, 명세, 관련 창작 판단 기준, 작성 결과, 실제 이미지 파일(이미지 생성 후)과 관련 원본. 작성 담당의 자기평가나 총괄이 바라는 결론을 미리 주지 않는다. 수정 검수에는 원래 결함도 전달하며, 권고한 수정 방법을 따랐는지만 확인하지 않는다.

요청: "Compare the actual draft with the original request and specification; return pass / revise / needs_user. For each issue, report the field, exact passage or image location, impact, and smallest correction. Check established-setting conflicts, knowledge overreach, secret disclosure, forced player emotions or actions, repeated dialogue, and unjustified relationship, choice, or ending decisions. Verify that care and risk responses lead to concrete follow-through rather than plausible dialogue alone. Do not invent unresolved core facts to conceal defects. Do not operate the browser or overwrite the draft."

스토리는 스탯·미디어·키워드북·단축어·엔딩의 필요성/미사용/보류 이유도 확인한다. 이미지가 아직 없으면 이미지 검수는 pending이다. 모델 간 역할극은 정적 리허설이며 실제 크랙 응답 검증으로 표시하지 않는다.

설정·원고 검수에는 위 계약의 일곱 항목과 여섯 상황의 근거를 `review.design` 또는 지정 검수 파일의 `design`에 남기도록 요청한다. 결함은 기존 `findings`를 사용한다. 정적인 성격이나 의도된 미정을 결함으로 만들지 않으며, 과거 통과 메타데이터로 현재 원고의 검수를 대신하지 않는다. 이미지 교체·오탈자만 바꾸는 작업은 관련 범위만 확인한다.

### 통과 기준별 근거 기록

새 실행을 `ready_to_enter`로 올릴 때는 `review.checks_version: 1`을 사용하고, 현재 작업의 적용 가능한 핵심 기준마다 `review.checks`에 다음을 남긴다.

- `criterion`: brief 또는 승인된 UI 조건에서 가져온 확인 기준
- `method`: `static`(원고·자료 확인), `simulation`(가상 응답·흐름 점검), `live`(실제 Crack 동작 관찰)
- `result`: `pass`; 실패·미결 기준은 통과 목록에 넣지 않고 기존 `findings`와 `review.verdict`로 처리한다.
- `evidence`: 실제 필드 키와 짧은 인용, 또는 작업 폴더 기준 자료 경로와 관찰 위치·내용

`review.reviewer_id`에는 독립 검수 담당의 실제 에이전트 ID를 기록한다. 검수 결과를 총괄이 옮길 때 문구를 요약해도 근거 위치와 확인 방식을 잃지 않는다. `simulation`은 실제 Crack 응답을 입증하지 않으며, `live`는 실제 화면·대화의 관찰 근거를 가리켜야 한다. 체크는 이번 brief의 목표와 실제 UI 조건에 적용되는 기준만 둔다. 설계 기준 일곱 항목과 여섯 상황을 전부 매번 기계적인 필수 체크로 복제하지 않는다.

독립 검수자가 실제 확인한 `work_type`, `target`, `brief`, `fields`를 `review.input_sha256`으로 연결한다. `python -B -X utf8 <스킬경로>/scripts/validate_run.py --review-hash <작업폴더>/run.json`은 이 네 필드의 정렬된 UTF-8 JSON 해시만 출력하며 검수나 합격을 수행하지 않는다. 검수자가 같은 입력을 확인한 뒤 반환한 해시를 기록한다. 최신 정정으로 명세·원고·대상이 바뀌면 이전 검토로 입력/저장 완료를 판정할 수 없다. 바뀐 조건의 검수를 다시 하고 체크와 입력 해시를 함께 갱신하며, 옛 pass를 유지한 채 해시만 바꾸지 않는다. 이미지 품질 검수는 기존 별도 이미지/브리프 해시 계약을 유지한다. 이 연결은 입력 버전을 검사하며 독립 검수의 의미·진위를 자동 증명하지 않는다.

기존 실행 파일은 레거시 자료로 보존하고 자동 수정하지 않는다. 현재 `ready_to_enter`/`saved` 검증은 v1 체크와 일치하는 입력 해시를 요구한다. 체크 버전 또는 해시가 없는 과거 파일은 현재 입력/저장 완료의 인증으로 재사용하지 않고, 재개할 때 실제 독립 검수와 해시를 보완한다. `draft`의 미완성 검토는 허용한다. 이전 통과를 새 내용의 근거로 재사용하지 않는다.

### 브라우저 — Luna

두 번에 나눠 맡긴다. 먼저 읽기 전용 정찰, 검수 통과 후 입력·임시저장이다. 동일 담당을 이어 쓸 수 있다. 브라우저 권한을 맡긴 동안 다른 에이전트와 총괄은 같은 탭을 조작하지 않는다.

정찰 요청: "Reuse one existing Crack tab. Verify the specified work type and target, then record actual required fields, individual and aggregate character limits, and image constraints in the assigned file. Do not enter values, upload, or save. If unrelated unsaved work is open, leave it untouched and report it."

입력 요청: "Enter the validated run.json values and image files exactly into the specified builder; stop at temporary save. Do not change the prose, art style, meaning, or work type. Return to the coordinator if additional fields, exceeded limits, conflicts, irreversible rating choices, paid features, or final registration/update appear necessary. Do not open new tabs. Return each section's save notice, exact draft URL/ID, reopened text/image comparison, and completion-screen evidence. Do not modify other works or publish."

브라우저 도구의 선택·업로드·화면 관찰 지침과 해당 빌더 스킬을 따른다. 반환 파일은 실제 관찰만 기록한다. 입력 실패 시 동일 동작을 맹목적으로 반복하지 않고 최신 화면부터 확인한다. 원고 수정은 총괄→작성→독립 검수로 돌린다.

## run.json

아래는 구조 예시이며 실제 작품 내용이 아니다. 필드 키는 실제 UI 항목을 구분할 수 있게 평평한 점 표기법으로 쓴다. 예: `profile.name`, `intro`, `examples.0.user`, `examples.0.assistant`.

```json
{
  "work_type": "character",
  "phase": "draft",
  "stop_at": "temporary_save",
  "target": {"mode": "new", "work_id": null},
  "brief": {
    "idea": "사용자의 아이디어 원문",
    "confirmed": [],
    "proposals": [],
    "open_questions": []
  },
  "agents": {
    "writer": {"id": null, "model": "gpt-6.1-sol"},
    "reviewer": {"id": null, "model": "gpt-6-astra"},
    "browser_operator": {"id": null, "model": "gpt-6-luna"}
  },
  "fields": {},
  "ui": {
    "checked": false,
    "limits": {},
    "aggregate_limits": {},
    "required": [],
    "required_media": [],
    "image_max_bytes": null,
    "image_formats": []
  },
  "media": [],
  "review": {"checks_version": 1, "reviewer_id": null, "input_sha256": null, "verdict": "pending", "checks": [], "findings": []},
  "attempts": {"text": 0, "images": {}},
  "save": {"url": null, "draft_id": null, "notice": null, "status_evidence": null, "reopened": false, "observed_fields": {}, "reopened_media": {}, "screenshot": null}
}
```

- phase는 `draft → ready_to_enter → saved`다. 준비되지 않은 단계에 맞춰 낮게 기록한다.
- ui는 Luna가 실제 화면에서 확인한 값이다. limits의 값은 숫자 또는 명시적으로 무제한인 null이며, 화면에서 한도를 확인하지 못한 항목은 준비 완료로 넘기지 않는다. aggregate_limits는 예시 대사처럼 접두사가 같은 필드들의 합산 한도다.
- required_media는 대표 이미지의 역할 이름(예: profile/cover)이다. ui.image_max_bytes와 image_formats는 화면에서 확인한 업로드 조건이며 형식은 png/jpeg/webp/gif로 정규화한다. 미확인 또는 지원하지 않는 형식만 허용되면 입력 준비를 멈춘다.
- media는 path, role, status(planned/ready), review_status(pending/pass/revise), prompt, appearance_ref, style_ref를 갖는다. 파일 경로는 run.json 폴더 기준 상대 경로이며 기존 참조는 원본 경로를 기록할 수 있다. 준비 완료 파일과 실제 생성 프롬프트가 없으면 ready로 쓰지 않고, 실제 이미지를 독립 검수한 경우에만 review_status=pass로 쓴다. 재사용 이미지는 출처와 재사용 이유를 prompt에 기록한다. 파일 헤더 확인은 전체 디코딩·시각 검수를 대신하지 않는다.
- finding은 severity(blocker/major/minor), field, reason, fix, resolved를 갖는다. pass 판정이어도 미해결 blocker/major가 있으면 입력하지 않는다.
- open_questions 중 blocks_entry=true가 있으면 입력을 멈춘다. 사용자 확인이 필요 없는 초안 제안까지 질문으로 바꾸지 않는다.
- saved는 초안 URL·실제 초안 ID·재열기 원고/이미지 확인·스크린샷과 실제 저장 알림 또는 관찰한 저장 상태 근거를 확보했을 때만 기록한다. 알림이 없으면 notice=null로 두고 status_evidence에 실제 버튼 변화·초안 ID 추가 등을 기록한다. 상태 변화만으로 성공을 확정하지 않고 재열기 비교를 반드시 통과해야 한다. 기존 공개 작품의 편집 URL을 초안 식별자로 대신하지 않는다. 스크립트 통과는 이 증거의 진실성을 증명하지 않는다.
- 재열기에서 누락·불일치가 있으면 해당 키를 pending_fields에 기록하고 saved로 올리지 않는다. 이미 저장된 핵심 필드와 미반영 필드를 나눠 보고하고, 재개는 미반영 항목만 대상으로 한다. UI 발화 분할 과정의 공백 정리는 원문과의 차이 및 의미 보존 비교를 기록한다. 반복 저장에도 같은 필드가 누락되면 맹목적으로 재시도하지 않는다.

## 중단과 재개

이미지의 `quality_review` 파일과 재열기 실측값의 형식은 [품질·피드백 계약](quality-and-feedback.md)을 따른다. 기존 review_status나 reopened=true만으로 새 검증을 대체하지 않는다. 이전 실행에 증거가 없으면 미확인으로 남기며 형식을 채우려고 관찰 결과를 발명하지 않는다.

대표 이미지(profile/cover)는 `media.art_brief`와 quality_review의 `appeal` 객체도 필요하다. [구매 매력 계약](buyer-appeal.md)의 첫인상·표시 조건·비교 근거와 실제 브리프/증거 해시를 기록한다. 기존 이미지가 이 기록 없이 통과한 경우 재사용 시 필요한 실제 검수를 보완하며 사후에 성공 증거를 발명하지 않는다.

같은 결함은 초안 포함 최대 3차까지 자동 수정한다. 이미지도 장면별 최대 3차다. 승인 없는 비용 증가·대량 생성·모델 변경·새 작품 유형·공개 작업으로 우회하지 않는다. 지정 모델이나 도구를 쓸 수 없으면 완료로 쓰지 않는다.

재개할 때 run.json의 작업 대상과 현재 사용자 요청이 같은지 확인하고 변경분만 처리한다. 미완료 단계부터 이어가며 검수된 원고·이미지를 이유 없이 다시 만들지 않는다. 실제 크랙 채팅 테스트는 요청과 비용 범위가 확보됐을 때만 별도로 수행한다. Luna에게 [설정·세계관·캐릭터 검수](design-and-play-review.md)의 실제 응답 시험 기준과 대상·종료점을 함께 전달한다. 플레이 조사는 메타 질문보다 장면 속 행동과 그 결과를 잇는 대화로 진행하며, 공개 소개와 실제 응답의 근거를 분리해 반환하도록 한다.
