"""Validate a local Crack run packet; this never operates the browser."""
import hashlib
import json
import sys
from pathlib import Path
from urllib.parse import parse_qs, urlparse


def review_input_sha256(run):
    reviewed = {key: run.get(key) for key in ('work_type', 'target', 'brief', 'fields')}
    return hashlib.sha256(json.dumps(reviewed, ensure_ascii=False, sort_keys=True,
                                    separators=(',', ':')).encode('utf-8')).hexdigest()


def image_kind(path):
    with path.open('rb') as stream:
        header = stream.read(12)
    return ('png' if header.startswith(b'\x89PNG\r\n\x1a\n') else
            'jpeg' if header.startswith(b'\xff\xd8\xff') else
            'gif' if header[:6] in (b'GIF87a', b'GIF89a') else
            'webp' if header[:4] == b'RIFF' and header[8:12] == b'WEBP' else None)


def validate(run, root):
    errors = []
    def need(condition, message):
        if not condition:
            errors.append(message)
    def local_file(value):
        if not isinstance(value, str) or not value:
            return None
        path = (root / value).resolve()
        if not path.is_relative_to(root.resolve()):
            return None
        return path if path.is_file() else None

    phase = run.get('phase')
    need(phase in ('draft', 'ready_to_enter', 'saved'), 'Unknown phase')
    need(run.get('work_type') in ('character', 'story'), 'Unknown work_type')
    need(run.get('stop_at') == 'temporary_save', 'This harness stops at temporary_save')
    brief = run.get('brief', {})
    need(bool(brief.get('idea', '').strip()), 'Missing original idea')
    target = run.get('target', {})
    need(target.get('mode') in ('new', 'existing'), 'Missing target mode')
    if target.get('mode') == 'existing':
        need(bool(target.get('work_id')), 'Existing target requires work_id')
    fields = run.get('fields', {})
    need(isinstance(fields, dict), 'fields must be an object')
    if not isinstance(fields, dict):
        return errors
    for key, value in fields.items():
        need(isinstance(value, str), f'{key}: value must be text')
    if phase == 'draft':
        return errors

    ui, review = run.get('ui', {}), run.get('review', {})
    need(bool(fields), 'No fields to enter')
    need(bool(ui.get('required')), 'Live required fields not recorded')
    need(ui.get('checked') is True, 'Live UI has not been checked')
    need(review.get('verdict') == 'pass', 'Independent review has not passed')
    for issue in review.get('findings', []):
        need(issue.get('resolved') is True or issue.get('severity') not in ('blocker', 'major'),
             f"Unresolved finding: {issue.get('field', '?')}")
    need(not any(q.get('blocks_entry') for q in brief.get('open_questions', [])),
         'Blocking user question remains')
    agents = run.get('agents', {})
    checks_version = review.get('checks_version')
    need(type(checks_version) is int and checks_version == 1,
         'Current entry/save requires review checks version 1; preserve legacy packets and re-review before reuse')
    if type(checks_version) is int and checks_version == 1:
        need(review.get('input_sha256') == review_input_sha256(run),
             'Review input changed since independent review')
        need(review.get('reviewer_id') == agents.get('reviewer', {}).get('id'),
             'Review checklist does not identify the independent reviewer')
        checks = review.get('checks')
        need(isinstance(checks, list) and bool(checks),
             'Versioned review checklist is missing checks')
        for index, check in enumerate(checks if isinstance(checks, list) else []):
            label = f'Review check {index + 1}'
            need(isinstance(check, dict), f'{label} must be an object')
            if not isinstance(check, dict):
                continue
            need(isinstance(check.get('criterion'), str) and bool(check['criterion'].strip()),
                 f'{label} is missing its criterion')
            need(check.get('method') in ('static', 'simulation', 'live'),
                 f'{label} has an invalid verification method')
            need(check.get('result') == 'pass',
                 f'{label} did not pass')
            need(isinstance(check.get('evidence'), str) and bool(check['evidence'].strip()),
                 f'{label} is missing evidence')
    ids = [agents.get(role, {}).get('id') for role in ('writer', 'reviewer', 'browser_operator')]
    need(all(isinstance(i, str) and i for i in ids), 'Missing actual agent IDs')
    need(all(isinstance(i, str) for i in ids) and len({i for i in ids if isinstance(i, str)}) == 3,
         'Writing, independent review and browser require separate agents')
    limits = ui.get('limits', {})
    for key, value in fields.items():
        need(key in limits, f'{key}: UI limit not recorded')
        cap = limits.get(key)
        valid_cap = cap is None or (type(cap) is int and cap > 0)
        need(valid_cap, f'{key}: invalid UI limit')
        if isinstance(value, str) and type(cap) is int and cap > 0:
            need(len(value.encode('utf-16-le')) // 2 <= cap, f'{key}: exceeds {cap}')
    for prefix, cap in ui.get('aggregate_limits', {}).items():
        valid = type(cap) is int and cap > 0
        need(valid, f'{prefix}: invalid aggregate limit')
        if valid:
            total = sum(len(v.encode('utf-16-le')) // 2 for k, v in fields.items()
                        if isinstance(v, str) and (k == prefix or k.startswith(prefix + '.')))
            need(total <= cap, f'{prefix}: aggregate exceeds {cap}')
    for key in ui.get('required', []):
        need(bool(fields.get(key, '').strip()), f'{key}: required field empty')
    media = run.get('media', [])
    image_cap, formats = ui.get('image_max_bytes'), ui.get('image_formats', [])
    valid_image_cap = type(image_cap) is int and image_cap > 0
    if media:
        need(valid_image_cap, 'Live image size limit not recorded')
        need(isinstance(formats, list) and bool(formats), 'Live image formats not recorded')
    for role in ui.get('required_media', []):
        need(any(m.get('role') == role and m.get('status') == 'ready' for m in media),
             f'{role}: required image missing')
    for item in media:
        path = local_file(item.get('path'))
        need(item.get('status') == 'ready' and path is not None, 'Image is not ready or local')
        need(item.get('review_status') == 'pass', 'Independent image review has not passed')
        need(bool(item.get('prompt', '').strip()), 'Missing actual image prompt or reuse record')
        proof_path = local_file(item.get('quality_review'))
        need(proof_path is not None, 'Missing local image quality review')
        if proof_path:
            try:
                proof = json.loads(proof_path.read_text(encoding='utf-8'))
                need(proof.get('reviewer_id') == agents.get('reviewer', {}).get('id'),
                     'Image quality reviewer does not match independent reviewer')
                need(proof.get('viewed_actual_image') is True, 'Actual image was not reviewed')
                need(proof.get('brief_verdict') == 'pass', 'Image brief review has not passed')
                need(proof.get('release_verdict') == 'pass', 'Image release review has not passed')
                if path:
                    need(proof.get('asset_sha256') == hashlib.sha256(path.read_bytes()).hexdigest(),
                         'Image changed since quality review')
                if item.get('role') in ('profile', 'cover'):
                    art_brief = local_file(item.get('art_brief'))
                    need(art_brief is not None and bool(art_brief.read_text(encoding='utf-8').strip()),
                         'Missing cover art-direction brief')
                    appeal = proof.get('appeal', {})
                    need(appeal.get('verdict') == 'pass', 'Cover appeal/display review has not passed')
                    if art_brief:
                        need(appeal.get('brief_sha256') == hashlib.sha256(art_brief.read_bytes()).hexdigest(),
                             'Art direction changed since cover review')
                    for key in ('first_impression', 'visible_promise', 'comparison', 'delivery_note'):
                        need(isinstance(appeal.get(key), str) and appeal[key].strip(),
                             f'Missing cover appeal evidence: {key}')
                    checks = appeal.get('display_checks')
                    need(isinstance(checks, list) and bool(checks), 'Missing cover use-size checks')
                    for check in checks if isinstance(checks, list) else []:
                        size = check.get('size')
                        need(check.get('basis') in ('live_ui', 'proxy') and
                             isinstance(size, list) and len(size) == 2 and
                             all(type(v) is int and v > 0 for v in size),
                             'Invalid cover display conditions')
                        need(all(isinstance(check.get(key), str) and check[key].strip()
                                 for key in ('crop', 'result')), 'Missing cover display observation')
                        evidence = local_file(check.get('evidence'))
                        need(evidence is not None and evidence.stat().st_size > 0,
                             'Missing local cover display evidence')
                        if evidence:
                            need(path is None or evidence.resolve() != path.resolve(),
                                 'Raw cover image is not use-size evidence')
                            need(check.get('evidence_sha256') == hashlib.sha256(evidence.read_bytes()).hexdigest(),
                                 'Cover display evidence changed since review')
                for issue in proof.get('findings', []):
                    need(issue.get('severity') in ('blocker', 'major', 'minor') and
                         type(issue.get('required')) is bool and type(issue.get('resolved')) is bool,
                         'Invalid image finding classification')
                    need(all(isinstance(issue.get(key), str) and issue[key].strip()
                             for key in ('location', 'evidence', 'impact', 'minimal_fix')),
                         'Missing image finding evidence')
                    need(issue.get('resolved') is True or
                         (issue.get('required') is False and issue.get('severity') == 'minor'),
                         'Unresolved required image correction')
            except (OSError, ValueError, TypeError, AttributeError):
                need(False, 'Invalid image quality review')
        if path:
            kind = image_kind(path)
            need(kind is not None, f'{path.name}: unsupported image signature')
            need(isinstance(formats, list) and kind in formats, f'{path.name}: format not allowed by UI')
            if valid_image_cap:
                need(0 < path.stat().st_size <= image_cap, f'{path.name}: exceeds live image size limit')
    if phase == 'saved':
        need(not run.get('pending_fields'), 'Pending fields remain; saved phase is not complete')
        save = run.get('save', {})
        url = urlparse(save.get('url') or '')
        need(url.scheme == 'https' and url.hostname == 'crack.wrtn.ai' and
             url.path.rstrip('/') == '/builder/' + run.get('work_type', ''),
             'Missing exact Crack builder draft URL')
        need(isinstance(save.get('draft_id'), str) and bool(save['draft_id'].strip()),
             'Missing observed draft ID')
        need(parse_qs(url.query).get('draftId') == [save.get('draft_id')],
             'Draft URL ID does not match observed draft ID')
        need(bool((save.get('notice') or '').strip() or (save.get('status_evidence') or '').strip()),
             'Missing observed save notice or status evidence')
        need(save.get('reopened') is True, 'Saved draft was not reopened and compared')
        need(save.get('observed_fields') == fields, 'Reopened field values do not match requested fields')
        for item in media:
            path = local_file(item.get('path'))
            if path:
                observed = save.get('reopened_media', {}).get(item.get('role'), {})
                need(observed.get('uploaded_sha256') == hashlib.sha256(path.read_bytes()).hexdigest()
                     and observed.get('thumbnail_matches') is True,
                     'Reopened image does not match reviewed image')
        screenshot = local_file(save.get('screenshot'))
        need(screenshot is not None, 'Missing local completion screenshot')
        if screenshot:
            need(image_kind(screenshot) is not None, 'Completion screenshot is not an image')
    return errors


def main():
    hash_only = len(sys.argv) == 3 and sys.argv[1] == '--review-hash'
    if len(sys.argv) != 2 and not hash_only:
        print('Usage: validate_run.py [--review-hash] path/to/run.json')
        return 2
    path = Path(sys.argv[-1]).resolve()
    try:
        run = json.loads(path.read_text(encoding='utf-8'))
        if hash_only:
            print(review_input_sha256(run))
            return 0
        errors = validate(run, path.parent)
    except (OSError, ValueError, TypeError, AttributeError) as exc:
        print(f'FAIL: {exc}')
        return 2
    for error in errors:
        print(f'FAIL: {error}')
    if not errors:
        print(f"PASS: {run['phase']} (structural checks only)")
    return 1 if errors else 0


if __name__ == '__main__':
    sys.exit(main())
