import base64
import copy
import hashlib
import json
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path
from validate_run import validate, review_input_sha256


class RunGateTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)
        (self.root / 'portrait.png').write_bytes(base64.b64decode(
            'iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAwMCAO+a3ioAAAAASUVORK5CYII='))
        (self.root / 'art-brief.json').write_text('{"intent":"friendly desk encounter"}', encoding='utf-8')
        (self.root / 'display.html').write_text('<img src="portrait.png" width="190" height="190">', encoding='utf-8')
        self.run = {
            'work_type': 'character', 'phase': 'ready_to_enter', 'stop_at': 'temporary_save',
            'target': {'mode': 'new'}, 'brief': {'idea': 'Test idea', 'open_questions': []},
            'fields': {'profile.name': '민서', 'examples.0.user': '안녕', 'examples.0.assistant': '안녕하세요'},
            'ui': {'checked': True, 'limits': {'profile.name': 30, 'examples.0.user': 500,
                  'examples.0.assistant': 500}, 'aggregate_limits': {'examples': 2000},
                  'required': ['profile.name'], 'required_media': ['profile'],
                  'image_max_bytes': 5 * 1024 * 1024, 'image_formats': ['png', 'jpeg', 'webp']},
            'agents': {k: {'id': k} for k in ('writer', 'reviewer', 'browser_operator')},
            'media': [{'path': 'portrait.png', 'role': 'profile', 'status': 'ready',
                       'review_status': 'pass', 'prompt': 'Fixture reuse',
                       'quality_review': 'quality.json', 'art_brief': 'art-brief.json'}],
            'review': {'checks_version': 1, 'reviewer_id': 'reviewer', 'verdict': 'pass',
                       'checks': [{'criterion': 'Name matches the brief', 'method': 'static',
                                   'result': 'pass', 'evidence': 'Synthetic profile.name check only'}],
                       'findings': []}, 'save': {}
        }
        self.run['review']['input_sha256'] = review_input_sha256(self.run)
        self.quality = {'reviewer_id': 'reviewer', 'viewed_actual_image': True,
                        'asset_sha256': hashlib.sha256((self.root / 'portrait.png').read_bytes()).hexdigest(),
                        'brief_verdict': 'pass', 'release_verdict': 'pass', 'findings': [],
                        'appeal': {'verdict': 'pass',
                                   'brief_sha256': hashlib.sha256((self.root / 'art-brief.json').read_bytes()).hexdigest(),
                                   'first_impression': 'Friendly colleague', 'visible_promise': 'Desk conversation',
                                   'comparison': 'Same identity retained', 'delivery_note': 'Synthetic test fixture only',
                                   'display_checks': [{'basis': 'proxy', 'size': [190, 190], 'crop': 'center cover',
                                                       'evidence': 'display.html',
                                                       'evidence_sha256': hashlib.sha256((self.root / 'display.html').read_bytes()).hexdigest(),
                                                       'result': 'Synthetic observation; no real art or buyer test'}]}}
        self.write_quality()

    def write_quality(self):
        (self.root / 'quality.json').write_text(json.dumps(self.quality), encoding='utf-8')

    def test_valid_entry(self):
        self.assertEqual(validate(self.run, self.root), [])

    def test_changed_prose_cannot_reuse_old_independent_review(self):
        self.run['review'].update({'checks_version': 1, 'reviewer_id': 'reviewer',
            'checks': [{'criterion': 'Name and opening match the brief', 'method': 'static',
                        'result': 'pass', 'evidence': 'profile.name and brief.idea inspected'}]})
        self.assertEqual(validate(self.run, self.root), [])
        self.run['fields']['profile.name'] = '정정된 이름'
        self.assertIn('Review input changed since independent review', validate(self.run, self.root))
        self.run['review']['checks'][0]['evidence'] = 'Fresh synthetic review: profile.name is 정정된 이름 and still matches brief.idea'
        self.run['review']['input_sha256'] = review_input_sha256(self.run)
        self.assertEqual(validate(self.run, self.root), [])

    def test_brief_and_target_changes_also_invalidate_review(self):
        for key, value in [('brief', {'idea': 'A different requested concept'}),
                           ('target', {'mode': 'existing', 'work_id': 'different-work'})]:
            changed = copy.deepcopy(self.run); changed[key] = value
            self.assertIn('Review input changed since independent review', validate(changed, self.root))

    def test_review_hash_cli_reports_current_input_without_claiming_review(self):
        packet = self.root / 'run.json'
        packet.write_text(json.dumps(self.run), encoding='utf-8')
        result = subprocess.run([sys.executable, '-B', '-X', 'utf8',
            str(Path(__file__).with_name('validate_run.py')), '--review-hash', str(packet)],
            capture_output=True, encoding='utf-8')
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertEqual(result.stdout.strip(), review_input_sha256(self.run))
        self.assertNotIn('PASS', result.stdout)

    def test_craft_pass_without_appeal_review_is_rejected(self):
        del self.quality['appeal']
        self.write_quality()
        self.assertIn('Cover appeal/display review has not passed', validate(self.run, self.root))

    def test_cover_brief_change_invalidates_approval(self):
        (self.root / 'art-brief.json').write_text('{"intent":"new encounter"}', encoding='utf-8')
        self.assertIn('Art direction changed since cover review', validate(self.run, self.root))
        self.run['media'][0].pop('art_brief')
        self.assertIn('Missing cover art-direction brief', validate(self.run, self.root))

    def test_cover_use_size_evidence_is_required_and_bound(self):
        self.quality['appeal']['display_checks'] = []
        self.write_quality()
        self.assertIn('Missing cover use-size checks', validate(self.run, self.root))
        self.quality['appeal']['display_checks'] = [{'basis': 'proxy', 'size': [190, 190],
            'crop': 'center cover', 'result': 'visible face', 'evidence': 'missing.html'}]
        self.write_quality()
        self.assertIn('Missing local cover display evidence', validate(self.run, self.root))
        self.quality['appeal']['display_checks'][0]['evidence'] = 'display.html'
        self.write_quality()
        self.assertIn('Cover display evidence changed since review', validate(self.run, self.root))

    def test_appeal_revise_or_empty_positive_evidence_blocks_cover(self):
        self.quality['appeal']['verdict'] = 'revise'
        self.quality['appeal']['visible_promise'] = ''
        self.write_quality()
        errors = validate(self.run, self.root)
        self.assertIn('Cover appeal/display review has not passed', errors)
        self.assertIn('Missing cover appeal evidence: visible_promise', errors)

    def test_blank_brief_and_empty_display_evidence_are_rejected(self):
        (self.root / 'art-brief.json').write_text(' \n\t', encoding='utf-8')
        self.quality['appeal']['brief_sha256'] = hashlib.sha256((self.root / 'art-brief.json').read_bytes()).hexdigest()
        (self.root / 'display.html').write_text('', encoding='utf-8')
        self.quality['appeal']['display_checks'][0]['evidence_sha256'] = hashlib.sha256(b'').hexdigest()
        self.write_quality()
        errors = validate(self.run, self.root)
        self.assertIn('Missing cover art-direction brief', errors)
        self.assertIn('Missing local cover display evidence', errors)

    def test_native_image_cannot_replace_use_size_evidence(self):
        check = self.quality['appeal']['display_checks'][0]
        check['evidence'] = 'portrait.png'
        check['evidence_sha256'] = self.quality['asset_sha256']
        self.write_quality()
        self.assertIn('Raw cover image is not use-size evidence', validate(self.run, self.root))

    def test_empty_ready_packet_is_rejected(self):
        self.run['fields'] = {}
        self.run['ui']['required'] = []
        self.assertGreaterEqual(len(validate(self.run, self.root)), 2)

    def test_no_entry_before_live_ui_and_independent_review(self):
        self.run['ui']['checked'] = False
        self.run['agents']['reviewer']['id'] = 'writer'
        self.run['review']['findings'] = [{'severity': 'major', 'field': 'intro', 'resolved': False}]
        self.assertGreaterEqual(len(validate(self.run, self.root)), 3)

    def test_versioned_review_requires_criterion_evidence_and_reviewer_identity(self):
        self.run['review'].update({'checks_version': 1, 'reviewer_id': 'reviewer', 'checks': []})
        self.assertIn('Versioned review checklist is missing checks', validate(self.run, self.root))
        self.run['review']['checks'] = [{'criterion': 'Name fits requested concept', 'method': 'static',
                                         'result': 'pass', 'evidence': 'fields.profile.name: 민서'}]
        self.assertEqual(validate(self.run, self.root), [])
        self.run['review']['checks'][0]['evidence'] = ''
        self.assertIn('Review check 1 is missing evidence', validate(self.run, self.root))
        self.run['review']['checks'][0]['evidence'] = 'fields.profile.name: 민서'
        self.run['review']['reviewer_id'] = 'writer'
        self.assertIn('Review checklist does not identify the independent reviewer',
                      validate(self.run, self.root))

    def test_legacy_review_is_preserved_but_does_not_certify_current_entry(self):
        self.run['review'].pop('checks_version')
        original = copy.deepcopy(self.run)
        self.assertTrue(any('preserve legacy packets' in error for error in validate(self.run, self.root)))
        self.assertEqual(self.run, original)

    def test_aggregate_and_utf16_limits(self):
        self.run['fields']['profile.name'] = '😀' * 16
        self.run['ui']['aggregate_limits']['examples'] = 3
        errors = validate(self.run, self.root)
        self.assertTrue(any('profile.name: exceeds' in e for e in errors))
        self.assertTrue(any('aggregate exceeds' in e for e in errors))

    def test_missing_image_and_blocking_decision(self):
        self.run['media'][0]['path'] = '../outside.png'
        self.run['brief']['open_questions'] = [{'blocks_entry': True}]
        self.assertGreaterEqual(len(validate(self.run, self.root)), 2)

    def test_non_image_and_pending_image_review_are_rejected(self):
        (self.root / 'portrait.png').write_text('{}', encoding='utf-8')
        self.run['media'][0]['review_status'] = 'pending'
        errors = validate(self.run, self.root)
        self.assertTrue(any('image signature' in e for e in errors))
        self.assertTrue(any('image review' in e for e in errors))

    def test_live_image_constraints_are_required_and_enforced(self):
        self.run['ui']['image_max_bytes'] = 1
        self.run['ui']['image_formats'] = ['jpeg']
        errors = validate(self.run, self.root)
        self.assertTrue(any('live image size limit' in e for e in errors))
        self.assertTrue(any('format not allowed' in e for e in errors))
        del self.run['ui']['image_max_bytes']
        del self.run['ui']['image_formats']
        self.assertGreaterEqual(len(validate(self.run, self.root)), 2)

    def test_save_requires_observed_evidence(self):
        self.run['phase'] = 'saved'
        self.assertGreaterEqual(len(validate(self.run, self.root)), 4)
        (self.root / 'proof.png').write_bytes((self.root / 'portrait.png').read_bytes())
        self.run['save'] = {'url': 'https://crack.wrtn.ai/builder/character?draftId=fixture',
                            'draft_id': 'fixture', 'notice': '임시저장이 완료되었어요',
                            'reopened': True, 'screenshot': 'proof.png',
                            'observed_fields': copy.deepcopy(self.run['fields']),
                            'reopened_media': {'profile': {'uploaded_sha256': self.quality['asset_sha256'],
                                                          'thumbnail_matches': True}}}
        self.assertEqual(validate(self.run, self.root), [])
        self.run['save']['notice'] = None
        self.assertTrue(validate(self.run, self.root))
        self.run['save']['status_evidence'] = 'Save button disabled then enabled; draftId appeared in URL'
        self.assertEqual(validate(self.run, self.root), [])
        self.run['pending_fields'] = {'player_guide': 'Reopened empty'}
        self.assertTrue(validate(self.run, self.root))

    def test_changed_asset_invalidates_old_approval(self):
        with (self.root / 'portrait.png').open('ab') as stream:
            stream.write(b'new revision')
        self.assertIn('Image changed since quality review', validate(self.run, self.root))

    def test_brief_pass_cannot_override_release_revise(self):
        self.quality['release_verdict'] = 'revise'
        self.write_quality()
        self.assertIn('Image release review has not passed', validate(self.run, self.root))

    def test_required_minor_correction_blocks_release(self):
        self.quality['findings'] = [{'severity': 'minor', 'required': True, 'resolved': False,
                                    'location': 'mouth', 'evidence': 'irregular boundary',
                                    'impact': 'focal expression', 'minimal_fix': 'clean boundary'}]
        self.write_quality()
        self.assertIn('Unresolved required image correction', validate(self.run, self.root))
        self.quality['findings'][0]['required'] = False
        self.write_quality()
        self.assertEqual(validate(self.run, self.root), [])

    def test_unclassified_or_unsupported_findings_are_rejected(self):
        self.quality['findings'] = [{'required': False, 'resolved': False}]
        self.write_quality()
        errors = validate(self.run, self.root)
        self.assertIn('Invalid image finding classification', errors)
        self.assertIn('Missing image finding evidence', errors)

    def test_actual_independent_review_is_required(self):
        self.quality['viewed_actual_image'] = False
        self.quality['reviewer_id'] = 'writer'
        self.write_quality()
        self.assertGreaterEqual(len(validate(self.run, self.root)), 2)
        (self.root / 'quality.json').unlink()
        self.assertIn('Missing local image quality review', validate(self.run, self.root))

    def test_reopened_flag_does_not_prove_fields_or_image(self):
        self.run['phase'] = 'saved'
        (self.root / 'proof.png').write_bytes(b'fixture')
        self.run['save'] = {'url': 'https://crack.wrtn.ai/builder/character?draftId=fixture',
                            'draft_id': 'fixture', 'notice': 'saved', 'reopened': True,
                            'screenshot': 'proof.png', 'observed_fields': {}, 'reopened_media': {}}
        errors = validate(self.run, self.root)
        self.assertIn('Reopened field values do not match requested fields', errors)
        self.assertIn('Reopened image does not match reviewed image', errors)

    def test_wrong_draft_id_or_text_screenshot_is_rejected(self):
        self.run['phase'] = 'saved'
        (self.root / 'proof.png').write_text('not an image', encoding='utf-8')
        self.run['save'] = {'url': 'https://crack.wrtn.ai/builder/character?draftId=other',
                            'draft_id': 'fixture', 'notice': 'saved', 'reopened': True,
                            'screenshot': 'proof.png'}
        errors = validate(self.run, self.root)
        self.assertIn('Draft URL ID does not match observed draft ID', errors)
        self.assertIn('Completion screenshot is not an image', errors)

    def test_draft_may_keep_planned_assets_but_never_publish(self):
        self.run['phase'] = 'draft'
        self.run['media'][0]['status'] = 'planned'
        self.assertEqual(validate(self.run, self.root), [])
        self.run['stop_at'] = 'publish'
        self.assertTrue(validate(self.run, self.root))


if __name__ == '__main__':
    unittest.main()
