# Existing VFX: material and flow diagnostics

Use the relevant section for Unity wind/rain material diagnostics or deformation of readable features such as faces and symbols. These are conditional comparison questions drawn from production references, not universal style preferences or a request to add effects. Keep project-specific decisions in their project guide; this reference does not prescribe ultimate sequences, cameras, narrative, ground splashes, fog, or ripples. Feature-deformation checks also apply while reviewing a new candidate; they do not authorize its creation.

## Establish the current state

- Inspect the actual prefab, material, texture channels, shader branch/final output, clip/particle controls, and their consumers. Reuse current source-matched evidence. A control's existence does not prove that it affects the active pass or final alpha.
- Confirm the original purpose of authored shapes and motion before replacing them. Distinguish the user's intent, an implementation choice, an observed defect, and a hypothesis. Existing easing, masks, distortion, or density controls must not be reported as missing without checking them.
- Diagnose from the current result first. If project docs, installed skills, and existing references do not explain an important decision, request narrowly scoped primary production references or relevant GitHub skill examples. Read their contents; tool-operation instructions or feature lists alone may not supply visual criteria. Do not install or execute external skills as part of research.

## 1. Wind shape: brightness versus connected alpha

Question: does an uninterrupted bright contour dominate as a cord/tube, or do openings and density variation help the intended airflow read? A spiral can have an intentional role; neither keeping nor removing it is the default answer.

Hold mesh, motion, color/emission, and UV speed fixed. Compare one active erosion threshold or coverage control, then edge falloff separately if needed. If a fixed center highlight dominates, isolate its strength in a separate comparison rather than fading the entire effect.

Failure signs: the same tube merely becomes darker; erosion leaves dots/flicker and loses direction; a flat end cut appears; gaps remain stationary while the supposed flow moves. Verify whether grayscale RGB or texture alpha actually supplies the final density, including textures with opaque/missing alpha. Do not assume RGB must always replace alpha.

Try existing density/erosion/mask controls first. Consider another existing texture or new mask art only if its value distribution cannot express the intended openings; consider a shader connection change only if the needed control path is absent or ineffective. A reference's Power node is an example, not a required implementation.

## 2. Wind flow: shared direction versus individual phase

Question: do bright regions and gaps on multiple ribbons/particles pass together so the layers read as one rigid mass? Can the common direction remain readable while secondary density patterns differ? Shared translation curves are not inherently defective, and moving UVs on a fixed mesh do not by themselves establish convincing wind.

Hold translation, count, color, and strength fixed; compare only existing per-instance UV/flow offset phase. Compare speed differences later, separately. Inspect deceleration, loop seams, residual motion, and disappearance for pattern jumps or synchronized closure.

Failure signs: settings differ but rendered output does not; directions diverge enough to lose the common flow; pattern continuity breaks. Changing one shared material so every instance changes together is not an instance-phase experiment. Prefer existing instance data/offset paths; identify missing data plumbing separately before proposing new code, shaders, or flow-map art.

## 3. Rain readability: thickness versus brightness

At actual display size, compare bright/dark backgrounds and complex contours with the real UI and targets. Check whether rain direction/intensity remains readable while card text, health, silhouettes, and contact points remain legible.

Hold count, speed, and color fixed; vary one thickness/size/stretch axis first. Hold that result fixed before separately comparing alpha or brightness. Existing near/far layers may be tuned independently, but adding layers is not a prerequisite. Larger drops need not also be brighter.

Failure signs: a white curtain, thick streaks hiding information, increased count concealing weak shape, or pixel noise/flicker at small display size. Try existing particle settings and material controls, then suitable existing streak textures for exposed quad borders or blunt tips. Readability trouble alone is not evidence that a new shader or new art is necessary.

## 4. Readable features within a deforming effect

Use when a face, symbol, or other recognizable feature must remain readable while its surrounding material moves. Check whether the feature is painted color, an alpha hole, or a separate layer before selecting controls. Do not treat every low-alpha boundary as the outer silhouette: erosion can also remove eyes or other internal holes.

For a single-texture candidate, first consider shared motion with smoothly varying deformation strength across the feature and surrounding body. A feature mask evaluated in undeformed sprite-local coordinates can follow the body through rotation and flipping; world-aligned coordinates may not. Keep color and alpha sampling aligned unless their separation has an intentional, verified purpose. This is a candidate method, not a requirement for a mask, shader rewrite, or fixed strength ratio.

Consider a separate feature layer when independent expressions are needed or the combined texture cannot preserve readability. Check shared placement, lifetime, and common movement so the feature does not appear pasted on. If the original body retains eyes or mouth as painted marks or alpha holes, moving an added face alone can leave a second face behind.

Clamp extends border pixels outside the texture range; it does not clear them. Check transparent padding against actual displacement and filtering, border alpha, streaks, cuts, and halos. For an atlas, distinguish the full texture UV range from the individual sprite region. Keep reusable identity and silhouette in the base texture where practical, and compare assigning travel, rotation, or convergence paths to motion controls instead of baking one path into the art.

At the actual smallest display size, hold the outer flow fixed and compare no feature deformation with a small feature deformation. Check feature separation, a frozen-sticker appearance, creases at mask transitions, and loop jumps or duplicate features. Blending two differently displaced texture phases can double recognizable marks; compare bounded single-feature deformation before applying such blending to the entire face. Static extremes help diagnose causes but do not establish motion quality. These feature-specific proposals are adaptations of the source principles below, not demonstrations that the current asset passes.

## Evidence and acceptance

- Record the changed axis and match time, seed, background, placement, UI, and resolution. Control shader time as well as particle time; compare unchanged A/A samples before trusting A/B if reproducibility is uncertain. Verify shared-material consumers and default-off compatibility when adding an opt-in control.
- Static frames can support shape/mask observations. Flow, loop boundaries, residual motion, and disappearance require actual normal-speed motion observation. A player set to rate=1, playback completion, or dense screenshot sampling is not direct continuous observation. If unavailable, preserve that limitation; functional tests and video export do not certify the motion's visual quality.
- Review at real overlap/instance counts. Compare overdraw hotspots with visible benefit and measure performance separately; reduced alpha/brightness does not establish reduced GPU cost.
- Treat an A/B as improved only when the intended cue improves without merely hiding the effect or losing information. Separate functional correctness, observed visual change, user acceptance, and unverified quality. Do not import universal numeric budgets, speed ratios, particle counts, linear-curve bans, or mandatory start bursts from a reference.

## 5. Quality-preserving performance changes

When performance work is authorized, preserve the accepted presentation before reducing work. Match the saved source, warmup, resolution, phase, fixture and input sequence for before/after measurement; report selected routine timings, whole-frame cost, Editor/build environment, draw calls, managed allocations and reported texture memory as distinct metrics. A selected CPU increase is not a measured FPS loss; texture memory is not automatically dedicated VRAM, and a noisy GPU counter does not establish a GPU regression.

For geometry-result reuse, compare against the uncached result and exercise both producer-first and consumer-first rebuilds, invalidation after state/relative-transform changes, same-frame updates, reset, disable/re-enable and backward seeking. Preserve the existing consumer's geometry/bounds semantics, including hidden inputs it uses, rather than silently tightening them to rendered triangles. This is a cache-specific check, not a requirement to introduce caches.

Re-run affected checks on the final saved code before remeasuring performance. If regression checks fail or execution stops, retain the failed result and unverified edits; do not use an earlier pass, sampled image similarity or reduced call count to declare successful optimization. Static equality supports only sampled appearance; motion quality still follows the normal-speed evidence contract above. Protect originals and isolate temporary measurement copies; identify later independent source changes separately from the measured version.

## Sources and limits

- [Thanh Hon, Wind/Gust breakdown](https://thanh-hon.com/2021/05/14/visual-effect-breakdown-part-1/): combined noise shaping and wind texture example; older engine-feature statements are not current Unity requirements.
- [Torchinsky, Step/Smoothstep/Dissolve](https://torchinsky.me/stylized-vfx-unity-01/): fade versus erosion, source alpha, threshold/falloff and endpoint behavior; a cloud example, not a wind aesthetic rule.
- [NovaShader author documentation](https://github.com/CyberAgentGameEntertainment/NovaShader): separated flow targets and alpha transition controls; architectural reference only, not an installation or replacement recommendation.
- [2.5D rain author's explanation](https://www.reddit.com/r/Unity3D/comments/r4f7d6/complete_topdown_rain_effect_for_my_game/): small bright and larger darker drops; not proof of card-UI readability or an ideal contrast ratio.
- [scenario-unity-vfx critique](https://github.com/scenario-labs/skills/blob/main/skills/game-engines/unity/scenario-unity-vfx/references/critique.md): context, layer purpose, instance variation/reproducibility, and visible benefit versus overdraw. Its tools, environment, measured claims, numeric thresholds, and categorical prescriptions are not adopted.
- [Unity 6000.3 TextureWrapMode.Clamp](https://docs.unity3d.com/6000.3/Documentation/ScriptReference/TextureWrapMode.Clamp.html): out-of-range UVs extend the last border pixel; transparent padding still needs verification.
- [Cyanilux, Sprite Local UVs](https://www.cyanilux.com/tutorials/sprite-local-uv/): sprite/atlas coordinate distinctions and world-aligned bounds that do not follow rotation or flipping. Its 2024 batching/API choices are not automatic requirements for a newer Unity project.
- [Catlike Coding, Texture Distortion](https://catlikecoding.com/unity/tutorials/flow/texture-distortion/): spatial flow and two-phase blending principles. The example uses Unity 2017.4 Built-in opaque water, not a verified URP transparent character effect. Feature protection, layer selection, and duplicate-face risks above are application inferences.

These sources support diagnostic hypotheses and comparisons. They do not establish the current project's motion quality, performance, or the user's confirmed taste.
