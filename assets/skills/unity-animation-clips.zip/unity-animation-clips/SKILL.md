---
name: unity-animation-clips
description: Create or revise Unity visual direction and game presentation with editable AnimationClip assets as the default. Use for Unity VFX, UI motion, minigame presentations, and scripted scene direction; do not apply to purely static UI or gameplay logic without visual motion.
---

# Unity Animation Clips

For Unity presentation work that includes motion, make editable `AnimationClip` assets the source of timing, curves, transforms, alpha, and visual state. Connect clips to a prefab through an `Animator` and controller, then expose the clips in the Inspector.

- Create separate clips for readable phases such as enter, pour, stir, settle, exit, or success. Name them by feature and phase.
- Put the values an artist is expected to tune in clip curves. Keep code responsible for gameplay data, dynamic colors, amounts, validation, and phase transitions only.
- Do not replace authored clips with procedural coroutine or `Update` motion unless the value inherently depends on runtime input. When runtime data is necessary, let a clip animate a normalized driver value and let code map that value to the data.
- Preserve existing clip and controller edits when rebuilding a prefab. Create missing assets and states; do not overwrite curves, duration, or transitions that may have been authored manually.
- For ProjectUT, expose new effects through the existing `Tools/Project UT/VFX/Effect Preview` window and its catalog. Do not add effect-specific tool buttons, `MenuItem` entries, or separate preview windows; put any needed preview controls inside Effect Preview.
- Test the saved prefab and saved test scene in Play Mode. Verify every clip phase reaches its intended end state and report the clip paths, actual screen evidence, and any visual issue that needs authoring adjustment.

## Existing VFX material and motion review

Before improving an existing effect, confirm its current assets, rendered result, original purpose, and existing controls; use its working chat when available. Identify the remaining diagnostic gap before requesting research. Do not infer that a spiral, shared curve, or highlight is accidental merely because its current rendering needs work.

For wind/rain material quality, surface flow, deformation of readable features such as faces and symbols, or quality-preserving performance changes, read the relevant section of [material and flow diagnostics](references/material-flow-review.md). This review route does not require creating clips or shaders for a material-only task. Preserve the user's chosen authoring method and apply only the relevant checks; research or review alone does not authorize implementation.
