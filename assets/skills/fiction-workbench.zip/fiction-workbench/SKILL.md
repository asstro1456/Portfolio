---
name: fiction-workbench
description: "한국어 소설·세계관·캐릭터·AI 캐릭터 챗의 기획, 프롬프트 작성, 대사 및 분기 검증에 맞는 설치된 창작 스킬을 선택한다. 크랙 등 기존 작품의 설정 검토와 캐릭터 반응 테스트에 사용하며 일반 업무 문서에는 적용하지 않는다."
---

# Fiction Workbench

## 작업에 맞는 스킬 선택

[설치 목록과 용도](references/catalog.md)에서 현재 질문에 필요한 스킬만 읽는다. 보통 주 스킬 하나와 보조 스킬 하나로 시작하고, 실제 문제가 여러 영역에 걸칠 때만 추가한다.

| 현재 작업 | 먼저 읽을 스킬 | 필요할 때 추가 |
|---|---|---|
| 기존 세계관의 모순·작동 원리 검토 | worldbuilding-diagnostic | systemic-worldbuilding, governance-systems |
| 인물의 동기·변화·관계 검토 | character-arc | dialogue, character-sim |
| 소개·첫 대화·장면 작성 | creative-writing-modes | creative-writing-craft, writing-principles |
| 선택권·분기·엔딩 검토 | interactive-fiction-diagnostic | endings, genre-conventions |
| 기존 원고의 구조·문체 검토 | story-review | reader-sim, dialogue |
| 새 아이디어와 줄거리 탐색 | story-planning | premise-workshop, underdog-unit |
| Story Skills 형식의 프로젝트 작성·관리 | 해당 작성 스킬 | story-maintenance |

스킬은 이 폴더의 형제 폴더에 있다. 예: `../dialogue/SKILL.md`. `worldbuilding-diagnostic`과 `interactive-fiction-diagnostic`은 진단용이고, 접미사 없는 동명 스킬은 Story Skills 프로젝트 작성용이다.

## 기존 작품을 검증할 때

- 공개 소개만으로 판단하지 말고 확인 가능한 설정 원문, 시작 상황, 예시 대사, 키워드북, 스탯 및 엔딩 조건을 함께 읽는다. 접근하지 못한 영역은 미검증으로 남긴다.
- 사실로 확정된 설정, 의도적으로 미정인 설정, 독자에게만 숨긴 비밀을 구분한다. 미정이라는 사실만으로 오류라 하지 않는다. 현재 플레이에 반드시 필요한 규칙이 미정일 때만 영향과 필요한 결정을 설명한다.
- 결과는 원문 근거 → 충돌 또는 공백 → 예상되는 플레이 영향 → 최소 개선안 순서로 제시한다. 원문에 없는 사건·심리·관계·기능을 이미 존재하는 것으로 쓰지 않는다.
- 사용자 조종 캐릭터의 성격·감정·신념 변화는 플레이어 선택을 우선한다. NPC용 캐릭터 아크를 주인공에게 강제하지 않는다. 모든 인물에게 트라우마나 반전을 요구하지 않는다.
- `character-sim`이나 `reader-sim`은 가상의 압박 테스트다. 실제 플랫폼 실행, 실제 독자 반응, 흥행 또는 유입 검증과 구분한다. 미정인 사실을 채우는 답변을 만들기보다 해당 입력에서 결정이 필요하다고 표시한다.
- 남성향은 사용자 취향에 따라 관계·활약·성장·동료 서사 등을 구체화한다. 성적 내용이나 하렘을 자동으로 추가하지 않으며 기존 이용 등급을 존중한다.

## 환경별 적용

- 원문 검토 요청에는 대화로 결과를 전달한다. 파일 보관을 요청받지 않았다면 외부 스킬의 자동 기록 규정보다 사용자의 보관 원칙을 따른다.
- 기존 웹 작품을 점검하기 위해 Story Skills의 `story.md`나 소설 폴더를 자동 생성하지 않는다. 해당 형식의 프로젝트를 만들거나 가져오라는 요청이 있을 때 작성·유지보수 계열을 사용한다.
- Story CLI는 `../story-maintenance/scripts/story.js`를 Node로 실행할 수 있다. Deno 기반 보조 분석기는 Deno가 있을 때만 쓰며, 없으면 수동 진단 사실을 보고한다. 영어 어휘·문장 길이 점수는 한국어 품질의 증거로 취급하지 않는다.
- 외부 스킬의 명칭·도구가 이 환경에 없으면 사용 가능한 동등한 방식만 사용한다. 설치가 임의의 에이전트 생성, 자동 게시, 파일 이동·삭제 권한을 의미하지 않는다.
- 크랙 편집은 기존 `../crack-story-builder/SKILL.md` 또는 `../crack-character-builder/SKILL.md`를 함께 사용한다. 검토 요청만으로 라이브 작품을 수정하지 않는다.

설치 출처와 고정 커밋은 [manifest.json](references/manifest.json)에 기록한다. 원본 업데이트 시 로컬 호환성 변경과 출력 보관 원칙을 다시 확인한다.
