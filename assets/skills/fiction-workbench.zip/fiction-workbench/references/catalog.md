# 창작 스킬 분류

설치일: 2026-10-17. 외부 스킬 32개와 안내 스킬 `fiction-workbench` 1개.
아래 이름은 모두 `C:/Users/User/.codex/skills/<이름>/SKILL.md`로 연결된다.

## 1. 기존 작품 진단 — jwynia/agent-skills (9개)

| 스킬 | 쓰는 시점 |
|---|---|
| worldbuilding-diagnostic | 세계 규칙·기관·생활 환경이 서로 맞는지 검토 |
| systemic-worldbuilding | 기술이나 초자연적 조건이 사회에 미치는 연쇄 영향 확인 |
| governance-systems | 정부·권력·명령 체계·정치적 이해관계 설계 |
| character-arc | NPC 목표·신념·변화의 동기와 과정 검토 |
| dialogue | 말투 구별·설명 대사·속뜻·관계 변화 검토 |
| underdog-unit | 조직 내 소외된 팀과 부족한 자원, 불가능한 임무를 다루는 새 구상 |
| genre-conventions | 미스터리·관계·공포 등 주 장르의 기대와 혼합 충돌 확인 |
| interactive-fiction-diagnostic | 선택 결과·플레이어 주도권·분기 폭증·상태 추적 검토 |
| endings | 복선 회수·결말의 인과·정서적 마무리 검토 |

선택적 Deno 스크립트는 설치되어 있지만 이 환경에는 Deno가 없어 실행하지 않았다. 진단 본문은 직접 사용할 수 있다. 원본의 자동 파일 보관 규정은 사용자의 요청 시에만 저장하도록 조정했다.

## 2. 설정 프로젝트 관리 — danjdewhurst/story-skills (16개)

이 계열의 파일 작성은 `story.md`가 있는 Story Skills 프로젝트에서 사용한다. 기존 크랙 작품을 검토할 때 이 형식으로 무단 변환하지 않는다. 필요한 분석 기준은 수동으로 적용할 수 있지만 CLI 검증을 했다고 말하지 않는다.

| 스킬 | 쓰는 시점 |
|---|---|
| premise-workshop | 아이디어의 갈등·확장성·이야기 가능성 검토 |
| story-init | 사용자가 새 설정 프로젝트 생성을 요청했을 때 |
| character-management | 인물 프로필·관계·변화 기록 작성 |
| worldbuilding | 장소·제도·세력·용어 기록 작성 |
| plot-structure | 사건·막·주요 전환점 구성 |
| theme-craft | 중심 질문·가치 충돌·주제 정리 |
| genre-craft | 미스터리의 단서 공정성 등 장르별 설계 |
| scene-craft | 장면 목표·갈등·시점·대사·도입부 검토 |
| voice-style | 작품 문체와 캐릭터별 말투 기준 작성 |
| interactive-fiction | 선택 그래프·분기 합류·엔딩 작성 |
| revision-continuity | 인물 지식·상태·시간선·복선의 정합성 검토 |
| line-editing | 문장 단위 수정과 변경 이유 제시 |
| reader-panel | 복수 독자 유형의 가상 반응 비교; 실사용자 근거 아님 |
| feedback-triage | 실제 독자 피드백의 근거·우선순위 정리 |
| story-maintenance | 등록된 설정의 구조·연결·상태를 번들 Node CLI로 검사 |
| chapter-writing | 승인된 줄거리와 설정을 바탕으로 장면·장 작성 |

Story CLI는 별도 전역 패키지 없이 번들 파일을 사용할 수 있다. 설치되어 있지 않은 출판·시리즈·운문 등의 추가 스킬로 넘어가라는 원문 안내는 자동 실행하지 않는다.

## 3. 글쓰기와 반응 테스트 — haowjy/creative-writing-skills (7개)

| 스킬 | 쓰는 시점 |
|---|---|
| creative-writing-craft | 문장·장면·문체·장르별 작성 기법 참조 |
| creative-writing-modes | 초안·수정·연결 장면·대안·문장 다듬기 |
| writing-principles | 독자에게 주는 재미와 AI의 상투적 문장 점검 |
| story-planning | 확정 전 아이디어와 구조 탐색 |
| story-review | 구조·문체·설정 연속성에 대한 분석적 검토 |
| reader-sim | 특정 독자 관점의 첫 읽기 가상 반응 |
| character-sim | 특정 시점의 인물 지식과 말투로 대화 압박 테스트 |

현재 환경에서는 독립적인 skill-only 경로를 사용한다. Meridian·Claude 에이전트 구성은 설치하지 않았다. 존재하지 않는 동료 도구나 에이전트를 호출하지 않는다. 원본의 `type`, `model-invocable` 필드는 Codex 형식 검사를 위해 metadata에 보존했다.

## 선택에서 제외한 항목

- SillyTavern: 별도 AI 챗 프로그램. 스킬이 아니므로 설치하지 않음.
- 출판·ISBN·투고·운문·번역·자동 집필 배포: 현재 세계관·캐릭터·AI 챗 작업 범위와 거리가 있어 제외.
- 자동 기록용 지식 관리·상시 에이전트 운영: 기존 보관 원칙 및 환경과 겹쳐 제외.
- 여러 저장소의 중복 총괄 스킬: `fiction-workbench`에서 필요한 개별 스킬을 선택.

## 사용 예

- “이 세계관에서 칩을 제거했을 때 생기는 모순을 찾아줘.” → worldbuilding-diagnostic + systemic-worldbuilding
- “두 인물의 말투가 같은지 봐줘.” → dialogue; 필요하면 character-sim으로 가상 테스트
- “거절했는데 강제 진행되는지 검토해줘.” → interactive-fiction-diagnostic
- “이 설정을 유지하면서 첫 대화를 써줘.” → creative-writing-modes + creative-writing-craft
- “미스터리 단서와 엔딩 조건을 점검해줘.” → genre-conventions + endings; 구조화된 프로젝트면 revision-continuity

출처·커밋·로컬 변경은 [manifest.json](manifest.json)을 확인한다. 다음 턴부터 자동 탐색 대상이 되며 실제 호출 여부는 요청 적합성에 따라 결정된다.
