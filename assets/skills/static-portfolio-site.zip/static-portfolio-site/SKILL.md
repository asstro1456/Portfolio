---
name: static-portfolio-site
description: Build, refine, and verify a static GitHub Pages HTML/CSS/JS portfolio site. Use when working on a local static portfolio website, especially for GitHub Pages deployment, hero/navigation polish, responsive layout fixes, card/modal copy updates, asset replacement, Playwright UI verification, cache-busting version sync, or portfolio targeting such as Limbus Company UI/UX applications.
---

# Static Portfolio Site

## Core Workflow

1. Classify the task as a static GitHub Pages web task before editing.
2. Inspect the relevant files first: usually `index.html`, `portfolio.html`, `css/style.css`, `js/main.js`, and `scripts/verify-ui-flow.mjs`.
3. Keep changes minimal and preserve the existing structure, naming, class conventions, and section flow.
4. Do not change Pages deployment settings, workflows, `CNAME`, `_config.yml`, or branch strategy unless explicitly requested.
5. After functional or visual changes, run the project Playwright verification script when available.
6. Only after verification passes, bump the patch version and sync cache-busting query strings.

## Version And Cache Rules

- Treat the visible site version and asset cache query as one contract.
- Keep these values synchronized:
  - `#hero .hero-version`
  - `index.html` `css/style.css?v=...`
  - `index.html` `js/main.js?v=...`
  - `portfolio.html` `css/style.css?v=...` when present
  - `portfolio.html` `js/main.js?v=...` when present
- Bump only the patch version after verification succeeds.
- Do not claim success if verification was not run or failed.

## Verification

Use the local verification command when this project shape is present:

```powershell
& 'C:\Program Files\nodejs\node.exe' .\scripts\verify-ui-flow.mjs 'file:///C:/Users/User/Documents/Portfolio/index.html'
```

Also verify the risky viewport manually or with Playwright when layout changes affect:

- sticky navigation readability and width
- hero title/card overflow
- tablet and mobile breakpoints
- How carousel card clipping
- modal open/close behavior
- portfolio page image loading
- broken images or console errors

Keep `output/playwright/*.png` as verification artifacts; do not include them in commits unless the user explicitly asks.

## Layout Heuristics

- Keep the top nav sticky and readable over dark and light sections.
- Let the nav panel wrap only the nav items; avoid a large empty panel area.
- Preserve the main flow: `Main / What / Why / How / Vision / Portfolio`.
- Keep the main page focused on identity and work method; move detailed evidence cards to `portfolio.html` when the portfolio becomes too heavy.
- Use the desktop 3D How carousel when there is enough width.
- On tablet and smaller widths, prioritize full content visibility over 3D side-card peeking.
- Prevent text and card overflow at `1024x768`, `768x1024`, and narrow tablet widths around `695x514`.

## Content Direction

For the current Limbus Company UI/UX direction:

- Core message: `시스템을 이해하고 UX로 풀어내는 게임 UI/UX 기획자`.
- Position portfolio cards around:
  - `Limbus 재학습 UX 분석`
  - `Limbus 슬롯 프로토타입`
  - `Unity UI 상태 설계`
  - `시스템 조건과 UX 흐름`
- Emphasize system conditions, UI states, feedback, re-learning flows, Unity UI readiness, and player comprehension.
- Avoid over-positioning as only a systems planner when the target role is UI/UX designer.
- Prefer problem-action-learning copy for cards and modals.

## Assets

- Prefer flowcharts, data structure diagrams, and prototype screenshots over character art or atmospheric images.
- Put web assets in `assets/images/` and prototypes in `assets/prototypes/`.
- Avoid large videos unless explicitly requested; use thumbnails or short captures instead.
- Use `object-fit: contain` for flowcharts and data diagrams so structure is not cropped.
- Check image loading with Playwright or browser inspection after replacing placeholders.

## Git And Scope

- The user commits and pushes directly unless they explicitly ask otherwise.
- Do not commit or push on your own.
- Run `git status --short` before and after changes.
- Ignore unrelated dirty files unless they block the task.
- Do not revert user or generated changes without explicit instruction.

## Response Shape

When closing out this project, report in this order:

1. 요약
2. 변경 파일
3. 핵심 변경점
4. 검증 결과
5. 남은 리스크 또는 추가 확인 사항

## Shared Standard

- Keep the scope narrow, reuse linked references, and report evidence plus validation limits.
