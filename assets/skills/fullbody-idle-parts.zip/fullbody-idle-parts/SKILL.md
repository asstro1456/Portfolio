---
name: fullbody-idle-parts
description: "Prepare, separate, restore, and review full-body standing character illustrations as layered parts for subtle idle animation. Use for breathing, small weight shifts, head motion, blinking, and secondary hair/ear motion while preserving approved artwork. Covers part ownership, hidden-area restoration, alignment, and static/motion acceptance. Does not authorize new character designs, large pose changes, or engine/project modification."
---

# Full-body Idle Parts

Turn an approved standing illustration into a coherent set of reusable animation parts. The deliverable is an image asset package with explicit validation state, not merely attractive isolated drawings. Human artists and agents can follow the same criteria.

## Scope and reading order

Read this entrypoint for every task. Read [PSD and layer authoring](references/psd-and-layers.md) before production or layer review, and [Quality gates and handoff](references/quality-and-handoff.md) before validating or delivering parts. Read [Develli trial](references/develli-trial.md) for detached tips/ghost fragments and [Whitehair correction case](references/whitehair-corrections.md) for ribbon ownership, restoration joins or stale import meshes. These are imperfect cases, not finished quality targets.

Treat analysis/review requests as read-only. For production, use available image-authoring tools according to their instructions. No particular provider, paid application, MCP server, or local drive is required by this skill. If tools are unavailable, provide the scoped part specification and identify unperformed work. Do not claim instructions alone generated or validated assets.

The target remains **full-body** even when facial details need close-up inspection. A face-only preview cannot establish success at the intended full-body display size. Walking, side/back views, taking hands out of pockets, and large limb gestures need a different asset plan. Do not silently expand a limited idle request to those motions.

## Establish the contract

Inspect supplied art and existing project conventions before asking questions. Resolve consequential missing choices; state conservative assumptions for incidental ones. Record:

- Approved source, pixel dimensions, color/alpha handling, and immutable original. Choose one master; do not alternate between original, background-removed, and upscaled versions without recording coordinate conversions.
- Full-body display size, target importer if known, supported motions, and maximum tested poses. Blinking is optional unless requested or included in the agreed scope. Keep feet planted unless the intended motion includes lifting one.
- Permitted visible retouching. Approval to separate parts normally permits masking and hidden-area restoration, not redesign of the exposed face, silhouette, palette, or linework.
- Editable format and output location. For new or revised raster production, keep a layered PSD working master with distinguishable source extraction, hidden restoration and subsequent retouching. Export merged PNG parts as derivatives. Do not invent historical painting layers or claim a PSD exists when only PNGs were produced. If PSD authoring is unavailable, complete authorized planning/review, disclose the missing source and keep delivery unfinished; do not silently substitute flattened output. Review-only tasks need not convert an existing source.

Select the source strategy deliberately:

| Situation | Preferred starting point | Reason and boundary |
|---|---|---|
| Approved standing art; subtle idle | Extract that art; restore limited occluded regions | Reuses approved appearance. Dense overlap may still make restoration expensive. |
| New character; no approved art | If new-art creation is authorized, compose a rig-friendly master, obtain master approval, then separate | Without that authorization, provide a proposed part/layout specification or request an approved source; do not generate a character. A new flat image does not automatically provide aligned layers. |
| Independently generated parts | Require explicit alignment and consistency checks | Attractive parts may still have incompatible shape, scale, position, line style, or color. |

These are workflow judgments, not measured speed ratios. Do not invent hours, cost savings, success rates, or universal superiority.

The strategy table routes work; it does not grant creation permission. A request to separate existing art authorizes neither a replacement master nor a new character design. Reuse an explicit new-art authorization already present in the task instead of requesting it again. If it is absent, continue authorized analysis/planning and pause only the new-art step. Even when generation is authorized, approve the resulting master before treating it as the separation baseline. Record the authorization scope separately from prototype acceptance and asset readiness.

## Plan parts by motion and occlusion

Before cutting, map each part's ID, semantic ownership, source region, depth relationships, attachment region, intended deformation, and hidden areas that motion may expose. Define left/right as image-space or character anatomy and keep it consistent.

Split when a region must move differently, cross another layer, or change expression. Keep shared-motion regions together when separation adds no benefit. Pocketed hands may remain with the clothing/body. Stationary legs need not be divided into every anatomical segment. Part and bone counts are not quality targets.

Use this table as a decision aid, not a required layer list:

| Region | Separation decision | Restoration/check |
|---|---|---|
| Torso, clothing, lower body | Permit breathing/weight shift while retaining foot contact | Cover neck/shoulder and hem/leg joins during motion. Keep printed patterns attached to their cloth. |
| Head/neck | Separate for relative head movement | Restore covered neck and skin under hair as far as tested poses expose them. Prevent doubled chin contours. |
| Back hair, front locks, crown, accessories | Divide by depth and distinct motion, not arbitrary tiles | Restore concealed strands and covered body; remove attached skin/cloth fragments. A strand mask or polyline is not a complete isolated image. |
| Ears/appendages | Retain root-to-tip continuity; split only for actual depth/motion needs | Include complete tips, anti-aliased edges, and covered roots. Distal pixel islands must not remain on hair/body layers. |
| Eyes, brows, mouth | Prepare requested facial states | A blink needs a clean underlying surface and an intentional eyelid/closed-eye solution. Cutting out an open eye does not produce a blink. Lip sync is separate scope. |

A global layer order can fail where a long lock passes both behind and in front of another region. Split at that depth change or document a suitable masking solution. Do not repair an occlusion contradiction by enlarging a hole.

## Extract and restore

1. **Lock alignment.** Preserve the master and work in new files. Default to full-canvas transparent PNGs with shared dimensions/origin. Cropped parts require lossless offsets and a compatible importer; never independently recenter, fit, or resize them.
2. **Extract visible pixels.** Follow semantic boundaries and preserve anti-aliasing. Inspect each part alone, with neighbors, and on light/dark backgrounds. Remove foreign fragments; avoid missing edges, duplicate outlines, and background matte. Segmentation is a starting mask, not proof of ownership.
3. **Restore occluded areas.** Extend parts under their occluders to cover planned motion. Keep extraction, restoration and actual retouching independently editable within identifiable part groups/layers, with masks where used. Preserve exposed source pixels; use generated underpainting only in authorized hidden regions. Reject candidate scale/pose drift before compositing.
4. **Reassemble and refine.** Compare the neutral stack to the master, then test maximum relative displacement. Refine masks, overlap, and restored contours together. Choose overlap from actual exposure; another character's fixed pixel margin is not a guarantee.

Do not run background removal, upscaling, broad repainting, or replacement generation simply because separation is requested. Those require relevant task authorization. Previous character masks, coordinates, counts, and margins are examples, not reusable geometry.

## Diagnose before changing the rig

Locate the affected frames and parts first:

| Symptom | First discriminating check | Corrective direction |
|---|---|---|
| Detached/doubled tip | Solo appendage and neighboring layers; inspect the complete tip and residual islands | Fix ownership/restoration first. If it persists, inspect mesh coverage, weights, and attachment. |
| Hole/repeated contour at chin, neck, shoulder | Inspect both parts with their usual occluder hidden; test extreme relative poses | Restore coverage or remove foreign contours. Do not merely reduce motion to hide a known gap. |
| Cloth/skin moves with a hair lock | Solo the lock at native scale | Remove foreign pixels and restore the exposed background part. |
| Full-body motion is hard to notice | Review intended full-body framing and characteristic poses | Adjust readable body/head motion and secondary timing within scope. More bones or camera zoom does not prove a better full-body result. |
| Correct isolated part fails in motion | Check order, rest placement, pivots, bind pose, parent transforms, then weights | Separate asset defects from rig/import defects. GPU deformation does not repair masks or missing artwork. |

Do not assume every detached tip shares the trial's cause. That trial demonstrated ownership errors and remaining motion defects; it did not establish that all residual artifacts came solely from too few bones.

## Validate and hand off

Apply independent structural, neutral-composite, and motion gates in [Quality gates and handoff](references/quality-and-handoff.md). Keep evidence for each. A neutral pixel match, successful import, changing transform, supported shader, or one screenshot cannot replace full-body motion review.

Return the highest state supported by the [state matrix and required fields](references/quality-and-handoff.md#state-matrix):

- `DRAFT`: asset gates or their required fields are incomplete/failed, or a motion defect leaves asset correctness unresolved.
- `PARTS_READY`: structural and neutral gates pass with the required asset fields. Motion may be untested, partially tested, or failed for a demonstrated rig-only reason. This is asset readiness, not successful idle validation.
- `IDLE_READY`: all gates and the additional motion fields pass for the named rig, motion range, preview environment, and full-body display size. This does not certify other poses or implementations.

A user may accept an imperfect prototype for testing/rendering. Preserve that scope; do not turn it into finished-art approval. Keep known issues visible even when a test export is authorized.

If a part's alpha or extent changes after import, invalidate its previous mesh-coverage result and recheck the actual importer mesh, binding and extreme poses. Image production does not itself authorize engine edits. For ProjectUT integration, continue through the separately installed `$ut-fullbody-rigging-harness` when available and requested; otherwise deliver the asset state and outstanding engine checks without claiming that integration occurred.

Deliver parts, actual editable source if available, relative-path manifest, and available review evidence. Use [the manifest template](assets/handoff-template.json) for a new handoff if no project schema exists. Do not replace an established schema unnecessarily. Report accepted scope, current state, failed/unrun checks, and one concrete next action. Engine scenes, prefabs, packages, and publishing remain outside this skill's authority unless requested.
