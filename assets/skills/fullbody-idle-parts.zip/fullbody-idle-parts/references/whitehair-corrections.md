# Whitehair gown — additional correction case

Case record: 2026-10-22, approved standing illustration, subtle idle. The v6 delivery had 13 common-canvas parts at 1882×3344 and an extraction/restoration PSD. These numbers, the character and its geometry are case facts, not defaults or reusable masks. This document records prior evidence; it does not claim a new visual inspection.

| Observation / explicit decision | Corrective principle | Remaining boundary |
|---|---|---|
| The waist knot and connected long white cloth were requested as one ribbon part; black garment pixels had mixed into that part | Map the whole semantic object and neighboring ownership before extracting. Check the root, knot and complete tails together | This character's combined ribbon does not forbid splitting another ribbon when depth/motion requires it |
| Missing patches/straight boundaries remained near the waist root; restored skirt and extracted source did not join cleanly | Preserve extraction, hidden restoration and later repair separately; inspect solo, adjacent composite and maximum relative displacement | v6 remained `DRAFT`; rendering authorization was not art approval |
| The new long ribbon alpha extended outside an older Unity mesh | After PNG/alpha changes, recheck mesh coverage, weights/bindings and motion. Repair only authorized imported copies while preserving IDs, alignment and existing animation | A good PNG cannot prove a valid mesh; mesh correction cannot prove good artwork |
| A fit-to-cell contact sheet scaled each part independently | Label it explanatory; judge relative scale/placement using common-canvas reconstruction | Never derive offsets or size ratios from the sheet |
| Neck motion was to remain lower while hair and waist ribbon read more clearly | Preserve the latest accepted clip and adjust only requested controls when animation editing is authorized | Existing animation was copied during UT transfer, not newly authored then |

The UT copy's regenerated meshes totaled 1,650 vertices while preserving placement, bone mapping and animation. This is a recorded result for that copy, not a quality target or universal mesh prescription. The source personal-experiment project was not updated by that import repair.

The first video container had plausible dimensions/duration but a corrupt H.264 stream and green playback. Its cause was not proven to be a particular GPU/driver. A PNG-sequence render followed by independent FFmpeg encoding produced v2: 1080×1920, 30fps, 6 seconds, 180 PNGs and 180 decoded frames, each set with 180 unique frames and zero strict decode errors. Samples were viewed; every frame's artwork was not approved. Technical video success and asset readiness are separate.

Transferable sequence: inspect PSD/actual parts → repair authorized source/masks → export aligned parts → recheck changed import mesh/binding → full-body loop and joins → independent video decode and source comparison. If the user requests only analysis, stop at findings; these examples grant no production or engine-change permission.

<a id="central-bang-20261023"></a>
## 2026-10-23 — central bang, fixed shadow and source outline

This case applies to the separated central bang of this Whitehair illustration. The canonical user criterion is `projectut/art/whitehair-gown-parts`, judgment `87acaf83-a3bf-4aaa-96ec-21f1931d4fae`. Retrieve its current source and scope through the judgment harness before applying; do not generalize this character's shadow removal to other characters or parts.

When separating this bang for motion, remove its fixed shadow from the face while preserving the user's marked boundary and the eyes, nose and mouth. Inspect the bang and face separately, then hide/move the bang and inspect the adjacent reconstruction. Removing the shadow must not remove the hair outline. Match repaired line color, width and softness to the actual original side hair at matched scale, rather than applying an arbitrary hard dark line.

The [U1 before/after case](D:/CodexData/art/outputs/20261023/image-review-casebook.md#projectut-cases) links the cut outline, overly hard repair and softer source-matched revision. Use it with the [common correction review](../../review-ai-generated-art/references/correction-review.md). This is a link to prior static evidence, not a new visual approval of current parts or a native PSD check.

For an intended attached hair chain, assess root attachment, mid-strand curvature and tip timing according to its actual design; do not impose a rigid root or delayed tip on every appendage. Static line/shadow acceptance cannot prove these temporal properties. Inspect the intended full-body loop at normal speed and its wrap, preserving approved artwork and motion. A frame-only waiver limits the conclusion to the frames actually inspected.

## 2026-10-25 — old bright outline inside extended underpainting

In this character's v26→v27 correction, retaining the original bright edge while extending gray hair underpainting left an internal seam. Preserve the face and the separately exported bang's outer contour; those invariants do not require retaining the obsolete edge inside the new shading. Isolate the demonstrated seam, sample matching interior material, and check for dark dots as well as bright leftovers. Generated edge pixels can reintroduce a contour even when their brightness falls below a chosen threshold; inspect the local composite instead of treating that threshold as artistic approval.

The local v27 candidate-v2 report records a 20-pixel seam mask, unchanged alpha/outside-mask pixels and separate static review; 20 pixels and its coordinates are case facts, not a general mask. Evidence: [candidate validation](D:/CodexData/projectut/outputs/20261025/whitehair-v27-root-seam/candidate-v2/candidate-validation.json). Native Photoshop, Unity integration and normal-speed motion were NOT_RUN. Reuse this as a diagnostic case, not whole-character readiness or authority to repaint other parts. Interpret user annotation roles before editing: a cut boundary and an area to fill need different operations even when both are drawn as lines.
