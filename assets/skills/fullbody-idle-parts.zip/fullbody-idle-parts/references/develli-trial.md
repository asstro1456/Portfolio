# Develli trial — evidence and transferable decisions

Personal Unity experiment using a supplied standing character with long purple hair, long ears, hoodie, pocketed hands, and stationary legs. The intended use was clarified as **full-body idle**, not a face portrait. Character features explain this case; they are not requirements for other art.

## Evidence scope

Master: 1882×3344 RGBA. Eighteen common-canvas parts. Final test skeleton: 29 transforms including root, 28 controls. Export: 6 seconds, 1080×1920, 30fps; all 180 frames decoded. Counts and settings are case facts, not universal prescriptions.

The user allowed temporary motion testing despite boundary defects, then accepted current motion as sufficient to render. This was prototype acceptance. Subsequent review still found jaw/neck seams, stray boundary fragments, and a right-ear-tip separation line at some poses. Finished production quality was not established. Blinking and lip sync were not demonstrated.

## Failures and decisions

| Observation | Meaning | Transferable action |
|---|---|---|
| Generated underpaint candidates changed shape, scale, or position | Attractive new drawings did not automatically fit the master | Preserve extracted visible pixels; selectively use hidden underpainting. Verify alignment before adopting exposed changes. |
| Neutral reconstruction reported zero visible RGBA mismatches | Static agreement coexisted with incorrect boundaries | Test reconstruction and semantic ownership independently. Neither establishes motion readiness. |
| Opaque ear-tip pixels remained on rear-hair layers | Relative ear/hair motion could expose detached distal islands | Inspect the whole appendage and solo adjacent layers before assuming a root/bone-count problem. |
| Checked tip regions reached zero missing opaque pixels after mask repair, but motion review still showed a seam | A local mask count did not exclude other boundary, alpha, weight, or restoration defects | Recheck sequential rendered poses. Do not extend an opaque-pixel metric to all edges or claim a residual cause is proven. |
| Skin/cloth fragments and baked-in contours remained on hair/face/neck parts | Occluders hid them at rest; motion exposed/carried them | Inspect isolated parts without occluders, then maximum relative displacement. |
| Early motion was difficult to read from the full-body view | Close-ups could overstate readability | Review full-body silhouette motion first; use close-ups for continuity. Preserve the full-body deliverable. |
| Early checks emphasized transforms and a single capture | They missed the user's clarification that the **tip**, not the root, appeared detached | Verify the reported location across time; collect screen evidence in addition to import/transform state. |

## Diagnostic images

[Full-body poses](../assets/develli-fullbody-review.png) show 0, 1.5, 3, and 4.5 seconds. [Face/ear crops](../assets/develli-joins-review.png) show the same samples enlarged. They are **imperfect prototype examples**, not a before/after pair or complete temporal test. Inspect neck/chin contours and the right side of the 1.5-second ear tip. The diagnostic crops cut off some geometry; use the full-body sheet for framing.

## Scope retained from the task

- Full-body standing idle is the target. Pocketed hands and planted feet are acceptable; they do not require redesign simply to demonstrate rigging.
- An approved standing illustration can remain the master. New rig-friendly art may help future characters; no matched timing study established the efficiency difference.
- Visible appearance survives extraction. Hidden restoration and correct overlap are the main artwork tasks. More bones or CPU/GPU changes cannot fix wrong pixel ownership.
- A shared specification can support other workers. No independent second-worker reproduction of finished art was demonstrated in this trial.

Prefab parenting errors and asset-preview GPU warnings were engine integration issues, not general image-separation steps. Keep those diagnoses separate. No engine automation from this case is bundled in the skill.
