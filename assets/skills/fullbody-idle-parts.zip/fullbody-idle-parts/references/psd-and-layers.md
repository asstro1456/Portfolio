# PSD and layer authoring

## Choose layers by the intended edit

Keep an immutable supplied/master raster and a layered PSD working source. Name semantic part groups and preserve the common canvas/origin. Within each part, distinguish actual `EXTRACT`, `RESTORE`, and subsequent `RETOUCH` work by layers and/or masks whose roles can be inspected independently. Use retouch layers only when a correction was made; do not add empty layers to meet a count. Keep separately moving cast shadows/overlays independent when needed.

A supplied flattened image has no recoverable historical line/base-color/shadow layers. Semantic extraction is real editable work, but it must not be labeled the original artist's painting stages. Whole-image duplicates and renamed empty layers are not meaningful separation. Newly painted hidden pixels must remain distinguishable from preserved visible pixels.

For authorized new layered illustration, separate actual drawing stages, objects/materials and effects where later editing benefits. Painterly art need not invent line art. Animation additionally needs independent moving drawables and consistent occlusion; a painter's editable layer tree alone does not satisfy that requirement. Do not turn Live2D facial splits or importer settings into Unity requirements.

For explicit line/base-color/shadow editing or generic PSD packaging, use the separately installed `$layered-psd` [entrypoint](../../layered-psd/SKILL.md) when available. It distinguishes existing layers, inferred reconstruction of flat art, and packaging of already-separated PNGs. Its normal-blend PNG packer does not replace this skill's part ownership, restoration or motion gates, and does not preserve native groups/masks/blend features. If absent, follow the criteria here with available authoring tools and disclose missing steps.

Keep useful masks, clipping and adjustment layers only where the saved PSD and chosen editing tool preserve the intended result. Unity may consume merged PNGs per drawable; export those without flattening the PSD master. Preserve the original and do not overwrite it with a repaired derivative.

## Use public references with evidence boundaries

Before choosing a new layer plan, inspect public explanations suited to the actual medium and use. Prefer direct illustrator explanations/making-of material from Korean, Chinese and Japanese creators. Reuse a previously verified matching reference within the task; search further when it does not fit. A translated page's language does not establish the creator's nationality. Report any gap rather than filling it with invented workflow details.

The following written references were reviewed on 2026-10-22; their practices support decisions, not a mandatory universal tree:

| Public source | Applicable practice | Limit |
|---|---|---|
| [lack / CLIP STUDIO official making-of, line art](https://tips.clip-studio.com/ja-jp/articles/1269) | Object folders, line/paint separation and folder masks | One artist's process; no universal highlight order. |
| [夏水かなた, rig-art handoff notes](https://note.com/kanata_natsumi/n/n7f96b96b6e26) | Distinguishable part names, left/right conventions, separate moving shadows, completed hidden contours | The author limits some conventions to their own Live2D modeling; transfer the rationale, not all importer details. |
| [CG插画小驴老师 / ZCOOL, SAI2 coloring](https://www.zcool.com.cn/article/ZMTExOTQ5Ng==.html) | Named material groups and independent clipped shading/lighting | The example's stacking order is not a universal occlusion plan. |
| [Wacom Korea, pen-line tutorial](https://wacomkoreablog.com/1225) | Preserve draft; separate and name line/detail work | Official Korean educational supplement, not a named illustrator's personal process. |

An official catalog identified a Korean artist HAEYOON video candidate, but its video content was not reviewed. Do not cite its unseen contents as established layer rules. No paid class, private PSD or unviewed video is evidence here. The requirement to retain a PSD master is this workflow's authoring contract, not a claim that all cited artists use PSD.

## Verify the saved source

- Toggle extraction/restoration/retouching independently and check the stated region actually changes.
- Reopen or parse the saved PSD; inspect dimensions, layer names/order, positions, alpha and the neutral composite. State whether this was a native application check or a parser/pixel check. A parser cannot prove Photoshop-open behavior or every blend-mode feature.
- Test one intended local edit non-destructively on a copy or temporary in-memory version, verify neighboring independent work stays editable, then discard only that temporary edit. Never overwrite the source for this test.
- For restructuring alone, require exact visible RGBA equality against the previous neutral composite, ignoring RGB where both pixels are fully transparent. Authorized artwork repair instead identifies the allowed changed regions and compares preserved regions separately.
- Deliver the PSD plus actual PNG exports and their mapping. Missing or failed required PSD checks keep new/revised production at `DRAFT`; report unsupported features and unperformed checks.
