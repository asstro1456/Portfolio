# Quality gates and handoff

Apply these gates in order. Revisit earlier gates if motion reveals an asset defect. Review methods below do not assert that any particular tool or engine is available.

## Gate A — structure and ownership

Inspect exported files, not only editor thumbnails.

- Required parts exist, have useful alpha, and match agreed canvas, coordinates, color handling, and naming. Detect empty exports, baked checkerboards/mattes, accidental rescaling, and unreported offsets. Preserve the original and identify the approved master.
- Visible regions belong to the intended semantic parts. Solo appendages, hair, clothing, and facial features. Inspect outer tips and anti-aliased fringes, not only opaque interiors. Overlapping restored coverage is valid; an exposed foreign fragment moving with another part is not.
- Hidden fills cover planned exposure. Disable occluders and inspect for missing skin/cloth, hair-shaped holes, doubled jaw/ear contours, and foreign lines baked into a layer. Do not demand invisible anatomy that the agreed idle can never reveal.
- Layer relationships handle local depth changes. Revise segmentation if one part cannot satisfy its front/back relationships. Attachment regions remain covered throughout the planned poses.
- For new/revised raster production, verify the layered PSD using [PSD and layer authoring](psd-and-layers.md). Preserve independently inspectable extraction/restoration/retouching, saved composite and export mapping; a flattened PSD is insufficient. A PNG-only engine copy may still be reviewed without silently claiming its missing working source was produced.

Missing a tip is not acceptable merely because a neighboring layer currently covers it.

## Gate B — neutral reconstruction

Compose exported parts in declared order at saved rest positions. Compare to the master at identical resolution and color/alpha handling. Inspect full-body display size and native-scale crops of sensitive joins.

For extraction-only output, visible RGBA agreement should be exact unless approved edits or documented compositing differences justify deviations. Ignore meaningless RGB differences where both images are fully transparent. Report the comparison mask, mismatch result, and authorized retouch regions. Do not conceal silhouette or linework changes behind a permissive global threshold. Report a visual comparison honestly if no numeric comparison ran.

Use light/dark backgrounds to expose fringe contamination and lost translucent edges. Handle premultiplied alpha consistently if used; do not interpret it as straight alpha.

**Limit:** a wrongly owned fragment can be perfectly covered at rest. Zero mismatch does not establish correct ownership or acceptable motion. Gates A and C remain independent.

## Gate C — intended idle motion

Record rig/importer, actual motion range, framing, and whether validation used an engine, authoring preview, or static simulation.

Review the entire loop at its intended full-body size. Inspect native-scale crops of roots, tips, jaw/neck, shoulder/hair overlaps, and hem/legs over time. Quarter-cycle poses help comparison, but continuous playback or sufficient sequential frames is needed for short-lived defects. Also inspect delayed secondary-chain extrema, which may not occur at quarter cycles.

For a complete temporal check, review a continuous full loop at the intended playback cadence and its wrap into the next loop. An exported frame sequence should cover that cadence without unexplained gaps; record frame/time indices and inspect critical joins through transitions as well as at extrema. A few representative stills are diagnostic evidence, not complete coverage. If captures skip intervals where defects could occur, or deformation has not updated reliably, mark temporal evidence `PARTIAL` until coverage is repaired. Do not invent a universal fps or a minimum defect duration to justify sparse sampling.

| Concern | Acceptance evidence |
|---|---|
| Continuity | No detached ends, holes, foreign fragments, doubled edges, stretched seams, or crossing contours at tested maximum displacement. |
| Full-body readability | Intended motion reads at the actual full-body framing. Close-ups supplement it. Do not require exaggeration when subtle motion is intended. |
| Contact/anatomy | Feet keep intended contact; torso motion does not unintentionally slide legs. Head/neck and clothing stay connected without unintended rubber-like distortion. |
| Timing | Secondary motion may lag the driver. Avoid indiscriminate lockstep rotation. Loop closure is coherent; a reset or repeated seam blink is not mistaken for intended acting. |
| Capture validity | Frames represent requested times, with deformation updated before rendering. Changed transforms alone do not establish changed rendered geometry. |

For GPU-skinned capture, let actual player/engine updates and deformation finish after posing before rendering. This is an observed Unity capture pitfall, not a reason to add permanent runtime hooks. Verify characteristic rendered poses differ and the export decodes. An MP4's existence does not prove visual quality.

Without a rig, maximum-pose overlap mockups can check exposure assumptions. Label such motion evidence `PARTIAL`, not engine-tested. Import, binding, GPU configuration, and animation authoring are separate operations requiring their own scope authorization.

Classify motion failures as artwork/ownership, depth order, or rigging before repairing. Reducing amplitude is valid when the requested motion range changes; it is not a substitute for fixing a known defect inside the agreed range.

## Status and issues

Use `PASS`, `FAIL`, `PARTIAL`, or `NOT_RUN` per gate. Overall states are defined in SKILL.md. Prototype acceptance is not automatic production approval.

## State matrix

Assign the state from current evidence, not from whether a test has merely finished. A completed failed motion test is `FAIL`, not `NOT_RUN` or `PARTIAL`.

| Gate A: structure/ownership | Gate B: neutral reconstruction | Gate C: motion | Highest supported state |
|---|---|---|---|
| Anything except `PASS` | Any | Any | `DRAFT` |
| `PASS` | Anything except `PASS` | Any | `DRAFT` |
| `PASS` | `PASS` | `NOT_RUN` or `PARTIAL` | `PARTS_READY` |
| `PASS` | `PASS` | `FAIL` | `PARTS_READY` only if the failure is demonstrated to be confined to rigging and A/B remain valid; otherwise `DRAFT` |
| `PASS` | `PASS` | `PASS` | `IDLE_READY` for the recorded preview environment and tested scope |

This table also requires the fields below. If `IDLE_READY` fields are missing but `PARTS_READY` fields are complete, cap the state at `PARTS_READY`; if required asset fields are missing, use `DRAFT`. Report the missing fields instead of manufacturing values. A visible motion defect with an unknown cause invalidates confident asset readiness until artwork/ownership has been cleared; do not retain stale A/B passes as proof.

To classify a failure as rig-only, retain the failing pose/frame, recheck the relevant ownership/restoration and neutral regions, and identify a concrete binding, pivot, ordering, mesh, or weighting mechanism. A controlled correction must remove that defect at the failing pose/range without changing the image assets; record the before/after evidence and how unchanged asset versions were established. A guess about bones, a successful import, or a seam disappearing in one unrelated pose is insufficient. A local successful correction does not turn a previously failed full-loop test into `PASS`; keep the failed full-loop result disclosed until the required motion review is rerun. If evidence cannot isolate the cause, use the unresolved-cause path.

An implementation sorting-order mistake may be rig-only when correcting renderer/layer settings works with unchanged parts. An impossible depth relationship that requires splitting or repainting a part is an asset defect and returns Gate A to a failed/unresolved state; do not classify both as the same ordering problem.

User acceptance for a prototype/export is a separate record and does not override these states. An actual asset defect returns the package to `DRAFT` even if an MP4 export is accepted.

## Required, conditional, and optional fields

The JSON template is an unfilled starting point, not a strict schema or a completed package. Preserve equivalent fields in an existing project manifest. Use these requirements for the highest state claimed:

| Field group | `DRAFT` | `PARTS_READY` | Additional `IDLE_READY` requirement |
|---|---|---|---|
| Identity and source | Record available facts; unknowns permitted | `character_id`; source original/master references and baseline permission; canvas size, color space, alpha encoding, origin, left/right convention, and visible-retouch policy | Same approved/supplied baseline version as tested |
| Intended scope | Record known requests | Full-body use; motion scope; blink required/not required; intended foot contact | Actual full-body display size and tested extreme poses/ranges |
| Parts | Proposed or unfinished entries allowed | Nonempty exported parts with the fields below and valid relative file references | Same exported part versions as tested |
| Validation | All gate statuses explicit; unresolved checks stay unpassed | A/B `PASS`, methods and evidence; C's actual status and any blockers disclosed | C `PASS`, named rig/version, preview environment/mode, and continuous-loop or sufficient sequence evidence at the tested range |
| Handoff | Known issues and next action recorded | No unresolved asset defects; disclose downstream limitations, editable-source availability, and any scoped acceptance | No failed required motion checks; record remaining out-of-scope limitations |

Engine/importer, import settings, and pivots are **conditional**, not universal blockers. For asset-only delivery without an engine they may be unknown or not applicable. When a ready claim includes a specific importer or binding convention, record the settings that affect reproduction. `IDLE_READY` can refer to a qualifying authoring preview; it need not claim an engine was tested. If engine playback was actually used, identify that engine/import setup. Static pose mockups alone remain `PARTIAL`.

For exported video evidence, record its frame dimensions, fps, and duration. Other evidence may use an authoring clip/version and a recorded playback review; do not invent video metadata for a preview that was not exported. A checksum is recommended for identity tracking but not mandatory if another unambiguous master/part version reference is used.

Use null for an unknown value. For a conditional field that is not applicable, leave its value null and explain why in `field_notes` using its dotted field path, `status: "NOT_APPLICABLE"`, and a reason. Do not use N/A to hide a required unknown. Optional unknown values may remain null. `false` is a known Boolean value, not missing data; empty issue/retouch lists are valid when there are genuinely no entries.

New or revised raster production under this skill requires a layered PSD working source by default; an explicit user exception changes only the stated task. Review-only checks need not convert existing assets, but must disclose any missing required working source. Set `editable_source.availability` to `AVAILABLE`, `NOT_PRODUCED`, or `UNKNOWN`. `AVAILABLE` requires the actual file/format and appropriate saved-source checks. `NOT_PRODUCED` requires a limitation explaining what was delivered instead; if layered delivery was required, that omission blocks readiness until fulfilled or the contract changes. Never invent a PSD to fill the field.

Record new-master generation authorization as `AUTHORIZED`, `NOT_REQUESTED`, or `UNKNOWN`, with its scope when authorized. Only `AUTHORIZED` permits that step; an absent authorization does not block extraction from an already supplied/approved master. Existing explicit authorization is sufficient and does not need repeated confirmation. Authorization to generate and approval of the resulting master are separate checks.

Record baseline permission in `source.master_approval`: `APPROVED`, `SUPPLIED_FOR_SEPARATION`, `PENDING`, or `UNKNOWN`, plus the evidence and applicable source/version. A user-provided image explicitly designated for separation can use `SUPPLIED_FOR_SEPARATION` without another approval request. A newly generated/replacement master needs `APPROVED` for that specific result before separation uses it. `PENDING`/`UNKNOWN` cannot support a ready asset package. None of these states implies approval of finished animation quality.

An editable restoration mask is distinct from a layered illustration project. Keep the actual hidden-fill/extraction masks used for edits; lossless mask images may supplement the PSD but do not replace its required working layers. Document their paths and relation to source pixels/restored regions when restoration was performed. If no restoration was needed, record that fact instead of inventing masks. A `NOT_PRODUCED` layered-file declaration does not excuse missing restoration evidence.

Each issue identifies part IDs, region/crop, time/frame or pose, symptom, evidence, and next repair. Mark causes `observed`, `inferred`, or `unknown`. Pixels visibly remaining on a hair layer prove an ownership problem; a residual seam screenshot alone does not prove its precise rigging cause.

Separate process checks from art checks: a skill can pass format/link validation without producing a finished rig; successful compilation can coexist with motion defects.

## Portable deliverables

Keep established project layouts. For a new delivery:

```text
character-id/
  source/                 Immutable original and approved master
  editable/               Actual working layer/mask files, if produced
  parts/                  Transparent exports
  review/                 Neutral comparison, join crops, motion evidence
  handoff.json            Relative paths and validation state
```

Do not include unrelated project assets, logs, credentials, or engine installations. Packages must not depend on the author's absolute paths. Only include art authorized for that delivery. Skill diagnostic images are not a reusable character asset library.

Use [handoff-template.json](../assets/handoff-template.json) when no established manifest exists. Fill values from observations; keep unperformed checks `NOT_RUN`. Apply the state-specific requirements above: conditional/optional unknowns do not automatically block a ready state. This template is not a completed delivery.

Minimum fields for each `parts` entry:

| Fields | Meaning |
|---|---|
| `id`, `file`, `draw_order` | Unique stable ID, relative image path, back-to-front numeric order. |
| `semantic_region`, `attachment` | Owned region and attachment part ID or documented fixed anchor. |
| `source_region`, `occluded_fill` | Extraction mask/region and restored-area mask/description. Distinguish source pixels from synthesized hidden artwork. |
| `motion`, `depth_relations` | Intended motion and neighboring front/back relationships. |
| `offset_px`, `pivot` | Position convention. Full-canvas parts use `[0, 0]` offsets. Record pivot values/units only if applicable; unmeasured pivots are not verified. |

Declare canvas and origin globally unless overridden. Define image-space versus anatomical left/right. For Unity, add agreed PPU, texture limit/compression, and pivot convention; do not copy the trial's dimensions or PPU to unrelated art.

Name the next action: repair a specific asset defect, bind parts for an idle test, or integrate a validated package. Unfinished restoration must not be disguised as a downstream rigger's responsibility.
