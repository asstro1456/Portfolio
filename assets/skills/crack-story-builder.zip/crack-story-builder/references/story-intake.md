# Crack story intake

Use this compact manifest when the user wants browser-assisted, repeatable registration. `action: draft` means save only; `action: publish` authorizes the final public registration for this exact story. Treat every quality section below as part of the intake; preserve matching live content only when a section is intentionally omitted.

```yaml
action: draft # draft | publish
title: ""
one_line: ""
profile_image: "" # local path, if replacing

template: ""
story_settings: ""
examples: [] # optional, up to 3 user/character pairs

start_settings:
  - name: ""
    prologue: ""
    situation: ""
    player_guide: ""
    suggested_replies: [] # up to 3
    stats: []

endings: [] # include image path or approved generation brief for every ending
media: [] # include image paths or approved generation briefs
keyword_notes: []
slash_commands: []

registration:
  description: ""
  genre: ""
  target: ""
  dialogue_form: ""
  recommended_mode: ""
  output_length: ""
  tags: []
  user_tier: "" # set once; choose deliberately
  visibility: "private" # public | private | link-only
  comments_enabled: false
```

## Minimum publish gate

Before `action: publish`, verify that the live UI has every visible required field completed: profile image, name, one-line introduction, story template/settings, first start setting, and registration fields marked `*`. Then complete a quality pass for stats, media, keyword notes, slash commands, and endings. If an image asset or a creative decision is missing, pause once with a consolidated list instead of inventing it or repeatedly asking section by section.

Browser automation can reliably fill and save this manifest after the user is logged in. Do not describe it as an API or unattended background publishing workflow; Crack currently exposes this work through its UI.
