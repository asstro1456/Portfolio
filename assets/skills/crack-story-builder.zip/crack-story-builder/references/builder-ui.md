# Crack Story Builder — current UI map

Last checked: 2026-09-14. These are observed UI constraints, not permanent product guarantees. Inspect the live screen before acting.

## Global behavior

- Builder steps: 프로필 → 스토리 설정 → 시작 설정 → 스탯 설정 → 미디어 → 키워드북 → 단축어 → 엔딩 설정 → 등록.
- Every step has `임시저장`; verify the `임시저장이 완료되었어요` notice after a change.
- `등록하기` is the publishing action. It is different from temporary saving.

## Profile

- Profile image: required; current UI states 5 MB maximum and 1,080 × 1,620 px.
- Name: required, 2–30 characters; special characters and emoji are excluded.
- One-line introduction: required, maximum 30 characters.
- The page offers random generation, image upload, image generation, and image deletion. Do not use random or generation unless asked.

## Story settings

- Select a prompt template; changing it says existing input is retained.
- `스토리 설정 및 정보`: required, maximum 5,000 characters.
- Example dialogues: up to 3. Each user and story example field currently has a 500-character limit.
- Auto-generation and advanced settings exist; they are optional.

## Starting settings and stats

- Multiple starting settings can be added. The first starting setting governs the profile image code / preview basis.
- Per starting setting: prologue 1,000 characters, starting-setting name 12 characters, starting situation 1,000 characters, player guide 500 characters, and up to 3 suggested first replies of 200 characters each.
- Stats are scoped by starting setting. A starting setting supports at most 7 stats.

## Media, keyword book, and slash commands

- Situation images can apply to every start setting or one specific setting. Upload file names use `분류_상황` so Crack classifies them automatically. Current limit: up to 1,000 images per upload, 5 MB each; the image placement table permits up to 1,600 images and 80 category/situation entries.
- Keyword notes can be global or start-setting-specific. Crack loads a note when a story or user message contains its keyword.
- Slash commands support up to 20 per work.

## Endings

- Endings are scoped by starting setting; the current UI allows up to 10 per start setting. Available grades are dynamic, so inspect enabled grade buttons rather than assuming SR/SSR availability.
- Condition checks run every 5 turns and cannot start before turn 10. The rule editor is the numeric gate; the prompt determines the actual narrative decision.
- Current text limits: prompt 500, epilogue 1,000, hint 20 characters.
- Ending image is required. Current UI says 5 MB maximum and card size 1,005 × 1,490 px. After file selection, an `이미지 자르기` dialog appears; use `자르기` to apply it, then verify the image appears in the ending preview before saving.

## Registration

- Detailed description: required, maximum 1,000 characters.
- Select genre, target audience, dialogue form, recommended mode, output-length mode, and up to 10 hashtags.
- User tier is set once and cannot be changed. Selecting the all-ages option displays a policy warning; keep content free of sexual, graphic violent, criminal, drug, or excessive-profanity descriptions before confirming it.
- Visibility choices are public, private, and link-only. Preserve the existing visibility unless the user requests a change.
