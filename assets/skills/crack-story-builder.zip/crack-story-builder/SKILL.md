---
name: crack-story-builder
description: "Create or edit stories in the Crack Story Builder with current UI constraints, efficient reuse of existing content, and safe publishing boundaries. Use for Crack story-builder setup, content entry, ending setup, or registration."
---

# Crack Story Builder

Use this skill for Crack's **story** builder. It is not an API or an MCP integration; operate the visible builder UI.

Before work, read [the current builder map](references/builder-ui.md). Treat it as a tested reference, not a substitute for the live UI: inspect the current page before entering or changing a value.

For worldbuilding, character, dialogue, or branching review and drafting, use [Fiction Workbench](../fiction-workbench/SKILL.md) to select the relevant installed craft skills. Review-only requests do not authorize editing the live story; the builder UI is a source for the current settings.

## Efficient workflow

- Maintain a compact in-chat working state: requested fields, confirmed creative decisions, current step, and unsaved changes. Reuse existing values that already match; do not retype the full story specification or produce optional prose.
- Work only on requested sections. Use built-in generation only when the user asks for it; otherwise write or revise the supplied content directly.
- After completing an edited section, use **임시저장** and verify its completion notice. Do not revisit already verified sections without a requested change.
- Follow visible limits and controls over this reference. If a field or option is absent, do not invent a workaround; explain the changed UI briefly and ask only for the decision that the UI genuinely requires.
- For repeated work, accept the compact [story intake](references/story-intake.md) as the single source of truth. Preserve matching live values, but run every quality section—stats, media, keyword notes, slash commands, and endings—before calling a story complete.

## Quality pass

Treat stats, media, keyword notes, slash commands, and endings as the standard story-quality pass, not as features to silently skip. Fill them from the intake or preserve their existing matching content. If a new story lacks content for one or more of these sections, report the missing sections together before publishing; never invent decisive lore, endings, or image assets merely to satisfy the checklist.

## Decisions that need care

- Distinguish a **story** from a **character**. A request to register a character does not authorize publishing a similarly named story. Verify the asset type in `내 작품` when it matters.
- `등록하기` is publication, not a draft save. Use it only when the user explicitly asks to register or publish the identified asset. Confirm the selected title and visibility immediately before this action.
- Treat the user-tier choice as irreversible. If the user has chosen all ages, keep story prose and visual direction non-graphic; do not change the tier later without a new instruction.
- For uploads, use the platform's crop/apply step after choosing a file. Do not treat file selection alone as a completed upload.

## Scope

Do not claim a Crack-specific API, MCP, or official skill exists unless it is actually connected in the current environment. Browser UI operation is the default path.
