import contextlib
import io
import json
import os
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

import render_gdd


class RenderOutputSafetyTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.root = Path(self.temp.name)
        self.source = self.root / 'input.json'
        self.template = self.root / 'template.html'
        data = dict(document=dict(title='원본',subtitle='보존 확인',status='초안',version='1',date='2026-10-23'),
            project_meta=[dict(label='종류',value='합성 테스트')],summary='원본 보존 회귀 검증',
            sections=[dict(id='test-section',title='검증',blocks=[dict(type='paragraph',text='합성 입력')])])
        self.source.write_text(json.dumps(data,ensure_ascii=False), encoding='utf-8')
        self.template.write_text('<main>{{TITLE}}</main>', encoding='utf-8')
        self.original_source = self.source.read_bytes()
        self.original_template = self.template.read_bytes()

    def tearDown(self):
        self.temp.cleanup()

    def run_renderer(self, output):
        argv = ['render_gdd.py', str(self.source), '--template', str(self.template), '-o', str(output)]
        with patch('sys.argv', argv), \
                contextlib.redirect_stdout(io.StringIO()), contextlib.redirect_stderr(io.StringIO()):
            return render_gdd.main()

    def test_input_json_cannot_be_used_as_output(self):
        self.assertEqual(self.run_renderer(self.source), 2)
        self.assertEqual(self.source.read_bytes(), self.original_source)

    def test_template_cannot_be_used_as_output(self):
        self.assertEqual(self.run_renderer(self.template), 2)
        self.assertEqual(self.template.read_bytes(), self.original_template)

    def test_hard_link_alias_of_input_cannot_be_used_as_output(self):
        alias = self.root / 'alias.html'
        try:
            os.link(self.source, alias)
        except OSError as error:
            self.skipTest(str(error))
        self.assertEqual(self.run_renderer(alias), 2)
        self.assertEqual(self.source.read_bytes(), self.original_source)

    def test_separate_output_preserves_both_original_files(self):
        output = self.root / 'result.html'
        self.assertEqual(self.run_renderer(output), 0)
        self.assertEqual(output.read_text(encoding='utf-8'), '<main>원본</main>')
        self.assertEqual(self.source.read_bytes(), self.original_source)
        self.assertEqual(self.template.read_bytes(), self.original_template)


if __name__ == '__main__':
    unittest.main()
