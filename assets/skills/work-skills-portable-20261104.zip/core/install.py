"""Verify the portable bundle and optionally install its skills without overwriting."""
import argparse
import hashlib
import json
from pathlib import Path, PurePosixPath
import sys


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def contained(root, relative):
    parts = PurePosixPath(relative)
    if parts.is_absolute() or ".." in parts.parts or "\\" in relative or ":" in relative:
        raise ValueError("Invalid manifest path: " + relative)
    path = root.joinpath(*parts.parts)
    if not path.resolve().is_relative_to(root.resolve()):
        raise ValueError("Path escapes selected directory: " + relative)
    return path


def install(bundle, target, apply=False):
    manifest = json.loads((bundle / "MANIFEST.json").read_text(encoding="utf-8"))
    planned = []
    seen = set()
    for item in manifest["files"]:
        relative = item["path"]
        if relative in seen:
            raise ValueError("Duplicate manifest path: " + relative)
        seen.add(relative)
        source = contained(bundle, relative)
        if not source.is_file() or digest(source) != item["sha256"]:
            raise ValueError("Package integrity mismatch: " + relative)
        if not relative.startswith("skills/"):
            continue
        skill_relative = relative[len("skills/"):]
        destination = contained(target, skill_relative)
        parent = destination.parent
        while parent != target:
            if parent.exists() and not parent.is_dir():
                raise ValueError("Destination parent is a file: " + str(parent))
            parent = parent.parent
        if target.exists() and not target.is_dir():
            raise ValueError("Target is not a directory: " + str(target))
        if destination.exists():
            if not destination.is_file() or digest(destination) != item["sha256"]:
                raise ValueError("Existing content differs; no files written: " + str(destination))
        else:
            planned.append((source, destination))
    if not seen or not any(p.startswith("skills/") for p in seen):
        raise ValueError("No skills in package manifest")
    print("Verified package. New files:", len(planned))
    print("Target:", target)
    if not apply:
        print("PLAN ONLY. Pass --install to copy. Existing files are never overwritten.")
        return len(planned)
    for source, destination in planned:
        destination.parent.mkdir(parents=True, exist_ok=True)
        with destination.open("xb") as output:
            output.write(source.read_bytes())
        if digest(destination) != digest(source):
            raise OSError("Installed hash mismatch: " + str(destination))
    print("Installed new files:", len(planned), "; existing identical files preserved.")
    return len(planned)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--install", action="store_true")
    parser.add_argument("--target", type=Path, default=Path.home() / ".agents" / "skills")
    args = parser.parse_args()
    try:
        install(Path(__file__).resolve().parent, args.target.expanduser().resolve(), args.install)
    except (OSError, ValueError, KeyError, TypeError) as error:
        print("STOP:", error, file=sys.stderr)
        return 1
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
