---
name: work-text-safety
description: Read and modify Korean or other non-ASCII text without corrupting encoding, BOM, line endings, or unrelated content. Use when encoding is uncertain, output looks garbled, or a narrow section must change on Windows or Mac.
---

# 업무 텍스트 안전 처리

현재 회사 지침과 승인된 작업 범위를 먼저 따른다. 읽기·진단 요청만 있으면 파일을 바꾸지 않는다.

1. 표시가 깨지면 해석·수정을 멈추고 원본 바이트를 다시 읽는다. 깨진 화면 문자열을 역추정해 덮어쓰지 않는다.
2. UTF-8 문서는 인코딩을 명시해 엄격하게 읽는다. BOM 가능성이 있으면 Python의 `encoding="utf-8-sig", errors="strict"`를 사용할 수 있다. 대체문자나 무시 옵션으로 오류를 숨기지 않는다.
3. UTF-8 해석에 실패하면 읽기 전용으로 BOM과 실제 인코딩을 확인한다. UTF-16·CP949 등 다른 인코딩 가능성과 미확인을 구분하고, 파일 변환은 별도 요청이 있을 때만 한다.
4. 필요한 구획의 정확한 시작·끝을 확인한 뒤 그 부분만 수정한다. 환경에 `apply_patch`가 있으면 사용한다. 없으면 사용 가능한 편집 도구로 최소 수정하고 같은 보존 조건을 확인한다.
5. 수정 후 원본 인코딩·BOM·줄바꿈과 인접 구획·무관한 바이트가 보존됐는지 재조회한다. 출력 표시만 고치기 위해 파일을 저장하지 않는다.

PowerShell에서는 `Get-Content -LiteralPath <파일> -Encoding UTF8`처럼 인코딩을 지정하되, 이 명령만으로 잘못된 바이트가 반드시 오류로 검출된다고 가정하지 않는다. 엄격한 검증은 Python의 `Path(...).read_text(encoding="utf-8-sig", errors="strict")`나 .NET의 `UTF8Encoding(false, true)` 같은 오류 검출 디코더를 사용한다. 시스템 기본 인코딩이나 손실 허용 읽기에 의존하지 않는다. 도구가 없으면 설치를 자동 시작하지 말고 사용 가능한 읽기 경로와 검증 한계를 알린다.
