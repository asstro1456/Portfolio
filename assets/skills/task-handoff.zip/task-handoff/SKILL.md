---
name: task-handoff
description: Prepare concise instructions when the user requests handing work to another task, chat, assistant, or tool. Reuse one handoff record; a request for only a copyable message needs no file. Do not trigger merely on conversation ending or context compression.
---

# 작업 간 인수인계

## 적용 조건

- 사용자가 다른 작업·채팅·도구로 업무를 넘길 인수인계를 요청한 경우에 사용한다.
- 복사용 문장만, 채팅 답변만, 단순 요약을 요청하면 파일 없이 답한다.
- 일반 대화, 종료, 아카이브, 컨텍스트 압축을 이유로 인수인계 파일을 자동 생성하지 않는다. 매번 보관 여부를 묻지 않는다.
- 단순 파일 보관은 `preserve-chat-summary`를 사용한다. 같은 요청에 인수인계와 대화 요약을 중복 저장하지 않는다.

## 저장 위치와 갱신

사용자가 지정한 경로를 우선한다. 없으면 같은 프로젝트·작업에서 사용하던 인수인계 문서를 갱신한다. 새 문서가 필요하면 활성 프로젝트의 `chat_summaries/`, 프로젝트가 없으면 `C:\Users\User\.codex\chat_summaries\` 중 한 곳에 `YYYY-MM-DD_task_handoff_주제.md`로 저장한다.

최신 작업 지시는 문서 상단에서 자체적으로 이해할 수 있게 유지한다. 기존 문서의 `<!-- LATEST_TASK_INSERT_BELOW -->` 등 구획이 있으면 그대로 사용한다. 변경할 구획 밖의 기존 이력과 무관한 기록은 보존하고, 매 후속 대화마다 새 파일이나 누적 이력을 추가하지 않는다.

## 최소 내용

- 목표와 확정된 결정·제약
- 현재 상태와 확인된 검증 결과
- 대상 파일·자료의 경로 또는 링크
- 미해결 사항과 실제 위험
- 다음 행동과 완료 기준

요청 규모에 맞게 필요한 항목만 작성한다. 상세 지침과 과거 대화 전체를 복제하지 않는다. 사실·미확인을 구분하며, 인수인계 요청을 대상 코드·외부 문서 변경이나 다른 채팅으로 메시지를 보내라는 승인으로 확대하지 않는다.

## 전달과 읽기

저장 결과를 한 번 확인하고 파일 링크와 짧은 복사용 전달 문장을 제공한다. 전달 문장에는 문서 경로, 읽을 최신 구획, 다음 행동, 핵심 제한만 넣는다. 지원되는 환경에서는 `chat_message` 작성 블록을 사용한다.

받는 작업은 현재 대화와 관련 파일만으로 필요한 맥락이 부족할 때 관련 인수인계 문서 1개의 최신 구획부터 읽는다. 필요한 맥락이 이미 있으면 다시 읽지 않고, 과거 이력은 구체적인 빈틈을 해결할 때만 추가로 읽는다.
