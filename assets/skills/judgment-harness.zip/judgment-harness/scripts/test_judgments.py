import json
import sqlite3
from contextlib import closing
import tempfile
import unittest
import zipfile
from pathlib import Path

import judgments as j


class JudgmentTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.root = Path(self.tmp.name)
        self.db = j.connect(self.root / 'test.sqlite3', create=True)
        self.source = j.add_source(self.db, dict(project='projectut', role='user',
            origin='test-conversation/message-1', observed_at='2026-10-19',
            text='플레이 모드는 켜지 마라. 다른 세션 작업 방해된다.'))

    def tearDown(self):
        self.db.close()
        self.tmp.cleanup()

    def decision(self, **changes):
        data = dict(project='projectut', domain='vfx', target='*', status='confirmed',
                    decision='플레이 모드를 켜지 않는다.', reason_kind='user_stated',
                    reason='다른 작업 보호', reason_quote='다른 세션 작업 방해된다.',
                    source_id=self.source, quote='플레이 모드는 켜지 마라.')
        data.update(changes)
        return data

    def export(self):
        conv = dict(id='conversation-1', title='합성 테스트', current_node='chosen', mapping={
            'root': dict(parent=None, message=None),
            'chosen': dict(parent='root', message=dict(id='m1', author=dict(role='user'),
                create_time=1, content=dict(parts=['선택한 사용자 판단']))),
            'other': dict(parent='root', message=dict(id='m2', author=dict(role='user'),
                content=dict(parts=['선택하지 않은 판단']))),
            'assistant': dict(parent='chosen', message=dict(id='m3', author=dict(role='assistant'),
                content=dict(parts=['제안일 뿐']))),
        })
        path = self.root / 'conversations.json'
        path.write_text(json.dumps([conv], ensure_ascii=False), encoding='utf-8')
        return path

    def test_scope_and_korean_search(self):
        rid = j.add_judgment(self.db, self.decision())
        self.assertEqual(j.search(self.db, 'projectut', '플레이')['results'][0]['id'], rid)
        self.assertEqual(j.search(self.db, 'crack', '플레이')['results'], [])
        self.assertEqual(j.search(self.db, 'projectut', domain='writing')['results'], [])

    def test_read_only_connection_cannot_write_even_if_query_only_is_disabled(self):
        self.db.commit()
        with closing(j.connect(self.root / 'test.sqlite3', read_only=True)) as reader:
            self.assertEqual(j.get(reader, self.source)['project'], 'projectut')
            reader.execute('PRAGMA query_only=OFF')
            with self.assertRaises(sqlite3.OperationalError):
                reader.execute('DELETE FROM records')
        missing = self.root / 'missing.sqlite3'
        with self.assertRaises(ValueError):
            j.connect(missing, read_only=True)
        self.assertFalse(missing.exists())
        with self.assertRaises(ValueError):
            j.connect(missing, create=True, read_only=True)

    def test_source_summary_retains_original_text_and_provenance_without_raw_export(self):
        source = j.get(self.db, self.source)
        source['payload']['raw'] = {'unrelated_export': 'must not be returned'}
        summary = j.select_fields(source, summary=True)
        for key in ('text', 'role', 'origin', 'observed_at'):
            self.assertEqual(summary['payload'][key], source['payload'][key])
        self.assertNotIn('raw', summary['payload'])

    def test_pending_hidden(self):
        j.add_judgment(self.db, self.decision(status='hypothesis'))
        self.assertEqual(j.search(self.db, 'projectut')['results'], [])
        self.assertEqual(len(j.search(self.db, 'projectut', include_pending=True)['results']), 1)

    def test_search_reason_points_to_decision_without_duplicating_its_excerpt(self):
        j.add_judgment(self.db,self.decision())
        result=j.search(self.db,'projectut','플레이')['results'][0]
        self.assertEqual(result['match'],{'field':'decision'})
        self.assertNotIn('match',j.search(self.db,'projectut')['results'][0])

    def test_search_reason_shows_quote_only_match_and_bounds_long_context(self):
        j.add_judgment(self.db,self.decision(decision='사용자 지침을 유지한다.'))
        result=j.search(self.db,'projectut','플레이')['results'][0]
        self.assertEqual(result['match']['field'],'quote')
        self.assertIn('플레이',result['match']['snippet'])
        payload={'decision':'검색과 무관','context_refs':[{'quote':'앞'*3000+'고유키워드'+'뒤'*3000}]}
        reason=j.match_reason(payload,['고유키워드'],'검색과 무관')
        self.assertEqual(reason['field'],'context_refs[0].quote')
        self.assertLessEqual(len(reason['snippet']),100)
        self.assertIn('고유키워드',reason['snippet'])

    def test_metadata_only_match_is_not_described_as_user_utterance(self):
        reason=j.match_reason({'decision':'내용','unique_metadata':False},['unique_metadata'],'내용')
        self.assertEqual(reason['field'],'serialized_metadata')
        self.assertLessEqual(len(reason['snippet']),100)

    def test_target_not_global(self):
        j.add_judgment(self.db, self.decision(target='aileen'))
        self.assertEqual(j.search(self.db, 'projectut')['results'], [])
        self.assertEqual(j.search(self.db, 'projectut', target='rishar')['results'], [])
        self.assertEqual(len(j.search(self.db, 'projectut', target='aileen')['results']), 1)

    def test_quote_and_reason_evidence(self):
        with self.assertRaises(ValueError):
            j.add_judgment(self.db, self.decision(quote='없는 인용'))
        with self.assertRaises(ValueError):
            j.add_judgment(self.db, self.decision(reason_quote='추측한 이유'))

    def test_reason_context_cannot_use_assistant_or_other_project(self):
        for role,project in [('assistant','projectut'),('user','crack')]:
            sid=j.add_source(self.db,dict(project=project,role=role,origin='reason-test',
                observed_at='unknown',text='다른 작업 보호'))
            with self.subTest(role=role,project=project),self.assertRaises(ValueError):
                j.add_judgment(self.db,self.decision(reason_source_id=sid,reason_quote='다른 작업 보호',
                    context_refs=[dict(source_id=sid,quote='다른 작업 보호',relation='previous')]))

    def test_reason_context_must_be_explicitly_linked(self):
        sid=j.add_source(self.db,dict(project='projectut',role='user',origin='reason-test',
            observed_at='unknown',text='다른 작업 보호'))
        with self.assertRaises(ValueError):
            j.add_judgment(self.db,self.decision(reason_source_id=sid,reason_quote='다른 작업 보호'))

    def test_readback_includes_reason_outside_primary_quote(self):
        from retrieval import retrieve
        rid=j.add_judgment(self.db,self.decision())
        item=next(x for x in retrieve(self.db,'projectut',target='*',query='플레이')['results'] if x['id']==rid)
        self.assertTrue(item['source_review']['complete'])
        self.assertEqual([x['quote'] for x in item['source_review']['sources']],
                         ['플레이 모드는 켜지 마라.','다른 세션 작업 방해된다.'])
        self.assertEqual(item['user_reason_source_id'],self.source)

    def test_no_assistant_confirmation_or_cross_project_promotion(self):
        source = j.add_source(self.db, dict(project='projectut', role='assistant', origin='test',
                                          observed_at='today', text='플레이 모드는 켜지 마라.'))
        with self.assertRaises(ValueError):
            j.add_judgment(self.db, self.decision(source_id=source))
        with self.assertRaises(ValueError):
            j.add_judgment(self.db, self.decision(project='global'))

    def test_supersession_preserves_history_and_retries(self):
        first = j.add_judgment(self.db, self.decision())
        next_data = self.decision(decision='수정된 판단', supersedes=first, change_reason='테스트 수정')
        second = j.add_judgment(self.db, next_data)
        self.assertEqual(j.add_judgment(self.db, next_data), second)
        self.assertEqual(j.get(self.db, first)['payload']['decision'], '플레이 모드를 켜지 않는다.')
        self.assertEqual([r['id'] for r in j.search(self.db, 'projectut')['results']], [second])
        with self.assertRaises(ValueError):
            j.add_judgment(self.db, self.decision(target='other', supersedes=second, change_reason='범위 다름'))

    def test_document_snapshot_is_reference_and_latest_only(self):
        path = self.root / '판단.md'
        path.write_text('# 기준\n\n## 항목\n이전 판단', encoding='utf-8')
        old = j.import_markdown(self.db, path, 'crack', 'creative')
        again = j.import_markdown(self.db, path, 'crack', 'creative')
        self.assertEqual(old, again)
        path.write_text('# 기준\n\n## 항목\n새 판단', encoding='utf-8')
        j.import_markdown(self.db, path, 'crack', 'creative')
        self.assertEqual(j.search(self.db, 'crack', '이전')['results'], [])
        result = j.search(self.db, 'crack', '새 판단')['results'][0]
        self.assertEqual(result['kind'], 'reference')
        self.assertIn('이전 판단', j.get(self.db, old['source_id'])['payload']['text'])

    def test_export_catalog_does_not_import(self):
        result = j.import_export(self.db, self.export(), [], 'unclassified')
        self.assertFalse(result['imported'])
        self.assertEqual(self.db.execute("SELECT COUNT(*) FROM records WHERE kind='message'").fetchone()[0], 0)

    def test_export_branch_role_and_idempotency(self):
        path = self.export()
        j.import_export(self.db, path, ['conversation-1'], 'projectut')
        j.import_export(self.db, path, ['conversation-1'], 'projectut')
        messages = [j.get(self.db, r[0]) for r in self.db.execute("SELECT id FROM records WHERE kind='message'")]
        self.assertEqual(len(messages), 3)
        chosen = next(r for r in messages if r['payload']['node_id'] == 'chosen')
        other = next(r for r in messages if r['payload']['node_id'] == 'other')
        j.evidence(self.db, dict(source_id=chosen['id'], quote='선택한'), True)
        with self.assertRaises(ValueError):
            j.evidence(self.db, dict(source_id=other['id'], quote='판단'), True)
        self.assertEqual(j.search(self.db, 'projectut')['results'], [])

    def test_zip_read_without_extraction(self):
        path = self.export()
        archive = self.root / 'export.zip'
        with zipfile.ZipFile(archive, 'w') as output:
            output.write(path, 'folder/conversations.json')
        self.assertEqual(j.read_export(path), j.read_export(archive))
        self.assertFalse((self.root / 'folder').exists())

    def test_export_cannot_be_global(self):
        with self.assertRaises(ValueError):
            j.import_export(self.db, self.export(), ['conversation-1'], 'global')

    def test_superseded_prediction_evidence_rejected(self):
        old = j.add_judgment(self.db, self.decision())
        j.add_judgment(self.db, self.decision(status='rejected', supersedes=old, change_reason='테스트'))
        with self.assertRaises(ValueError):
            j.predict(self.db, dict(project='projectut', domain='vfx', target='*',
                      task='test', prediction='test', judgment_ids=[old]))

    def test_malformed_export_rolls_back(self):
        self.db.commit()
        path = self.export()
        convs = json.loads(path.read_text(encoding='utf-8'))
        convs.append(dict(id='broken', mapping={}, current_node='missing'))
        path.write_text(json.dumps(convs), encoding='utf-8')
        with self.assertRaises(ValueError), self.db:
            j.import_export(self.db, path, ['conversation-1', 'broken'], 'projectut')
        self.assertEqual(self.db.execute("SELECT COUNT(*) FROM records WHERE kind='message'").fetchone()[0], 0)

    def test_prediction_then_feedback_not_retroactive(self):
        rid = j.add_judgment(self.db, self.decision())
        pred = j.predict(self.db, dict(project='projectut', domain='vfx', target='*',
                         task='preview', prediction='Play 없이 확인해야 함', judgment_ids=[rid]))
        data = dict(prediction_id=pred, outcome='matched', analysis='사용자 표현과 비교',
                    source_id=self.source, quote='플레이 모드는 켜지 마라.')
        with self.assertRaises(ValueError):
            j.feedback(self.db, data)
        newer = j.add_source(self.db, dict(project='projectut', role='user', origin='test-new',
                         observed_at='2026-10-19', text='미리보기로 확인해줘'))
        fid = j.feedback(self.db, dict(data, source_id=newer, quote='미리보기로 확인해줘'))
        self.assertEqual(j.get(self.db, fid)['status'], 'matched')

    def test_sql_characters_and_output_bounds(self):
        j.add_judgment(self.db, self.decision())
        self.assertEqual(j.search(self.db, "'; DROP TABLE records; --")['results'], [])
        with self.assertRaises(ValueError):
            j.search(self.db, 'projectut', limit=100)
        self.assertTrue(j.get(self.db, self.source))


if __name__ == '__main__':
    unittest.main()
