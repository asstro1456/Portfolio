import copy
import json
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

import judgments as j
from evaluation import check_interpretation
from test_batch import packet


class InterpretationTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.path = Path(self.temp.name) / 'interpretation.sqlite3'
        self.db = j.connect(self.path, create=True)
        saved = j.save_batch(self.db, packet())['results']
        self.sid, self.rid = saved[0]['id'], saved[-1]['id']
        source = j.get(self.db, self.sid)
        self.case = dict(name='fixture-referent', scope=dict(project='projectut', domain='vfx', target='vision-blur'),
            sources=[dict(source_id=self.sid, quote=source['payload']['text'], fingerprint=source['fingerprint'])],
            review_note='Synthetic source-linked structured interpretation, not a real production assessment.',
            expected=dict(target='vision-blur', actions=dict(character_motion='preserve')),
            forbidden=[dict(target='vision-blur', actions=dict(character_motion='freeze'))],
            response=None, retrieval=dict(query=dict(project='projectut', domain='vfx', target='vision-blur'), expected_ids=[self.rid]))

    def tearDown(self):
        self.db.close(); self.temp.cleanup()

    def check(self, case=None):
        return check_interpretation(self.db, dict(evaluation_kind='interpretation_regression',
            expected_by='agent_source_review', cases=[case or self.case]))

    def test_search_success_is_not_interpretation_success(self):
        self.case['response'] = copy.deepcopy(self.case['forbidden'][0])
        result = self.check()
        self.assertEqual(result['retrieval_passed'], 1)
        self.assertEqual(result['interpretation_passed'], 0)
        self.assertFalse(result['passed'])
        self.assertFalse(result['independent_accuracy_measured'])

    def test_missing_response_is_unmeasured_and_correct_submission_is_replay_only(self):
        result = self.check()
        self.assertEqual(result['interpretation_evaluated'], 0)
        self.assertFalse(result['passed'])
        self.case['response'] = copy.deepcopy(self.case['expected'])
        before = self.db.total_changes
        self.assertTrue(self.check()['passed'])
        self.assertEqual(before, self.db.total_changes)

    def test_wrong_target_missing_action_or_extra_action_fails(self):
        for changes in [dict(target='other'), dict(actions=dict(character_motion='freeze')),
                        dict(actions=dict(character_motion='preserve', unrelated='remove'))]:
            self.case['response'] = dict(self.case['expected'], **changes)
            with self.subTest(changes=changes): self.assertFalse(self.check()['passed'])

    def test_stale_quote_scope_and_missing_negative_are_rejected(self):
        for kind in ['fingerprint', 'quote', 'scope', 'forbidden', 'source']:
            case = copy.deepcopy(self.case)
            if kind in ('fingerprint', 'quote'): case['sources'][0][kind] = 'stale'
            elif kind == 'scope': case['scope']['project'] = 'crack'
            elif kind == 'source': case['sources'] = []
            else: case['forbidden'] = []
            with self.subTest(kind=kind), self.assertRaises(ValueError): self.check(case)

    def test_real_case_specs_have_originals_targets_and_wrong_answers_without_fabricated_results(self):
        data = json.loads((Path(j.__file__).parents[1] / 'examples/interpretation-cases.json').read_text(encoding='utf-8'))
        self.assertEqual(len(data['cases']), 2)
        for case in data['cases']:
            self.assertTrue(case['sources'] and case['expected'] and case['forbidden'])
            self.assertIsNone(case['response'])

    def test_cli_readonly_exit_status_for_failure_and_success(self):
        self.db.commit(); before = self.path.read_bytes()
        for response, code in [(self.case['forbidden'][0], 1), (self.case['expected'], 0), (None, 1)]:
            self.case['response'] = response
            result = subprocess.run([sys.executable, '-B', '-X', 'utf8', j.__file__, '--db', str(self.path),
                'check-interpretation', '--input', '-'], input=json.dumps(dict(evaluation_kind='interpretation_regression',
                    expected_by='agent_source_review', cases=[self.case])), capture_output=True, encoding='utf-8')
            self.assertEqual(result.returncode, code, result.stderr)
            self.assertFalse(json.loads(result.stdout)['database_writes'])
        self.assertEqual(before, self.path.read_bytes())


if __name__ == '__main__': unittest.main()
