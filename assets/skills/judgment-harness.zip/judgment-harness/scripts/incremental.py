"""Persist agent-reviewed utterances and resume safely across process boundaries."""
import argparse
import hashlib
import json
import os
import sqlite3
import sys
import tempfile
from datetime import datetime, timezone
from pathlib import Path

import judgments as j

CHECKPOINT = Path('D:/CodexData/judgment-data/pre-reset/checkpoint.json')


def source_data(raw):
    for key in ('backend', 'conversation_id', 'message_id', 'project', 'role', 'text'):
        j.required(raw, key)
    p = dict(raw)
    digest = hashlib.sha256(p['text'].encode('utf-8')).hexdigest()
    identity = f"{p['backend']}:{p['conversation_id']}:{p['message_id']}:{digest}"
    p.update(source_identity=identity, text_hash=digest,
             origin=f"{p['backend']}:thread:{p['conversation_id']}/message:{p['message_id']}/sha256:{digest}")
    p.setdefault('observed_at', 'unknown')
    return p


def find_source(db, p):
    rows = db.execute("""SELECT id,payload FROM records WHERE kind='source' AND project=? AND
        (json_extract(payload,'$.source_identity')=? OR
         (json_extract(payload,'$.conversation_id')=? AND json_extract(payload,'$.message_id')=?
          AND json_extract(payload,'$.role')=? AND json_extract(payload,'$.text')=?))""",
        (p['project'], p['source_identity'], p['conversation_id'], p['message_id'], p['role'], p['text'])).fetchall()
    ambiguous = False
    for row in rows:
        old = json.loads(row['payload'])
        backend = old.get('backend')
        if not backend:
            origin = old.get('origin', '')
            backend = next((name for name in ('codex', 'chatgpt') if origin.startswith(
                (name + ':', 'export:' + name + '.json/'))), None)
        if old.get('source_identity') == p['source_identity']:
            if backend != p['backend'] or any(old.get(k) != p[k] for k in ('conversation_id','message_id','role','text')):
                raise ValueError('Stored source identity conflicts with its backend or message fields; review the original source.')
            return row['id']
        if backend == p['backend']:
            return row['id']
        ambiguous |= backend is None
    if ambiguous:
        raise ValueError('Legacy source backend is unknown; verify its origin before reusing or duplicating this message.')
    return None


def save_checkpoint(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    with tempfile.NamedTemporaryFile(mode='w', encoding='utf-8', dir=path.parent,
                                     prefix=path.name+'.', suffix='.tmp', delete=False) as out:
        json.dump(value, out, ensure_ascii=False, indent=2)
        out.write('\n');out.flush();os.fsync(out.fileno())
        temporary = out.name
    os.replace(temporary, path)


def refresh_pending(state, packet):
    completed={x['identity'] for x in state['completed_sources']}
    pending={x['identity']:x for x in state['pending'] if x.get('identity') and x['identity'] not in completed}
    other=[x for x in state['pending'] if not x.get('identity')]
    for item in packet['items']:
        s=source_data(item['source'])
        if s['source_identity'] not in completed:
            pending.setdefault(s['source_identity'],dict(identity=s['source_identity'],backend=s['backend'],
                conversation_id=s['conversation_id'],message_id=s['message_id'],project=s['project'],
                reason='reviewed_packet_remaining'))
    state['pending']=other+list(pending.values())


def persist_one(db, item):
    source = source_data(item['source'])
    if source['role'] != 'user':
        raise ValueError('Only real user utterances may enter the incremental classification queue.')
    operations=[]
    def add_source(raw, alias):
        p=source_data(raw);rid=find_source(db,p)
        if rid:return rid
        operations.append(dict(ref=alias,command='source',data=p))
        return {'$ref':alias}
    source_id=add_source(source,'user')
    bindings={'user':source_id}
    refs=[]
    for n,ctx in enumerate(item.get('contexts',[])):
        context_id=add_source(ctx['source'],f'ctx{n}');bindings[f'ctx{n}']=context_id
        refs.append(dict(source_id=context_id,
                         quote=ctx['quote'],relation=ctx['relation']))
    def bind(value):
        if isinstance(value,dict):
            if set(value)=={'$ref'}:return bindings.get(value['$ref'],value)
            return {k:bind(v) for k,v in value.items()}
        if isinstance(value,list):return [bind(v) for v in value]
        return value
    candidate=bind(dict(item['candidate'], project=source['project'], source_id=source_id, context_refs=refs))
    candidate.setdefault('classification_version',2)
    existing=None
    if isinstance(source_id,str):
        rows=db.execute("SELECT id,payload FROM records r WHERE kind='candidate' AND "
            "json_extract(payload,'$.source_id')=? AND NOT EXISTS "
            "(SELECT 1 FROM records n WHERE n.supersedes=r.id)", (source_id,)).fetchall()
        for row in rows:
            old=json.loads(row['payload'])
            if old==candidate:existing=row['id'];break
        if rows and not existing:
            raise ValueError('Existing classification differs; review it explicitly instead of duplicating it.')
    candidate_id=existing or {'$ref':'candidate'}
    if not existing:
        operations.append(dict(ref='candidate',command='candidate',data=candidate))
    judgment_id=None
    if item.get('record'):
        record=bind(item['record'])
        if existing:
            record=j.inherit_record(j.get(db,existing),dict(record,candidate_id=existing))
            rows=db.execute("SELECT id,payload FROM records r WHERE kind='judgment' AND "
                "json_extract(payload,'$.candidate_id')=? AND NOT EXISTS "
                "(SELECT 1 FROM records n WHERE n.supersedes=r.id)",(existing,)).fetchall()
            for row in rows:
                previous=json.loads(row['payload'])
                if previous==record:
                    judgment_id=row['id'];break
            if rows and not judgment_id:
                raise ValueError('Existing judgment differs; review it explicitly instead of reusing it.')
        if not judgment_id:
            operations.append(dict(ref='rule',command='record',data=dict(record,candidate_id=candidate_id)))
    if len(operations)>50:raise ValueError('Too many context sources; split this reviewed packet.')
    result=j.save_batch(db,dict(operations=operations)) if operations else dict(results=[])
    ids={x['ref']:x['id'] for x in result['results']}
    source_id=source_id if isinstance(source_id,str) else ids['user']
    candidate_id=existing or ids['candidate'];judgment_id=judgment_id or ids.get('rule')
    row=j.get(db,candidate_id);raw=j.get(db,source_id)
    if row['payload']['quote'] not in raw['payload']['text']:
        raise ValueError('Read-back quote mismatch.')
    if judgment_id:j.get(db,judgment_id)
    return dict(identity=source['source_identity'], backend=source['backend'],
                conversation_id=source['conversation_id'], message_id=source['message_id'],
                source_id=source_id, candidate_id=candidate_id, judgment_id=judgment_id,
                new_records=len(ids), readback_verified=True)


def apply(db, packet, checkpoint_path=CHECKPOINT, max_items=20):
    if not 1<=max_items<=20:raise ValueError('max_items must be 1..20.')
    items=packet.get('items')
    if not isinstance(items,list) or not 1<=len(items)<=20:raise ValueError('Provide 1..20 reviewed items.')
    state=json.loads(checkpoint_path.read_text(encoding='utf-8')) if checkpoint_path.exists() else dict(
        version=1,completed_sources=[],threads={},pending=[],counts=dict(processed=0),current_run=None)
    refresh_pending(state,packet)
    completed={x['identity']:x for x in state['completed_sources']}
    processed=[];skipped=0
    for item in items:
        source=source_data(item['source']);identity=source['source_identity']
        if identity in completed:
            with db:
                db.execute('BEGIN IMMEDIATE')
                entry=persist_one(db,item)
                if entry['new_records'] or any(entry.get(k)!=completed[identity].get(k) for k in (
                        'source_id','candidate_id','judgment_id')):
                    raise ValueError('Completed checkpoint differs from this reviewed packet; reconcile it explicitly.')
            skipped+=1;continue
        if len(processed)>=max_items:break
        with db:
            db.execute('BEGIN IMMEDIATE')
            entry=persist_one(db,item)
        completed[identity]=entry;state['completed_sources'].append(entry)
        state.pop('note',None)
        state['counts']['processed']=len(completed)
        key=source['backend']+':'+source['conversation_id']
        thread=state['threads'].setdefault(key,{})
        thread.update(last_processed_message_id=source['message_id'],coverage_complete=False)
        state['updated_at']=datetime.now(timezone.utc).isoformat()
        state['current_run']=dict(mode=packet.get('mode','reviewed-incremental'),
                                   status='checkpointed',last_source_identity=identity)
        refresh_pending(state,packet)
        save_checkpoint(checkpoint_path,state)
        processed.append(entry)
    remaining=sum(source_data(x['source'])['source_identity'] not in completed for x in items)
    if processed:
        state['current_run'].update(status='batch_limit' if remaining else 'packet_complete',remaining_in_packet=remaining)
        save_checkpoint(checkpoint_path,state)
    return dict(processed=processed,skipped_completed=skipped,remaining_in_packet=remaining,
                checkpoint=str(checkpoint_path),total_completed=len(completed),
                stop_reason='batch_limit' if remaining else 'packet_complete',
                new_records=sum(x['new_records'] for x in processed))


def main():
    parser=argparse.ArgumentParser();parser.add_argument('--db',type=Path,default=j.DEFAULT_DB)
    parser.add_argument('--checkpoint',type=Path,default=CHECKPOINT)
    parser.add_argument('--max-items',type=int,default=20);args=parser.parse_args()
    packet=json.loads(sys.stdin.read().lstrip('\ufeff'));db=j.connect(args.db)
    try:print(json.dumps(apply(db,packet,args.checkpoint,args.max_items),ensure_ascii=False,indent=2))
    finally:db.close()


if __name__=='__main__':
    try:main()
    except (ValueError,KeyError,TypeError,OSError,sqlite3.Error) as exc:
        print(json.dumps(dict(error=str(exc)),ensure_ascii=False),file=sys.stderr);sys.exit(1)
