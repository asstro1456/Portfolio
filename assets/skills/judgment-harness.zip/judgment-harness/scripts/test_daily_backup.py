import json
import io
import tempfile
import unittest
from contextlib import closing
from datetime import datetime, timedelta, timezone
from pathlib import Path
from unittest.mock import Mock, patch

import judgments as j
from backup_github import KST, daily_backup, daily_lock, revision, snapshot, main
from test_backup_github import FakeGitHub


class DailyBackupTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory()
        self.root=Path(self.temp.name)
        self.source,self.target,self.state=[self.root/n for n in ('live.db','snapshot.db','state.json')]
        j.connect(self.source,create=True).close()
        self.now=datetime(2026,10,20,22,tzinfo=KST)
        self.api=FakeGitHub()
        self.factory=Mock(return_value=self.api)

    def tearDown(self):self.temp.cleanup()

    def run_daily(self,now=None):
        return daily_backup(self.source,self.target,self.state,self.factory,now or self.now)

    def change(self):
        with closing(j.connect(self.source)) as db:
            j.add_source(db,dict(project='projectut',role='user',origin='test-only',observed_at='test',
                                text='수정 요청을 기록한다.'))
            db.commit()

    def test_before_due_time_does_not_touch_state_or_network(self):
        result=self.run_daily(self.now.replace(hour=21,minute=59))
        self.assertIn('not_due',result['reason'])
        self.assertEqual(result['retry_after_seconds'],60)
        self.assertEqual(result['not_before'],self.now.isoformat())
        self.factory.assert_not_called()
        self.assertFalse(self.state.exists())

    def test_early_heartbeat_defers_until_due_then_backs_up_once(self):
        for minutes,seconds,micros in [(59,43,266000),(55,31,267000)]:
            early=self.now.replace(hour=21,minute=minutes,second=seconds,microsecond=micros)
            with patch('backup_github.revision') as read_source:
                result=self.run_daily(early)
                read_source.assert_not_called()
            self.factory.assert_not_called()
            self.assertFalse(self.state.exists())
            self.assertFalse(self.target.exists())
            retry=early+timedelta(seconds=result['retry_after_seconds'])
            self.assertGreaterEqual(retry,self.now)
            self.assertLess(retry-self.now,timedelta(seconds=1))
        self.assertTrue(self.run_daily(retry)['verified'])
        self.assertEqual(self.run_daily(retry)['reason'],'already_checked_today')
        self.assertEqual(self.api.updates,1)

    def test_early_utc_time_returns_kst_boundary(self):
        early=self.now.replace(hour=21,minute=59,second=43).astimezone(timezone.utc)
        result=self.run_daily(early)
        self.assertEqual(result['retry_after_seconds'],17)
        self.assertEqual(result['not_before'],'2026-10-20T22:00:00+09:00')
        self.factory.assert_not_called()

    def test_once_daily_changed_backup_then_unchanged_next_day_skips_network(self):
        self.assertTrue(self.run_daily()['verified'])
        self.change()
        self.assertEqual(self.run_daily()['reason'],'already_checked_today')
        self.assertTrue(self.run_daily(self.now+timedelta(days=1))['verified'])
        self.assertEqual(self.api.updates,2)
        self.factory.reset_mock()
        self.assertEqual(self.run_daily(self.now+timedelta(days=2))['reason'],'unchanged')
        self.factory.assert_not_called()

    def test_existing_verified_snapshot_bootstraps_without_remote_calls(self):
        snapshot(self.source,self.target.with_name('github-verified.sqlite3'))
        self.assertEqual(self.run_daily()['reason'],'unchanged')
        self.factory.assert_not_called()
        self.assertEqual(json.loads(self.state.read_text())['revision'],revision(self.source))

    def test_failure_does_not_advance_daily_state_and_can_retry(self):
        with patch('backup_github.backup',side_effect=ValueError('network failed')):
            with self.assertRaises(ValueError):self.run_daily()
        self.assertFalse(self.state.exists())
        self.assertTrue(self.run_daily()['verified'])

    def test_parallel_daily_attempt_is_skipped_and_lock_is_released(self):
        with daily_lock(self.state.with_suffix('.lock')) as acquired:
            self.assertTrue(acquired)
            self.assertEqual(self.run_daily()['reason'],'another_backup_running')
            self.factory.assert_not_called()
        self.assertTrue(self.run_daily()['verified'])

    def test_manual_before_due_records_verified_snapshot_and_preserves_schedule(self):
        early=self.now.replace(hour=10)
        result=daily_backup(self.source,self.target,self.state,self.factory,early,force=True)
        state=json.loads(self.state.read_text())
        self.assertTrue(result['verified'])
        self.assertEqual(state['last_success_at'],early.isoformat())
        self.assertEqual(state['commit'],result['commit'])
        self.assertEqual(state['revision'],revision(self.target.with_name('github-verified.sqlite3')))
        self.assertNotIn('last_run_day',state)
        self.factory.reset_mock()
        self.assertEqual(self.run_daily()['reason'],'unchanged')
        self.factory.assert_not_called()

    def test_manual_then_new_changes_are_backed_up_at_scheduled_time(self):
        daily_backup(self.source,self.target,self.state,self.factory,self.now.replace(hour=10),force=True)
        self.change()
        self.assertTrue(self.run_daily()['verified'])
        self.assertEqual(self.api.updates,2)
        self.assertEqual(self.run_daily()['reason'],'already_checked_today')

    def test_manual_bypasses_daily_limit_but_cannot_bypass_shared_lock(self):
        self.run_daily()
        self.change()
        before=self.state.read_bytes()
        self.factory.reset_mock()
        with daily_lock(self.state.with_suffix('.lock')):
            result=daily_backup(self.source,self.target,self.state,self.factory,self.now,force=True)
        self.assertEqual(result['reason'],'another_backup_running')
        self.factory.assert_not_called()
        self.assertEqual(self.state.read_bytes(),before)
        self.assertTrue(daily_backup(self.source,self.target,self.state,self.factory,self.now,force=True)['verified'])
        self.assertEqual(self.api.updates,2)

    def test_manual_failure_preserves_success_record_and_source_then_releases_lock(self):
        self.run_daily()
        self.change()
        state_before,source_before=self.state.read_bytes(),self.source.read_bytes()
        self.api.corrupt_download=True
        with self.assertRaisesRegex(ValueError,'verification failed'):
            daily_backup(self.source,self.target,self.state,self.factory,self.now,force=True)
        self.assertEqual(self.state.read_bytes(),state_before)
        self.assertEqual(self.source.read_bytes(),source_before)
        self.api.corrupt_download=False
        self.assertTrue(daily_backup(self.source,self.target,self.state,self.factory,self.now,force=True)['verified'])

    def test_manual_auth_failure_preserves_existing_backup_and_state(self):
        self.run_daily()
        self.change()
        before=[p.read_bytes() for p in (self.state,self.target,self.source)]
        for error in ['No saved GitHub account','GitHub authentication rejected (HTTP 401)']:
            with self.subTest(error=error):
                with patch('backup_github.GitHub',side_effect=ValueError(error)):
                    with self.assertRaises(ValueError):
                        daily_backup(self.source,self.target,self.state,now=self.now,force=True)
                self.assertEqual(before,[p.read_bytes() for p in (self.state,self.target,self.source)])

    def test_both_cli_modes_use_shared_backup_path(self):
        for argv,force,create in [([],False,False),(['--force'],True,False),
                                  (['--force','--create-private'],True,True)]:
            with self.subTest(argv=argv):
                with patch('backup_github.daily_backup',return_value={'verified':True}) as run:
                    with patch('sys.stdout',new_callable=io.StringIO) as output:main(argv)
                self.assertEqual(run.call_args.kwargs,{'force':force,'create':create})
                self.assertTrue(json.loads(output.getvalue())['verified'])

    def test_create_requires_manual_permission_before_any_work(self):
        with patch('backup_github.daily_backup') as run:
            with patch('sys.stderr',new_callable=io.StringIO):
                with self.assertRaises(SystemExit) as error:main(['--create-private'])
        self.assertEqual(error.exception.code,2)
        run.assert_not_called()
        with self.assertRaisesRegex(ValueError,'explicit manual'):
            daily_backup(self.source,self.target,self.state,self.factory,self.now,create=True)
        self.factory.assert_not_called()
        self.assertFalse(self.state.exists())

    def test_revision_sees_wal_changes_not_yet_checkpointed(self):
        before=revision(self.source)
        with closing(j.connect(self.source)) as db:
            db.execute('PRAGMA journal_mode=WAL')
            db.execute('PRAGMA wal_autocheckpoint=0')
            j.add_source(db,dict(project='projectut',role='user',origin='wal-test',observed_at='test',text='변경'))
            db.commit()
            self.assertNotEqual(revision(self.source),before)
            self.assertTrue(self.run_daily()['verified'])

    def test_concurrent_source_change_remains_pending_for_next_day(self):
        from backup_github import backup
        def changing_backup(*args,**kwargs):
            result=backup(*args,**kwargs)
            self.change()
            return result
        with patch('backup_github.backup',side_effect=changing_backup):
            self.run_daily()
        state=json.loads(self.state.read_text())
        self.assertNotEqual(state['revision'],revision(self.source))
        self.assertTrue(self.run_daily(self.now+timedelta(days=1))['verified'])


if __name__=='__main__':unittest.main()
