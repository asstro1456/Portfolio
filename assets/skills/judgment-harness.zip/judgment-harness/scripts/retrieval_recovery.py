"""Automatic, scoped source-delivery recovery; no criteria writes or semantic tuning."""
import copy
import json
import os
import sqlite3
import tempfile
import uuid
from contextlib import contextmanager
from pathlib import Path
from time import perf_counter

import harness_trials as trials
import judgments as j
import retrieval

ROOT = trials.OUTPUT_ROOT / 'retrieval-recovery'
MAX_BYTES = 400_000
RECOVERABLE = {'context_limit', 'related_change_limit', 'truncated_quote',
               'truncated_analysis', 'truncated_attributes'}


@contextmanager
def scope_lock(path):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('a+b') as handle:
        handle.seek(0, 2)
        if handle.tell() == 0:
            handle.write(b'0'); handle.flush()
        handle.seek(0)
        if os.name == 'nt':
            import msvcrt
            msvcrt.locking(handle.fileno(), msvcrt.LK_NBLCK, 1)
        else:
            import fcntl
            fcntl.flock(handle.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
        try:
            yield
        finally:
            handle.seek(0)
            if os.name == 'nt':
                msvcrt.locking(handle.fileno(), msvcrt.LK_UNLCK, 1)
            else:
                fcntl.flock(handle.fileno(), fcntl.LOCK_UN)


def save_state(path, state):
    temporary = None
    try:
        with tempfile.NamedTemporaryFile(mode='w', encoding='utf-8', dir=path.parent, delete=False) as out:
            temporary = Path(out.name)
            json.dump(state, out, ensure_ascii=False, indent=2)
            out.flush(); os.fsync(out.fileno())
        os.replace(temporary, path)
        if json.loads(path.read_text(encoding='utf-8')) != state:
            raise ValueError('Recovery state readback mismatch')
    finally:
        if temporary is not None:
            temporary.unlink(missing_ok=True)


def versions(db):
    code = trials.source_versions()
    import hashlib
    code[Path(__file__).name] = hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
    return dict(snapshot=trials.snapshot_version(db), code=code)


def eligible_gaps(result, request):
    return [x['id'] for x in result['results'] if x['usage'] == 'confirmed_rule' and
            x['scope_level'] == 'object' and not x['review_alerts'] and
            all(x[k] == request[k] for k in trials.SCOPE) and
            not x['rule_eligible'] and not x['source_review']['complete'] and
            x['source_review'].get('followup') and
            all(f['reason'] in RECOVERABLE for f in x['source_review']['followup'])]


def preserves(baseline, candidate, required):
    before, after = baseline['results'], candidate['results']
    return (len(json.dumps(candidate, ensure_ascii=False, indent=2).encode('utf-8')) < MAX_BYTES and
            [x['id'] for x in before] == [x['id'] for x in after] and
            baseline['total_matches'] == candidate['total_matches'] and
            all(not a['rule_eligible'] or b['rule_eligible'] for a, b in zip(before, after)) and
            all(any(x['id'] == rid and x['rule_eligible'] and x['source_review']['complete'] and
                    not x['review_alerts'] for x in after) for rid in required))


def trial_packet(db, request, patch, required):
    scope = {k: request[k] for k in trials.SCOPE}
    return dict(trial_version=1, trial_id='auto-' + uuid.uuid4().hex,
        task='Deliver complete current sources for the unchanged scoped query.',
        hypothesis='Expand source delivery without changing keywords, scope, result count or order.',
        expected_by='mechanical_source_delivery',
        record_fingerprints={rid: j.get(db, rid)['fingerprint'] for rid in required},
        cases=[dict(name='source-delivery', query=copy.deepcopy(request), candidate_query=patch,
                    must_be_eligible=required)] + [
            dict(name='other-' + key, query=dict(scope, **{key:value}), must_not_be_eligible=required)
            for key, value in (('project', 'crack' if scope['project'] == 'projectut' else 'projectut'),
                               ('target', scope['target'] + '-recovery-scope-guard'),
                               ('domain', scope['domain'] + '-recovery-scope-guard'))])


def validate_state(state):
    keys = {'version', 'stamp', 'failures', 'last_attempt', 'profile'}
    if (not isinstance(state, dict) or set(state) not in (keys, keys | {'rejected_attempts'}) or
            type(state['version']) is not int or state['version'] != 1 or
            type(state['failures']) is not int or not 0 <= state['failures'] <= 2 or
            state['last_attempt'] is not None and not isinstance(state['last_attempt'], str)):
        raise ValueError('Invalid recovery state; preserved for inspection')
    rejected = state.setdefault('rejected_attempts', [])
    if not isinstance(rejected, list) or len(rejected) > 64 or any(not isinstance(x, str) for x in rejected):
        raise ValueError('Invalid recovery rejection history; preserved for inspection')
    profile = state['profile']
    if profile is not None and (not isinstance(profile, dict) or
            set(profile) != {'patch', 'request_sha256', 'report', 'report_sha256'} or
            not isinstance(profile['patch'], dict) or not profile['patch'] or
            set(profile['patch']) - {'full_source_review', 'chars'} or
            'full_source_review' in profile['patch'] and profile['patch']['full_source_review'] is not True or
            'chars' in profile['patch'] and (type(profile['patch']['chars']) is not int or profile['patch']['chars'] != 2000) or
            any(not isinstance(profile[k], str) for k in ('request_sha256', 'report', 'report_sha256'))):
        raise ValueError('Invalid recovery profile; preserved for inspection')


def recover(db, request, db_path, root=ROOT, budget_seconds=8):
    """CLI entry only. On recovery errors, preserve a valid ordinary retrieval response."""
    baseline = retrieval.retrieve(db, **request)
    def result(status, value=None, **details):
        answer = copy.deepcopy(baseline if value is None else value)
        answer['auto_recovery'] = dict(status=status, database_writes=False, **details)
        return answer
    if (request.get('project') not in ('crack', 'projectut') or
            any(not request.get(k) or request[k] == '*' for k in trials.SCOPE) or baseline.get('fallback')):
        return result('unsupported_scope')
    required = eligible_gaps(baseline, request)
    if not required:
        return result('no_delivery_gap', candidate_applied=False)
    if len(json.dumps(baseline, ensure_ascii=False, indent=2).encode('utf-8')) >= MAX_BYTES:
        return result('output_budget', candidate_applied=False)
    started = perf_counter()
    try:
        identity = dict(path=str(Path(db_path).resolve()), inode=Path(db_path).stat().st_ino)
        key = j.digest(dict(db=identity, options={k:v for k,v in request.items() if k != 'query'}))
        directory = Path(root) / key
        with scope_lock(directory / 'scope.lock'):
            stamp = versions(db)
            baseline = retrieval.retrieve(db, **request)
            required = eligible_gaps(baseline, request)
            if versions(db) != stamp:
                return result('evidence_changed', retrieval.retrieve(db, **request), candidate_applied=False)
            if not required:
                return result('no_delivery_gap', candidate_applied=False)
            path = directory / 'state.json'
            state = json.loads(path.read_text(encoding='utf-8')) if path.exists() else dict(
                version=1, stamp=stamp, failures=0, last_attempt=None, profile=None)
            validate_state(state)
            if state['stamp'] != stamp:
                state.update(stamp=stamp, failures=0, last_attempt=None, profile=None, rejected_attempts=[])
            request_sha = j.digest(request)
            profile = state['profile']
            if profile and profile['request_sha256'] == request_sha:
                report_path = (directory / profile['report']).resolve()
                if report_path.parent != directory.resolve():
                    raise ValueError('Recovery report outside scope')
                report = json.loads(report_path.read_text(encoding='utf-8'))
                if (j.digest(report) != profile['report_sha256'] or report['decision'] != 'candidate_supported' or
                        report['snapshot_sha256'] != stamp['snapshot'] or
                        report['source_files_sha256'] != trials.source_versions() or
                        report['input']['cases'][0]['query'] != request or
                        report['input']['cases'][0]['candidate_query'] != profile['patch']):
                    raise ValueError('Recovery proof mismatch')
                expanded = retrieval.retrieve(db, **dict(request, **profile['patch']))
                if preserves(baseline, expanded, required) and versions(db) == stamp:
                    return result('reused', expanded, candidate_applied=True, patch=profile['patch'], report=str(report_path))
                return result('evidence_changed', retrieval.retrieve(db, **request), candidate_applied=False)
            state['failures'] = min(2, state['failures'] + 1)
            if state['failures'] < 2:
                save_state(path, state)
                return result('observed', failures=state['failures'], candidate_applied=False)
            attempt = j.digest(dict(request=request, stamp=stamp))
            if state['last_attempt'] == attempt or attempt in state['rejected_attempts']:
                return result('no_verified_candidate', candidate_applied=False)
            if len(state['rejected_attempts']) >= 64:
                return result('attempt_budget', candidate_applied=False)
            state['last_attempt'] = attempt
            patches = [dict(full_source_review=True)]
            if request.get('chars', retrieval.DEFAULT_CHARS) < 2000:
                patches.append(dict(full_source_review=True, chars=2000))
            for patch in patches:
                if perf_counter() - started >= budget_seconds:
                    # An unfinished attempt may retry later; a rejected one is not retried unchanged.
                    state['last_attempt'] = None
                    save_state(path, state)
                    return result('time_budget', candidate_applied=False)
                expanded = retrieval.retrieve(db, **dict(request, **patch))
                if not preserves(baseline, expanded, required):
                    continue
                report = trials.run_trial(db, trial_packet(db, request, patch, required))
                report_path = directory / (report['trial_id'] + '.json')
                trials.write_report(report_path, report)
                if json.loads(report_path.read_text(encoding='utf-8')) != report:
                    raise ValueError('Trial report readback mismatch')
                if report['decision'] != 'candidate_supported':
                    continue
                # Frozen comparison alone cannot authorize use after concurrent DB/code changes.
                current = retrieval.retrieve(db, **request)
                expanded = retrieval.retrieve(db, **dict(request, **patch))
                if (versions(db) != stamp or report['snapshot_sha256'] != stamp['snapshot'] or
                        report['source_files_sha256'] != trials.source_versions() or
                        not preserves(current, expanded, required)):
                    return result('evidence_changed', retrieval.retrieve(db, **request), candidate_applied=False)
                state['profile'] = dict(patch=patch, request_sha256=request_sha,
                    report=report_path.name, report_sha256=j.digest(report))
                save_state(path, state)
                if versions(db) != stamp:
                    return result('evidence_changed', retrieval.retrieve(db, **request), candidate_applied=False)
                return result('applied', expanded, candidate_applied=True, patch=patch, report=str(report_path))
            state['rejected_attempts'].append(attempt)
            save_state(path, state)
            return result('no_verified_candidate', candidate_applied=False)
    except (OSError, ValueError, KeyError, TypeError, sqlite3.Error) as exc:
        refreshed = True
        try:
            current = retrieval.retrieve(db, **request)
        except (OSError, ValueError, KeyError, TypeError, sqlite3.Error):
            current, refreshed = baseline, False
        return result('recovery_unavailable', current, candidate_applied=False,
                      baseline_refreshed=refreshed, error=str(exc)[:160])
