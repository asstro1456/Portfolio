import copy
import json
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

import judgments as j
from check_classification_cases import CASES, replay

V2_CASES = CASES.with_name('classification-cases-v2.json')


class ClassificationV2Tests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.path = Path(self.temp.name) / 'v2.sqlite3'
        self.db = j.connect(self.path, create=True)

    def tearDown(self):
        self.db.close()
        self.temp.cleanup()

    def make(self, text='일정 문제 생기면 해당 효과는 빼도 된다.'):
        sid = j.add_source(self.db, dict(project='projectut', origin='test', observed_at='unknown', role='user', text=text))
        return dict(classification_version=2, project='projectut', domain='vfx', target='test-effect',
            source_id=sid, quote=text, types=['request'], type_quotes={'request':text},
            interpretation='일정 문제 발생 시 해당 효과 생략 허용', rationale='테스트 분류',
            decision_state='explicit', scope_level='object', scope_basis='해당 효과만', reuse='reusable',
            context_state='standalone', context_refs=[], missing_context=[], reason_kind='unknown',
            attributes=dict(conditions=[dict(when='일정 문제 발생', then='해당 효과 생략 허용', source_id=sid, quote=text)],
                            priority=None, action_state=None, acceptance_scope=None))

    def promotion(self, candidate, cid):
        data = {k:candidate[k] for k in ('project','domain','target','source_id','quote','attributes')}
        data.update(status='confirmed', decision=candidate['interpretation'], reason_kind='unknown',
                    candidate_id=cid, review_note='조건과 범위를 확인한 테스트 승격')
        return data

    def test_v1_and_v2_can_coexist_and_samples_round_trip(self):
        replay(self.db)
        report = replay(self.db, V2_CASES)
        self.assertEqual(len(report['results']), 6)
        self.assertEqual(replay(self.db, V2_CASES), report)
        self.assertEqual(self.db.execute("SELECT count(*) FROM records WHERE kind='candidate'").fetchone()[0], 11)
        self.assertEqual(j.search(self.db, 'projectut', include_pending=True)['results'], [])

    def test_unclassified_is_preserved_filterable_and_cannot_be_promoted(self):
        data = self.make('이거는 좀...')
        data.update(types=['unclassified'], type_quotes={'unclassified':data['quote']},
                    interpretation='의도 미확인', decision_state='unresolved', reuse='uncertain',
                    unclassified_reason='요청인지 평가인지 구분하기 어려움')
        data['attributes']['conditions'] = []
        cid = j.add_candidate(self.db, data)
        self.db.commit()
        result = subprocess.run([sys.executable, '-X', 'utf8', j.__file__, '--db', str(self.path),
                                 'candidates', '--project', 'projectut', '--status', 'unclassified'],
                                capture_output=True, encoding='utf-8', check=True)
        self.assertEqual(json.loads(result.stdout)[0]['id'], cid)
        self.assertEqual(j.get(self.db, cid)['payload']['quote'], '이거는 좀...')
        self.assertEqual(j.search(self.db, 'projectut')['results'], [])
        with self.assertRaises(ValueError):
            j.add_judgment(self.db, self.promotion(data, cid))

    def test_unclassified_requires_reason_and_uncertainty(self):
        data = self.make()
        data.update(types=['unclassified'], type_quotes={'unclassified':data['quote']})
        with self.assertRaises(ValueError):
            j.add_candidate(self.db, data)
        data['unclassified_reason'] = '미확인'
        with self.assertRaises(ValueError):
            j.add_candidate(self.db, data)

    def test_conditions_survive_promotion_and_search(self):
        data = self.make()
        cid = j.add_candidate(self.db, data)
        promotion = self.promotion(data, cid)
        without = copy.deepcopy(promotion)
        without['attributes']['conditions'] = []
        with self.assertRaises(ValueError):
            j.add_judgment(self.db, without)
        rid = j.add_judgment(self.db, promotion)
        result = j.search(self.db, 'projectut', target='test-effect')['results'][0]
        self.assertEqual(result['id'], rid)
        self.assertEqual(result['attributes'], data['attributes'])

    def test_attribute_evidence_must_match_connected_user_source(self):
        data = self.make()
        data['attributes']['priority'] = dict(description='최우선', source_id=data['source_id'], quote='최우선이다')
        with self.assertRaises(ValueError):
            j.add_candidate(self.db, data)

    def test_information_and_evaluation_are_not_implicit_decisions(self):
        for kind in ('information', 'evaluation'):
            data = self.make()
            data.update(types=[kind], type_quotes={kind:data['quote']})
            with self.subTest(kind=kind), self.assertRaises(ValueError):
                j.add_candidate(self.db, data)

    def test_acceptance_requires_scope_and_preserves_quality_boundary(self):
        data = self.make('이 결과는 이 정도면 됨')
        data.update(types=['acceptance'], type_quotes={'acceptance':data['quote']}, reuse='task_only')
        data['attributes']['conditions'] = []
        with self.assertRaises(ValueError):
            j.add_candidate(self.db, data)
        data['attributes']['acceptance_scope'] = 'result_quality'
        cid = j.add_candidate(self.db, data)
        self.assertEqual(j.get(self.db, cid)['payload']['attributes']['acceptance_scope'], 'result_quality')

    def test_pause_cancel_resume_are_task_states_not_standing_rules(self):
        for action in ('pause', 'cancel', 'resume'):
            data = self.make()
            data['attributes']['action_state'] = dict(value=action, target='이번 작업', source_id=data['source_id'], quote=data['quote'])
            with self.subTest(action=action), self.assertRaises(ValueError):
                j.add_candidate(self.db, data)
            data['reuse'] = 'task_only'
            self.assertEqual(j.get(self.db, j.add_candidate(self.db, data))['payload']['attributes']['action_state']['value'], action)

    def test_v2_attributes_cannot_silently_disappear(self):
        data = self.make()
        del data['attributes']
        with self.assertRaises(ValueError):
            j.add_candidate(self.db, data)

    def test_unclassified_reclassification_keeps_original(self):
        data = self.make()
        data.update(types=['unclassified'], type_quotes={'unclassified':data['quote']},
                    decision_state='unresolved', reuse='uncertain', unclassified_reason='검토 전')
        old = j.add_candidate(self.db, data)
        resolved = self.make()
        resolved['reclassifies'] = old
        new = j.add_candidate(self.db, resolved)
        self.assertEqual(j.get(self.db, old)['status'], 'unclassified')
        self.assertEqual(j.get(self.db, new)['supersedes'], old)


if __name__ == '__main__':
    unittest.main()
