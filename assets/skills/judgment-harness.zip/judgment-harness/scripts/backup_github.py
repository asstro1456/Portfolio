"""Explicit private GitHub backup; credentials stay in Windows Credential Manager."""
import argparse
import base64
import hashlib
import gzip
import io
import json
import math
import os
import re
import sqlite3
import subprocess
import tempfile
from contextlib import closing, contextmanager
from datetime import datetime, timezone, timedelta
from pathlib import Path
from urllib.error import HTTPError
from urllib.request import Request, urlopen
from urllib.parse import quote

from judgments import DEFAULT_DB

REPO = 'asstro1456/codex-judgment-backup'
SNAPSHOT = Path('D:/CodexData/backups/github-judgment-db/judgments.sqlite3')
DAILY_STATE = Path('D:/CodexData/judgment-data/github-backup-state.json')
KST = timezone(timedelta(hours=9))


def revision(source):
    """Hash logical rows in one SQLite read transaction, including WAL-visible changes."""
    digest = hashlib.sha256()
    with closing(sqlite3.connect(source.resolve().as_uri() + '?mode=ro', uri=True)) as db:
        db.execute('BEGIN')
        digest.update(str(db.execute('PRAGMA user_version').fetchone()[0]).encode())
        for table, order in [('records','id'), ('document_heads','project,path')]:
            digest.update(table.encode())
            for row in db.execute('SELECT * FROM ' + table + ' ORDER BY ' + order):
                digest.update((json.dumps(row,ensure_ascii=False,separators=(',',':'))+'\n').encode())
    return digest.hexdigest()


@contextmanager
def daily_lock(path):
    path.parent.mkdir(parents=True,exist_ok=True)
    with path.open('a+b') as handle:
        if handle.tell() == 0:
            handle.write(b'0'); handle.flush()
        handle.seek(0)
        try:
            if os.name == 'nt':
                import msvcrt
                msvcrt.locking(handle.fileno(),msvcrt.LK_NBLCK,1)
            else:
                import fcntl
                fcntl.flock(handle,fcntl.LOCK_EX|fcntl.LOCK_NB)
        except OSError:
            yield False
            return
        try:
            yield True
        finally:
            handle.seek(0)
            if os.name == 'nt':
                msvcrt.locking(handle.fileno(),msvcrt.LK_UNLCK,1)
            else:
                fcntl.flock(handle,fcntl.LOCK_UN)


def daily_backup(source, target, state_path=DAILY_STATE, api_factory=None, now=None, force=False, create=False):
    if create and not force:
        raise ValueError('--create-private requires explicit manual --force')
    real_time = now is None
    now = (now or datetime.now(timezone.utc)).astimezone(KST)
    if not force and now.hour < 22:
        due = now.replace(hour=22, minute=0, second=0, microsecond=0)
        return dict(skipped=True, reason='not_due_before_22_KST', not_before=due.isoformat(),
                    retry_after_seconds=math.ceil((due - now).total_seconds()))
    with daily_lock(state_path.with_suffix('.lock')) as acquired:
        if not acquired:
            return dict(skipped=True,reason='another_backup_running')
        state = json.loads(state_path.read_text(encoding='utf-8')) if state_path.exists() else {}
        today = now.date().isoformat()
        if not force and state.get('last_run_day') == today:
            return dict(skipped=True,reason='already_checked_today')
        current = revision(source)
        previous = state.get('revision')
        verified_file = target.with_name('github-verified.sqlite3')
        if previous is None and verified_file.exists():
            previous = revision(verified_file)
        if not force and current == previous:
            result = dict(skipped=True,reason='unchanged')
        else:
            result = backup((api_factory or GitHub)(),source,target,create=create)
            # Persist the verified snapshot's revision, not a newer concurrent DB state.
            current = revision(verified_file)
        state.update(version=1,revision=current,checked_at=now.isoformat())
        # Manual verification must not consume tonight's scheduled check of newer changes.
        if not force:
            state['last_run_day'] = today
        if not result.get('skipped'):
            verified_at = datetime.now(KST) if real_time else now
            state.update(last_success_at=verified_at.isoformat(),commit=result['commit'])
        state_path.parent.mkdir(parents=True,exist_ok=True)
        with tempfile.NamedTemporaryFile(dir=state_path.parent,suffix='.pending.json',mode='w',
                                         encoding='utf-8',delete=False) as handle:
            json.dump(state,handle,ensure_ascii=False)
            pending = Path(handle.name)
        try:
            pending.replace(state_path)
        finally:
            pending.unlink(missing_ok=True)
        return result


def snapshot(source, target):
    if not source.is_file():
        raise ValueError('Source DB is missing')
    target.parent.mkdir(parents=True, exist_ok=True)
    with tempfile.NamedTemporaryFile(dir=target.parent, suffix='.pending.sqlite3', delete=False) as handle:
        temporary = Path(handle.name)
    try:
        with closing(sqlite3.connect(source.resolve().as_uri() + '?mode=ro', uri=True)) as src:
            with closing(sqlite3.connect(temporary)) as dst:
                src.backup(dst)
                if dst.execute('PRAGMA integrity_check').fetchone()[0] != 'ok':
                    raise ValueError('SQLite integrity check failed')
                if dst.execute('PRAGMA user_version').fetchone()[0] != 1:
                    raise ValueError('Unsupported DB schema')
                count = dst.execute('SELECT count(*) FROM records').fetchone()[0]
        temporary.replace(target)
    finally:
        temporary.unlink(missing_ok=True)
    return dict(sha256=hashlib.sha256(target.read_bytes()).hexdigest(), records=count, schema=1)


class GitHub:
    def __init__(self):
        env = {**os.environ, 'GIT_TERMINAL_PROMPT':'0', 'GCM_INTERACTIVE':'never'}
        try:
            result = subprocess.run(['git', 'credential', 'fill'],
                input='protocol=https\nhost=github.com\n\n', text=True, capture_output=True,
                env=env, timeout=20)
        except subprocess.TimeoutExpired:
            raise ValueError('GitHub credential lookup timed out; check Git Credential Manager and retry') from None
        values = dict(line.split('=', 1) for line in result.stdout.splitlines() if '=' in line)
        if result.returncode or not values.get('password'):
            diagnostic = 'GitHub credential unavailable; check the credential helper'
            try:
                accounts = subprocess.run(['git','credential-manager','github','list'],
                    text=True,capture_output=True,env=env,timeout=20)
                if accounts.returncode == 0:
                    diagnostic = ('Stored GitHub credential could not be read' if accounts.stdout.strip()
                                  else 'No saved GitHub account in Git Credential Manager')
            except (OSError, subprocess.TimeoutExpired):
                pass
            raise ValueError(diagnostic + '; reconnect with: git credential-manager github login --username '
                             + REPO.split('/')[0] + ' --browser')
        credential = values.get('username', 'x-access-token') + ':' + values['password']
        self.headers = {'Authorization':'Basic ' + base64.b64encode(credential.encode()).decode(),
                        'Accept':'application/vnd.github+json', 'User-Agent':'Codex-Judgment-Backup'}

    def call(self, path, data=None, method='GET', raw=False):
        request = Request('https://api.github.com' + path,
            data=None if data is None else json.dumps(data).encode(),
            headers={**self.headers, 'Content-Type':'application/json',
                     'Accept':'application/vnd.github.raw+json' if raw else self.headers['Accept']}, method=method)
        try:
            with urlopen(request, timeout=120) as response:
                return response.read() if raw else json.load(response)
        except HTTPError as error:
            if error.code == 404 and method == 'GET':
                return None
            if error.code == 401:
                raise ValueError('GitHub authentication rejected (HTTP 401): credential invalid or expired; '
                                 'reconnect with git credential-manager github login --username '
                                 + REPO.split('/')[0] + ' --force --browser') from None
            headers = error.headers or {}
            if error.code == 429 or (error.code == 403 and
                    (headers.get('X-RateLimit-Remaining') == '0' or headers.get('Retry-After'))):
                raise ValueError('GitHub rate limit reached (HTTP ' + str(error.code)
                                 + '); wait before retrying; do not reset credentials automatically') from None
            if error.code == 403:
                raise ValueError('GitHub access forbidden (HTTP 403): check repository/token permissions '
                                 'and organization policy; rate limiting is also possible') from None
            raise ValueError('GitHub request failed: HTTP ' + str(error.code)) from None


def backup(api, source, target, repo=REPO, create=False):
    if not re.fullmatch(r'[A-Za-z0-9-]+/[A-Za-z0-9_.-]+', repo):
        raise ValueError('Invalid repository')
    owner, name = repo.split('/')
    if api.call('/user')['login'].lower() != owner.lower():
        raise ValueError('Only the authenticated personal repository is allowed')
    root = '/repos/' + repo
    info = api.call(root)
    if info is None and create:
        info = api.call('/user/repos', dict(name=name, private=True, auto_init=True,
            description='Private backup of locally accumulated judgment criteria.'), 'POST')
    if info is None:
        raise ValueError('GitHub repository missing or inaccessible: check repository name and token permissions')
    if not info or info.get('private') is not True or info['owner']['login'].lower() != owner.lower():
        raise ValueError('Verified private personal repository required')
    metadata = snapshot(source, target)
    body = target.read_bytes()
    if hashlib.sha256(body).hexdigest() != metadata['sha256']:
        raise ValueError('Concurrent local backup changed the snapshot; retry')
    archive = gzip.compress(body, compresslevel=6, mtime=0)
    if len(archive) >= 100_000_000:
        raise ValueError('Compressed backup exceeds GitHub file limit; existing remote backup preserved')
    branch = quote(info['default_branch'], safe='')
    head = api.call(root + '/git/ref/heads/' + branch)
    if not head:
        raise ValueError('Initialized repository branch required')
    parent = head['object']['sha']
    commit = api.call(root + '/git/commits/' + parent)
    previous = api.call(root + '/contents/snapshot.json?ref=' + parent)
    prior = json.loads(base64.b64decode(previous['content'])) if previous else {}
    metadata['captured_at'] = prior.get('captured_at') if prior.get('sha256') == metadata['sha256'] else datetime.now(timezone.utc).isoformat()
    metadata.update(storage='gzip', archive_file='judgments.sqlite3.gz', bytes=len(body),
                    archive_bytes=len(archive), archive_sha256=hashlib.sha256(archive).hexdigest())
    files = {
        'judgments.sqlite3.gz':archive,
        'snapshot.json':(json.dumps(metadata, ensure_ascii=False, indent=2) + '\n').encode(),
        'README.md':b'# Private judgment DB backup\n\nThe current backup is judgments.sqlite3.gz. Decompress it to a separate SQLite file. Verify the archive SHA-256 and decompressed SHA-256 against snapshot.json, then run PRAGMA integrity_check and verify the records count. Close DB users and preserve the existing DB before restoring to D:/CodexData/judgment-data/judgments.sqlite3. The old uncompressed judgments.sqlite3, if present, is a legacy backup, not the latest. Each current backup and its metadata are published in one commit. No credentials or media are included.\n',
    }
    tree = []
    for filename, content in files.items():
        expected = hashlib.sha1(('blob ' + str(len(content)) + '\0').encode() + content).hexdigest()
        old = api.call(root + '/contents/' + filename + '?ref=' + parent)
        if old and old['sha'] == expected:
            continue
        blob = api.call(root + '/git/blobs', dict(content=base64.b64encode(content).decode(), encoding='base64'), 'POST')
        if blob['sha'] != expected:
            raise ValueError('Uploaded Git blob mismatch; existing branch preserved')
        tree.append(dict(path=filename, mode='100644', type='blob', sha=blob['sha']))
    published = parent
    if tree:
        new_tree = api.call(root + '/git/trees', dict(base_tree=commit['tree']['sha'], tree=tree), 'POST')
        new_commit = api.call(root + '/git/commits', dict(message='[Update] Back up judgment database',
            tree=new_tree['sha'], parents=[parent]), 'POST')
        published = new_commit['sha']
        api.call(root + '/git/refs/heads/' + branch, dict(sha=published, force=False), 'PATCH')
    downloaded = api.call(root + '/contents/judgments.sqlite3.gz?ref=' + published, raw=True)
    manifest = api.call(root + '/contents/snapshot.json?ref=' + published, raw=True)
    if not downloaded or hashlib.sha256(downloaded).hexdigest() != metadata['archive_sha256'] or manifest != files['snapshot.json']:
        raise ValueError('Remote archive or manifest verification failed')
    with gzip.GzipFile(fileobj=io.BytesIO(downloaded)) as stream:
        restored = stream.read(len(body) + 1)
    if hashlib.sha256(restored).hexdigest() != metadata['sha256']:
        raise ValueError('Downloaded SQLite hash mismatch')
    with tempfile.NamedTemporaryFile(dir=target.parent, suffix='.verify.sqlite3', delete=False) as handle:
        handle.write(restored)
        verified_file = Path(handle.name)
    try:
        with closing(sqlite3.connect(verified_file.resolve().as_uri() + '?mode=ro', uri=True)) as db:
            if (db.execute('PRAGMA integrity_check').fetchone()[0] != 'ok' or
                db.execute('SELECT count(*) FROM records').fetchone()[0] != metadata['records']):
                raise ValueError('Downloaded SQLite integrity or record count mismatch')
        verified_file.replace(target.with_name('github-verified.sqlite3'))
    finally:
        verified_file.unlink(missing_ok=True)
    return dict(repository='https://github.com/' + repo, private=True, verified=True,
                changed=bool(tree), commit=published, downloaded_integrity='ok', **metadata)


def main(argv=None):
    parser = argparse.ArgumentParser()
    parser.add_argument('--create-private', action='store_true')
    parser.add_argument('--force', action='store_true', help='Explicit manual request only: bypass daily policy')
    args = parser.parse_args(argv)
    try:
        if args.create_private and not args.force:
            parser.error('--create-private requires explicit manual --force')
        result = daily_backup(DEFAULT_DB,SNAPSHOT,force=args.force,create=args.create_private)
        print(json.dumps(result))
    except (ValueError, OSError, sqlite3.Error, subprocess.TimeoutExpired) as error:
        raise SystemExit(str(error))


if __name__ == '__main__':
    main()
