"""Read-only retrieval of current rules and scoped historical evidence."""
import json
from datetime import datetime, timezone
from conflicts import NONBLOCKING, current_reviews, superseded_candidates, validate as validate_conflict_review

PURPOSE_TYPES = {
    'all': None,
    'corrections': {'correction', 'rejection', 'evaluation'},
    'wants': {'request', 'selection', 'acceptance'},
    'thinking': {'proposal', 'reason', 'evaluation'},
    'reference': {'question', 'information', 'other'},
}
SEMANTIC_KEYS = ('project', 'domain', 'target', 'source_id', 'quote', 'types',
                 'interpretation', 'scope_level', 'reuse', 'decision_state',
                 'context_state', 'context_refs', 'missing_context', 'attributes',
                 'reason_kind', 'reason', 'reason_quote', 'reason_source_id')
DEFAULT_LIMIT = 3
DEFAULT_CHARS = 1600
MAX_CHARS = 2000


def normalized(text):
    return text.casefold().replace('\\_', '_')


def event_time(value):
    try:
        if isinstance(value, (int, float)):
            dt = datetime.fromtimestamp(value, timezone.utc)
        else:
            dt = datetime.fromisoformat(str(value).replace('Z', '+00:00'))
        if dt.tzinfo is None:
            dt = dt.replace(tzinfo=timezone.utc)
        return dt.timestamp()
    except (TypeError, ValueError, OverflowError, OSError):
        return None


def content_fields(payload):
    for key in ('decision', 'interpretation', 'quote', 'text', 'reason_quote', 'reason'):
        value = payload.get(key)
        if isinstance(value, str):
            yield key, value
    for n, ref in enumerate(payload.get('context_refs', [])):
        yield f'context_refs[{n}].quote', ref.get('quote', '')
    attrs = payload.get('attributes', {})
    for n, condition in enumerate(attrs.get('conditions', [])):
        for key in ('when', 'then', 'quote'):
            yield f'attributes.conditions[{n}].{key}', condition.get(key, '')
    if attrs.get('priority'):
        yield 'attributes.priority.description', attrs['priority'].get('description', '')


def compact(value, chars):
    truncated = False

    def visit(item):
        nonlocal truncated
        if isinstance(item, str) and len(item) > chars:
            truncated = True
            return item[:chars]
        if isinstance(item, list):
            truncated |= len(item) > 4
            return [visit(v) for v in item[:4]]
        if isinstance(item, dict):
            return {k: visit(v) for k, v in item.items()}
        return item

    return visit(value), truncated


def source_review(db, item, chars, full=False):
    """Read selected evidence again; a search excerpt alone is not source review."""
    raw = db.execute('SELECT payload FROM records WHERE id=?', (item['id'],)).fetchone()
    if not raw:
        return dict(complete=False, reason='record_missing')
    p = json.loads(raw[0])
    refs = [dict(source_id=p.get('source_id'), quote=p.get('quote', p.get('text', '')))]
    refs.extend(p.get('context_refs', []))
    if p.get('candidate_id'):
        candidate = db.execute('SELECT payload FROM records WHERE id=?', (p['candidate_id'],)).fetchone()
        if candidate:
            refs.extend(json.loads(candidate[0]).get('context_refs', []))
    if p.get('reason_kind') == 'user_stated':
        reason_id = p.get('reason_source_id', p.get('source_id'))
        reason_quote = p.get('reason_quote', '')
        if not any(r.get('source_id') == reason_id and reason_quote in r.get('quote', '') for r in refs):
            refs.append(dict(source_id=reason_id, quote=reason_quote, relation='reason'))
    attrs = p.get('attributes', {})
    for attribute in list(attrs.get('conditions', [])) + [attrs.get('priority'), attrs.get('action_state')]:
        if attribute and not any(ref.get('source_id') == attribute['source_id'] and
                attribute['quote'] in ref.get('quote', '') and len(ref.get('quote', '')) <= chars for ref in refs):
            refs.append(dict(source_id=attribute['source_id'], quote=attribute['quote'], relation='attribute'))
    review_followup = []
    if item['kind'] == 'judgment':
        try:
            predecessors = superseded_candidates(db, item['id'])
            history = [dict(rule_id=old['id'], candidate_id=candidate['id']) for old,candidate in predecessors]
            if 'supersession_history' in item and [dict(rule_id=h['rule_id'],candidate_id=h['candidate_id'])
                    for h in item['supersession_history']] != history:
                raise ValueError('supersession history changed')
            item['supersession_history'] = history
            for entry,(old,candidate) in zip(history,predecessors):
                cp = candidate['payload']
                refs.append(dict(source_id=cp['source_id'], quote=cp['quote'], relation='explicit_predecessor'))
                refs.extend(cp.get('context_refs', []))
                refs.extend(old['payload'].get('context_refs', []))
                attrs = cp.get('attributes', {})
                entry['attributes'], truncated = compact(attrs, chars)
                for attribute in list(attrs.get('conditions', [])) + [attrs.get('priority'),attrs.get('action_state')]:
                    if attribute and not any(ref.get('source_id') == attribute['source_id'] and
                            attribute['quote'] in ref.get('quote', '') and len(ref.get('quote', '')) <= chars for ref in refs):
                        refs.append(dict(source_id=attribute['source_id'],quote=attribute['quote'],relation='predecessor_attribute'))
                if truncated:
                    review_followup.append(dict(id=candidate['id'], kind='candidate', reason='truncated_attributes'))
        except (ValueError, KeyError, TypeError):
            review_followup.append(dict(id=item['id'], kind='record', reason='supersession_history_changed'))
    relation_limit, source_limit = (20,20) if full else (4,5)
    relations = item.get('related_changes', [])
    for relation in relations[:relation_limit]:
        review = db.execute('SELECT payload FROM records WHERE id=?', (relation['review_id'],)).fetchone()
        try:
            reviewed = json.loads(review[0]) if review else {}
            validate_conflict_review(db, reviewed)
            if db.execute('SELECT 1 FROM records WHERE supersedes=?', (relation['review_id'],)).fetchone():
                raise ValueError('superseded conflict review')
            change = db.execute('SELECT payload FROM records WHERE id=?', (reviewed['change_id'],)).fetchone()
            change_payload = json.loads(change[0])
            relation['source_review'] = source_review(db, dict(id=reviewed['change_id'], kind='candidate',
                details_truncated=compact(change_payload.get('attributes', {}), chars)[1]), chars, full=full)
            if not relation['source_review']['complete']:
                review_followup.extend(relation['source_review']['followup'])
            if len(reviewed['analysis']) > chars:
                review_followup.append(dict(id=relation['review_id'], kind='conflict_review', reason='truncated_analysis'))
        except (ValueError, KeyError, TypeError):
            review_followup.append(dict(id=relation['review_id'], kind='conflict_review', reason='stale_conflict_review'))
    for relation in relations[relation_limit:]:
        review_followup.append(dict(id=relation['review_id'], kind='conflict_review', reason='related_change_limit'))
    if len(relations) > relation_limit:
        item['related_changes'] = relations[:relation_limit]
    sources = []
    seen = set()
    complete = not item['details_truncated'] and not review_followup
    followup = review_followup + ([dict(id=item['id'], kind='record', reason='truncated_attributes')] if item['details_truncated'] else [])
    for ref in refs:
        key = (ref.get('source_id'), ref.get('quote'))
        if key in seen:
            continue
        seen.add(key)
        if len(sources) >= source_limit:
            complete = False
            followup.append(dict(id=ref.get('source_id'), kind='source', reason='context_limit'))
            continue
        source = db.execute('SELECT payload FROM records WHERE id=?', (ref.get('source_id'),)).fetchone()
        s = json.loads(source[0]) if source else {}
        quote = ref.get('quote', '')
        valid = bool(quote and quote in s.get('text', ''))
        if not sources and item['kind'] != 'reference':
            valid = valid and s.get('role') == 'user'
        truncated = len(quote) > chars
        complete = complete and valid and not truncated
        if not valid or truncated:
            followup.append(dict(id=ref.get('source_id'), kind='source',
                                 reason='truncated_quote' if truncated else 'missing_source_or_quote_mismatch'))
        sources.append(dict(source_id=ref.get('source_id'), role=s.get('role'),
                            quote=quote[:chars], quote_in_source=valid, truncated=truncated,
                            observed_at=s.get('observed_at', 'unknown'), origin=s.get('origin'),
                            conversation_id=s.get('conversation_id'), message_id=s.get('message_id'),
                            relation=ref.get('relation', 'primary')))
    retired = db.execute('SELECT id FROM records WHERE supersedes=?', (item['id'],)).fetchone()
    if retired:
        complete = False
        followup.append(dict(id=retired[0], kind='record', reason='superseding_record'))
    return dict(complete=bool(complete and sources), record_id=item['id'], sources=sources,
                followup=followup,
                delivery_limits=dict(related_changes=relation_limit,sources=source_limit),
                superseded_by=retired[0] if retired else None,
                method='selected_record_and_source_readback',
                instruction='Read these exact quotes and context before applying; complete means evidence delivery, not semantic approval. ' +
                    ('Focused readback is bounded at20/20; remaining gaps still block. ' if full else
                     'For count limits only, repeat the same scoped query with limit=1 for focused20/20 readback. ') +
                    'If still incomplete, inspect the exact followup IDs; do not infer missing evidence or apply a blocked rule.')


def retrieve(db, project, purpose='all', query='', domain=None, target=None,
             conversation=None, limit=DEFAULT_LIMIT, chars=DEFAULT_CHARS, include_unresolved=False,
             fallback_target=False, _related=False, _selected_ids=None, full_source_review=False,
             _eligibility_ids=None):
    if purpose not in PURPOSE_TYPES or not 1 <= limit <= 20 or not 80 <= chars <= MAX_CHARS:
        raise ValueError('purpose 또는 limit 1~20, chars 80~2000 범위를 확인하세요.')
    if not project or not (query.strip() or target):
        raise ValueError('project와 query 또는 target을 지정하세요.')
    if type(full_source_review) is not bool:
        raise ValueError('full_source_review는 bool이어야 합니다.')
    focused_readback = limit == 1 or _selected_ids is not None or full_source_review
    terms = normalized(query).split()
    cached = {}

    def get(rid):
        if not rid:
            return None
        if rid not in cached:
            raw = db.execute('SELECT * FROM records WHERE id=?', (rid,)).fetchone()
            cached[rid] = dict(raw) if raw else None
            if raw:
                cached[rid]['payload'] = json.loads(raw['payload'])
        return cached[rid]

    def reviewed_group(item):
        d = item['_p'].get('deduplication', {})
        if item['kind'] != 'candidate' or not d.get('representative_view_only') or not d.get('context_and_scope_reviewed'):
            return None
        member = next((m for m in d.get('members', []) if m.get('source_id') == item['source_id']), None)
        baseline = get(member.get('candidate_id')) if member else None
        if (baseline and d.get('project') == item['project'] and d.get('domain') == item['domain'] and
                d.get('scope_level') == item['scope_level'] and
                all(baseline['payload'].get(k) == item['_p'].get(k) for k in SEMANTIC_KEYS)):
            return d
        return None

    sql = """SELECT r.* FROM records r
             WHERE r.kind IN ('judgment','candidate','reference')
             AND r.project IN (?, 'global')
             AND NOT EXISTS (SELECT 1 FROM records n WHERE n.supersedes=r.id)"""
    params = [project]
    if domain:
        sql += " AND r.domain IN (?, '*')"
        params.append(domain)
    items = []
    for raw in db.execute(sql + ' ORDER BY r.rowid DESC', params).fetchall():
        row = dict(raw)
        p = json.loads(row['payload'])
        if row['kind'] == 'candidate' and p.get('derived_from'):
            continue  # Split rule aspects are exposed through their judgment, not repeated as history.
        linked = get(p.get('candidate_id')) if row['kind'] == 'judgment' else None
        classification = linked['payload'] if linked else p
        scope = p.get('scope_level', classification.get('scope_level',
                      'global' if row['project'] == 'global' else
                      'project' if row['target'] == '*' else 'unknown'))
        common = row['target'] == '*' or (row['kind'] == 'judgment' and scope in ('global', 'project'))
        exact = bool(target and row['target'] == target)
        target_match = not target or common or exact or _related
        if not target_match and row['kind'] != 'candidate':
            continue
        source = get(p.get('source_id'))
        s = source['payload'] if source else {}
        if row['kind'] != 'reference' and (s.get('role') != 'user' or
                s.get('representation') == 'original_nontext_content_json_not_user_speech'):
            continue
        if source and source['kind'] == 'message' and not s.get('active_branch'):
            continue
        if row['kind'] == 'reference':
            head = db.execute('SELECT source_id FROM document_heads WHERE project=? AND path=?',
                              (row['project'], p.get('origin'))).fetchone()
            if not head or head[0] != p.get('source_id'):
                continue
        elif not p.get('quote') or p['quote'] not in s.get('text', ''):
            continue
        conversation_match = (not conversation or s.get('conversation_id') == conversation or
                              (row['kind'] == 'judgment' and scope in ('global', 'project')))
        if not conversation_match and row['kind'] != 'candidate':
            continue
        fields = list(content_fields(p))
        score = sum(any(term in normalized(text) for _, text in fields) for term in terms)
        if terms and not score and row['kind'] != 'candidate':
            continue
        types = set(classification.get('types', []))
        attrs = p.get('attributes', classification.get('attributes', {}))
        unresolved = (row['status'] in ('needs_context', 'unclassified') or
                      classification.get('context_state') == 'missing' or
                      classification.get('decision_state') == 'unresolved')
        wanted = PURPOSE_TYPES[purpose]
        purpose_match = (wanted is None or bool(types & wanted) or
                         (purpose == 'thinking' and p.get('reason_kind') == 'user_stated'))
        if purpose == 'reference' and row['kind'] == 'candidate':
            purpose_match = bool(types & wanted) and not bool(types & (
                PURPOSE_TYPES['corrections'] | PURPOSE_TYPES['wants'] | PURPOSE_TYPES['thinking']))
        usage = ('confirmed_rule' if row['kind'] == 'judgment' and row['status'] == 'confirmed'
                 else 'inactive_judgment' if row['kind'] == 'judgment'
                 else 'reference' if row['kind'] == 'reference'
                 else 'unresolved_evidence' if unresolved else 'historical_evidence')
        body = p.get('decision', p.get('quote', p.get('text', '')))
        match = None
        for field, text in fields:
            positions = [normalized(text).find(t) for t in terms if t in normalized(text)]
            if positions:
                start = max(0, min(positions) - 25)
                match = dict(field=field, snippet=text[start:start + 100])
                break
        clipped_attrs, truncated = compact(attrs, chars)
        item = dict(id=row['id'], kind=row['kind'], status=row['status'], usage=usage,
                    supersedes=row.get('supersedes'), candidate_id=p.get('candidate_id'),
                    project=row['project'], domain=row['domain'], target=row['target'],
                    scope_level=scope, scope_basis=classification.get('scope_basis', ''),
                    excerpt=body[:chars], source_id=p.get('source_id'),
                    observed_at=s.get('observed_at', 'unknown'), classified_at=row['created'],
                    source=dict(conversation_id=s.get('conversation_id'), message_id=s.get('message_id'),
                                origin=s.get('origin', p.get('origin'))),
                    types=sorted(types), attributes=clipped_attrs, details_truncated=truncated,
                    applicability='exact_target' if exact else 'common_scope' if common else 'target_review_required',
                    review_required=True, rule_eligible=usage == 'confirmed_rule', score=score,
                    review_alerts=[], related_changes=[], _time=event_time(s.get('observed_at')),
                    _p=p, _classification=classification, _purpose=purpose_match,
                    _matched=target_match and conversation_match and (not terms or bool(score)))
        if not common and not exact and (not target or _related):
            item['rule_eligible'] = False
        if usage == 'confirmed_rule' and scope in ('task', 'unknown'):
            item['rule_eligible'] = False
        if row['kind'] == 'candidate':
            item['rule_eligible'] = False
            item['reuse'] = p.get('reuse')
            item['decision_state'] = p.get('decision_state')
            item['missing_context'] = p.get('missing_context', [])[:4]
        if match:
            item['match'] = match
        if p.get('reason_kind') == 'user_stated':
            item['user_reason_quote'] = p.get('reason_quote', '')[:chars]
            item['user_reason_source_id'] = p.get('reason_source_id', p.get('source_id'))
        if linked:
            if 'scope_level' in p and p['scope_level'] != classification.get('scope_level'):
                item['review_alerts'].append(dict(reason='judgment_scope_mismatch', id=linked['id']))
                item['rule_eligible'] = False
            current = linked
            while True:
                child = db.execute('SELECT id FROM records WHERE supersedes=?', (current['id'],)).fetchone()
                if not child:
                    break
                current = get(child[0])
            if any(current['payload'].get(k) != linked['payload'].get(k) for k in SEMANTIC_KEYS):
                item['review_alerts'].append(dict(reason='linked_classification_changed', id=current['id']))
                item['rule_eligible'] = False
        items.append(item)

    rules = [x for x in items if x['usage'] == 'confirmed_rule']
    rule_contexts = {r['id']: {r['source']['conversation_id']} for r in rules}
    for item in items:
        d = reviewed_group(item)
        if d:
            for rule in rules:
                if item['source_id'] == rule['source_id']:
                    for member in d['members']:
                        source = get(member.get('source_id'))
                        if source:
                            rule_contexts[rule['id']].add(source['payload'].get('conversation_id'))
    reviews = current_reviews(db, project)
    predecessor_ids = {}
    for rule in rules:
        try:
            predecessors = superseded_candidates(db, rule['id'])
            predecessor_ids[rule['id']] = {candidate['id'] for _,candidate in predecessors}
            rule['supersession_history'] = [dict(rule_id=old['id'], candidate_id=candidate['id']) for old,candidate in predecessors]
        except (ValueError, KeyError, TypeError):
            predecessor_ids[rule['id']] = set()
            rule['review_alerts'].append(dict(reason='invalid_supersession_history', id=rule['id']))
            rule['rule_eligible'] = False
    for change in items:
        p = change['_classification']
        if change['kind'] != 'candidate' or not (set(change['types']) & {'correction', 'rejection'} or
                change['attributes'].get('action_state')):
            continue
        for rule in rules:
            review = reviews.get((rule['id'], change['id']))
            if change['id'] in predecessor_ids[rule['id']] and (not review or review['relation'] in NONBLOCKING):
                continue
            linked_source = rule['source_id'] in {r.get('source_id') for r in p.get('context_refs', [])}
            common_change = change['scope_level'] in ('global', 'project')
            same_project = (change['project'] == rule['project'] or
                            (change['project'] == 'global' and change['scope_level'] == 'global') or
                            (rule['project'] == 'global' and change['project'] == project and
                             (common_change or linked_source or review)))
            same_domain = change['domain'] == rule['domain'] or '*' in (change['domain'], rule['domain'])
            common_context = (rule['scope_level'] == 'project' and change['source']['conversation_id'] and
                              change['source']['conversation_id'] in rule_contexts[rule['id']])
            same_scope = (same_project and same_domain and
                          (change['target'] == rule['target'] or common_change or linked_source or common_context or review))
            if same_scope and (change['source_id'] != rule['source_id'] or review):
                if review and review['relation'] in NONBLOCKING:
                    rule['related_changes'].append(dict(id=change['id'], review_id=review['id'],
                        relation=review['relation'], analysis=review['analysis'][:chars],
                        verdict_by='agent_source_review', blocking=False))
                    continue
                newer = (change['_time'] is None or rule['_time'] is None or change['_time'] > rule['_time'])
                if newer or (review and review['relation'] in ('replacement', 'exception', 'unresolved')):
                    time_relation = ('unknown' if change['_time'] is None or rule['_time'] is None else
                                     'later' if change['_time'] > rule['_time'] else 'earlier_or_equal')
                    reason = ('change_time_unknown' if time_relation == 'unknown' else
                              'later_related_change' if time_relation == 'later' else 'reviewed_relation')
                    alert = dict(reason=reason, id=change['id'], relation='unresolved', blocking=True,
                                 time_relation=time_relation)
                    if review:
                        alert.update(relation=review['relation'], review_id=review['id'],
                                     analysis=review['analysis'][:chars], verdict_by='agent_source_review')
                        if review.get('condition'):
                            alert['condition'] = review['condition'][:chars]
                    rule['review_alerts'].append(alert)
                    rule['rule_eligible'] = False
                    change['review_alerts'].append(dict(reason=reason, rule_id=rule['id']))
    visible = [x for x in items if x['kind'] != 'candidate' or x['review_alerts'] or
               (x['_matched'] and x['_purpose'] and (include_unresolved or x['usage'] != 'unresolved_evidence'))]
    collapsed = {}
    for item in visible:
        key = item['id']
        d = reviewed_group(item)
        if d:
            key = (d.get('run_id'), d['group_id'], item['project'], item['domain'], item['scope_level'])
            item['duplicate_group'] = d['group_id']
        if key not in collapsed:
            item['equivalent_sources'] = []
            collapsed[key] = item
        result = collapsed[key]
        result['equivalent_sources'].append(dict(id=item['id'], source_id=item['source_id'],
                                                observed_at=item['observed_at'], **item['source']))
        result['score'] = max(result['score'], item['score'])
        if item['id'] != result['id']:
            result['review_alerts'].extend(item['review_alerts'])
        if item['_time'] is not None and (result['_time'] is None or item['_time'] > result['_time']):
            result['_time'] = item['_time']
            result['latest_observed_at'] = item['observed_at']
    results = list(collapsed.values())
    order = {'confirmed_rule': 0, 'inactive_judgment': 1, 'historical_evidence': 2,
             'reference': 3, 'unresolved_evidence': 4}
    results.sort(key=lambda x: (bool(x['review_alerts']), -order[x['usage']], x['score'],
                               x['_time'] is not None, x['_time'] or 0), reverse=True)
    total = len(results)
    has_matches = bool(results)
    if _selected_ids is not None:
        # Prediction links are checked after all conflicts, before display pagination.
        results = [item for item in results if item['id'] in _selected_ids]
    # Eligibility checks select reviewed IDs without changing source-delivery limits.
    results = ([item for item in results if item['id'] in _eligibility_ids]
               if _eligibility_ids is not None else results[:limit])
    for item in results:
        item['event_time_known'] = item['_time'] is not None
        item.setdefault('latest_observed_at', item['observed_at'])
        for key in ('_p', '_classification', '_purpose', '_time', '_matched'):
            item.pop(key, None)
        item['source_review'] = source_review(db, item, chars, full=focused_readback)
        if not item['source_review']['complete']:
            item['rule_eligible'] = False
    result = dict(instruction='확정 기준과 과거 근거를 구분한다. review_alerts는 미해결 정정·교체·예외 검토이며 자동 대체가 아니다. related_changes는 해당 버전의 양쪽 원문·맥락을 대조한 별개 요구 또는 일치 기록이며 최신성이나 사용자 승인을 뜻하지 않는다. 최신 사용자 지시·범위·조건과 source_review를 확인한다. 과거 승인은 현재 권한이 아니다.',
                  project=project, purpose=purpose, results=results, total_matches=total,
                  candidate_auto_promotion=False, database_writes=False,
                  recency='source.observed_at; unknown dates remain unknown; explicit supersession wins',
                  query_options=dict(limit=limit, chars=chars))
    if focused_readback:
        result['query_options']['focused_source_review'] = True
    if not has_matches and target and fallback_target and terms and not _related:
        result = retrieve(db, project, purpose, query, domain, target, conversation, limit, chars,
                          include_unresolved, False, _related=True, full_source_review=full_source_review,
                          _eligibility_ids=_eligibility_ids)
        result['fallback'] = 'related_targets_same_project_domain; verify applicability'
        result['requested_target'] = target
    return result
