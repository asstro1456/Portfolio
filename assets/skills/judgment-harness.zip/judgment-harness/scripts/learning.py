"""Prospective work feedback and reviewed improvement; no automatic rule promotion."""
import json
import re
from datetime import datetime

CONNECTED = ('crack', 'projectut')
CAUSES = ('none', 'rule_gap', 'retrieval_miss', 'application_miss', 'execution_defect', 'ambiguous')


def validate_prediction(db, data):
    from judgments import required
    if 'evaluation_version' not in data:
        return
    if data['evaluation_version'] != 1 or data['project'] not in CONNECTED:
        raise ValueError('평가 v1은 연결된 crack/projectut 작업만 기록합니다.')
    required(data, 'conversation_id', 'turn_id')
    modes = data.get('validation_modes')
    if modes is not None and (not isinstance(modes, list) or not modes or
            any(m not in ('still', 'motion') for m in modes) or len(modes) != len(set(modes))):
        raise ValueError('validation_modes는 완료 조건에 필요한 still/motion 목록입니다.')
    ids = data.get('judgment_ids', [])
    if not isinstance(ids, list) or len(ids) > 20 or any(not isinstance(i, str) for i in ids):
        raise ValueError('judgment_ids는 실제 적용한 판단 ID 0~20개입니다.')
    if ids:
        from retrieval import retrieve
        eligible = {r['id'] for r in retrieve(db, data['project'], domain=data['domain'],
                    target=data['target'], limit=20, chars=2000, _selected_ids=ids)['results'] if r['rule_eligible']}
        if not set(ids) <= eligible:
            raise ValueError('원문 확인 가능하고 현재 차단되지 않은 적용 후보 기준만 연결하세요.')
    for row in db.execute("SELECT payload FROM records WHERE kind='prediction' AND project=? "
                          "AND json_extract(payload,'$.evaluation_version')=1 "
                          "AND json_extract(payload,'$.conversation_id')=? "
                          "AND json_extract(payload,'$.turn_id')=? AND json_extract(payload,'$.task')=?",
                          (data['project'], data['conversation_id'], data['turn_id'], data['task'])):
        if json.loads(row[0]) != data:
            raise ValueError('같은 작업·대화·턴의 사전 판단은 수정할 수 없습니다. 새 작업 버전/턴을 사용하세요.')


def timestamp(value):
    try:
        if not isinstance(value, str) or 'T' not in value:
            return None
        dt = datetime.fromisoformat(value.replace('Z', '+00:00'))
        return dt.timestamp() if dt.tzinfo is not None else None
    except (ValueError, OverflowError, OSError):
        return None


def validate_feedback(db, prediction, source, data):
    from judgments import required
    p, s = prediction['payload'], source['payload']
    if p.get('evaluation_version') != 1:
        return
    required(data, 'task')
    if data['outcome'] != 'undetermined' and feedback_intent(db, source) == 'non_quality':
        raise ValueError('실행 승인·무응답은 품질 평가가 아닙니다. undetermined로 보존하세요.')
    if s.get('task') is not None and s['task'] != p['task']:
        raise ValueError('다른 산출물 버전의 피드백을 연결할 수 없습니다.')
    if s.get('target') is not None and s['target'] != prediction['target']:
        raise ValueError('다른 대상의 피드백을 연결할 수 없습니다.')
    if (data['task'] != p['task'] or source['project'] != prediction['project'] or
            s.get('conversation_id') != p['conversation_id'] or not s.get('message_id')):
        raise ValueError('실제 피드백의 프로젝트·대화·작업·메시지 ID가 사전 판단과 연결돼야 합니다.')
    observed = timestamp(s.get('observed_at'))
    if observed is not None and observed < timestamp(prediction['created']):
        raise ValueError('사전 판단보다 오래된 발언을 새 피드백으로 재등록할 수 없습니다.')
    if observed is not None and observed > timestamp(source['created']):
        raise ValueError('서버 등록 시각보다 미래인 사용자 발언은 평가할 수 없습니다.')
    if observed is None and data['outcome'] != 'undetermined':
        raise ValueError('실제 발언 시각이 미확인이면 undetermined로 보존하세요.')
    prediction_order = db.execute('SELECT rowid FROM records WHERE id=?', (prediction['id'],)).fetchone()[0]
    for known in db.execute("SELECT rowid,payload FROM records WHERE project=? AND kind IN ('source','message') "
                            "AND json_extract(payload,'$.conversation_id')=? AND json_extract(payload,'$.message_id')=?",
                            (prediction['project'], p['conversation_id'], s['message_id'])):
        original = json.loads(known['payload'])
        if known['rowid'] <= prediction_order or any(original.get(k) != s.get(k) for k in ('text','role','observed_at')):
            raise ValueError('이미 알려진 메시지의 ID·시각·내용을 바꾸어 새 피드백으로 사용할 수 없습니다.')
    if data.get('supersedes'):
        from judgments import get
        replay = db.execute("SELECT 1 FROM records WHERE kind='feedback' AND payload=?",
                            (json.dumps(dict(data, verdict_by='agent_interpretation_of_user_feedback'),
                                        ensure_ascii=False, sort_keys=True, separators=(',', ':')),)).fetchone()
        if replay:
            return
        old = get(db, data['supersedes'])
        if (old['kind'] != 'feedback' or old['payload']['prediction_id'] != prediction['id'] or
                db.execute('SELECT 1 FROM records WHERE supersedes=?', (old['id'],)).fetchone()):
            raise ValueError('같은 사전 판단의 현재 feedback만 명시적으로 대체할 수 있습니다.')
        old_source = get(db, old['payload']['source_id'])
        old_time = timestamp(old_source['payload'].get('observed_at'))
        if source['id'] == old_source['id'] or observed is None or old_time is not None and observed <= old_time:
            raise ValueError('평가 정정은 더 나중의 실제 사용자 원문으로 연결하세요.')


def improve(db, data):
    from judgments import get, put, required
    from evaluation import check_retrieval
    required(data, 'feedback_id', 'disposition', 'cause', 'analysis')
    feedback = get(db, data['feedback_id'])
    if feedback['kind'] != 'feedback':
        raise ValueError('실제 평가 feedback ID가 필요합니다.')
    prediction = get(db, feedback['payload']['prediction_id'])
    if prediction['payload'].get('evaluation_version') != 1:
        raise ValueError('새 개선 흐름은 사전에 기록한 평가 v1 작업만 지원합니다.')
    if db.execute('SELECT 1 FROM records WHERE supersedes=?', (feedback['id'],)).fetchone():
        raise ValueError('정정된 과거 피드백으로 개선을 완료할 수 없습니다.')
    disposition = data['disposition']
    if disposition not in ('keep', 'rule_updated', 'case_only', 'needs_context') or data['cause'] not in CAUSES:
        raise ValueError('유효한 disposition/cause가 필요합니다.')
    if feedback['status'] == 'undetermined' and disposition not in ('case_only', 'needs_context'):
        raise ValueError('미정 평가는 성공이나 기준 개선 완료로 닫을 수 없습니다.')
    if data['cause'] == 'ambiguous' and disposition != 'needs_context':
        raise ValueError('핵심 맥락이 불명확하면 needs_context로 보존하세요.')
    outcomes = {r[0] for r in db.execute("SELECT status FROM records r WHERE kind='feedback' "
        "AND json_extract(payload,'$.prediction_id')=? AND NOT EXISTS "
        "(SELECT 1 FROM records n WHERE n.supersedes=r.id)", (prediction['id'],))}
    if len(outcomes) > 1 and disposition != 'needs_context':
        raise ValueError('상반된 평가는 후속 원문으로 정정하기 전 needs_context로 보존하세요.')
    if disposition == 'rule_updated' and data['cause'] != 'rule_gap':
        raise ValueError('검색·적용·구현 실수를 새 취향 기준의 근거로 삼지 마세요.')
    for key in ('criterion_id', 'candidate_id', 'regression'):
        expected = 'rule_updated' if key != 'candidate_id' else 'case_only'
        if (key in data) != (disposition == expected):
            raise ValueError('개선 종류에 맞는 criterion_id/regression 또는 candidate_id만 지정하세요.')
    supersedes = data.get('supersedes')
    previous = db.execute("SELECT id,payload FROM records r WHERE kind='improvement' "
                          "AND json_extract(payload,'$.feedback_id')=? "
                          "AND NOT EXISTS (SELECT 1 FROM records n WHERE n.supersedes=r.id)",
                          (feedback['id'],)).fetchall()
    if len(previous) == 1 and json.loads(previous[0]['payload']).get('request') == data:
        return previous[0]['id']
    if previous and not supersedes:
        raise ValueError('기존 개선 결론 변경은 현재 improvement ID를 supersedes로 연결하세요.')
    if supersedes and not any(row['id'] == supersedes for row in previous):
        raise ValueError('같은 피드백의 현재 개선 결론만 대체할 수 있습니다.')
    validation = None
    if disposition in ('rule_updated', 'case_only'):
        item = get(db, data['criterion_id'] if disposition == 'rule_updated' else data['candidate_id'])
        if (item['project'], item['domain'], item['target']) != (feedback['project'], feedback['domain'], feedback['target']):
            raise ValueError('피드백보다 넓거나 다른 프로젝트·분야·대상으로 기준을 확대할 수 없습니다.')
        if disposition == 'rule_updated' and (item['kind'] != 'judgment' or item['status'] != 'confirmed'):
            raise ValueError('원문·범위를 검토한 확정 판단만 개선 기준으로 연결하세요.')
        candidate = get(db, item['payload']['candidate_id']) if disposition == 'rule_updated' else item
        if (candidate['kind'] != 'candidate' or candidate['payload'].get('classification_version') != 2 or
                candidate['payload'].get('source_id') != feedback['payload']['source_id']):
            raise ValueError('이 피드백 원문을 근거로 검토한 v2 후보가 필요합니다.')
        if db.execute('SELECT 1 FROM records WHERE supersedes=?', (candidate['id'],)).fetchone():
            raise ValueError('정정된 과거 후보는 개선 근거로 사용할 수 없습니다.')
        if feedback['target'] != '*' and (candidate['payload'].get('scope_level') not in ('object', 'task') or
                item['payload'].get('scope_level', candidate['payload'].get('scope_level')) not in ('object', 'task')):
            raise ValueError('대상 한정 피드백을 프로젝트 공통 기준으로 확대할 수 없습니다.')
        if disposition == 'rule_updated':
            cases = data['regression'].get('cases', []) if isinstance(data['regression'], dict) else []
            if not isinstance(cases, list) or any(not isinstance(c, dict) or
                    not isinstance(c.get('query'), dict) for c in cases):
                raise ValueError('회귀 사례와 query는 객체여야 합니다.')
            scope = {k:feedback[k] for k in ('project', 'domain', 'target')}
            positive = any(item['id'] in c.get('must_be_eligible', []) and c['query'] == scope for c in cases)
            negative = any(item['id'] in c.get('must_not_be_eligible', []) and
                           c['query'] == dict(scope, project=other) for c in cases
                           for other in CONNECTED if other != feedback['project'])
            other_target = feedback['target'] == '*' or any(item['id'] in c.get('must_not_be_eligible', []) and
                c['query'] == dict(scope, target=c['query'].get('target')) and
                c['query'].get('target') not in (None, '*', feedback['target']) for c in cases)
            if not positive or not negative or not other_target:
                raise ValueError('해당 작업 적용·다른 프로젝트 금지·대상 한정이면 다른 대상 금지 사례가 필요합니다.')
            validation = check_retrieval(db, data['regression'])
            if not validation['passed']:
                raise ValueError('검색 회귀 검사 실패: 기준 개선 완료로 기록하지 않았습니다.')
        elif candidate['payload'].get('reuse') == 'reusable':
            raise ValueError('case_only에는 일회성/불확실 후보만 연결하세요.')
    payload = dict(request=data, prediction_id=prediction['id'], feedback_id=feedback['id'],
                   source_id=feedback['payload']['source_id'], conversation_id=prediction['payload']['conversation_id'],
                   task=prediction['payload']['task'], disposition=disposition, cause=data['cause'],
                   analysis=data['analysis'], validation=validation,
                   verdict_by='agent_source_review_not_user_approval')
    for key in ('criterion_id', 'candidate_id'):
        if key in data:
            payload[key] = data[key]
    return put(db, 'improvement', feedback['project'], feedback['domain'], feedback['target'],
               'needs_context' if disposition == 'needs_context' else 'resolved', payload, supersedes)


def feedback_intent(db, source):
    """A conservative veto, never a positive quality classifier."""
    s = source['payload']
    text = re.sub(r'[\s.!?~。]+', '', s.get('text', '')).lower()
    if text in ('', '진행해', '진행해줘', '진행해주세요', '계속해', '계속해줘', '응진행해',
                '네진행해주세요', '해줘', '해', '응', '네', 'goahead', 'proceed', 'continue'):
        return 'non_quality'
    scopes = []
    for row in db.execute("SELECT payload FROM records r WHERE kind='candidate' "
                          "AND json_extract(payload,'$.source_id')=? AND NOT EXISTS "
                          "(SELECT 1 FROM records n WHERE n.supersedes=r.id)", (source['id'],)):
        p = json.loads(row[0])
        if p.get('classification_version') == 2:
            scopes.append(p.get('attributes', {}).get('acceptance_scope'))
    if scopes and all(scope in ('execution', 'method', 'publication', 'unknown') for scope in scopes):
        return 'non_quality'
    return 'requires_source_review'


def feedback_evidence(db, project, query='', domain=None, target=None, conversation=None, task=None, limit=3, chars=1600):
    """Separate historical feedback evidence; never a criterion or an artifact pass."""
    from judgments import get
    from retrieval import normalized
    if project not in CONNECTED or not 1 <= limit <= 20 or not 1 <= chars <= 2000 or not isinstance(query, str):
        raise ValueError('연결 프로젝트·limit 1~20·chars 1~2000·검색어 문자열이 필요합니다.')
    terms = normalized(query).split()
    sql = "SELECT id FROM records r WHERE kind='feedback' AND project=? AND NOT EXISTS " \
          "(SELECT 1 FROM records n WHERE n.supersedes=r.id)"
    params = [project]
    for field, value in (('domain', domain), ('target', target)):
        if value:
            sql += ' AND ' + field + '=?'
            params.append(value)
    results, invalid = [], 0
    for raw in db.execute(sql + ' ORDER BY rowid DESC', params):
        row = get(db, raw['id']); p = row['payload']
        try:
            prediction = get(db, p['prediction_id'])
            source = get(db, p['source_id']); s = source['payload']
        except (ValueError, KeyError):
            invalid += 1
            continue
        if (prediction['kind'] != 'prediction' or
                any(prediction[k] != row[k] for k in ('project', 'domain', 'target')) or
                source['kind'] not in ('source', 'message') or source['project'] not in (project, 'global') or
                s.get('role') != 'user' or not p.get('quote') or p['quote'] not in s.get('text', '') or
                source['kind'] == 'message' and not s.get('active_branch')):
            invalid += 1
            continue
        if conversation and s.get('conversation_id') != conversation or task and prediction['payload'].get('task') != task:
            continue
        fields = dict(user_quote=p['quote'], agent_analysis=p.get('analysis', ''), task=prediction['payload'].get('task', ''))
        score = sum(any(term in normalized(value) for value in fields.values()) for term in terms)
        if terms and not score:
            continue
        quote = p['quote'][:chars]
        results.append(dict(id=row['id'], kind='feedback', usage='feedback_evidence', rule_eligible=False,
            review_required=True, project=project, domain=row['domain'], target=row['target'],
            feedback_outcome=p['outcome'], task=prediction['payload'].get('task'), prediction_id=prediction['id'],
            source_id=source['id'], user_quote=quote, agent_analysis=p.get('analysis', '')[:chars],
            verdict_by='agent_interpretation_of_user_feedback', score=score,
            source_review=dict(complete=len(quote) == len(p['quote']), meaning_review_complete=False,
                sources=[dict(source_id=source['id'], quote=quote, role=s['role'], origin=s.get('origin'),
                    observed_at=s.get('observed_at', 'unknown'), conversation_id=s.get('conversation_id'),
                    message_id=s.get('message_id'))])))
    results.sort(key=lambda r: r['score'], reverse=True)
    return dict(project=project, database_writes=False, results=results[:limit], total=len(results),
                truncated=len(results) > limit, skipped_invalid_evidence=invalid,
                measurement='historical_feedback_evidence_not_confirmed_rules_or_artifact_acceptance')


def feedback_candidates(db, project, conversation, source_id, task=None, limit=3):
    from judgments import get
    source = get(db, source_id)
    s = source['payload']
    if (source['kind'] not in ('source', 'message') or source['project'] != project or
            s.get('role') != 'user' or s.get('conversation_id') != conversation or not s.get('message_id') or
            source['kind'] == 'message' and not s.get('active_branch')):
        raise ValueError('동일 프로젝트·대화의 실제 사용자 메시지 원문을 지정하세요.')
    candidates = []
    for row in db.execute("SELECT id FROM records r WHERE kind='prediction' AND project=? "
                          "AND json_extract(payload,'$.evaluation_version')=1 "
                          "AND json_extract(payload,'$.conversation_id')=? AND NOT EXISTS "
                          "(SELECT 1 FROM records n WHERE n.supersedes=r.id) ORDER BY rowid DESC", (project, conversation)):
        prediction = get(db, row['id'])
        if task and prediction['payload']['task'] != task:
            continue
        reasons = []
        if s.get('task') is None:
            reasons.append('output_version_requires_review')
        if feedback_intent(db, source) == 'non_quality':
            reasons.append('execution_or_non_quality_utterance')
        # Reuse write-side time, known-message, task and target safeguards without writing.
        try:
            validate_feedback(db, prediction, source, dict(task=prediction['payload']['task'], outcome='matched'))
            source_order = db.execute('SELECT rowid FROM records WHERE id=?', (source_id,)).fetchone()[0]
            prediction_order = db.execute('SELECT rowid FROM records WHERE id=?', (prediction['id'],)).fetchone()[0]
            if source_order <= prediction_order:
                reasons.append('source_precedes_prediction')
        except ValueError as error:
            reasons.append(str(error))
        candidates.append(dict(prediction_id=prediction['id'], task=prediction['payload']['task'],
                               domain=prediction['domain'], target=prediction['target'],
                               review_required=True, issues=reasons,
                               outcome='undetermined', automatic_link=False))
    return dict(source_id=source_id, candidates=candidates[:limit], total=len(candidates),
                truncated=len(candidates) > limit, automatic_link=False, database_writes=False)


def validate_outcome(db, data):
    """Append artifact checks separately from the immutable rule-review conclusion."""
    from judgments import get, put, required
    required(data, 'improvement_id', 'task', 'revised_task', 'before_artifact', 'after_artifact')
    change = get(db, data['improvement_id'])
    if change['kind'] != 'improvement' or change['status'] != 'resolved':
        raise ValueError('검토를 완료한 improvement ID가 필요합니다.')
    feedback = get(db, change['payload']['feedback_id'])
    for item in (change, feedback):
        if db.execute('SELECT 1 FROM records WHERE supersedes=?', (item['id'],)).fetchone():
            raise ValueError('현재 개선·피드백 버전에만 결과 검증을 연결하세요.')
    if feedback['status'] == 'undetermined' or len({r[0] for r in db.execute(
            "SELECT status FROM records r WHERE kind='feedback' AND json_extract(payload,'$.prediction_id')=? "
            "AND NOT EXISTS (SELECT 1 FROM records n WHERE n.supersedes=r.id)",
            (change['payload']['prediction_id'],))}) > 1:
        raise ValueError('미정·상반 피드백은 결과 성공으로 닫을 수 없습니다.')
    if data['task'] != change['payload']['task'] or data['task'] == data['revised_task']:
        raise ValueError('원래 작업 버전과 별개의 실제 수정 버전을 연결하세요.')
    modes, checks = data.get('required_modes'), data.get('checks')
    if (not isinstance(modes, list) or not modes or any(m not in ('still', 'motion') for m in modes) or
            len(modes) != len(set(modes)) or not isinstance(checks, dict) or set(checks) != set(modes)):
        raise ValueError('필요한 still/motion 검증 종류와 각각의 checks를 명시하세요.')
    prediction = get(db, change['payload']['prediction_id'])
    if not set(prediction['payload'].get('validation_modes', [])) <= set(modes):
        raise ValueError('사전에 선언한 정지/동작 완료 조건을 결과 검증에서 제거할 수 없습니다.')
    states = []
    for mode in modes:
        check = checks[mode]
        if not isinstance(check, dict) or check.get('status') not in ('passed', 'failed', 'unverified', 'excluded'):
            raise ValueError('검증 상태는 passed/failed/unverified/excluded입니다.')
        required(check, 'note')
        evidence = check.get('evidence', [])
        if not isinstance(evidence, list) or any(not isinstance(e, str) or not e.strip() for e in evidence):
            raise ValueError('검증 근거는 실제 경로/관측 식별자 배열입니다.')
        if check['status'] in ('passed', 'failed'):
            if not evidence or timestamp(check.get('observed_at')) is None:
                raise ValueError('실제 검사 근거와 관측 시각 없이는 합격/실패로 기록할 수 없습니다.')
            if timestamp(check['observed_at']) > datetime.now().astimezone().timestamp():
                raise ValueError('미래의 관측 결과를 기록할 수 없습니다.')
            if timestamp(check['observed_at']) < timestamp(change['created']):
                raise ValueError('수정 검토 이전 관측을 새 수정본 검증으로 재사용할 수 없습니다.')
            if mode == 'motion' and check.get('observation') != 'normal_speed':
                raise ValueError('동작 검증은 정상 속도 실제 관측이 필요합니다.')
        if check['status'] == 'excluded':
            waiver = check.get('waiver')
            if not isinstance(waiver, dict):
                raise ValueError('검증 제외는 실제 사용자 제외 원문이 필요합니다.')
            from judgments import evidence as source_evidence
            source = source_evidence(db, waiver, True)
            if source['project'] != change['project'] or source['payload'].get('conversation_id') != change['payload']['conversation_id']:
                raise ValueError('같은 프로젝트·대화의 실제 검증 제외 원문을 연결하세요.')
        states.append(check['status'])
    outcome = ('failed' if 'failed' in states else 'passed' if all(s == 'passed' for s in states) else
               'excluded' if all(s == 'excluded' for s in states) else 'unverified')
    previous = db.execute("SELECT id,payload FROM records r WHERE kind='outcome_validation' "
                          "AND json_extract(payload,'$.improvement_id')=? AND NOT EXISTS "
                          "(SELECT 1 FROM records n WHERE n.supersedes=r.id)", (change['id'],)).fetchall()
    if len(previous) == 1 and json.loads(previous[0]['payload']).get('request') == data:
        return previous[0]['id']
    if previous and not set(json.loads(previous[0]['payload'])['required_modes']) <= set(modes):
        raise ValueError('기존 동작/정지 검증 요구를 결과 정정에서 제거할 수 없습니다.')
    if previous and data.get('supersedes') not in {r['id'] for r in previous} or not previous and data.get('supersedes'):
        raise ValueError('결과 정정은 같은 개선의 현재 outcome_validation ID를 supersedes로 지정하세요.')
    payload = dict(request=data, improvement_id=change['id'], feedback_id=feedback['id'],
                   prediction_id=change['payload']['prediction_id'], conversation_id=change['payload']['conversation_id'],
                   task=data['task'], revised_task=data['revised_task'], before_artifact=data['before_artifact'],
                   after_artifact=data['after_artifact'], required_modes=modes, checks=checks,
                   outcome=outcome, verdict_by='agent_observation_not_user_acceptance')
    return put(db, 'outcome_validation', change['project'], change['domain'], change['target'], outcome,
               payload, data.get('supersedes'))


def status(db, project, conversation, task=None, limit=3, feedback_source=None):
    if project not in CONNECTED or not conversation or not 1 <= limit <= 20:
        raise ValueError('연결 프로젝트·실제 대화 ID·limit 1~20이 필요합니다.')
    rows = [dict(r) for r in db.execute("SELECT id,kind,domain,target,status,payload FROM records r WHERE project=? "
             "AND kind IN ('prediction','feedback','improvement','outcome_validation') "
             "AND NOT EXISTS (SELECT 1 FROM records n WHERE n.supersedes=r.id) ORDER BY rowid DESC", (project,))]
    for row in rows:
        row['payload'] = json.loads(row['payload'])
    counts = dict(awaiting_feedback=0, awaiting_improvement=0, needs_context=0, resolved=0)
    pending = []
    outcome_counts = dict(unverified=0, passed=0, failed=0, excluded=0)
    outcome_pending = []
    for prediction in rows:
        p = prediction['payload']
        if (prediction['kind'] != 'prediction' or p.get('evaluation_version') != 1 or
                p.get('conversation_id') != conversation or task and p['task'] != task):
            continue
        feedbacks = [f for f in rows if f['kind'] == 'feedback' and f['payload']['prediction_id'] == prediction['id']]
        if not feedbacks:
            entries = [(None, 'awaiting_feedback', None)]
        else:
            entries = []
            conflicting = len({f['status'] for f in feedbacks}) > 1
            for feedback in feedbacks:
                changes = [i for i in rows if i['kind'] == 'improvement' and i['payload']['feedback_id'] == feedback['id']]
                change = changes[0] if changes else None
                state = ('needs_context' if conflicting or change and change['status'] == 'needs_context' else
                         'resolved' if change else 'awaiting_improvement')
                entries.append((feedback, state, change))
        for feedback, state, change in entries:
            counts[state] += 1
            if change and state == 'resolved':
                validations = [r for r in rows if r['kind'] == 'outcome_validation' and
                               r['payload']['improvement_id'] == change['id']]
                result = validations[0] if validations else None
                outcome_state = result['status'] if result else 'unverified'
                outcome_counts[outcome_state] += 1
                if outcome_state != 'passed':
                    outcome_pending.append(dict(improvement_id=change['id'], prediction_id=prediction['id'],
                        task=p['task'], target=prediction['target'], rule_review_state=state,
                        outcome_state=outcome_state, validation_id=result['id'] if result else None))
            if state != 'resolved':
                pending.append(dict(prediction_id=prediction['id'], task=p['task'], domain=prediction['domain'],
                                    target=prediction['target'],
                                    prediction=p['prediction'][:360], state=state,
                                    feedback_id=feedback['id'] if feedback else None,
                                    improvement_id=change['id'] if change else None))
    return dict(project=project, conversation_id=conversation, database_writes=False, counts=counts,
                pending=pending[:limit], pending_truncated=len(pending) > limit,
                outcome_counts=outcome_counts, outcome_pending=outcome_pending[:limit],
                outcome_pending_truncated=len(outcome_pending) > limit,
                feedback_review=feedback_candidates(db, project, conversation, feedback_source, task, limit) if feedback_source else None,
                measurement='operational_feedback_review_not_accuracy_or_causal_gain')
