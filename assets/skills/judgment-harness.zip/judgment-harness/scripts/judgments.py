"""Local, append-only judgment evidence. Standard library only; no network calls."""
import argparse
import hashlib
import json
import re
import sqlite3
import sys
import uuid
import zipfile
from datetime import datetime, timezone
from pathlib import Path

DEFAULT_DB = Path('D:/CodexData/judgment-data/judgments.sqlite3')
LEGACY_DB = Path.home() / '.codex' / 'judgment-data' / 'judgments.sqlite3'
STATES = {'confirmed', 'proposed', 'hypothesis', 'unresolved', 'rejected'}
UTTERANCE_TYPES = {'request', 'selection', 'correction', 'rejection', 'reason', 'question', 'proposal', 'other'}
UTTERANCE_TYPES_V2 = UTTERANCE_TYPES | {'evaluation', 'acceptance', 'information', 'unclassified'}


def canonical(value):
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(',', ':'))


def digest(value):
    return hashlib.sha256(canonical(value).encode('utf-8')).hexdigest()


def resolve_db_path(path):
    path = Path(path).resolve()
    return DEFAULT_DB.resolve() if path == LEGACY_DB.resolve() else path


def connect(path, create=False, read_only=False):
    if create and read_only:
        raise ValueError('읽기 전용 연결에서는 DB를 만들 수 없습니다.')
    path = resolve_db_path(path)
    if not create and not path.is_file():
        raise ValueError('DB가 없습니다. init을 먼저 실행하세요.')
    if create:
        path.parent.mkdir(parents=True, exist_ok=True)
    db = sqlite3.connect(path.as_uri() + '?mode=ro' if read_only else str(path),
                         uri=read_only, timeout=15)
    db.row_factory = sqlite3.Row
    db.execute('PRAGMA foreign_keys=ON')
    version = db.execute('PRAGMA user_version').fetchone()[0]
    if version not in (0, 1):
        db.close()
        raise ValueError('지원하지 않는 DB 버전입니다.')
    if version == 0 and create:
        db.executescript('''
            CREATE TABLE records (
                id TEXT PRIMARY KEY, kind TEXT NOT NULL, project TEXT NOT NULL,
                domain TEXT NOT NULL, target TEXT NOT NULL, status TEXT NOT NULL,
                created TEXT NOT NULL, payload TEXT NOT NULL,
                fingerprint TEXT UNIQUE NOT NULL,
                supersedes TEXT UNIQUE REFERENCES records(id)
            );
            CREATE TABLE document_heads (
                project TEXT NOT NULL, path TEXT NOT NULL,
                source_id TEXT NOT NULL REFERENCES records(id),
                PRIMARY KEY(project, path)
            );
            CREATE INDEX scope_index ON records(kind, project, domain, target, status);
            PRAGMA user_version=1;
        ''')
    elif version == 0:
        db.close()
        raise ValueError('초기화되지 않은 DB입니다.')
    return db


def get(db, record_id):
    row = db.execute('SELECT * FROM records WHERE id=?', (record_id,)).fetchone()
    if row is None:
        raise ValueError('기록을 찾을 수 없습니다: ' + record_id)
    result = dict(row)
    result['payload'] = json.loads(result['payload'])
    return result


def required(data, *keys):
    for key in keys:
        if not isinstance(data.get(key), str) or not data[key].strip():
            raise ValueError('비어 있지 않은 문자열 필요: ' + key)


def put(db, kind, project, domain, target, status, payload, supersedes=None):
    required(dict(project=project, domain=domain, target=target), 'project', 'domain', 'target')
    if project != 'global' and not re.fullmatch(r'[a-z0-9][a-z0-9_-]*', project):
        raise ValueError('project는 소문자 영문/숫자/밑줄/하이픈 ID입니다.')
    fingerprint = digest([kind, project, domain, target, status, payload, supersedes])
    old = db.execute('SELECT id FROM records WHERE fingerprint=?', (fingerprint,)).fetchone()
    if old:
        return old['id']
    record_id = str(uuid.uuid4())
    db.execute('INSERT INTO records VALUES (?,?,?,?,?,?,?,?,?,?)', (
        record_id, kind, project, domain, target, status,
        datetime.now(timezone.utc).isoformat(), canonical(payload), fingerprint, supersedes))
    return record_id


def evidence(db, data, user_only=False):
    required(data, 'source_id', 'quote')
    source = get(db, data['source_id'])
    if source['kind'] not in ('source', 'message'):
        raise ValueError('근거는 source 또는 message여야 합니다.')
    body = source['payload']
    if data['quote'] not in body.get('text', ''):
        raise ValueError('인용문이 원문에 없습니다.')
    if user_only and body.get('role') != 'user':
        raise ValueError('확정 판단/사용자 피드백은 실제 사용자 발언 근거가 필요합니다.')
    if user_only and source['kind'] == 'message' and not body.get('active_branch'):
        raise ValueError('선택되지 않은 대화 분기는 자동 확정 근거로 사용할 수 없습니다.')
    return source


def add_source(db, data):
    required(data, 'project', 'origin', 'text', 'role', 'observed_at')
    if data['role'] not in ('user', 'assistant', 'document'):
        raise ValueError('source role은 user/assistant/document 중 하나입니다.')
    from source_identity import normalize
    if data['origin'].startswith('conversation:'):
        db.execute('SAVEPOINT source_identity')
        try:
            data = normalize(db, data)
            rid = put(db, 'source', data['project'], '*', '*', 'evidence', data)
        except Exception:
            db.execute('ROLLBACK TO source_identity')
            db.execute('RELEASE source_identity')
            raise
        db.execute('RELEASE source_identity')
        return rid
    return put(db, 'source', data['project'], '*', '*', 'evidence', data)


def validate_attributes(db, data):
    attributes = data.get('attributes')
    keys = {'conditions', 'priority', 'action_state', 'acceptance_scope'}
    if not isinstance(attributes, dict) or set(attributes) != keys:
        raise ValueError('v2 attributes에는 conditions/priority/action_state/acceptance_scope가 필요합니다.')
    allowed_sources = {data['source_id']} | {ref['source_id'] for ref in data['context_refs']}

    def check(item, *fields):
        if not isinstance(item, dict):
            raise ValueError('속성은 원문 근거를 포함한 객체여야 합니다.')
        required(item, *fields, 'source_id', 'quote')
        if item['source_id'] not in allowed_sources:
            raise ValueError('속성 근거는 발언 또는 연결된 맥락이어야 합니다.')
        evidence(db, item, True)

    if not isinstance(attributes['conditions'], list):
        raise ValueError('conditions는 배열이어야 합니다.')
    for condition in attributes['conditions']:
        check(condition, 'when', 'then')
    priority = attributes['priority']
    if priority is not None:
        check(priority, 'description')
    action = attributes['action_state']
    if action is not None:
        check(action, 'value', 'target')
        if action['value'] not in ('pause', 'cancel', 'resume'):
            raise ValueError('action_state.value는 pause/cancel/resume입니다.')
        if data['reuse'] == 'reusable':
            raise ValueError('현재 작업의 보류·취소·재개를 상시 기준으로 승격할 수 없습니다.')
    acceptance = attributes['acceptance_scope']
    if 'acceptance' in data['types']:
        if acceptance not in ('result_quality', 'method', 'execution', 'publication', 'unknown'):
            raise ValueError('수용·승인은 대상 범위를 명시해야 합니다.')
        if acceptance == 'unknown' and data['decision_state'] == 'explicit':
            raise ValueError('승인 범위를 모르면 명시 결정으로 확정할 수 없습니다.')
    elif acceptance is not None:
        raise ValueError('acceptance 발언이 없으면 acceptance_scope는 null입니다.')


def add_candidate(db, data):
    """Validate an agent's classification, not infer meaning from keywords."""
    required(data, 'project', 'domain', 'target', 'interpretation', 'decision_state',
             'scope_level', 'scope_basis', 'context_state', 'reuse', 'reason_kind', 'rationale')
    version = data.get('classification_version')
    if type(version) is not int or version not in (1, 2):
        raise ValueError('classification_version은 1 또는 2입니다. 새 분류는 2를 사용하세요.')
    allowed_types = UTTERANCE_TYPES if version == 1 else UTTERANCE_TYPES_V2
    types = data.get('types')
    if (not isinstance(types, list) or not types or
            any(not isinstance(t, str) or t not in allowed_types for t in types) or
            len(types) != len(set(types))):
        raise ValueError('types에는 중복 없는 발언 종류 목록이 필요합니다.')
    spans = data.get('type_quotes')
    if not isinstance(spans, dict) or set(spans) != set(types):
        raise ValueError('각 발언 종류마다 type_quotes 원문 근거가 필요합니다.')
    source = evidence(db, data, True)
    if source['project'] not in (data['project'], 'global'):
        raise ValueError('발언과 후보의 프로젝트가 다릅니다.')
    for span in spans.values():
        if not isinstance(span, str) or not span.strip() or span not in data['quote']:
            raise ValueError('발언 종류의 인용은 해당 발언 원문 안에 있어야 합니다.')
    if data['decision_state'] not in ('explicit', 'proposed', 'unresolved', 'none'):
        raise ValueError('decision_state는 explicit/proposed/unresolved/none입니다.')
    if data['scope_level'] not in ('global', 'project', 'task', 'object', 'unknown'):
        raise ValueError('유효하지 않은 scope_level')
    if (data['project'] == 'global') != (data['scope_level'] == 'global'):
        raise ValueError('global 프로젝트와 범위는 함께 명시해야 합니다.')
    if data['scope_level'] in ('task', 'object', 'unknown') and data['target'] == '*':
        raise ValueError('한정되거나 미확인인 범위를 전체 대상으로 저장할 수 없습니다.')
    if data['reuse'] not in ('reusable', 'task_only', 'uncertain'):
        raise ValueError('reuse는 reusable/task_only/uncertain입니다.')
    if data['scope_level'] == 'task' and data['reuse'] == 'reusable':
        raise ValueError('이번 작업 한정 발언을 재사용 기준으로 자동 확대할 수 없습니다.')
    refs = data.get('context_refs')
    missing = data.get('missing_context')
    if not isinstance(refs, list) or not isinstance(missing, list):
        raise ValueError('context_refs와 missing_context 배열이 필요합니다.')
    if any(not isinstance(item, str) or not item.strip() for item in missing):
        raise ValueError('누락 맥락은 비어 있지 않은 설명이어야 합니다.')
    for ref in refs:
        if not isinstance(ref, dict):
            raise ValueError('맥락 참조는 객체여야 합니다.')
        required(ref, 'relation')
        if ref['relation'] not in ('prompt', 'previous', 'referent', 'later_correction'):
            raise ValueError('유효하지 않은 맥락 연결 종류')
        context = evidence(db, ref)
        if context['project'] not in (data['project'], 'global'):
            raise ValueError('맥락 참조의 프로젝트가 다릅니다.')
        if ref['source_id'] == data['source_id']:
            raise ValueError('발언 자신을 누락된 앞뒤 맥락으로 사용할 수 없습니다.')
    state = data['context_state']
    if state not in ('standalone', 'resolved', 'missing'):
        raise ValueError('context_state는 standalone/resolved/missing입니다.')
    if state == 'missing':
        if not missing or data['decision_state'] == 'explicit' or data['reuse'] != 'uncertain':
            raise ValueError('맥락 누락은 누락 설명·미확정 판단·uncertain으로 저장해야 합니다.')
    elif missing:
        raise ValueError('누락 맥락이 있는데 해소됐다고 표시할 수 없습니다.')
    if state == 'resolved' and not refs:
        raise ValueError('맥락 해소에는 실제 원문 참조가 필요합니다.')
    if state == 'standalone' and refs:
        raise ValueError('앞뒤 맥락을 사용한 분류는 resolved 또는 missing입니다.')
    if set(types) & {'selection', 'correction'} and state == 'standalone':
        raise ValueError('선택·정정은 대상/이전 판단 맥락을 연결하거나 missing으로 남기세요.')
    if set(types) <= {'question', 'proposal', 'other', 'reason', 'evaluation', 'information'} and data['decision_state'] == 'explicit':
        raise ValueError('질문·제안·평가·정보만으로 명시 결정을 확정할 수 없습니다.')
    if 'unclassified' in types:
        required(data, 'unclassified_reason')
        if data['decision_state'] != 'unresolved' or data['reuse'] != 'uncertain':
            raise ValueError('미분류는 unresolved/uncertain으로 보존해야 합니다.')
    if version == 2:
        validate_attributes(db, data)
    if data['reason_kind'] not in ('unknown', 'inferred', 'user_stated'):
        raise ValueError('유효하지 않은 reason_kind')
    if data['reason_kind'] != 'unknown':
        required(data, 'reason')
    if data['reason_kind'] == 'user_stated':
        required(data, 'reason_quote')
        reason_id = data.get('reason_source_id', data['source_id'])
        if reason_id not in [data['source_id']] + [ref['source_id'] for ref in refs]:
            raise ValueError('이유의 원문은 발언 또는 연결된 맥락에 있어야 합니다.')
        evidence(db, dict(source_id=reason_id, quote=data['reason_quote']), True)
    previous = data.get('reclassifies')
    if previous:
        old = get(db, previous)
        if old['kind'] != 'candidate' or old['project'] != data['project'] or old['payload']['source_id'] != data['source_id']:
            raise ValueError('같은 발언의 분류 후보만 정정할 수 있습니다.')
    status = 'unclassified' if 'unclassified' in types else ('needs_context' if state == 'missing' else 'pending_review')
    return put(db, 'candidate', data['project'], data['domain'], data['target'], status, data, previous)


def check_candidate_link(db, data):
    if not data.get('candidate_id'):
        return  # Legacy callers remain supported; new work follows the shared classification contract.
    row = get(db, data['candidate_id'])
    if row['kind'] != 'candidate':
        raise ValueError('candidate_id는 분류 후보여야 합니다.')
    if db.execute('SELECT 1 FROM records WHERE supersedes=?', (row['id'],)).fetchone():
        raise ValueError('정정된 이전 분류 후보를 승격할 수 없습니다.')
    candidate = row['payload']
    for key in ('project', 'domain', 'target', 'source_id', 'quote'):
        if candidate[key] != data[key]:
            raise ValueError('후보와 판단의 원문·범위가 달라졌습니다: ' + key)
    required(data, 'review_note')
    if candidate.get('classification_version') == 2:
        if 'scope_level' in data and data['scope_level'] != candidate['scope_level']:
            raise ValueError('판단 승격 시 검토된 후보의 적용 범위를 그대로 보존해야 합니다.')
        if data.get('attributes') != candidate['attributes']:
            raise ValueError('판단 승격 시 조건·우선순위·작업 상태·승인 범위를 그대로 보존해야 합니다.')
        if data['reason_kind'] != candidate['reason_kind'] or (candidate['reason_kind'] != 'unknown' and
                any(data.get(k) != candidate.get(k) for k in ('reason', 'reason_quote'))) or (
                candidate['reason_kind'] == 'user_stated' and
                data.get('reason_source_id', data['source_id']) != candidate.get('reason_source_id', candidate['source_id'])):
            raise ValueError('판단 승격 시 수정 이유·원문·이유 출처를 그대로 보존해야 합니다.')
        if row['status'] == 'unclassified' and data['status'] == 'confirmed':
            raise ValueError('미분류 후보를 확정 기준으로 적용할 수 없습니다.')
    if data['status'] == 'confirmed' and (
            row['status'] == 'needs_context' or candidate['decision_state'] != 'explicit' or
            candidate['reuse'] != 'reusable' or candidate['scope_level'] == 'unknown'):
        raise ValueError('미확정·맥락 누락·일회성 후보는 확정 재사용 기준으로 승격할 수 없습니다.')


def add_judgment(db, data):
    required(data, 'project', 'domain', 'target', 'status', 'decision', 'reason_kind')
    if data['status'] not in STATES:
        raise ValueError('유효하지 않은 판단 상태')
    if data['reason_kind'] not in ('user_stated', 'inferred', 'unknown'):
        raise ValueError('reason_kind는 user_stated/inferred/unknown입니다.')
    source = evidence(db, data, data['status'] == 'confirmed')
    if source['project'] not in (data['project'], 'global'):
        raise ValueError('다른 프로젝트 근거를 직접 승격할 수 없습니다. 해당 범위의 사용자 지시가 필요합니다.')
    check_candidate_link(db, data)
    if data['reason_kind'] != 'unknown':
        required(data, 'reason')
    if data['reason_kind'] == 'user_stated':
        required(data, 'reason_quote')
        reason_id = data.get('reason_source_id', data['source_id'])
        refs = list(data.get('context_refs', []))
        if data.get('candidate_id'):
            refs.extend(get(db, data['candidate_id'])['payload'].get('context_refs', []))
        if reason_id not in {data['source_id']} | {r['source_id'] for r in refs}:
            raise ValueError('이유 출처는 발언 또는 연결된 사용자 맥락이어야 합니다.')
        reason_source = evidence(db, dict(source_id=reason_id, quote=data['reason_quote']), True)
        if reason_source['project'] not in (data['project'], 'global'):
            raise ValueError('다른 프로젝트의 이유를 가져올 수 없습니다.')
    previous = data.get('supersedes')
    if previous:
        old = get(db, previous)
        if old['kind'] != 'judgment' or any(old[k] != data[k] for k in ('project', 'domain', 'target')):
            raise ValueError('변경 이력은 같은 프로젝트/분야/대상의 판단만 대체합니다.')
        required(data, 'change_reason')
    return put(db, 'judgment', data['project'], data['domain'], data['target'], data['status'], data, previous)


def import_markdown(db, path, project, domain):
    path = Path(path).resolve()
    text = path.read_text(encoding='utf-8-sig')
    sid = put(db, 'source', project, domain, '*', 'evidence',
              dict(origin=str(path), text=text, role='document', content_sha256=digest(text)))
    lines = text.splitlines()
    starts = [i for i, line in enumerate(lines) if re.match(r'^#{1,6} ', line)]
    starts = sorted(set([0] + starts))
    ids = []
    for start, end in zip(starts, starts[1:] + [len(lines)]):
        chunk = '\n'.join(lines[start:end]).strip()
        if not chunk:
            continue
        payload = dict(source_id=sid, origin=str(path), line_start=start + 1,
                       line_end=end, title=lines[start], text=chunk)
        ids.append(put(db, 'reference', project, domain, '*', 'reference', payload))
    db.execute('INSERT INTO document_heads VALUES (?,?,?) ON CONFLICT(project,path) '
               'DO UPDATE SET source_id=excluded.source_id', (project, str(path), sid))
    return dict(source_id=sid, reference_count=len(ids), status='reference_only')


def read_export(path):
    path = Path(path)
    if path.suffix.lower() == '.zip':
        with zipfile.ZipFile(path) as archive:
            names = [n for n in archive.namelist() if n.replace('\\', '/').split('/')[-1] == 'conversations.json']
            if len(names) != 1:
                raise ValueError('ZIP 안 conversations.json이 정확히 하나여야 합니다.')
            if archive.getinfo(names[0]).file_size > 256 * 1024 * 1024:
                raise ValueError('256 MiB 초과 export: 필요한 대화를 JSON으로 분할하세요.')
            with archive.open(names[0]) as stream:
                return json.load(stream)
    if path.stat().st_size > 256 * 1024 * 1024:
        raise ValueError('256 MiB 초과 export: 필요한 대화를 JSON으로 분할하세요.')
    return json.loads(path.read_text(encoding='utf-8-sig'))


def import_export(db, path, selected_ids, project):
    if project == 'global':
        raise ValueError('대화 전체를 global 범위로 가져올 수 없습니다. 개별 공통 판단을 선별하세요.')
    conversations = read_export(path)
    if not isinstance(conversations, list):
        raise ValueError('conversations.json 배열 형식이 필요합니다.')
    indexed = {}
    for conversation in conversations:
        if not isinstance(conversation, dict):
            raise ValueError('대화 항목은 객체여야 합니다.')
        cid = conversation.get('id') or conversation.get('conversation_id')
        if not cid or cid in indexed:
            raise ValueError('대화 ID가 없거나 중복됩니다.')
        indexed[cid] = conversation
    if not selected_ids:
        return dict(catalog=[dict(id=k, title=v.get('title', '')) for k, v in indexed.items()], imported=False)
    if any(cid not in indexed for cid in selected_ids):
        raise ValueError('요청한 대화 ID가 export에 없습니다.')
    count = 0
    for cid in selected_ids:
        conv = indexed[cid]
        mapping = conv.get('mapping')
        if not isinstance(mapping, dict):
            raise ValueError('대화 mapping이 없습니다.')
        branch = set()
        current = conv.get('current_node')
        while current is not None:
            if current in branch or current not in mapping:
                raise ValueError('대화 부모 연결이 손상됐습니다.')
            branch.add(current)
            current = mapping[current].get('parent')
        sid = put(db, 'source', project, '*', '*', 'evidence',
                  dict(origin=str(Path(path).resolve()), conversation_id=cid,
                       role='document', text='', raw=conv))
        for node_id, node in mapping.items():
            message = node.get('message')
            if not message:
                continue
            parts = message.get('content', {}).get('parts', [])
            text = '\n'.join(p for p in parts if isinstance(p, str))
            payload = dict(source_id=sid, conversation_id=cid, node_id=node_id,
                           parent=node.get('parent'), message_id=message.get('id'),
                           role=message.get('author', {}).get('role'),
                           observed_at=message.get('create_time'), active_branch=node_id in branch,
                           text=text, raw=message)
            put(db, 'message', project, '*', '*', 'evidence', payload)
            count += 1
    return dict(conversations=len(selected_ids), processed_messages=count, rules_created=0)


def match_reason(payload, terms, excerpt):
    """One bounded explanation, not another full source dump."""
    def values(value, path):
        if isinstance(value, dict):
            for key, child in value.items():
                yield from values(child, path + '.' + key if path else key)
        elif isinstance(value, list):
            for index, child in enumerate(value):
                yield from values(child, path + '[' + str(index) + ']')
        else:
            yield path, value if isinstance(value, str) else canonical(value)

    ordered = dict.fromkeys(['decision', 'interpretation', 'text', 'quote', 'reason',
                            'attributes', 'context_refs'] + list(payload))
    for key in ordered:
        if key not in payload:
            continue
        for path, text in values(payload[key], key):
            folded = text.casefold()
            positions = [folded.find(term) for term in terms if term in folded]
            if positions:
                start = max(0, min(positions) - 25)
                snippet = text[start:start + 100]
                reason = dict(field=path[:100])
                if snippet not in excerpt:
                    reason['snippet'] = snippet
                return reason
    # Existing matching also includes JSON keys/escapes; label those honestly.
    serialized = canonical(payload)
    position = min(serialized.casefold().find(t) for t in terms if t in serialized.casefold())
    return dict(field='serialized_metadata', snippet=serialized[max(0,position-25):max(0,position-25)+100])


def search(db, project, query='', domain=None, target=None, limit=6, chars=480, include_pending=False,
           fallback_target=False, _all_targets=False):
    if not 1 <= limit <= 20 or not 80 <= chars <= 2000:
        raise ValueError('limit 1~20, chars 80~2000 범위를 사용하세요.')
    sql = '''SELECT r.* FROM records r WHERE r.kind IN ('judgment','reference')
             AND r.project IN (?, 'global')
             AND NOT EXISTS (SELECT 1 FROM records n WHERE n.supersedes=r.id)'''
    params = [project]
    if not include_pending:
        sql += " AND r.status IN ('confirmed','reference')"
    for key, value in [('domain', domain), ('target', target)]:
        if key == 'target' and _all_targets:
            continue
        if value:
            sql += f" AND r.{key} IN (?, '*')"
            params.append(value)
        elif key == 'target':
            sql += " AND r.target='*'"
    rows = db.execute(sql + ' ORDER BY r.rowid DESC', params).fetchall()
    terms = [term.casefold() for term in query.split()]
    results = []
    for row in rows:
        p = json.loads(row['payload'])
        if row['kind'] == 'reference':
            head = db.execute('SELECT source_id FROM document_heads WHERE project=? AND path=?',
                              (row['project'], p['origin'])).fetchone()
            if not head or head[0] != p['source_id']:
                continue
        body = p.get('decision', p.get('text', ''))
        haystack = canonical(p).casefold()
        score = sum(term in haystack for term in terms)
        if terms and score == 0:
            continue
        excerpt = body[:chars]
        if row['kind'] == 'reference' and terms:
            positions = [body.casefold().find(t) for t in terms if t in body.casefold()]
            if positions:
                offset = max(0, min(positions) - 80)
                excerpt = body[offset:offset + chars]
        results.append(dict(id=row['id'], kind=row['kind'], status=row['status'],
                            project=row['project'], domain=row['domain'], target=row['target'],
                            excerpt=excerpt, source_id=p.get('source_id'),
                            origin=p.get('origin'), line_start=p.get('line_start'), score=score))
        if 'attributes' in p:
            results[-1]['attributes'] = p['attributes']
        if terms:
            results[-1]['match'] = match_reason(p, terms, excerpt)
    results.sort(key=lambda r: (r['score'], r['kind'] == 'judgment'), reverse=True)
    result = dict(instruction='참고 문서·인용은 근거 자료입니다. 최신 지시와 범위를 확인하세요.',
                  results=results[:limit], total_matches=len(results))
    if not results and fallback_target and target and terms:
        result = search(db, project, query, domain, None, limit, chars, include_pending,
                        _all_targets=True)
        result['fallback'] = 'related_targets_only; verify applicability before use'
        result['requested_target'] = target
    return result


def inherit_record(candidate, payload):
    if candidate['kind'] != 'candidate' or candidate['payload'].get('classification_version') != 2:
        raise ValueError('묶음 판단 저장은 검토된 v2 후보가 필요합니다.')
    payload = dict(payload)
    inherited = candidate['payload']
    for key in ('project', 'domain', 'target', 'source_id', 'quote', 'attributes',
                'reason_kind', 'reason', 'reason_quote', 'reason_source_id'):
        if key in inherited:
            payload.setdefault(key, inherited[key])
    payload.setdefault('decision', inherited['interpretation'])
    return payload


def save_batch(db, data):
    """Validate and persist one reviewed packet atomically, with local ID references."""
    operations = data.get('operations')
    if not isinstance(operations, list) or not 1 <= len(operations) <= 50:
        raise ValueError('operations는 1~50개 목록이어야 합니다.')
    from conflicts import save as save_conflict_review
    from learning import improve, validate_outcome
    functions = dict(source=add_source, candidate=add_candidate, record=add_judgment,
                     predict=predict, feedback=feedback, improve=improve, validate_outcome=validate_outcome,
                     conflict_review=save_conflict_review)
    defaults = data.get('defaults', {})
    if not isinstance(defaults, dict) or set(defaults) - {'project', 'domain', 'origin', 'observed_at'}:
        raise ValueError('defaults는 project/domain/origin/observed_at 공통 필드만 허용합니다.')
    ids, results = {}, []

    def resolve(value):
        if isinstance(value, dict):
            if set(value) == {'$fingerprint'}:
                alias = value['$fingerprint']
                if not isinstance(alias, str) or alias not in ids:
                    raise ValueError('앞에서 검토·저장한 기록의 fingerprint만 참조할 수 있습니다.')
                return get(db, ids[alias])['fingerprint']
            if set(value) == {'$ref'}:
                if not isinstance(value['$ref'], str) or value['$ref'] not in ids:
                    raise ValueError('앞에서 정의한 $ref만 사용할 수 있습니다.')
                return ids[value['$ref']]
            return {(resolve({'$ref':k[5:]}) if k.startswith('$ref:') else k):resolve(v) for k, v in value.items()}
        if isinstance(value, list):
            return [resolve(v) for v in value]
        return value

    db.execute('SAVEPOINT judgment_batch')
    try:
        for op in operations:
            if not isinstance(op, dict):
                raise ValueError('각 operation은 객체여야 합니다.')
            alias, command = op.get('ref'), op.get('command')
            if not isinstance(alias, str) or not re.fullmatch(r'[a-zA-Z][a-zA-Z0-9_-]*', alias) or alias in ids:
                raise ValueError('ref는 중복 없는 영문 식별자여야 합니다.')
            if not isinstance(command, str) or command not in functions or not isinstance(op.get('data'), dict):
                raise ValueError('허용된 command와 data 객체가 필요합니다.')
            keys = ('project', 'origin', 'observed_at') if command == 'source' else ('project', 'domain')
            payload = resolve({**{k:defaults[k] for k in keys if k in defaults}, **op['data']})
            if command == 'candidate':
                payload.setdefault('classification_version', 2)
            if command == 'source':
                from source_identity import normalize
                payload = normalize(db, payload)
            if command == 'candidate' and payload.get('classification_version') != 2:
                raise ValueError('묶음 저장의 새 후보는 v2를 사용하세요.')
            if command == 'record':
                candidate = get(db, payload.get('candidate_id', ''))
                payload = inherit_record(candidate, payload)
            rid = functions[command](db, payload)
            row = get(db, rid)
            if row['payload'] != payload and command not in ('feedback', 'improve', 'validate_outcome'):
                raise ValueError('저장 후 재조회 내용 불일치')
            ids[alias] = rid
            results.append(dict(ref=alias, id=rid, kind=row['kind'], project=row['project'],
                                target=row['target'], status=row['status'], verified=True))
    except Exception:
        db.execute('ROLLBACK TO judgment_batch')
        db.execute('RELEASE judgment_batch')
        raise
    db.execute('RELEASE judgment_batch')
    return dict(results=results, atomic=True)


def select_fields(row, fields=None, summary=False):
    """Project a fetched record without changing stored evidence or scope."""
    if summary:
        names = ('id', 'kind', 'project', 'domain', 'target', 'status', 'supersedes')
        result = {k:row[k] for k in names}
        result['payload'] = {k:v for k, v in row['payload'].items() if k in {
            'source_id', 'candidate_id', 'quote', 'decision', 'interpretation', 'attributes',
            'scope_level', 'scope_basis', 'decision_state', 'context_state', 'reason_kind',
            'reason', 'reason_quote', 'reason_source_id', 'context_refs', 'missing_context',
            'rule_id', 'change_id', 'rule_candidate_id', 'relation', 'analysis', 'condition', 'evidence'}}
        for key in ('evaluation_version', 'conversation_id', 'turn_id', 'task', 'prediction', 'judgment_ids',
                    'prediction_id', 'feedback_id', 'criterion_id', 'outcome', 'disposition', 'cause', 'validation', 'verdict_by',
                    'improvement_id', 'revised_task', 'before_artifact', 'after_artifact', 'required_modes', 'checks', 'validation_modes'):
            if key in row['payload']:
                result['payload'][key] = row['payload'][key]
        if row['kind'] in ('source', 'message'):
            result['payload'].update({k:v for k,v in row['payload'].items() if k in {
                'text', 'role', 'origin', 'observed_at', 'conversation_id', 'message_id', 'node_id', 'parent'}})
        return result
    if fields is None:
        return row
    paths = fields.split(',')
    if not 1 <= len(paths) <= 30 or any(not re.fullmatch(r'[a-z_]+(?:\.[a-z_]+)*', p) for p in paths):
        raise ValueError('fields는 쉼표로 구분한 필드 경로 1~30개입니다.')
    result = {}
    for path in paths:
        value = row
        for part in path.split('.'):
            if not isinstance(value, dict) or part not in value:
                raise ValueError('없는 필드: ' + path)
            value = value[part]
        result[path] = value
    return result


def predict(db, data):
    required(data, 'project', 'domain', 'target', 'task', 'prediction')
    from learning import validate_prediction as validate_learning_prediction
    validate_learning_prediction(db, data)
    from evaluation import validate_prediction
    validate_prediction(db, data)
    for rid in data.get('judgment_ids', []):
        row = get(db, rid)
        if row['kind'] != 'judgment' or row['project'] not in (data['project'], 'global'):
            raise ValueError('예측 근거 판단의 종류/프로젝트가 다릅니다.')
        linked = get(db, row['payload']['candidate_id']) if row['payload'].get('candidate_id') else None
        if linked and 'scope_level' in row['payload'] and row['payload']['scope_level'] != linked['payload'].get('scope_level'):
            raise ValueError('예측 근거 판단과 검토된 후보의 적용 범위가 다릅니다.')
        scope = row['payload'].get('scope_level', linked['payload'].get('scope_level') if linked else None)
        common = scope in ('global', 'project')
        if row['domain'] not in ('*', data['domain']) or (not common and row['target'] not in ('*', data['target'])):
            raise ValueError('예측 근거의 분야/대상 범위가 다릅니다.')
        if row['status'] != 'confirmed' or db.execute('SELECT 1 FROM records WHERE supersedes=?', (rid,)).fetchone():
            raise ValueError('현재 확정 판단만 예측 기준으로 사용하세요.')
    return put(db, 'prediction', data['project'], data['domain'], data['target'], 'predicted', data)


def feedback(db, data):
    required(data, 'prediction_id', 'outcome', 'analysis')
    if data['outcome'] not in ('matched', 'missed', 'undetermined'):
        raise ValueError('outcome은 matched/missed/undetermined입니다.')
    row = get(db, data['prediction_id'])
    source = evidence(db, data, True)
    if row['kind'] != 'prediction' or source['project'] not in (row['project'], 'global'):
        raise ValueError('예측/피드백 프로젝트가 맞지 않습니다.')
    source_order = db.execute('SELECT rowid FROM records WHERE id=?', (source['id'],)).fetchone()[0]
    prediction_order = db.execute('SELECT rowid FROM records WHERE id=?', (row['id'],)).fetchone()[0]
    if source_order <= prediction_order:
        raise ValueError('이미 확보한 피드백을 사전 예측 검증으로 기록할 수 없습니다.')
    from learning import validate_feedback as validate_learning_feedback
    validate_learning_feedback(db, row, source, data)
    from evaluation import validate_feedback
    validate_feedback(db, row, source['id'], source_order)
    data = dict(data, verdict_by='agent_interpretation_of_user_feedback')
    return put(db, 'feedback', row['project'], row['domain'], row['target'], data['outcome'], data,
               data.get('supersedes') if row['payload'].get('evaluation_version') == 1 else None)


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--db', default=str(DEFAULT_DB))
    parser.add_argument('--trace-id', help='훅이 제공한 24자리 hex 관측 연결 ID; 원문/작업명 금지')
    sub = parser.add_subparsers(dest='command', required=True)
    sub.add_parser('init')
    sub.add_parser('stats')
    sub.add_parser('observation-status', help='명시한 trace-id의 최소 관측 단계 집계; 판단 DB 조회 없음')
    p = sub.add_parser('observe-skip', help='새 판단 없음 등 의도적 미기록 사유의 최소 메타데이터')
    from observation import REASONS
    p.add_argument('--reason', choices=sorted(REASONS), required=True)
    from skill_queue import register as register_skill_queue
    register_skill_queue(sub)
    p = sub.add_parser('design-references', help='GPTDB 게임 디자인 참고자료 조회; 판단 DB 연결/기록 없음')
    p.add_argument('--query', required=True)
    from design_references import TOPICS
    p.add_argument('--topic', choices=['auto', *TOPICS], default='auto')
    p.add_argument('--limit', type=int, default=3)
    p.add_argument('--chars', type=int, default=1600)
    p = sub.add_parser('compare', help='같은 작업의 하네스 미사용/사용 예측·피드백 비교')
    p.add_argument('--project', required=True)
    p.add_argument('--domain')
    p.add_argument('--target')
    p.add_argument('--limit', type=int, default=6)
    sub.add_parser('check-retrieval', help='검토된 적용/금지 검색 사례의 읽기 전용 재검사').add_argument('--input', required=True)
    sub.add_parser('check-interpretation', help='원문 기반 구조화 판정과 검색을 분리하는 읽기 전용 회귀 검사').add_argument('--input', required=True)
    for command in ('source', 'candidate', 'record', 'predict', 'feedback', 'improve', 'validate-outcome', 'batch'):
        sub.add_parser(command).add_argument('--input', required=True)
    p = sub.add_parser('learning-status', help='이 대화의 사전 판단·피드백·기준 개선 미완료 조회')
    p.add_argument('--project', choices=('crack', 'projectut'), required=True)
    p.add_argument('--conversation', required=True)
    p.add_argument('--task')
    p.add_argument('--feedback-source', help='실제 후속 사용자 source ID; 읽기 전용 연결 검토 후보')
    p.add_argument('--limit', type=int, default=3)
    p = sub.add_parser('feedback-evidence', help='확정 기준과 분리된 실제 피드백 근거의 읽기 전용 검색')
    p.add_argument('--project', choices=('crack', 'projectut'), required=True)
    p.add_argument('--query', default='')
    p.add_argument('--domain')
    p.add_argument('--target')
    p.add_argument('--conversation')
    p.add_argument('--task')
    p.add_argument('--limit', type=int, default=3)
    p.add_argument('--chars', type=int, default=1600)
    p = sub.add_parser('show')
    p.add_argument('id', nargs='+')
    output = p.add_mutually_exclusive_group()
    output.add_argument('--summary', action='store_true')
    output.add_argument('--fields', help='예: id,status,payload.quote,payload.attributes')
    p = sub.add_parser('candidates')
    p.add_argument('--project', required=True)
    p.add_argument('--status', choices=['pending_review', 'needs_context', 'unclassified'])
    p.add_argument('--limit', type=int, default=10)
    p.add_argument('--offset', type=int, default=0)
    p = sub.add_parser('messages')
    p.add_argument('--conversation', required=True)
    p.add_argument('--project', required=True)
    p.add_argument('--limit', type=int, default=20)
    p.add_argument('--offset', type=int, default=0)
    p = sub.add_parser('search')
    p.add_argument('--project', required=True)
    p.add_argument('--query', default='')
    p.add_argument('--domain')
    p.add_argument('--target')
    p.add_argument('--limit', type=int, default=6)
    p.add_argument('--chars', type=int, default=480)
    p.add_argument('--include-pending', action='store_true')
    p.add_argument('--fallback-target', action='store_true')
    from retrieval import DEFAULT_LIMIT, DEFAULT_CHARS
    p = sub.add_parser('retrieve', help='프로젝트·목적별 최신 기준과 과거 근거 조회')
    p.add_argument('--project', required=True)
    p.add_argument('--purpose', choices=['all', 'corrections', 'wants', 'thinking', 'reference'], default='all')
    p.add_argument('--query', default='')
    p.add_argument('--domain')
    p.add_argument('--target')
    p.add_argument('--conversation')
    p.add_argument('--limit', type=int, default=DEFAULT_LIMIT, help='기본 3개, 범위 1~20; 1개 집중 조회는 원문/관계 각각20개까지 확인')
    p.add_argument('--chars', type=int, default=DEFAULT_CHARS, help='기본 1600자, 2000자 초과는 상한 적용 및 결과에 표시')
    p.add_argument('--include-unresolved', action='store_true')
    p.add_argument('--fallback-target', action='store_true')
    p.add_argument('--full-source-review', action='store_true', help='결과 개수·순서를 유지하며 원문/관계 각각20개까지 전달')
    p.add_argument('--no-auto-recovery', action='store_true', help='이번 조회에서 자동 검색 복구·설정 저장을 생략')
    p.add_argument('--no-design-references', action='store_true', help='이번 조회에서 GPTDB 참고자료 조회를 생략')
    p = sub.add_parser('import-markdown')
    p.add_argument('path')
    p.add_argument('--project', required=True)
    p.add_argument('--domain', default='*')
    p = sub.add_parser('import-export')
    p.add_argument('path')
    p.add_argument('--project', default='unclassified')
    p.add_argument('--conversation', action='append', default=[])
    args = parser.parse_args(argv)
    if args.trace_id is not None and not re.fullmatch(r'[a-f0-9]{24}', args.trace_id):
        raise ValueError('trace-id는 훅에서 제공한 24자리 hex ID입니다.')
    from observation import emit
    observation_enabled = resolve_db_path(args.db) == DEFAULT_DB.resolve()
    def observe(stage, status, ids=(), code=None):
        if observation_enabled:
            recorded = emit(stage, status, trace_id=args.trace_id, record_ids=ids, code=code)
            if recorded == 'unavailable':
                print('Judgment observation unavailable; primary operation result is unchanged.', file=sys.stderr)
            return recorded
        return 'disabled_for_non_operational_db'
    if args.command == 'observation-status':
        from observation import status as observation_status
        print(json.dumps(observation_status(args.trace_id)))
        return
    if args.command == 'observe-skip':
        recorded = observe('intentional_skip', 'skipped', code=args.reason)
        print(json.dumps(dict(database_writes=False, observation=recorded)))
        return
    if args.command == 'design-references':
        from design_references import search as design_search
        print(json.dumps(design_search(args.query, args.topic, args.limit, args.chars), ensure_ascii=False, indent=2))
        return
    actual_db_path = resolve_db_path(args.db)
    tracked = args.command in ('source', 'candidate', 'record', 'predict', 'feedback', 'improve', 'validate-outcome', 'batch', 'show')
    stage = 'readback' if args.command == 'show' else 'save'
    if tracked:
        observe(stage, 'started')
    try:
        db = connect(actual_db_path, create=args.command == 'init',
                 read_only=args.command in ('retrieve', 'show', 'compare', 'check-retrieval', 'check-interpretation', 'learning-status', 'feedback-evidence') or
                 (args.command == 'skill-queue' and args.queue_action in ('list', 'show')))
    except Exception:
        if tracked:
            observe(stage, 'failure', code='operation_failed')
        raise
    if args.command in ('retrieve', 'compare', 'check-retrieval'):
        db.execute('PRAGMA query_only=ON')
    try:
        with db:
            if args.command == 'init':
                result = dict(db=str(actual_db_path), schema=1)
            elif args.command == 'stats':
                result = [dict(r) for r in db.execute('SELECT kind,project,status,count(*) AS count '
                                                      'FROM records GROUP BY kind,project,status')]
            elif args.command == 'skill-queue':
                from skill_queue import execute
                result = execute(db, args)
            elif args.command == 'compare':
                from evaluation import compare
                result = compare(db, args.project, args.domain, args.target, args.limit)
            elif args.command == 'learning-status':
                from learning import status
                result = status(db, args.project, args.conversation, args.task, args.limit, args.feedback_source)
            elif args.command == 'feedback-evidence':
                from learning import feedback_evidence
                result = feedback_evidence(db, args.project, args.query, args.domain, args.target,
                                           args.conversation, args.task, args.limit, args.chars)
            elif args.command in ('check-retrieval', 'check-interpretation'):
                from evaluation import check_retrieval, check_interpretation
                raw = sys.stdin.read() if args.input == '-' else Path(args.input).read_text(encoding='utf-8-sig')
                data = json.loads(raw.lstrip('\ufeff'))
                if not isinstance(data, dict):
                    raise ValueError('JSON 객체가 필요합니다.')
                result = (check_retrieval if args.command == 'check-retrieval' else check_interpretation)(db, data)
            elif args.command in ('source', 'candidate', 'record', 'predict', 'feedback', 'improve', 'validate-outcome', 'batch'):
                raw = sys.stdin.read() if args.input == '-' else Path(args.input).read_text(encoding='utf-8-sig')
                data = json.loads(raw.lstrip('\ufeff'))
                if not isinstance(data, dict):
                    raise ValueError('JSON 객체가 필요합니다.')
                from learning import improve, validate_outcome
                function = {'source': add_source, 'candidate': add_candidate, 'record': add_judgment,
                            'predict': predict, 'feedback': feedback, 'improve': improve,
                            'validate-outcome': validate_outcome, 'batch':save_batch}[args.command]
                result = function(db, data) if args.command == 'batch' else dict(id=function(db, data))
            elif args.command == 'show':
                rows = [select_fields(get(db, rid), args.fields, args.summary) for rid in args.id]
                result = rows[0] if len(rows) == 1 else rows
            elif args.command == 'candidates':
                if not 1 <= args.limit <= 50 or args.offset < 0:
                    raise ValueError('limit 1~50, offset 0 이상을 사용하세요.')
                sql = ("SELECT id,status,payload FROM records r WHERE kind='candidate' AND project=? "
                       "AND NOT EXISTS (SELECT 1 FROM records n WHERE n.supersedes=r.id) ")
                params = [args.project]
                if args.status:
                    sql += 'AND status=? '
                    params.append(args.status)
                rows = db.execute(sql + 'ORDER BY rowid DESC LIMIT ? OFFSET ?',
                                  params + [args.limit, args.offset]).fetchall()
                result = [dict(id=r['id'], status=r['status'],
                               types=json.loads(r['payload'])['types'],
                               excerpt=json.loads(r['payload'])['interpretation'][:480]) for r in rows]
            elif args.command == 'messages':
                if not 1 <= args.limit <= 50 or args.offset < 0:
                    raise ValueError('limit 1~50, offset 0 이상을 사용하세요.')
                rows = db.execute("SELECT id,payload FROM records WHERE kind='message' AND project=? "
                                  "AND json_extract(payload,'$.conversation_id')=? ORDER BY rowid LIMIT ? OFFSET ?",
                                  (args.project, args.conversation, args.limit, args.offset)).fetchall()
                result = []
                for row in rows:
                    payload = json.loads(row['payload'])
                    result.append(dict(id=row['id'], node_id=payload['node_id'], role=payload['role'],
                                       active_branch=payload['active_branch'], excerpt=payload['text'][:240]))
            elif args.command == 'import-markdown':
                result = import_markdown(db, args.path, args.project, args.domain)
            elif args.command == 'import-export':
                result = import_export(db, args.path, args.conversation, args.project)
            elif args.command == 'retrieve':
                from retrieval import retrieve, MAX_CHARS
                request = dict(project=args.project, purpose=args.purpose, query=args.query, domain=args.domain,
                    target=args.target, conversation=args.conversation, limit=args.limit,
                    chars=min(args.chars, MAX_CHARS), include_unresolved=args.include_unresolved,
                    fallback_target=args.fallback_target, full_source_review=args.full_source_review)
                if not args.no_auto_recovery and actual_db_path == resolve_db_path(DEFAULT_DB):
                    from retrieval_recovery import recover
                    result = recover(db, request, actual_db_path)
                else:
                    result = retrieve(db, **request)
                if args.chars > MAX_CHARS:
                    result['query_options'].update(requested_chars=args.chars, chars_capped=True,
                        note='상한 2000자를 적용했다. 잘린 원문은 source_review.followup의 ID로 show한다.')
                if not args.no_design_references and actual_db_path == resolve_db_path(DEFAULT_DB):
                    from design_references import attach
                    attach(result, args.project, args.domain, args.query, args.target)
            else:
                result = search(db, args.project, args.query, args.domain, args.target,
                                args.limit, args.chars, args.include_pending, args.fallback_target)
        if tracked:
            if args.command == 'show':
                ids = args.id
            elif args.command == 'batch':
                ids = [r['id'] for r in result['results']]
            else:
                ids = [result['id']]
            observe(stage, 'success', ids)
        print(json.dumps(result, ensure_ascii=False, indent=2))
        if args.command in ('check-retrieval', 'check-interpretation') and not result['passed']:
            sys.exit(1)
    except Exception:
        if tracked:
            observe(stage, 'failure', code='operation_failed')
        raise
    finally:
        db.close()


if __name__ == '__main__':
    if hasattr(sys.stdout, 'reconfigure'):
        sys.stdout.reconfigure(encoding='utf-8')
        sys.stderr.reconfigure(encoding='utf-8')
    try:
        main()
    except (ValueError, KeyError, TypeError, OSError, sqlite3.Error, zipfile.BadZipFile) as exc:
        print(json.dumps(dict(error=str(exc)), ensure_ascii=False), file=sys.stderr)
        sys.exit(1)
