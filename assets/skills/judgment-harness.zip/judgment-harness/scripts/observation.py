"""Best-effort local metadata only. No source text, paths, queries or error messages."""
import json
import re
import uuid
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path('D:/CodexData/judgment-data/observability')
STAGES = {'save', 'readback', 'intentional_skip'}
REASONS = {'no_new_judgment', 'context_only', 'not_connected', 'missing_identity', 'no_feedback'}


def emit(stage, status, *, trace_id=None, record_ids=(), code=None, root=None):
    if stage not in STAGES or status not in ('started', 'success', 'failure', 'skipped'):
        raise ValueError('Invalid observation stage/status')
    if trace_id is not None and not re.fullmatch(r'[a-f0-9]{24}', trace_id):
        raise ValueError('trace-id must be the 24-hex hook trace identifier')
    if any(not isinstance(rid, str) or not re.fullmatch(r'[a-f0-9-]{36}', rid) for rid in record_ids):
        raise ValueError('Only generated record UUIDs may be logged')
    if code is not None and code not in REASONS | {'operation_failed'}:
        raise ValueError('Only fixed observation codes may be logged')
    event = dict(version=1, at=datetime.now(timezone.utc).isoformat(), stage=stage, status=status,
                 trace_id=trace_id, event_id=str(uuid.uuid4()), record_ids=list(record_ids), code=code)
    try:
        folder = Path(root) if root is not None else ROOT
        folder.mkdir(parents=True, exist_ok=True)
        with (folder / 'events.jsonl').open('a', encoding='utf-8', newline='\n') as stream:
            stream.write(json.dumps(event, separators=(',', ':')) + '\n')
        return 'recorded'
    except OSError:
        return 'unavailable'  # telemetry failure must never undo or conceal a judgment operation


def status(trace_id, root=None):
    if not isinstance(trace_id, str) or not re.fullmatch(r'[a-f0-9]{24}', trace_id):
        raise ValueError('An exact 24-hex trace identifier is required')
    counts, saved, readback = {}, set(), set()
    try:
        with ((Path(root) if root is not None else ROOT) / 'events.jsonl').open(encoding='utf-8') as stream:
            for line in stream:
                try:
                    event = json.loads(line)
                except ValueError:
                    continue  # a concurrent append or damaged line is not success
                if not isinstance(event, dict) or event.get('trace_id') != trace_id:
                    continue
                stage, state = event.get('stage'), event.get('status')
                key = str(stage) + ':' + str(state)
                counts[key] = counts.get(key, 0) + 1
                if state == 'success' and stage == 'save':
                    saved.update(event.get('record_ids', []))
                    readback.difference_update(event.get('record_ids', []))
                if state == 'success' and stage == 'readback':
                    readback.update(set(event.get('record_ids', [])) & saved)
    except FileNotFoundError:
        pass
    except OSError:
        return dict(trace_id=trace_id, observation='unavailable', database_writes=False)
    return dict(trace_id=trace_id, observation='available' if counts else 'no_observed_events', counts=counts,
                saved_records=len(saved), readback_records=len(saved & readback),
                awaiting_readback=sorted(saved - readback), database_writes=False,
                limitation='Observed local calls only; missing/unlinked events do not prove intentional skipping, complete collection or semantic correctness.')
