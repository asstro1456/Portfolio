"""Scoped, read-only evaluation; measured agreement is not model accuracy."""
import json
from collections import defaultdict


def comparison_predictions(db, project, comparison_id):
    return [dict(id=r['id'], order=r['rowid'], payload=json.loads(r['payload'])) for r in db.execute(
        "SELECT rowid,id,payload FROM records WHERE kind='prediction' AND project=? "
        "AND json_extract(payload,'$.comparison_id')=?", (project, comparison_id))]


def validate_prediction(db, data):
    from judgments import required
    if not {'comparison_id', 'variant'} & set(data):
        return
    required(data, 'comparison_id', 'variant')
    if data['variant'] not in ('baseline', 'harness'):
        raise ValueError('variant는 baseline 또는 harness입니다.')
    if (data['variant'] == 'baseline') == bool(data.get('judgment_ids')):
        raise ValueError('baseline은 판단 근거 없이, harness는 실제 판단 ID와 함께 예측하세요.')
    if data['variant'] == 'harness':
        from retrieval import retrieve
        ids = data['judgment_ids']
        if not isinstance(ids, list) or not 1 <= len(ids) <= 20 or any(not isinstance(i, str) for i in ids):
            raise ValueError('harness 판단 ID는 1~20개 목록이어야 합니다.')
        eligible = {r['id'] for r in retrieve(db, data['project'], domain=data['domain'], target=data['target'],
                    limit=20, chars=2000, _selected_ids=ids)['results'] if r['rule_eligible']}
        if not set(ids) <= eligible:
            raise ValueError('harness 비교에는 원문 확인 가능한 적용 후보 기준만 사용하세요.')
    for other in comparison_predictions(db, data['project'], data['comparison_id']):
        p = other['payload']
        if any(p[k] != data[k] for k in ('domain', 'target', 'task')):
            raise ValueError('같은 comparison_id는 동일 작업·분야·대상이어야 합니다.')
        if p['variant'] == data['variant'] and p != data:
            raise ValueError('같은 비교의 예측을 바꿀 수 없습니다. 새 comparison_id를 사용하세요.')


def validate_feedback(db, prediction, source_id, source_order):
    p = prediction['payload']
    if not p.get('comparison_id'):
        return
    predictions = comparison_predictions(db, prediction['project'], p['comparison_id'])
    if {r['payload']['variant'] for r in predictions} != {'baseline', 'harness'} or any(
            r['order'] >= source_order for r in predictions):
        raise ValueError('양쪽 예측을 같은 사용자 피드백 원문보다 먼저 기록해야 합니다.')
    ids = {r['id'] for r in predictions}
    for row in db.execute("SELECT payload FROM records WHERE kind='feedback' AND project=?", (prediction['project'],)):
        f = json.loads(row[0])
        if f['prediction_id'] in ids and f['source_id'] != source_id:
            raise ValueError('같은 비교는 동일한 사용자 피드백 원문으로 평가하세요.')


def compare(db, project, domain=None, target=None, limit=6):
    if not project or not 1 <= limit <= 20:
        raise ValueError('project 및 limit 1~20이 필요합니다.')
    groups, feedbacks = defaultdict(list), defaultdict(list)
    for row in db.execute("SELECT id,payload FROM records WHERE kind='prediction' AND project=?", (project,)):
        p = json.loads(row['payload'])
        if p.get('comparison_id') and (not domain or p['domain'] == domain) and (not target or p['target'] == target):
            groups[p['comparison_id']].append(dict(id=row['id'], payload=p))
    for row in db.execute("SELECT id,payload FROM records WHERE kind='feedback' AND project=?", (project,)):
        p = json.loads(row['payload'])
        feedbacks[p['prediction_id']].append(dict(id=row['id'], **p))
    counts = dict(determinate=0, incomplete=0, ambiguous=0, undetermined=0,
                  baseline_matched=0, harness_matched=0, improved=0, regressed=0, unchanged=0)
    pairs = []
    for cid, predictions in groups.items():
        pair = dict(comparison_id=cid, variants={})
        state = 'incomplete'
        if len(predictions) == 2 and {r['payload']['variant'] for r in predictions} == {'baseline', 'harness'}:
            state = 'determinate'
            for row in predictions:
                fs = feedbacks[row['id']]
                outcomes = {f['outcome'] for f in fs}
                pair['variants'][row['payload']['variant']] = dict(prediction_id=row['id'],
                    feedback_ids=[f['id'] for f in fs], outcomes=sorted(outcomes))
                if not outcomes:
                    state = 'incomplete'
                elif len(outcomes) > 1:
                    state = 'ambiguous' if state != 'incomplete' else state
                elif 'undetermined' in outcomes and state == 'determinate':
                    state = 'undetermined'
        counts[state] += 1
        pair['state'] = state
        if state == 'determinate':
            baseline = pair['variants']['baseline']['outcomes'] == ['matched']
            harness = pair['variants']['harness']['outcomes'] == ['matched']
            counts['baseline_matched'] += baseline
            counts['harness_matched'] += harness
            change = 'improved' if harness and not baseline else 'regressed' if baseline and not harness else 'unchanged'
            counts[change] += 1
            pair['change'] = change
        pairs.append(pair)
    n = counts['determinate']
    return dict(project=project, database_writes=False, pairs_total=len(pairs), counts=counts,
                baseline_match_rate=counts['baseline_matched'] / n if n else None,
                harness_match_rate=counts['harness_matched'] / n if n else None,
                evidence_status='available' if n else 'insufficient_data', pairs=pairs[:limit],
                pairs_truncated=len(pairs) > limit, verdict_by='agent_interpretation_of_user_feedback',
                measurement='paired_feedback_agreement_not_model_accuracy',
                limitation='Registration order cannot prove feedback was unseen or baseline was uncontaminated. No causal improvement claim.')


def check_retrieval(db, packet):
    from judgments import get
    from retrieval import retrieve
    cases = packet.get('cases')
    if (packet.get('evaluation_kind') != 'retrieval_regression' or
            packet.get('expected_by') not in ('agent_source_review', 'mechanical_source_delivery') or
            not isinstance(cases, list) or not 1 <= len(cases) <= 40):
        raise ValueError('원문 검토 기반 retrieval_regression 사례 1~40개가 필요합니다.')
    fingerprints = packet.get('record_fingerprints', {})
    if not isinstance(fingerprints, dict):
        raise ValueError('record_fingerprints는 검토 ID와 fingerprint 객체여야 합니다.')
    for rid, expected in fingerprints.items():
        if get(db, rid)['fingerprint'] != expected:
            raise ValueError('검토한 기록 버전이 다릅니다: ' + rid)
    names, results = set(), []
    for case in cases:
        name = case.get('name')
        if not isinstance(name, str) or not name.strip() or name in names:
            raise ValueError('사례 이름은 비어 있지 않고 중복 없어야 합니다.')
        names.add(name)
        required_ids, forbidden_ids = case.get('must_be_eligible', []), case.get('must_not_be_eligible', [])
        if (any(not isinstance(ids, list) or len(ids) > 20 or any(not isinstance(i, str) for i in ids)
                for ids in (required_ids, forbidden_ids)) or not (required_ids or forbidden_ids)):
            raise ValueError('각 사례에 검토한 적용 후보/금지 ID 목록이 필요합니다.')
        for rid in required_ids + forbidden_ids:
            row = get(db, rid)
            if row['kind'] not in ('judgment', 'candidate') or rid not in fingerprints:
                raise ValueError('기대 ID의 종류와 검토 버전 fingerprint가 필요합니다.')
        query = case.get('query')
        if not isinstance(query, dict) or set(query) - {'project', 'query', 'domain', 'target', 'purpose', 'conversation', 'limit', 'chars', 'include_unresolved', 'fallback_target', 'full_source_review'}:
            raise ValueError('사례 query에는 범위가 명확한 retrieve 인자만 사용하세요.')
        found = retrieve(db, **query, _eligibility_ids=set(required_ids + forbidden_ids))
        eligible = {r['id'] for r in found['results'] if r['usage'] == 'confirmed_rule' and r['rule_eligible']}
        missing, overapplied = sorted(set(required_ids) - eligible), sorted(set(forbidden_ids) & eligible)
        results.append(dict(name=name, passed=not (missing or overapplied), missing_candidates=missing,
                            forbidden_candidates=overapplied, query=query))
    return dict(database_writes=False, evaluation_kind='retrieval_regression', semantic_accuracy_measured=False,
                expected_by=packet['expected_by'], passed=all(r['passed'] for r in results),
                cases_total=len(results), cases_passed=sum(r['passed'] for r in results), results=results,
                limitation='Tests retrieval eligibility, not automatic condition satisfaction or final model decisions. Curated cases are not a held-out accuracy benchmark.')


def check_interpretation(db, packet):
    """Check submitted structured decisions against curated source-reviewed expectations."""
    from judgments import get, required
    from retrieval import retrieve
    cases = packet.get('cases')
    if (packet.get('evaluation_kind') != 'interpretation_regression' or
            packet.get('expected_by') != 'agent_source_review' or
            not isinstance(cases, list) or not 1 <= len(cases) <= 40):
        raise ValueError('원문 검토 interpretation_regression 사례 1~40개가 필요합니다.')
    results, names = [], set()
    for case in cases:
        required(case, 'name', 'review_note')
        if case['name'] in names:
            raise ValueError('사례 이름은 중복될 수 없습니다.')
        names.add(case['name'])
        scope = case.get('scope', {})
        if not isinstance(scope, dict) or set(scope) != {'project', 'domain', 'target'}:
            raise ValueError('사례는 정확한 project/domain/target 범위가 필요합니다.')
        required(scope, 'project', 'domain', 'target')
        sources = case.get('sources')
        if not isinstance(sources, list) or not sources:
            raise ValueError('실제 원문 ID·인용·fingerprint가 필요합니다.')
        for ref in sources:
            required(ref, 'source_id', 'quote', 'fingerprint')
            source = get(db, ref['source_id'])
            if (source['kind'] not in ('source', 'message') or source['project'] != scope['project'] or
                    source['payload'].get('role') != 'user' or ref['quote'] not in source['payload'].get('text', '') or
                    ref['fingerprint'] != source['fingerprint'] or
                    source['kind'] == 'message' and not source['payload'].get('active_branch')):
                raise ValueError('사례 원문의 화자·범위·인용·버전이 다릅니다.')
        expected, response, forbidden = case.get('expected'), case.get('response'), case.get('forbidden')
        def decision(value):
            if not isinstance(value, dict) or set(value) != {'target', 'actions'}:
                raise ValueError('판정은 target 및 대상별 actions 객체입니다.')
            required(value, 'target')
            if not isinstance(value['actions'], dict) or not value['actions']:
                raise ValueError('검토한 대상별 동작이 필요합니다.')
            for key, action in value['actions'].items():
                required(dict(object=key, action=action), 'object', 'action')
        decision(expected)
        if expected['target'] != scope['target'] or not isinstance(forbidden, list) or not forbidden:
            raise ValueError('기대 대상과 실제 실패의 오답 판정 조건이 필요합니다.')
        for wrong in forbidden:
            decision(wrong)
            if wrong == expected:
                raise ValueError('기대 판정은 오답과 같을 수 없습니다.')
        semantic = None
        if response is not None:
            decision(response)
            semantic = response == expected and response not in forbidden
        probe = case.get('retrieval')
        if not isinstance(probe, dict) or set(probe) - {'query', 'expected_ids', 'provider'} or not {'query', 'expected_ids'} <= set(probe):
            raise ValueError('검색 성공을 별도로 검사할 query/expected_ids가 필요합니다.')
        provider = probe.get('provider', 'retrieve')
        if provider not in ('retrieve', 'feedback_evidence'):
            raise ValueError('검색 provider는 retrieve/feedback_evidence입니다.')
        query, ids = probe['query'], probe['expected_ids']
        if (not isinstance(query, dict) or any(query.get(k) != v for k, v in scope.items()) or
                not isinstance(ids, list) or not ids or len(ids) > 20):
            raise ValueError('같은 범위의 검색과 실제 기대 기록 ID가 필요합니다.')
        for rid in ids:
            record = get(db, rid)
            if record['project'] != scope['project'] or record['payload'].get('source_id') not in {s['source_id'] for s in sources}:
                raise ValueError('검색 기대 기록은 이 사례의 실제 원문에 연결되어야 합니다.')
        if provider == 'feedback_evidence':
            from learning import feedback_evidence
            found = feedback_evidence(db, **query)
        else:
            found = retrieve(db, **query)
        returned = {r['id'] for r in found['results']}
        missing = sorted(set(ids) - returned)
        results.append(dict(name=case['name'], retrieval_provider=provider, retrieval_passed=not missing, missing_records=missing,
                            interpretation_passed=semantic, response_status='submitted' if response is not None else 'not_submitted'))
    return dict(database_writes=False, evaluation_kind='interpretation_regression', cases_total=len(results),
                retrieval_passed=sum(r['retrieval_passed'] for r in results),
                interpretation_evaluated=sum(r['interpretation_passed'] is not None for r in results),
                interpretation_passed=sum(r['interpretation_passed'] is True for r in results),
                passed=all(r['retrieval_passed'] and r['interpretation_passed'] is True for r in results),
                results=results, independent_accuracy_measured=False,
                limitation='Curated replay of submitted structured interpretations; not a live model/visual test, user acceptance or general improvement metric.')
