"""Replay curated conversation cases; validates storage, not model accuracy."""
import argparse
import copy
import json
from pathlib import Path

import judgments as j

CASES = Path(__file__).resolve().parent.parent / 'examples' / 'classification-cases.json'


def replay(db, cases_path=CASES):
    packet = json.loads(Path(cases_path).read_text(encoding='utf-8'))
    results = []
    for case in packet['cases']:
        data = copy.deepcopy(case['classification'])
        origin = 'current-conversation/classification-review/' + case['name']
        source_id = j.add_source(db, dict(project=data['project'], origin=origin,
                                 observed_at='unknown', role='user', text=case['quote']))
        context_ids = {}
        context_text = {}
        for context in case['contexts']:
            context_ids[context['key']] = j.add_source(db, dict(project=data['project'],
                origin=origin + '/' + context['key'], observed_at='unknown',
                role=context['role'], text=context['text']))
            context_text[context['key']] = context['text']
        for ref in data['context_refs']:
            key = ref.pop('key')
            ref.update(source_id=context_ids[key], quote=context_text[key])
        data.update(source_id=source_id, quote=case['quote'])
        for item in data.get('attributes', {}).get('conditions', []):
            item['source_id'] = source_id
        for name in ('priority', 'action_state'):
            item = data.get('attributes', {}).get(name)
            if item:
                item['source_id'] = source_id
        rid = j.add_candidate(db, data)
        readback = j.get(db, rid)
        assert readback['payload'] == data
        assert rid not in [r['id'] for r in j.search(db, data['project'], target=data['target'])['results']]
        results.append(dict(case=case['name'], id=rid, quote=case['quote'],
                            types=data['types'], interpretation=data['interpretation'],
                            scope=data['scope_level'], decision_state=data['decision_state'],
                            context_state=data['context_state'], reuse=data['reuse'],
                            stored_status=readback['status'], readback_equal=True,
                            attributes=data.get('attributes'), unclassified_reason=data.get('unclassified_reason')))
    return dict(classification_version=packet.get('classification_version', 1), classification_by=packet['classification_by'],
                independent_accuracy_evaluation=False, results=results)


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--db', required=True, help='Explicit DB path; no implicit production writes')
    parser.add_argument('--report', required=True)
    parser.add_argument('--cases', default=str(CASES))
    args = parser.parse_args()
    db = j.connect(args.db)
    try:
        with db:
            report = replay(db, args.cases)
        output = Path(args.report)
        output.parent.mkdir(parents=True, exist_ok=True)
        output.write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
        print(json.dumps(report, ensure_ascii=False, indent=2))
    finally:
        db.close()
