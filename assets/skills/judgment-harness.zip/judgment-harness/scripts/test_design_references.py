import contextlib
import io
import json
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

import design_references as refs
import judgments as j
from test_batch import packet


class DesignReferenceTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.root = Path(self.temp.name)
        self.write(refs.INDEX, 'game-design-reading-index', '게임 자료',
                   '[[Camera]]\n[[Level]]\n[[Workflow]]')
        self.write('Camera.md', 'game-design-reading', '전투 카메라',
            '## 원문 요약\n카메라 정보량과 전투 공간은 연결된다.\n\n'
            '## 적용 제안 (원문 내용이 아닌 분석)\n### 점검\n카메라 워킹의 정보 전달을 현재 게임에서 검토한다.',
            'status: verified\nurl: "https://example.invalid/camera"\ntags: [카메라, 전투]')
        self.write('Level.md', 'game-design-topic', '던전 구조와 레벨 디자인',
            '## 핵심 원칙\n레벨 디자인은 동선, 공간 구조, 인카운터를 함께 검토한다.\n\n[[LevelCase]]',
            'status: synthesized\ntopics: [던전, 레벨디자인]')
        self.write('LevelCase.md', 'game-design-reading', '던전 진행', '동선과 인카운터를 설계한다.', 'status: partial')
        self.write('Workflow.md', 'game-design-reading', '협업 흐름', '협업과 제작 파이프라인 사례. 워킹트리와 워킹데이.', 'priority: high')
        self.root_patch = patch.object(refs, 'ROOT', self.root)
        self.root_patch.start()

    def tearDown(self):
        self.root_patch.stop(); self.temp.cleanup()

    def write(self, name, kind, title, body, extra=''):
        (self.root / name).write_text(f'---\ntype: {kind}\ntitle: "{title}"\n{extra}\n---\n\n# {title}\n\n{body}\n', encoding='utf-8')

    def test_camera_query_delivers_exact_note_evidence_separate_from_user_judgments(self):
        before = {p.name:p.read_bytes() for p in self.root.iterdir()}
        result = refs.search('카메라 워킹')
        self.assertEqual(result['status'], 'ok')
        self.assertEqual(result['topics'], ['camera'])
        self.assertEqual(Path(result['results'][0]['path']).name, 'Camera.md')
        self.assertFalse(result['user_judgment'])
        self.assertFalse(result['database_writes'])
        note = result['results'][0]
        self.assertEqual(note['usage'], 'reference_only')
        self.assertFalse(note['rule_eligible'])
        self.assertEqual(note['note_status'], 'verified')
        self.assertIn('not a new primary-source verification', result['instruction'])
        text = Path(note['path']).read_text(encoding='utf-8')
        for block in note['passages']:
            self.assertIn(block['text'], text)
            self.assertEqual(text.splitlines()[block['line']-1], block['text'].splitlines()[0])
        analysis = next(b for b in note['passages'] if '현재 게임' in b['text'])
        self.assertIn('원문 내용이 아닌 분석', analysis['section'])
        self.assertEqual(before, {p.name:p.read_bytes() for p in self.root.iterdir()})

    def test_level_synonyms_reach_synthesis_and_its_linked_case(self):
        result = refs.search('level design')
        self.assertEqual(result['topics'], ['level'])
        self.assertEqual(result['indexed_note_count'], 4)
        self.assertTrue(any(x['note_type'] == 'game-design-topic' for x in result['results']))
        self.assertTrue(any(Path(x['path']).name == 'LevelCase.md' for x in result['results']))
        self.assertEqual(result['coverage']['level']['dedicated_topic_notes'], [str(self.root / 'Level.md')])

    def test_multi_topic_query_keeps_camera_evidence_when_level_materials_are_more_numerous(self):
        index = self.root / refs.INDEX
        for n in range(8):
            self.write(f'Level{n}.md', 'game-design-topic', '레벨 디자인 던전 동선 인카운터',
                       '레벨 디자인 공간 구조 동선 인카운터 dungeon encounter')
            with index.open('a', encoding='utf-8') as out: out.write(f'\n[[Level{n}]]')
        result = refs.search('카메라 워킹과 레벨 디자인', limit=2)
        self.assertTrue(any(Path(x['path']).name == 'Camera.md' for x in result['results']))
        self.assertEqual(len(result['results']), 2)
        self.assertEqual(result['coverage']['camera']['dedicated_topic_notes'], [])

    def test_favored_unrelated_article_is_not_returned_as_a_camera_rule(self):
        result = refs.search('카메라 워킹')
        self.assertFalse(any(x['priority'] == 'high' for x in result['results']))
        self.assertFalse(any(x['rule_eligible'] for x in refs.search('협업')['results']))
        self.assertEqual(refs.search('unmatched-token')['results'], [])
        self.assertEqual(refs.search('수익률 계산')['results'], [])

    def test_current_notes_and_index_are_read_again_without_an_import_or_cache(self):
        before = refs.search('카메라')['results'][0]['sha256']
        with (self.root / 'Camera.md').open('a', encoding='utf-8') as out:
            out.write('\n## 추가 한계\n카메라 회전 제약은 별도 검증한다.\n')
        self.assertNotEqual(before, refs.search('카메라')['results'][0]['sha256'])
        self.write('New.md', 'game-design-reading', '카메라 새 사례', '카메라 워킹 사례')
        self.assertFalse(any(Path(x['path']).name == 'New.md' for x in refs.search('카메라')['results']))
        with (self.root / refs.INDEX).open('a', encoding='utf-8') as out: out.write('\n[[New]]')
        self.assertTrue(any(Path(x['path']).name == 'New.md' for x in refs.search('카메라', limit=5)['results']))

    def test_extension_aliases_of_the_same_indexed_note_are_read_only_once(self):
        with (self.root / refs.INDEX).open('a',encoding='utf-8') as out:
            out.write('\n[[Camera.md]]\n[[Level.md]]')
            if Path('Camera.md') == Path('camera.md'):
                out.write('\n[[camera.md]]')
        with (self.root / 'Camera.md').open('a',encoding='utf-8') as out:
            out.write('\n[[Camera.md]]\n[[Camera]]')
        result=refs.search('카메라',limit=5)
        self.assertEqual(result['indexed_note_count'],4)
        paths=[x['path'] for x in result['results']]
        self.assertEqual(len(paths),len(set(paths)))
        self.assertEqual([Path(p).name for p in paths],['Camera.md'])

    def test_traversal_unrelated_note_and_missing_links_are_explicitly_excluded(self):
        self.write('Private.md', 'private-note', '카메라 개인 자료', '카메라 secret')
        with (self.root / refs.INDEX).open('a', encoding='utf-8') as out:
            out.write('\n[[../outside]]\n[[Private]]\n[[Missing]]')
        result = refs.search('카메라')
        self.assertFalse(any('secret' in str(x) for x in result['results']))
        self.assertEqual(len(result['warnings']), 3)
        (self.root / refs.INDEX).unlink()
        self.assertEqual(refs.search('카메라')['status'], 'unavailable')

    def test_truncated_passage_retains_its_exact_followup_and_does_not_claim_full_note_readback(self):
        self.write('Camera.md', 'game-design-reading', '카메라', '카메라 ' * 200)
        note = refs.search('카메라', chars=80)['results'][0]
        self.assertFalse(note['note_readback']['complete'])
        self.assertEqual(note['note_readback']['followup_path'], note['path'])
        self.assertLessEqual(sum(len(p['text']) for p in note['passages']), 80)
        self.assertIn('selected paragraphs only', note['note_readback']['scope'])

    def test_heading_only_note_does_not_claim_completed_passage_readback(self):
        self.write('Camera.md','game-design-reading','카메라','## 카메라 조사 예정')
        note=refs.search('카메라')['results'][0]
        self.assertEqual(note['passages'],[])
        self.assertFalse(note['note_readback']['complete'])
        self.assertEqual(note['note_readback']['followup_path'],note['path'])

    def test_standalone_cli_needs_no_db_and_validates_input(self):
        output = io.StringIO()
        with patch.object(j, 'connect', side_effect=AssertionError('DB must not open')), contextlib.redirect_stdout(output):
            j.main(['--db', str(self.root / 'missing.sqlite3'), 'design-references', '--query', '카메라'])
        self.assertEqual(json.loads(output.getvalue())['topics'], ['camera'])
        for kwargs in (dict(query=''), dict(query='x', limit=True), dict(query='x', topic='unknown'), dict(query='x', chars=2001)):
            with self.subTest(kwargs=kwargs), self.assertRaises(ValueError): refs.search(**kwargs)

    def test_common_default_db_cli_adds_references_without_changing_judgments(self):
        path = self.root / 'test.sqlite3'
        db = j.connect(path, create=True)
        rid = j.save_batch(db, packet())['results'][-1]['id']; db.close()
        def run(flags):
            output = io.StringIO()
            with patch.object(j, 'DEFAULT_DB', path), contextlib.redirect_stdout(output):
                j.main(['retrieve', '--project', 'projectut', '--query', '카메라', '--no-auto-recovery', *flags])
            return json.loads(output.getvalue())
        ordinary, with_refs = run(['--no-design-references']), run([])
        self.assertEqual(ordinary['results'], with_refs['results'])
        self.assertEqual(with_refs['design_references']['topics'], ['camera'])
        with contextlib.closing(j.connect(path, read_only=True)) as db:
            self.assertEqual(j.get(db, rid)['status'], 'confirmed')
        with patch.object(refs, 'search', side_effect=AssertionError('unrelated scope must not scan')):
            self.assertEqual(refs.attach({}, 'crack', 'creative', '카메라'), {})


if __name__ == '__main__':
    unittest.main()
