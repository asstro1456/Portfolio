"""Append-only skill-change proposals and later classification; never apply skills."""
import json
import re
import sys
from pathlib import Path

import judgments as j

CATEGORIES = ('existing_skill_update', 'new_skill', 'tooling', 'case_reference',
              'already_covered', 'defer', 'reject')


def register(sub):
    parser = sub.add_parser('skill-queue', help='스킬 개선 제안 대기열; 분류와 실제 구현을 구분')
    actions = parser.add_subparsers(dest='queue_action', required=True)
    for action in ('add', 'review'):
        actions.add_parser(action).add_argument('--input', required=True)
    parser = actions.add_parser('list')
    parser.add_argument('--project', required=True)
    parser.add_argument('--skill')
    parser.add_argument('--status', choices=('pending_review', 'needs_context', 'classified', 'all'), default='pending_review')
    parser.add_argument('--limit', type=int, default=10)
    parser.add_argument('--offset', type=int, default=0)
    actions.add_parser('show').add_argument('id')


def skill_name(value):
    if not isinstance(value, str) or not re.fullmatch(r'[a-z0-9][a-z0-9_-]{0,127}', value):
        raise ValueError('스킬 이름은 소문자 영문/숫자/밑줄/하이픈 ID입니다.')
    return value


def references(data):
    refs = data.get('evidence', [])
    if not isinstance(refs, list) or len(refs) > 20:
        raise ValueError('evidence는 근거 경로/설명 문자열 최대 20개입니다.')
    if any(not isinstance(ref, str) or not ref.strip() or len(ref) > 2000 for ref in refs):
        raise ValueError('근거 경로/설명은 비어 있지 않은 2000자 이하 문자열입니다.')
    return refs


def head(db, item_id):
    row = db.execute("SELECT r.id FROM records r WHERE r.kind='skill_review' "
                     "AND json_extract(r.payload,'$.item_id')=? "
                     "AND NOT EXISTS (SELECT 1 FROM records n WHERE n.supersedes=r.id)", (item_id,)).fetchone()
    return j.get(db, row['id']) if row else None


def add(db, data):
    j.required(data, 'project', 'source_id', 'quote', 'conversation_id', 'turn_id')
    source = j.evidence(db, data, user_only=True)
    if source['project'] != data['project']:
        raise ValueError('큐 항목과 요청 원문의 프로젝트가 같아야 합니다.')
    if source['payload'].get('conversation_id') != data['conversation_id']:
        raise ValueError('큐 항목과 요청 원문의 대화가 다릅니다.')
    if source['payload'].get('turn_id') != data['turn_id']:
        raise ValueError('큐 항목과 요청 원문의 턴이 다릅니다.')
    items = data.get('items')
    if not isinstance(items, list) or not 1 <= len(items) <= 20:
        raise ValueError('한 번에 등록할 items는 1~20개입니다.')
    result = []
    for item in items:
        if not isinstance(item, dict):
            raise ValueError('각 개선 제안은 JSON 객체여야 합니다.')
        j.required(item, 'proposal_key', 'target_skill', 'title', 'summary')
        skill_name(item['proposal_key'])
        skill_name(item['target_skill'])
        if len(item['title']) > 240 or len(item['summary']) > 8000:
            raise ValueError('제목 240자, 제안 설명 8000자 이내를 사용하세요.')
        payload = {key: data[key] for key in ('source_id', 'quote', 'conversation_id', 'turn_id')}
        payload.update({key: item[key] for key in ('proposal_key', 'target_skill', 'title', 'summary')})
        payload.update(evidence=references(item), provenance='agent_proposal_for_review', implementation_status='NOT_APPLIED')
        old = db.execute("SELECT id FROM records WHERE kind='skill_change' AND project=? AND target=? "
                         "AND json_extract(payload,'$.proposal_key')=?", (data['project'], item['target_skill'], item['proposal_key'])).fetchone()
        if old and j.get(db, old['id'])['payload'] != payload:
            raise ValueError('같은 proposal_key의 내용이 다릅니다. 기존 항목을 확인하고 새 버전 키를 사용하세요.')
        rid = old['id'] if old else j.put(db, 'skill_change', data['project'], 'skill-maintenance',
                                         item['target_skill'], 'pending_review', payload)
        review = head(db, rid)
        result.append(dict(id=rid, target_skill=item['target_skill'], status=review['status'] if review else 'pending_review'))
    return dict(items=result, active_rules_created=0, skills_modified=False)


def review(db, data):
    j.required(data, 'item_id', 'classification', 'review_note', 'reviewer_conversation_id', 'reviewer_turn_id')
    item = j.get(db, data['item_id'])
    if item['kind'] != 'skill_change' or data['classification'] not in CATEGORIES:
        raise ValueError('유효한 큐 항목과 스킬 분류 값이 필요합니다.')
    targets = data.get('target_skills', [])
    if not isinstance(targets, list) or len(targets) > 10:
        raise ValueError('target_skills는 중복 없는 스킬 이름 최대 10개입니다.')
    for name in targets:
        skill_name(name)
    if len(set(targets)) != len(targets):
        raise ValueError('target_skills에 중복된 스킬 이름이 있습니다.')
    if data['classification'] in ('existing_skill_update', 'new_skill', 'tooling', 'case_reference') and not targets:
        raise ValueError('적용/검토할 대상 스킬을 명시하세요.')
    refs = references(data)
    if data['classification'] == 'already_covered' and not refs:
        raise ValueError('이미 반영됐다고 분류하려면 실제 스킬 경로/구간 근거가 필요합니다.')
    previous = head(db, item['id'])
    payload = {key: data[key] for key in ('item_id', 'classification', 'review_note', 'reviewer_conversation_id', 'reviewer_turn_id')}
    payload.update(target_skills=targets, evidence=refs, implementation_status='NOT_APPLIED', verdict_by='review_session')
    prior = data.get('supersedes')
    status = 'needs_context' if data['classification'] == 'defer' else 'classified'
    replay = db.execute('SELECT id FROM records WHERE fingerprint=?',
                        (j.digest(['skill_review', item['project'], item['domain'], item['target'], status, payload, prior]),)).fetchone()
    if replay:
        return dict(id=replay['id'], item_id=item['id'], status=status, implementation_status='NOT_APPLIED')
    if prior != (previous['id'] if previous else None):
        raise ValueError('분류 기록이 변경됐습니다. show로 최신 검토를 읽고 supersedes를 지정하세요.')
    rid = j.put(db, 'skill_review', item['project'], item['domain'], item['target'], status, payload, prior)
    return dict(id=rid, item_id=item['id'], status=status, implementation_status='NOT_APPLIED')


def show(db, item_id):
    item = j.get(db, item_id)
    if item['kind'] != 'skill_change':
        raise ValueError('스킬 개선 큐 항목 ID가 필요합니다.')
    source = j.evidence(db, item['payload'], user_only=True)
    current = head(db, item_id)
    return dict(item=item, latest_review=current, status=current['status'] if current else 'pending_review',
                source=source, implementation_status='NOT_APPLIED', active_rule=False)


def listing(db, project, status='pending_review', skill=None, limit=10, offset=0):
    if not 1 <= limit <= 50 or offset < 0:
        raise ValueError('limit 1~50, offset 0 이상을 사용하세요.')
    sql = ("FROM records q LEFT JOIN records r ON r.kind='skill_review' "
           "AND json_extract(r.payload,'$.item_id')=q.id "
           "AND NOT EXISTS (SELECT 1 FROM records n WHERE n.supersedes=r.id) "
           "WHERE q.kind='skill_change' AND q.project=? ")
    params = [project]
    if status != 'all':
        sql += "AND coalesce(r.status,'pending_review')=? "
        params.append(status)
    if skill:
        sql += 'AND q.target=? '
        params.append(skill)
    total = db.execute('SELECT count(*) ' + sql, params).fetchone()[0]
    rows = db.execute("SELECT q.id,q.target,q.payload,coalesce(r.status,'pending_review') AS state,r.id AS review_id "
                      + sql + 'ORDER BY q.rowid LIMIT ? OFFSET ?', params + [limit, offset]).fetchall()
    return dict(total=total, items=[dict(id=row['id'], target_skill=row['target'], status=row['state'],
                                        title=json.loads(row['payload'])['title'], review_id=row['review_id'],
                                        implementation_status='NOT_APPLIED') for row in rows], limit=limit, offset=offset)


def execute(db, args):
    if args.queue_action == 'list':
        return listing(db, args.project, args.status, args.skill, args.limit, args.offset)
    if args.queue_action == 'show':
        return show(db, args.id)
    raw = sys.stdin.read() if args.input == '-' else Path(args.input).read_text(encoding='utf-8-sig')
    data = json.loads(raw.lstrip('\ufeff'))
    if not isinstance(data, dict):
        raise ValueError('JSON 객체가 필요합니다.')
    # Serialize deduplication and stale-review checks across separate review sessions.
    if not db.in_transaction:
        db.execute('BEGIN IMMEDIATE')
    return add(db, data) if args.queue_action == 'add' else review(db, data)
