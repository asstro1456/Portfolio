import json
import subprocess
import sys
import unittest

import judgments as j
import learning
import test_learning as fixtures
from evaluation import check_interpretation
from retrieval import retrieve


class FeedbackEvidenceTests(unittest.TestCase):
    setUp = fixtures.LearningTests.setUp
    tearDown = fixtures.LearningTests.tearDown
    prediction_data = fixtures.LearningTests.prediction_data
    predict = fixtures.LearningTests.predict
    source = fixtures.LearningTests.source
    feedback = fixtures.LearningTests.feedback

    def search(self, **updates):
        options = dict(project='projectut', domain='vfx', target='vision-blur', query='움직임')
        options.update(updates)
        return learning.feedback_evidence(self.db, **options)

    def test_actual_quote_and_agent_assessment_are_separate_not_eligible_and_readonly(self):
        fid = self.feedback()
        before = self.db.total_changes
        result = self.search()
        item = result['results'][0]
        self.assertEqual(item['id'], fid)
        self.assertEqual(item['kind'], 'feedback')
        self.assertEqual(item['usage'], 'feedback_evidence')
        self.assertFalse(item['rule_eligible'])
        self.assertTrue(item['review_required'])
        self.assertTrue(item['source_review']['complete'])
        self.assertFalse(item['source_review']['meaning_review_complete'])
        self.assertEqual(item['user_quote'], j.get(self.db, fid)['payload']['quote'])
        self.assertEqual(item['agent_analysis'], j.get(self.db, fid)['payload']['analysis'])
        self.assertEqual(before, self.db.total_changes)
        self.assertNotIn(fid, [r['id'] for r in retrieve(self.db, 'projectut', target='vision-blur')['results']])
        self.assertEqual(self.db.execute("SELECT count(*) FROM records WHERE kind IN ('judgment','candidate')").fetchone()[0], 0)

    def test_scope_and_task_and_conversation_do_not_leak(self):
        self.feedback()
        for changes in [dict(project='crack'), dict(domain='art'), dict(target='other'),
                        dict(conversation='other-chat'), dict(task='other-version'), dict(query='unrelated-word')]:
            with self.subTest(changes=changes): self.assertEqual(self.search(**changes)['results'], [])
        with self.assertRaises(ValueError): self.search(project='global')

    def test_undetermined_unknown_time_remains_evidence_and_truncation_is_explicit(self):
        pid = self.predict(); sid = self.source(observed_at='unknown')
        self.feedback(pid, sid, outcome='undetermined')
        item = self.search(chars=5)['results'][0]
        self.assertEqual(item['feedback_outcome'], 'undetermined')
        self.assertEqual(item['source_review']['sources'][0]['observed_at'], 'unknown')
        self.assertFalse(item['source_review']['complete'])
        self.assertFalse(item['rule_eligible'])
        for opts in [dict(chars=0), dict(chars=2001), dict(limit=21)]:
            with self.subTest(opts=opts), self.assertRaises(ValueError): self.search(**opts)

    def test_explicitly_superseded_feedback_is_not_duplicated_as_current_evidence(self):
        pid = self.predict()
        # Deterministic synthetic chronology, independent of the Windows clock tick.
        self.db.execute('UPDATE records SET created=? WHERE id=?', ('2020-01-01T00:00:00Z', pid))
        old = self.feedback(pid, self.source(observed_at='2021-01-01T00:00:00Z'))
        later = self.source(message_id='actual-later-correction', observed_at='2022-01-01T00:00:00Z')
        new = self.feedback(pid, later, outcome='matched', supersedes=old)
        ids = [r['id'] for r in self.search()['results']]
        self.assertNotIn(old, ids)
        self.assertIn(new, ids)

    def test_invalid_imported_evidence_is_skipped_without_creating_a_rule(self):
        pid = self.predict(); sid = self.source(role='assistant')
        j.put(self.db, 'feedback', 'projectut', 'vfx', 'vision-blur', 'matched',
              dict(prediction_id=pid, source_id=sid, quote='움직임', outcome='matched', analysis='invalid legacy fixture'))
        self.assertEqual(self.search()['results'], [])
        self.assertEqual(self.search()['skipped_invalid_evidence'], 1)

    def test_interpretation_replay_can_probe_separate_feedback_without_promoting_it(self):
        fid = self.feedback(); f = j.get(self.db, fid); source = j.get(self.db, f['payload']['source_id'])
        case = dict(name='feedback-supplement', scope=self.scope,
            sources=[dict(source_id=source['id'], quote=f['payload']['quote'], fingerprint=source['fingerprint'])],
            review_note='Synthetic structured response only.',
            expected=dict(target='vision-blur', actions=dict(motion='preserve')),
            forbidden=[dict(target='vision-blur', actions=dict(motion='freeze'))],
            response=None, retrieval=dict(provider='feedback_evidence', query=dict(self.scope, query='움직임'), expected_ids=[fid]))
        result = check_interpretation(self.db, dict(evaluation_kind='interpretation_regression', expected_by='agent_source_review', cases=[case]))
        self.assertEqual(result['retrieval_passed'], 1)
        self.assertEqual(result['interpretation_evaluated'], 0)
        self.assertFalse(result['passed'])

    def test_cli_search_does_not_write_database_or_merge_confirmed_rules(self):
        self.feedback(); self.db.commit(); before = self.path.read_bytes()
        result = subprocess.run([sys.executable, '-B', '-X', 'utf8', j.__file__, '--db', str(self.path),
            'feedback-evidence', '--project', 'projectut', '--domain', 'vfx', '--target', 'vision-blur',
            '--conversation', 'fixture-chat', '--task', 'blur-v1', '--query', '움직임'],
            capture_output=True, encoding='utf-8')
        self.assertEqual(result.returncode, 0, result.stderr)
        packet = json.loads(result.stdout)
        self.assertFalse(packet['database_writes'])
        self.assertFalse(packet['results'][0]['rule_eligible'])
        self.assertEqual(before, self.path.read_bytes())


if __name__ == '__main__': unittest.main()
