import copy
import io
import json
import tempfile
import unittest
from contextlib import redirect_stdout
from pathlib import Path
from unittest.mock import patch

import judgments as j
import skill_queue as q


class SkillQueueTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.path = Path(self.tmp.name) / 'test.sqlite3'
        self.db = j.connect(self.path, create=True)
        self.source = j.add_source(self.db, dict(project='projectut', role='user',
            origin='isolated-test', observed_at='2026-10-23T00:00:00+00:00',
            conversation_id='test-conversation', turn_id='test-turn', text='미반영 개선안을 검토 큐에 넣어줘.'))
        self.packet = dict(project='projectut', source_id=self.source, quote='미반영 개선안을 검토 큐에 넣어줘.',
            conversation_id='test-conversation', turn_id='test-turn', items=[dict(proposal_key='frame-audit',
            target_skill='ut-fullbody-rigging-harness', title='프레임 검사 공용화', summary='작업용 검사를 일반화할지 검토한다.', evidence=['test-only-reference'])])
        self.db.commit()

    def tearDown(self):
        self.db.close()
        self.tmp.cleanup()

    def add(self):
        return q.add(self.db, self.packet)['items'][0]['id']

    def review(self, item, **changes):
        packet = dict(item_id=item, classification='tooling', review_note='검사 로직을 검토한 분류이며 구현은 별도다.',
            reviewer_conversation_id='review-session', reviewer_turn_id='review-turn',
            target_skills=['ut-fullbody-rigging-harness'], evidence=['test-only-reference'])
        packet.update(changes)
        return q.review(self.db, packet)

    def test_add_replay_is_deduplicated_and_never_an_active_rule(self):
        item = self.add()
        self.assertEqual(self.add(), item)
        self.assertEqual(q.listing(self.db, 'projectut')['total'], 1)
        self.assertEqual(j.search(self.db, 'projectut', include_pending=True)['results'], [])
        self.assertEqual(j.get(self.db, item)['payload']['implementation_status'], 'NOT_APPLIED')
        with self.assertRaises(ValueError):
            j.add_judgment(self.db, dict(project='projectut', domain='skill-maintenance',
                target='ut-fullbody-rigging-harness', candidate_id=item, source_id=self.source,
                quote=self.packet['quote'], status='confirmed', decision='자동 적용 금지',
                reason_kind='unknown', review_note='Queue items are not judgment candidates.'))

    def test_batch_failure_rolls_back_and_changed_key_is_rejected(self):
        bad = copy.deepcopy(self.packet)
        bad['items'].append(dict(proposal_key='bad', target_skill='../invalid', title='bad', summary='bad'))
        with self.assertRaises(ValueError), self.db:
            q.add(self.db, bad)
        self.assertEqual(q.listing(self.db, 'projectut')['total'], 0)
        self.add()
        changed = copy.deepcopy(self.packet)
        changed['items'][0]['summary'] = '같은 키를 덮어쓰지 않는다.'
        with self.assertRaises(ValueError):
            q.add(self.db, changed)

    def test_user_source_project_conversation_and_turn_are_checked(self):
        for field, value in [('project', 'crack'), ('conversation_id', 'other'), ('turn_id', 'other'), ('quote', '없는 구절')]:
            bad = dict(self.packet, **{field: value})
            with self.subTest(field=field), self.assertRaises(ValueError):
                q.add(self.db, bad)

    def test_defer_classify_and_stale_review_preserve_history(self):
        item = self.add()
        first = self.review(item, classification='defer', target_skills=[])
        self.assertEqual(q.listing(self.db, 'projectut', 'needs_context')['total'], 1)
        self.assertEqual(q.listing(self.db, 'projectut')['total'], 0)
        with self.assertRaises(ValueError):
            self.review(item)
        second = self.review(item, supersedes=first['id'])
        self.assertEqual(self.review(item, supersedes=first['id']), second)
        self.assertEqual(q.show(self.db, item)['latest_review']['id'], second['id'])
        self.assertEqual(q.show(self.db, item)['implementation_status'], 'NOT_APPLIED')
        self.assertEqual(j.get(self.db, first['id'])['status'], 'needs_context')
        self.assertEqual(q.listing(self.db, 'projectut', 'classified')['total'], 1)

    def test_filters_and_already_covered_evidence(self):
        item = self.add()
        self.assertEqual(q.listing(self.db, 'crack', 'all')['total'], 0)
        self.assertEqual(q.listing(self.db, 'projectut', skill='other-skill')['total'], 0)
        with self.assertRaises(ValueError):
            self.review(item, classification='already_covered', evidence=[])
        with self.assertRaises(ValueError):
            self.review(item, target_skills=[{}])

    def test_cli_add_list_and_show_with_read_only_connection(self):
        with patch('sys.stdin', io.StringIO(json.dumps(self.packet, ensure_ascii=False))), redirect_stdout(io.StringIO()) as result:
            j.main(['--db', str(self.path), 'skill-queue', 'add', '--input', '-'])
        item = json.loads(result.getvalue())['items'][0]['id']
        with redirect_stdout(io.StringIO()) as result:
            j.main(['--db', str(self.path), 'skill-queue', 'list', '--project', 'projectut'])
        self.assertEqual(json.loads(result.getvalue())['items'][0]['id'], item)
        with redirect_stdout(io.StringIO()) as result:
            j.main(['--db', str(self.path), 'skill-queue', 'show', item])
        self.assertFalse(json.loads(result.getvalue())['active_rule'])


if __name__ == '__main__':
    unittest.main()
