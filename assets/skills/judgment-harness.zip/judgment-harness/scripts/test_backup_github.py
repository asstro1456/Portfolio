import base64
import hashlib
import json
import os
import subprocess
import tempfile
import sqlite3
from contextlib import closing
import unittest
from pathlib import Path
from unittest.mock import patch
from urllib.error import HTTPError

import judgments as j
from backup_github import backup, GitHub


class FakeGitHub:
    def __init__(self, private=True):
        self.private, self.writes = private, 0
        self.head, self.blobs = 'initial', {}
        self.trees = {'initial-tree':{}}
        self.commits = {'initial':{'tree':{'sha':'initial-tree'}, 'parents':[]}}
        self.raw_reads, self.updates = 0, 0
        self.reject_publish, self.corrupt_download = False, False

    def call(self, path, data=None, method='GET', raw=False):
        if path == '/user':
            return {'login':'asstro1456'}
        root = '/repos/asstro1456/codex-judgment-backup'
        if path == root:
            return {'private':self.private, 'owner':{'login':'asstro1456'}, 'default_branch':'main'}
        if path == root + '/git/ref/heads/main':
            return {'object':{'sha':self.head}}
        if '/contents/' in path:
            filename, _, ref = path.split('/contents/')[1].partition('?ref=')
            tree = self.trees[self.commits[ref or self.head]['tree']['sha']]
            sha = tree.get(filename)
            if not sha:
                return None
            content = self.blobs[sha]
            if raw:
                self.raw_reads += 1
                return b'corrupt' if self.corrupt_download else content
            return {'sha':sha, 'size':len(content), 'encoding':'none' if len(content)>1024**2 else 'base64',
                    'content':'' if len(content)>1024**2 else base64.b64encode(content).decode()}
        if method == 'GET' and '/git/commits/' in path:
            return self.commits[path.rsplit('/',1)[1]]
        if method == 'POST':
            self.writes += 1
            if path.endswith('/git/blobs'):
                content = base64.b64decode(data['content'])
                sha = hashlib.sha1(('blob '+str(len(content))+'\0').encode()+content).hexdigest()
                self.blobs[sha] = content
            elif path.endswith('/git/trees'):
                sha = 'tree-'+str(self.writes)
                tree = self.trees[data['base_tree']].copy()
                tree.update({entry['path']:entry['sha'] for entry in data['tree']})
                self.trees[sha] = tree
            elif path.endswith('/git/commits'):
                sha = 'commit-'+str(self.writes)
                self.commits[sha] = {'tree':{'sha':data['tree']}, 'parents':data['parents']}
            else:
                raise AssertionError(path)
            return {'sha':sha}
        if method == 'PATCH':
            assert data['force'] is False
            if self.reject_publish or self.commits[data['sha']]['parents'] != [self.head]:
                raise ValueError('Concurrent remote update; no force push')
            self.head = data['sha']
            self.updates += 1
            return {'object':{'sha':self.head}}
        raise AssertionError((path,method))


class BackupTests(unittest.TestCase):
    def test_credential_timeout_has_safe_diagnostic(self):
        error=subprocess.TimeoutExpired(['git'],20,output='DO-NOT-PRINT-SECRET')
        with patch('backup_github.subprocess.run',side_effect=error):
            with self.assertRaisesRegex(ValueError,'credential lookup timed out') as caught:GitHub()
        self.assertNotIn('DO-NOT-PRINT-SECRET',str(caught.exception))

    def test_missing_saved_account_has_safe_recovery_hint(self):
        secret='DO-NOT-PRINT-SECRET'
        failed=subprocess.CompletedProcess([],128,'',secret)
        accounts=subprocess.CompletedProcess([],0,'','')
        with patch('backup_github.subprocess.run',side_effect=[failed,accounts]):
            with self.assertRaises(ValueError) as caught:GitHub()
        self.assertIn('No saved GitHub account',str(caught.exception))
        self.assertIn('git credential-manager github login',str(caught.exception))
        self.assertNotIn(secret,str(caught.exception))

    def test_saved_account_read_failure_is_not_reported_as_expired(self):
        failed=subprocess.CompletedProcess([],128,'','private diagnostic')
        accounts=subprocess.CompletedProcess([],0,'asstro1456\n','')
        with patch('backup_github.subprocess.run',side_effect=[failed,accounts]):
            with self.assertRaises(ValueError) as caught:GitHub()
        self.assertIn('Stored GitHub credential could not be read',str(caught.exception))
        self.assertNotIn('expired',str(caught.exception))
        self.assertNotIn('private diagnostic',str(caught.exception))

    def test_unavailable_account_listing_keeps_generic_diagnostic(self):
        failed=subprocess.CompletedProcess([],128,'','DO-NOT-PRINT-SECRET')
        for listing in [subprocess.CompletedProcess([],1,'','DO-NOT-PRINT-SECRET'),
                        subprocess.TimeoutExpired(['git'],20),OSError('DO-NOT-PRINT-SECRET')]:
            with self.subTest(listing=type(listing).__name__):
                with patch('backup_github.subprocess.run',side_effect=[failed,listing]):
                    with self.assertRaises(ValueError) as caught:GitHub()
                self.assertIn('check the credential helper',str(caught.exception))
                self.assertNotIn('DO-NOT-PRINT-SECRET',str(caught.exception))

    def test_missing_repository_is_not_assumed_deleted_or_public(self):
        api=FakeGitHub()
        original=api.call
        def missing(path,*args,**kwargs):
            return None if path == '/repos/asstro1456/codex-judgment-backup' else original(path,*args,**kwargs)
        with tempfile.TemporaryDirectory() as folder:
            target=Path(folder)/'snapshot.db'
            with patch.object(api,'call',side_effect=missing):
                with self.assertRaisesRegex(ValueError,'missing or inaccessible'):
                    backup(api,Path(folder)/'absent.db',target)
            self.assertFalse(target.exists())
            self.assertEqual(api.writes,0)

    def test_http_auth_permission_and_rate_limit_failures_are_distinct_and_safe(self):
        api=GitHub.__new__(GitHub)
        api.headers={'Accept':'application/vnd.github+json'}
        for code,headers,expected in [(401,{},'invalid or expired'),
                                      (403,{},'permissions'),
                                      (403,{'X-RateLimit-Remaining':'0'},'rate limit'),
                                      (429,{'Retry-After':'60'},'rate limit')]:
            with self.subTest(code=code,headers=headers):
                error=HTTPError('https://api.github.com/user',code,'DO-NOT-PRINT-SECRET',headers,None)
                with patch('backup_github.urlopen',side_effect=error):
                    with self.assertRaises(ValueError) as caught:api.call('/user')
                self.assertIn(expected,str(caught.exception))
                self.assertNotIn('DO-NOT-PRINT-SECRET',str(caught.exception))

    def test_snapshot_remote_roundtrip_idempotency_and_metadata_repair(self):
        with tempfile.TemporaryDirectory() as folder:
            source, target = Path(folder)/'source.db', Path(folder)/'snapshot.db'
            j.connect(source, create=True).close()
            api = FakeGitHub()
            result = backup(api, source, target)
            self.assertTrue(result['verified'])
            with closing(sqlite3.connect(source)) as src, closing(sqlite3.connect(target)) as dst:
                self.assertEqual(list(src.iterdump()), list(dst.iterdump()))
            writes = api.writes
            self.assertFalse(backup(api, source, target)['changed'])
            self.assertEqual(api.writes, writes)
            del api.trees[api.commits[api.head]['tree']['sha']]['snapshot.json']
            backup(api, source, target)
            self.assertGreater(api.writes, writes)
            self.assertEqual(api.updates, 2)

    def test_large_archive_uses_raw_download_and_restores_verified_db(self):
        with tempfile.TemporaryDirectory() as folder:
            source, target = Path(folder)/'source.db', Path(folder)/'snapshot.db'
            with closing(j.connect(source, create=True)) as db:
                db.execute('CREATE TABLE large_payload(data BLOB)')
                db.execute('INSERT INTO large_payload VALUES (?)',(os.urandom(2*1024**2),))
                db.commit()
            api = FakeGitHub()
            result = backup(api, source, target)
            self.assertGreater(result['archive_bytes'],1024**2)
            self.assertEqual(result['downloaded_integrity'],'ok')
            self.assertEqual(api.raw_reads,2)
            self.assertEqual(api.updates,1)
            restored = target.with_name('github-verified.sqlite3')
            self.assertEqual(hashlib.sha256(restored.read_bytes()).hexdigest(),result['sha256'])

    def test_publish_failure_keeps_prior_branch_and_local_source(self):
        with tempfile.TemporaryDirectory() as folder:
            source, target = Path(folder)/'source.db', Path(folder)/'snapshot.db'
            j.connect(source, create=True).close()
            before=source.read_bytes()
            api=FakeGitHub();api.reject_publish=True
            with self.assertRaises(ValueError):backup(api, source, target)
            self.assertEqual(api.head,'initial')
            self.assertEqual(source.read_bytes(),before)

    def test_corrupt_download_cannot_be_reported_as_verified(self):
        with tempfile.TemporaryDirectory() as folder:
            source, target = Path(folder)/'source.db', Path(folder)/'snapshot.db'
            j.connect(source, create=True).close()
            api=FakeGitHub();api.corrupt_download=True
            with self.assertRaisesRegex(ValueError,'verification failed'):backup(api, source, target)
            self.assertFalse(target.with_name('github-verified.sqlite3').exists())

    def test_oversized_compressed_backup_fails_before_remote_writes(self):
        class Oversized:
            def __len__(self):return 100_000_000
        with tempfile.TemporaryDirectory() as folder:
            source, target = Path(folder)/'source.db', Path(folder)/'snapshot.db'
            j.connect(source, create=True).close()
            api=FakeGitHub()
            with patch('backup_github.gzip.compress',return_value=Oversized()):
                with self.assertRaisesRegex(ValueError,'file limit'):backup(api, source, target)
            self.assertEqual(api.writes,0)
            self.assertEqual(api.head,'initial')

    def test_public_repository_rejected_before_snapshot_or_upload(self):
        with tempfile.TemporaryDirectory() as folder:
            target = Path(folder)/'snapshot.db'
            api = FakeGitHub(private=False)
            with self.assertRaises(ValueError):
                backup(api, Path(folder)/'absent.db', target)
            self.assertEqual(api.writes, 0)
            self.assertFalse(target.exists())

    def test_legacy_path_redirect_and_no_stale_fallback(self):
        with tempfile.TemporaryDirectory() as folder:
            legacy, current = Path(folder)/'old.db', Path(folder)/'new.db'
            j.connect(legacy, create=True).close()
            before = legacy.read_bytes()
            with patch.object(j, 'LEGACY_DB', legacy), patch.object(j, 'DEFAULT_DB', current):
                with self.assertRaises(ValueError):
                    j.connect(legacy)
                db = j.connect(legacy, create=True)
                db.execute('CREATE TABLE redirect_probe(value)')
                db.commit()
                db.close()
                self.assertTrue(current.exists())
            self.assertEqual(before, legacy.read_bytes())


if __name__ == '__main__':
    unittest.main()
