"""Validate direct conversation-message source metadata without inferring user judgments."""
import json
import re

UUID = r'[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}'
ORIGIN = re.compile(r'conversation:(' + UUID + r')/message:((?:msg_)?' + UUID + r')')
IDENTITY = ('conversation_id', 'message_id', 'turn_id')


def normalize(db, data):
    """New direct origins require structured IDs; legacy replay may only reuse exact stored evidence."""
    origin = data.get('origin', '')
    if not isinstance(origin, str) or not origin.startswith('conversation:'):
        return data  # Existing export/session-log/document input contracts remain unchanged.
    match = ORIGIN.fullmatch(origin)
    if not match:
        raise ValueError('conversation origin에는 정확한 대화 UUID와 실제 메시지 UUID가 필요합니다.')
    conversation, message = match.groups()
    for key in IDENTITY:
        if key in data and (not isinstance(data[key], str) or not data[key].strip()):
            raise ValueError('빈 연결 메타데이터는 저장할 수 없습니다: ' + key)
    for key, expected in (('conversation_id', conversation), ('message_id', message)):
        if key in data and data[key] != expected:
            raise ValueError('origin과 구조화 연결 ID가 다릅니다: ' + key)
    if 'turn_id' in data and not re.fullmatch(UUID, data['turn_id']):
        raise ValueError('turn_id는 확인한 실제 턴 UUID여야 합니다.')
    for key in ('task', 'target'):
        if key in data and (not isinstance(data[key], str) or not data[key].strip()):
            raise ValueError('작업/대상 메타데이터는 비어 있을 수 없습니다.')
    rows = db.execute("SELECT id,project,payload FROM records WHERE kind='source' AND "
                      "(json_extract(payload,'$.origin')=? OR "
                      "(json_extract(payload,'$.conversation_id')=? AND json_extract(payload,'$.message_id')=?))",
                      (origin, conversation, message)).fetchall()
    missing = not all(key in data for key in ('conversation_id', 'message_id'))
    if missing:
        exact = []
        for row in rows:
            p = json.loads(row['payload'])
            # The only repair-compatible replay is the exact old packet minus verified identity additions.
            stripped = {k:v for k,v in p.items() if k not in IDENTITY or k in data}
            if row['project'] == data.get('project') and stripped == data and (
                    p == data or (p.get('conversation_id'), p.get('message_id')) == (conversation, message)):
                exact.append(p)
        if len(rows) == len(exact) == 1:
            return exact[0]  # Read/reuse only; no legacy migration or new origin-only row.
        raise ValueError('새 conversation 원문에는 conversation_id와 message_id를 명시하세요. 기존 누락은 원문 검증 후 별도로 복구하세요.')
    if rows:
        if len(rows) != 1 or rows[0]['project'] != data.get('project') or json.loads(rows[0]['payload']) != data:
            raise ValueError('기존 메시지의 프로젝트·화자·원문·시각·버전 메타데이터를 바꾸어 중복 저장할 수 없습니다.')
    return data
