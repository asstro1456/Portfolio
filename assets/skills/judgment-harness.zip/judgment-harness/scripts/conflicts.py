"""Evidence-backed, version-specific conflict reviews; never infer meaning from keywords."""
import json

RELATIONS = {'replacement', 'exception', 'separate', 'consistent', 'unresolved'}
NONBLOCKING = {'separate', 'consistent'}


def superseded_candidates(db, rule_id):
    """Exact unchanged evidence of explicit predecessor rules, never inferred recency."""
    from judgments import evidence, get
    rule = get(db, rule_id)
    current, seen, result = rule, {rule_id}, []
    while current.get('supersedes'):
        previous = current['supersedes']
        if previous in seen or current['payload'].get('supersedes') != previous or not current['payload'].get('change_reason'):
            raise ValueError('명시적 판단 대체 계보가 불완전합니다.')
        seen.add(previous)
        old = get(db, previous)
        if old['kind'] != 'judgment' or any(old[k] != rule[k] for k in ('project', 'domain', 'target')):
            raise ValueError('판단 대체 계보의 적용 범위가 다릅니다.')
        candidate_id = old['payload'].get('candidate_id')
        if old['status'] == 'confirmed' and candidate_id and not db.execute(
                'SELECT 1 FROM records WHERE supersedes=?', (candidate_id,)).fetchone():
            candidate = get(db, candidate_id)
            if candidate['kind'] != 'candidate' or any(candidate[k] != old[k] for k in ('project', 'domain', 'target')) or any(
                    candidate['payload'].get(k) != old['payload'].get(k) for k in ('source_id', 'quote')):
                raise ValueError('이전 판단과 분류 후보의 원문·범위가 다릅니다.')
            evidence(db, candidate['payload'], True)
            result.append((old, candidate))
        current = old
    return result


def head(db, record_id):
    from judgments import get
    row = get(db, record_id)
    while True:
        child = db.execute('SELECT id FROM records WHERE supersedes=?', (row['id'],)).fetchone()
        if not child:
            return row
        row = get(db, child[0])


def validate(db, data):
    from judgments import evidence, get, required
    required(data, 'project', 'domain', 'target', 'rule_id', 'change_id', 'relation', 'analysis')
    if data['relation'] not in RELATIONS:
        raise ValueError('relation은 replacement/exception/separate/consistent/unresolved입니다.')
    rule, change = get(db, data['rule_id']), get(db, data['change_id'])
    if (rule['kind'] != 'judgment' or rule['status'] != 'confirmed' or
            change['kind'] != 'candidate' or
            head(db, rule['id'])['id'] != rule['id'] or head(db, change['id'])['id'] != change['id']):
        raise ValueError('현재 확정 판단과 현재 분류 후보만 관계 검토할 수 있습니다.')
    if (rule['project'] not in (data['project'], 'global') or
            change['project'] not in (data['project'], 'global') or
            (data['project'] == 'global' and change['project'] != 'global') or
            rule['domain'] != data['domain'] or rule['target'] != data['target'] or
            (change['domain'] != rule['domain'] and '*' not in (change['domain'], rule['domain']))):
        raise ValueError('관계 검토의 프로젝트·분야·기준 대상이 다릅니다.')
    candidate_id = rule['payload'].get('candidate_id')
    current = head(db, candidate_id)['id'] if candidate_id else None
    if 'rule_candidate_id' not in data or data['rule_candidate_id'] != current:
        raise ValueError('rule_candidate_id는 검토한 기준의 현재 분류 버전이어야 합니다.')
    refs = data.get('evidence')
    if not isinstance(refs, list) or not refs or len(refs) > 20:
        raise ValueError('관계 검토 evidence에는 양쪽 원문·연결 맥락 인용 1~20개가 필요합니다.')
    expected = []
    for row in (rule, change):
        p = row['payload']
        expected.append(dict(source_id=p['source_id'], quote=p['quote']))
        expected.extend(p.get('context_refs', []))
    if candidate_id:
        expected.extend(get(db, current)['payload'].get('context_refs', []))
    allowed = {(r['source_id'], r['quote']) for r in expected}
    supplied = set()
    for ref in refs:
        if not isinstance(ref, dict):
            raise ValueError('evidence 인용은 객체여야 합니다.')
        source = evidence(db, ref)
        if source['project'] not in (data['project'], 'global'):
            raise ValueError('관계 검토 원문의 프로젝트가 다릅니다.')
        supplied.add((ref['source_id'], ref['quote']))
    if supplied != allowed:
        raise ValueError('관계 검토에는 양쪽 원문과 연결 맥락을 빠짐없이 그대로 인용해야 합니다.')
    for row in (rule, change):
        evidence(db, row['payload'], True)
    if data['relation'] == 'exception':
        required(data, 'condition')
    previous = data.get('supersedes')
    if previous:
        old = get(db, previous)
        if (old['kind'] != 'conflict_review' or old['project'] != data['project'] or
                any(old['payload'].get(k) != data[k] for k in ('rule_id', 'change_id')) or
                (head(db, previous)['id'] != previous and head(db, previous)['payload'] != data)):
            raise ValueError('같은 기록 쌍의 현재 관계 검토만 정정할 수 있습니다.')
    else:
        for row in db.execute("SELECT payload FROM records r WHERE kind='conflict_review' AND project=? "
                              'AND NOT EXISTS (SELECT 1 FROM records n WHERE n.supersedes=r.id)', (data['project'],)):
            p = json.loads(row[0])
            if all(p.get(k) == data.get(k) for k in ('rule_id', 'change_id', 'rule_candidate_id')) and p != data:
                raise ValueError('기존 관계 검토를 바꾸려면 supersedes를 명시하세요.')
    return rule


def save(db, data):
    from judgments import put
    rule = validate(db, data)
    return put(db, 'conflict_review', data['project'], rule['domain'], rule['target'],
               'reviewed', data, data.get('supersedes'))


def current_reviews(db, project):
    reviews = {}
    rows = db.execute("SELECT r.id,r.payload FROM records r WHERE kind='conflict_review' "
                      "AND project IN (?, 'global') AND NOT EXISTS "
                      '(SELECT 1 FROM records n WHERE n.supersedes=r.id)', (project,)).fetchall()
    for row in rows:
        p = json.loads(row['payload'])
        try:
            validate(db, p)
        except (ValueError, KeyError, TypeError):
            continue  # Changed record versions must be reviewed again, never inherit a suppression.
        key = (p['rule_id'], p['change_id'])
        if key not in reviews or p['project'] == project:
            reviews[key] = dict(id=row['id'], **p)
    return reviews
