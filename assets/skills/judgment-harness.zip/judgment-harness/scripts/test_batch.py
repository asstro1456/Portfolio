import copy
import json
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

import judgments as j


def packet(quote='블러 중에도 캐릭터나 배경 움직임은 유지되게 해줘.'):
    scope = dict(project='projectut', domain='vfx', target='vision-blur')
    attributes = dict(conditions=[], priority=None, action_state=None, acceptance_scope=None)
    candidate = dict(**scope, classification_version=2, source_id={'$ref':'user'}, quote=quote,
        types=['request'], type_quotes={'request':quote}, interpretation=quote,
        rationale='실제 수정 요청의 대상과 인용을 확인', decision_state='explicit',
        scope_level='object', scope_basis='시야 블러만', reuse='reusable',
        context_state='standalone', context_refs=[], missing_context=[], reason_kind='unknown',
        attributes=attributes)
    return {'operations':[
        dict(ref='user', command='source', data=dict(project='projectut', role='user',
             origin='synthetic-regression-only', observed_at='test', text=quote)),
        dict(ref='candidate', command='candidate', data=candidate),
        dict(ref='rule', command='record', data=dict(**scope, source_id={'$ref':'user'},
             quote=quote, candidate_id={'$ref':'candidate'}, status='confirmed', decision=quote,
             reason_kind='unknown', review_note='원문과 대상 범위를 검토', attributes=attributes))]}


class BatchTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.path = Path(self.temp.name)/'isolated.sqlite3'
        self.db = j.connect(self.path, create=True)

    def tearDown(self):
        self.db.close()
        self.temp.cleanup()

    def cli(self, command, data=None):
        return subprocess.run([sys.executable, '-X', 'utf8', j.__file__, '--db', str(self.path),
                               *command], input=None if data is None else json.dumps(data, ensure_ascii=False),
                              capture_output=True, encoding='utf-8')

    def test_stdin_roundtrip_without_input_files_and_idempotency(self):
        before = {p.name for p in Path(self.temp.name).iterdir()}
        first = self.cli(['batch', '--input', '-'], packet())
        self.assertEqual(first.returncode, 0, first.stderr)
        saved = json.loads(first.stdout)
        self.assertTrue(saved['atomic'])
        self.assertTrue(all(r['verified'] for r in saved['results']))
        second = self.cli(['batch', '--input', '-'], packet())
        self.assertEqual(json.loads(second.stdout), saved)
        read = self.cli(['show', saved['results'][-1]['id']])
        self.assertEqual(json.loads(read.stdout)['payload']['quote'], packet()['operations'][0]['data']['text'])
        self.assertEqual(before, {p.name for p in Path(self.temp.name).iterdir()})

    def test_failure_rolls_back_all_new_rows_and_returns_failure_exit(self):
        data = packet()
        data['operations'][2]['data']['quote'] = '발언에 없는 내용'
        result = self.cli(['batch', '--input', '-'], data)
        self.assertEqual(result.returncode, 1)
        self.assertIn('error', json.loads(result.stderr))
        self.assertEqual(self.db.execute('SELECT count(*) FROM records').fetchone()[0], 0)

    def test_context_failure_and_unknown_reference_leave_no_orphan_sources(self):
        for mode in ('context', 'reference', 'duplicate'):
            data = packet()
            if mode == 'context':
                c = data['operations'][1]['data']
                c.update(types=['correction'], type_quotes={'correction':c['quote']})
            elif mode == 'reference':
                data['operations'][1]['data']['source_id'] = {'$ref':'not-yet-defined'}
            else:
                data['operations'][1]['ref'] = 'user'
            with self.subTest(mode=mode), self.assertRaises(ValueError):
                j.save_batch(self.db, data)
            self.assertEqual(self.db.execute('SELECT count(*) FROM records').fetchone()[0], 0)

    def test_candidate_only_stays_pending_and_short_acceptance_needs_context(self):
        data = packet('이 정도면 될 듯.')
        data['operations'].pop()
        candidate = data['operations'][1]['data']
        candidate.update(types=['acceptance'], type_quotes={'acceptance':candidate['quote']},
                         reuse='task_only', scope_level='task')
        candidate['attributes']['acceptance_scope'] = 'result_quality'
        # Without a referent, do not invent what was accepted.
        candidate.update(context_state='missing', missing_context=['검토한 결과물'],
                         decision_state='unresolved', reuse='uncertain')
        result = j.save_batch(self.db, data)
        self.assertEqual(result['results'][-1]['status'], 'needs_context')
        self.assertEqual(j.search(self.db, 'projectut', target='vision-blur')['results'], [])

    def test_fallback_is_explicit_bounded_and_does_not_promote_scope(self):
        j.save_batch(self.db, packet())
        self.assertEqual(j.search(self.db, 'projectut', '블러', domain='vfx', target='blur-camera')['results'], [])
        related = j.search(self.db, 'projectut', '블러', domain='vfx', target='blur-camera', fallback_target=True)
        self.assertIn('related_targets_only', related['fallback'])
        self.assertEqual(related['results'][0]['target'], 'vision-blur')
        self.assertEqual(j.search(self.db, 'crack', '블러', domain='vfx', target='blur-camera', fallback_target=True)['results'], [])
        self.assertEqual(j.search(self.db, 'projectut', '블러', domain='ui', target='blur-camera', fallback_target=True)['results'], [])
        self.assertEqual(j.search(self.db, 'projectut', target='blur-camera', fallback_target=True)['results'], [])
        # Related evidence cannot be used as an exact target prediction.
        with self.assertRaises(ValueError):
            j.predict(self.db, dict(project='projectut', domain='vfx', target='blur-camera', task='test',
                prediction='test', judgment_ids=[related['results'][0]['id']]))

    def test_existing_individual_source_cli_accepts_stdin(self):
        result = self.cli(['source', '--input', '-'], packet()['operations'][0]['data'])
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertEqual(j.get(self.db, json.loads(result.stdout)['id'])['kind'], 'source')

    def test_mixed_status_and_revision_is_recorded_with_its_condition(self):
        quote = '지금 상태는 어때? 블러 중에도 캐릭터 움직임은 유지해줘.'
        data = packet(quote)
        candidate = data['operations'][1]['data']
        candidate.update(types=['question', 'request'], type_quotes={
            'question':'지금 상태는 어때?', 'request':'블러 중에도 캐릭터 움직임은 유지해줘.'})
        candidate['attributes']['conditions'] = [dict(when='블러 재생 중', then='캐릭터 움직임 유지',
            source_id={'$ref':'user'}, quote='블러 중에도 캐릭터 움직임은 유지해줘.')]
        data['operations'][2]['data']['attributes'] = candidate['attributes']
        saved = j.save_batch(self.db, data)
        self.assertEqual(j.get(self.db, saved['results'][-1]['id'])['payload']['attributes']['conditions'][0]['when'], '블러 재생 중')

    def test_changed_judgment_supersedes_without_erasing_history(self):
        old = j.save_batch(self.db, packet())['results'][-1]['id']
        data = packet('이번 블러는 배경만 흐려지게 해줘.')
        data['operations'][2]['data'].update(supersedes=old, change_reason='대상 변경 명시')
        new = j.save_batch(self.db, data)['results'][-1]['id']
        self.assertEqual(j.search(self.db, 'projectut', target='vision-blur')['results'][0]['id'], new)
        self.assertEqual(j.get(self.db, old)['id'], old)

    def compact_packet(self):
        data = packet()
        data['defaults'] = dict(project='projectut', domain='vfx',
                                origin='synthetic-regression-only', observed_at='test')
        for op in data['operations']:
            for key in data['defaults']:
                op['data'].pop(key, None)
        data['operations'][1]['data'].pop('classification_version')
        data['operations'][2]['data'] = dict(candidate_id={'$ref':'candidate'}, status='confirmed',
            review_note='원문과 대상 범위를 검토')
        return data

    def test_shared_fields_and_candidate_inheritance_preserve_exact_records(self):
        original = j.save_batch(self.db, packet())
        compact = self.compact_packet()
        before = copy.deepcopy(compact)
        short = j.save_batch(self.db, compact)
        self.assertEqual(original, short)
        self.assertEqual(before, compact)
        self.assertLess(len(json.dumps(compact)), len(json.dumps(packet())))

    def test_inheritance_does_not_assume_approval_or_ignore_scope_conflict(self):
        for change in ('status', 'review_note', 'scope', 'defaults'):
            data = self.compact_packet()
            if change in ('status', 'review_note'):
                data['operations'][2]['data'].pop(change)
            elif change == 'scope':
                data['operations'][2]['data']['project'] = 'crack'
            else:
                data['defaults']['status'] = 'confirmed'
            with self.subTest(change=change), self.assertRaises(ValueError):
                j.save_batch(self.db, data)
            self.assertEqual(self.db.execute('SELECT count(*) FROM records').fetchone()[0], 0)

    def test_summary_and_selected_fields_roundtrip_without_changing_default_output(self):
        saved = j.save_batch(self.db, self.compact_packet())['results'][-1]['id']
        full = json.loads(self.cli(['show', saved]).stdout)
        summary = json.loads(self.cli(['show', saved, '--summary']).stdout)
        self.assertEqual(summary['payload']['quote'], full['payload']['quote'])
        self.assertEqual(summary['payload']['attributes'], full['payload']['attributes'])
        self.assertNotIn('review_note', summary['payload'])
        short = self.cli(['show', saved, '--fields', 'id,status,payload.quote'])
        self.assertEqual(json.loads(short.stdout), {'id':saved, 'status':'confirmed',
                                                   'payload.quote':full['payload']['quote']})
        bad = self.cli(['show', saved, '--fields', 'payload.not_existing'])
        self.assertEqual(bad.returncode, 1)
        multi = self.cli(['show', saved, saved, '--fields', 'id'])
        self.assertEqual(json.loads(multi.stdout), [{'id':saved}, {'id':saved}])

    def test_inherited_conditions_and_reason_are_not_silently_dropped(self):
        data = self.compact_packet()
        candidate = data['operations'][1]['data']
        candidate['attributes']['conditions'] = [dict(when='블러 중', then='움직임 유지',
            source_id={'$ref':'user'}, quote=candidate['quote'])]
        candidate.update(reason_kind='user_stated', reason='움직임 유지', reason_quote='움직임은 유지')
        saved = j.save_batch(self.db, data)['results'][-1]['id']
        row = j.select_fields(j.get(self.db, saved), summary=True)
        self.assertEqual(row['payload']['reason_kind'], 'user_stated')
        self.assertEqual(row['payload']['reason_quote'], '움직임은 유지')
        self.assertEqual(row['payload']['attributes']['conditions'][0]['when'], '블러 중')

    def test_reason_from_linked_user_context_survives_promotion_and_readback(self):
        from retrieval import retrieve
        data=self.compact_packet()
        data['operations'].insert(1,dict(ref='reason',command='source',data=dict(project='projectut',role='user',
            origin='synthetic-reason',observed_at='unknown',text='다른 세션 작업을 방해하기 때문이야.')))
        candidate=data['operations'][2]['data']
        candidate.update(context_state='resolved',context_refs=[dict(source_id={'$ref':'reason'},
            quote='다른 세션 작업을 방해하기 때문이야.',relation='previous')],reason_kind='user_stated',
            reason='다른 작업 보호',reason_source_id={'$ref':'reason'},reason_quote='다른 세션 작업을 방해하기 때문이야.')
        saved=j.save_batch(self.db,data)['results']
        row=j.get(self.db,saved[-1]['id'])
        self.assertEqual(row['payload']['reason_source_id'],saved[1]['id'])
        item=next(x for x in retrieve(self.db,'projectut',target='vision-blur')['results'] if x['id']==row['id'])
        self.assertEqual(item['user_reason_source_id'],saved[1]['id'])
        self.assertTrue(any(x['quote']==candidate['reason_quote'] for x in item['source_review']['sources']))

    def test_promotion_cannot_drop_a_classified_user_reason(self):
        data=self.compact_packet();candidate=data['operations'][1]['data']
        candidate.update(reason_kind='user_stated',reason='움직임 유지',reason_quote='움직임은 유지')
        data['operations'][2]['data']['reason_kind']='unknown'
        with self.assertRaises(ValueError):j.save_batch(self.db,data)


if __name__ == '__main__':
    unittest.main()
