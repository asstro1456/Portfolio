"""Plan a pre-reset run from an already-fetched usage response; no polling or writes."""
import argparse
import json
import math
import sys
from itertools import product
from datetime import datetime, timedelta, timezone
from pathlib import Path

STATE = Path('D:/CodexData/judgment-data/pre-reset/state.json')
KST = timezone(timedelta(hours=9))


def plan(usage, state, now=None):
    limits = usage.get('rateLimitsByLimitId', {}).get('codex') or usage.get('rateLimits') or {}
    windows = [limits.get('primary'), limits.get('secondary')]
    weekly = next((w for w in windows if w and w.get('windowDurationMins') == 10080), None)
    if not weekly:
        raise ValueError('A current seven-day usage window is required.')
    reset = weekly.get('resetsAt')
    used = weekly.get('usedPercent')
    if (isinstance(reset, bool) or not isinstance(reset, (int, float)) or not math.isfinite(reset) or reset <= 0 or
            isinstance(used, bool) or not isinstance(used, (int, float)) or not math.isfinite(used) or not 0 <= used <= 100):
        raise ValueError('Invalid reset timestamp or usage percentage.')
    now = datetime.now(timezone.utc).timestamp() if now is None else now
    trigger = datetime.fromtimestamp(reset - 7200, KST)
    if trigger.second or trigger.microsecond:
        trigger = trigger.replace(second=0, microsecond=0) + timedelta(minutes=1)
    days = ['MO', 'TU', 'WE', 'TH', 'FR', 'SA', 'SU']
    starts = [trigger + timedelta(minutes=15*n) for n in range(8)]
    selected = {(t.weekday(), t.hour, t.minute) for t in starts}
    weekdays = sorted({t[0] for t in selected})
    hours = sorted({t[1] for t in selected})
    minutes = sorted({t[2] for t in selected})
    positions = [i+1 for i,t in enumerate(product(weekdays,hours,minutes)) if t in selected]
    rule = ('FREQ=WEEKLY;BYDAY=' + ','.join(days[d] for d in weekdays) +
            ';BYHOUR=' + ','.join(map(str,hours)) + ';BYMINUTE=' + ','.join(map(str,minutes)) +
            ';BYSECOND=0;BYSETPOS=' + ','.join(map(str,positions)))
    allowed = usage.get('ordinaryUsageAllowed') is True and not limits.get('spendControlReached', False)
    return dict(reset_at=reset, reset_kst=datetime.fromtimestamp(reset, KST).isoformat(),
                trigger_kst=trigger.isoformat(), resume_times_kst=[t.isoformat() for t in starts], rrule=rule,
                schedule_changed=rule != state.get('rrule'),
                due=allowed and used < 100 and 0 < reset - now <= 7200,
                seconds_to_reset=reset - now, used_percent=used, remaining_percent=100-used,
                usage_allowed=allowed, automation_id=state.get('automation_id'),
                instruction='No standalone polling. Update the existing automation only when schedule_changed; persist state after successful update. Work only when due, and never consume reset credits or paid overage.')


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--state', type=Path, default=STATE)
    args = parser.parse_args()
    usage = json.loads(sys.stdin.read().lstrip('\ufeff'))
    state = json.loads(args.state.read_text(encoding='utf-8')) if args.state.exists() else {}
    print(json.dumps(plan(usage, state), ensure_ascii=False, indent=2))


if __name__ == '__main__':
    try:
        main()
    except (ValueError, TypeError, OSError, OverflowError) as exc:
        print(json.dumps(dict(error=str(exc))), file=sys.stderr)
        sys.exit(1)
