import copy
import unittest
from reset_schedule import plan


class ResetScheduleTests(unittest.TestCase):
    def setUp(self):
        self.reset = 1793082770
        self.usage = dict(ordinaryUsageAllowed=True, rateLimitsByLimitId=dict(codex=dict(
            primary=dict(usedPercent=17, windowDurationMins=10080, resetsAt=self.reset))))

    def test_start_is_within_two_hours_and_korean_time(self):
        r=plan(self.usage,{},self.reset-7200)
        self.assertEqual(r['trigger_kst'],'2026-10-27T13:33:00+09:00')
        self.assertEqual(r['rrule'],'FREQ=WEEKLY;BYDAY=TU;BYHOUR=13,14,15;BYMINUTE=3,18,33,48;BYSECOND=0;BYSETPOS=3,4,5,6,7,8,9,10')
        self.assertTrue(r['due'])
        self.assertEqual(r['resume_times_kst'][-1],'2026-10-27T15:18:00+09:00')

    def test_resumption_window_crosses_midnight_without_extra_times(self):
        from datetime import datetime
        reset=datetime.fromisoformat('2026-10-27T01:05:00+09:00').timestamp()
        self.usage['rateLimitsByLimitId']['codex']['primary']['resetsAt']=reset
        r=plan(self.usage,{},reset-7200)
        self.assertIn('BYDAY=MO,TU;',r['rrule'])
        self.assertTrue(r['rrule'].endswith('BYSETPOS=5,6,7,8,9,10,11,12'))
        self.assertEqual(r['resume_times_kst'][0],'2026-10-26T23:05:00+09:00')
        self.assertEqual(r['resume_times_kst'][-1],'2026-10-27T00:50:00+09:00')

    def test_unchanged_schedule_does_not_request_update(self):
        rule=plan(self.usage,{},self.reset-10000)['rrule']
        self.assertFalse(plan(self.usage,dict(rrule=rule),self.reset-10000)['schedule_changed'])

    def test_normal_next_week_keeps_same_schedule(self):
        rule=plan(self.usage,{},self.reset-10000)['rrule']
        self.usage['rateLimitsByLimitId']['codex']['primary']['resetsAt']+=604800
        self.assertFalse(plan(self.usage,dict(rrule=rule),self.reset)['schedule_changed'])

    def test_observed_schedule_change_requests_update(self):
        rule=plan(self.usage,{},self.reset-10000)['rrule']
        self.usage['rateLimitsByLimitId']['codex']['primary']['resetsAt']+=3600
        self.assertTrue(plan(self.usage,dict(rrule=rule),self.reset-10000)['schedule_changed'])

    def test_outside_window_does_not_start_bulk_work(self):
        self.assertFalse(plan(self.usage,{},self.reset-7201)['due'])
        self.assertTrue(plan(self.usage,{},self.reset-3600)['due'])
        self.assertFalse(plan(self.usage,{},self.reset)['due'])

    def test_exhausted_or_disallowed_usage_does_not_spend_credits(self):
        self.usage['rateLimitsByLimitId']['codex']['primary']['usedPercent']=100
        self.assertFalse(plan(self.usage,{},self.reset-3600)['due'])
        self.usage['rateLimitsByLimitId']['codex']['primary']['usedPercent']=99
        self.usage['ordinaryUsageAllowed']=False
        self.assertFalse(plan(self.usage,{},self.reset-3600)['due'])

    def test_weekly_secondary_takes_priority_over_short_window(self):
        limits=self.usage['rateLimitsByLimitId']['codex']
        limits['secondary']=copy.deepcopy(limits['primary'])
        limits['primary']['windowDurationMins']=300
        limits['primary']['resetsAt']+=100
        self.assertEqual(plan(self.usage,{},self.reset-3600)['reset_at'],self.reset)

    def test_missing_or_invalid_limit_fails_without_a_schedule(self):
        with self.assertRaises(ValueError):plan({}, {}, self.reset)
        self.usage['rateLimitsByLimitId']['codex']['primary']['usedPercent']=-1
        with self.assertRaises(ValueError):plan(self.usage,{},self.reset)


if __name__=='__main__':unittest.main()
