import copy
import json
import sqlite3
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

import harness_trials as trials
import judgments as j
from test_batch import packet


class HarnessTrialTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.path = Path(self.temp.name) / 'trial.sqlite3'
        self.db = j.connect(self.path, create=True)
        self.rid = j.save_batch(self.db, packet())['results'][-1]['id']

    def tearDown(self):
        self.db.close()
        self.temp.cleanup()

    def trial(self):
        scope = dict(project='projectut', domain='vfx', target='vision-blur')
        return dict(trial_version=1, trial_id='retrieval-1', task='Find the reviewed motion criterion',
            hypothesis='Use its concrete object term instead of an unrelated keyword.',
            expected_by='agent_source_review', record_fingerprints={self.rid:j.get(self.db,self.rid)['fingerprint']},
            cases=[dict(name='required-rule', query=dict(scope, query='unrelated-token'),
                        candidate_query=dict(query='블러'), must_be_eligible=[self.rid]),
                   dict(name='other-project', query=dict(scope, project='crack'), must_not_be_eligible=[self.rid]),
                   dict(name='other-target', query=dict(scope, target='other-effect'), must_not_be_eligible=[self.rid])])

    def test_actual_search_improvement_is_not_feedback_or_deployment(self):
        data = self.trial(); original = copy.deepcopy(data)
        before = trials.snapshot_version(self.db)
        result = trials.run_trial(self.db, data)
        self.assertEqual(result['decision'], 'candidate_supported')
        self.assertEqual(result['improved_cases'], ['required-rule'])
        self.assertEqual(result['regressed_cases'], [])
        self.assertEqual(result['snapshot_sha256'], before)
        self.assertEqual(trials.snapshot_version(self.db), before)
        self.assertEqual(data, original)
        self.assertFalse(result['candidate_applied'])
        self.assertFalse(result['database_writes'])
        self.assertFalse(result['semantic_accuracy_measured'])
        self.assertEqual(result['model_calls'], 0)
        self.assertIsNone(result['api_cost_usd'])
        self.assertEqual(j.digest(result['input']), result['input_sha256'])

    def test_no_gain_keeps_baseline_and_new_failure_rejects_candidate(self):
        data = self.trial(); data['cases'][0]['query']['query'] = '블러'
        self.assertEqual(trials.run_trial(self.db, data)['decision'], 'keep_baseline')
        data['cases'][0]['candidate_query'] = dict(query='unrelated-token')
        result = trials.run_trial(self.db, data)
        self.assertEqual(result['decision'], 'candidate_rejected')
        self.assertEqual(result['regressed_cases'], ['required-rule'])

    def test_improving_one_case_does_not_hide_another_regression(self):
        data = self.trial()
        second = copy.deepcopy(data['cases'][0]); second.update(name='already-working',
            query=dict(second['query'], query='블러'), candidate_query=dict(query='unrelated-token'))
        data['cases'].append(second)
        result = trials.run_trial(self.db, data)
        self.assertEqual(result['improved_cases'], ['required-rule'])
        self.assertEqual(result['regressed_cases'], ['already-working'])
        self.assertEqual(result['decision'], 'candidate_rejected')

    def test_focused_evidence_delivery_can_be_compared_without_waiving_sources(self):
        data = packet(); refs = []
        for n in range(5):
            alias = 'context' + str(n); quote = '추가 맥락 ' + str(n)
            data['operations'].insert(1, dict(ref=alias, command='source', data=dict(project='projectut',
                role='user', text=quote, origin=alias, observed_at='unknown')))
            refs.append(dict(source_id={'$ref':alias}, quote=quote, relation='referent'))
        data['operations'][-2]['data'].update(context_refs=refs, context_state='resolved')
        # A separate object avoids a historical rule with the same source becoming a blocker.
        for op in data['operations']:
            if op['command'] in ('candidate', 'record'): op['data']['target'] = 'many-contexts'
        self.rid = j.save_batch(self.db, data)['results'][-1]['id']
        case = self.trial()
        for item in case['cases']:
            if item['name'] != 'other-target': item['query']['target'] = 'many-contexts'
        case['cases'][0].update(query=dict(project='projectut', domain='vfx', target='many-contexts', query='블러'),
                                candidate_query=dict(limit=1, chars=2000))
        self.assertEqual(trials.run_trial(self.db, case)['decision'], 'candidate_supported')

    def test_retirement_cannot_be_bypassed_by_query_changes(self):
        rule = j.get(self.db, self.rid)
        j.add_judgment(self.db, dict(rule['payload'], status='rejected', supersedes=self.rid, change_reason='철회'))
        self.db.commit()
        data = self.trial(); data['cases'][0]['candidate_query'].update(limit=1, chars=2000)
        result = trials.run_trial(self.db, data)
        self.assertEqual(result['decision'], 'candidate_rejected')
        self.assertIn(self.rid, result['variants']['candidate']['results'][0]['missing_candidates'])

    def test_current_conflict_and_clipped_source_still_block_a_focused_candidate(self):
        rule = j.get(self.db, self.rid)
        quote = '반대로 블러 중 움직임은 멈춰야 해.'
        source = j.add_source(self.db, dict(project='projectut', role='user', origin='new-correction',
            observed_at='unknown', text=quote))
        candidate = copy.deepcopy(j.get(self.db, rule['payload']['candidate_id'])['payload'])
        candidate.update(source_id=source, quote=quote, interpretation=quote, types=['correction'],
            type_quotes={'correction':quote}, context_state='resolved',
            context_refs=[dict(source_id=rule['payload']['source_id'], quote=rule['payload']['quote'], relation='referent')])
        j.add_candidate(self.db, candidate); self.db.commit()
        data = self.trial(); data['cases'][0]['candidate_query'].update(limit=1, chars=2000)
        self.assertEqual(trials.run_trial(self.db, data)['decision'], 'candidate_rejected')
        long_packet = packet('블러 ' + '원문 ' * 800)
        for op in long_packet['operations']:
            if op['command'] in ('candidate', 'record'): op['data']['target'] = 'long-source'
        self.rid = j.save_batch(self.db, long_packet)['results'][-1]['id']
        data = self.trial()
        for case in data['cases']:
            if case['name'] != 'other-target': case['query']['target'] = 'long-source'
        data['cases'][0]['candidate_query'].update(limit=1, chars=2000)
        self.assertEqual(trials.run_trial(self.db, data)['decision'], 'candidate_rejected')

    def test_scope_changes_code_and_model_options_are_rejected(self):
        for key in ('project', 'domain', 'target', 'purpose', 'conversation', 'include_unresolved', 'fallback_target', 'command'):
            data = self.trial(); data['cases'][0]['candidate_query'][key] = 'different'
            with self.subTest(key=key), self.assertRaises(ValueError): trials.run_trial(self.db, data)
        for key in ('model', 'script', 'expected_score'):
            data = self.trial(); data[key] = 'not accepted'
            with self.subTest(key=key), self.assertRaises(ValueError): trials.run_trial(self.db, data)

    def test_guards_are_mandatory_unfiltered_and_identical_for_both_variants(self):
        for mode in ('other-project', 'other-target', 'filtered', 'candidate-filter', 'wrong-scope', 'imaginary-project'):
            data = self.trial()
            if mode in ('other-project', 'other-target'):
                data['cases'] = [c for c in data['cases'] if c['name'] != mode]
            elif mode == 'filtered': data['cases'][1]['query']['query'] = 'hide matches'
            elif mode == 'candidate-filter': data['cases'][1]['candidate_query'] = dict(limit=1)
            elif mode == 'imaginary-project': data['cases'][1]['query']['project'] = 'not-a-real-project'
            else: data['cases'][1]['query']['domain'] = 'wrong-domain'
            with self.subTest(mode=mode), self.assertRaises(ValueError): trials.run_trial(self.db, data)

    def test_stale_versions_invalid_labels_and_unsupported_scope_fail_closed(self):
        for mode in ('fingerprint', 'extra-id', 'both-labels', 'duplicate-name', 'global-scope', 'boolean-limit', 'oversized-chars'):
            data = self.trial()
            if mode == 'fingerprint': data['record_fingerprints'][self.rid] = 'stale'
            elif mode == 'extra-id': data['record_fingerprints']['unknown'] = 'stale'
            elif mode == 'both-labels': data['cases'][0]['must_not_be_eligible'] = [self.rid]
            elif mode == 'duplicate-name': data['cases'][1]['name'] = data['cases'][0]['name']
            elif mode == 'global-scope': data['cases'][0]['query']['project'] = 'global'
            elif mode == 'boolean-limit': data['cases'][0]['candidate_query']['limit'] = True
            else: data['cases'][0]['candidate_query']['chars'] = 2001
            with self.subTest(mode=mode), self.assertRaises(ValueError): trials.run_trial(self.db, data)

    def test_snapshot_is_query_only_and_stable_during_an_external_update(self):
        real = trials.evaluation.check_retrieval; seen = []
        def inspect(db, data):
            seen.append(db.execute('SELECT count(*) FROM records').fetchone()[0])
            with self.assertRaises(sqlite3.OperationalError): db.execute('DELETE FROM records')
            if len(seen) == 1:
                j.add_source(self.db, dict(project='projectut', origin='another-task', role='user',
                    observed_at='unknown', text='A separate writer changed the source DB after the snapshot.'))
                self.db.commit()
            return real(db, data)
        with patch.object(trials.evaluation, 'check_retrieval', side_effect=inspect):
            result = trials.run_trial(self.db, self.trial())
        self.assertEqual(seen[0], seen[1])
        self.assertEqual(result['decision'], 'candidate_supported')
        self.assertNotEqual(result['snapshot_sha256'], trials.snapshot_version(self.db))

    def test_uncommitted_input_and_changed_implementation_are_not_success(self):
        self.db.execute('BEGIN')
        with self.assertRaises(ValueError): trials.run_trial(self.db, self.trial())
        self.db.rollback()
        with patch.object(trials, 'source_versions', side_effect=[{'code':'before'}, {'code':'after'}]):
            with self.assertRaises(ValueError): trials.run_trial(self.db, self.trial())

    def test_cli_reads_stdin_without_database_writes_and_rejects_unknown_input(self):
        before = trials.snapshot_version(self.db)
        args = [sys.executable, '-B', '-X', 'utf8', trials.__file__, '--db', str(self.path)]
        result = subprocess.run(args, input=json.dumps(self.trial()), capture_output=True, encoding='utf-8')
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertEqual(json.loads(result.stdout)['decision'], 'candidate_supported')
        bad = subprocess.run(args, input='{"trial_version":1,"script":"do not execute"}', capture_output=True, encoding='utf-8')
        self.assertEqual(bad.returncode, 2)
        self.assertFalse(json.loads(bad.stderr)['database_writes'])
        self.assertEqual(trials.snapshot_version(self.db), before)

    def test_complete_report_is_readable_and_never_overwrites_input_or_escapes_root(self):
        root = Path(self.temp.name) / 'reports'; root.mkdir()
        destination = root / 'trial.json'; report = trials.run_trial(self.db, self.trial())
        with patch.object(trials, 'OUTPUT_ROOT', root):
            trials.write_report(destination, report)
            self.assertEqual(json.loads(destination.read_text(encoding='utf-8')), report)
            for path in (destination, self.path, root / '..' / 'escape.json'):
                with self.subTest(path=path), self.assertRaises(ValueError): trials.write_report(path, report)
            with self.assertRaises(FileExistsError), patch.object(trials.os, 'link', side_effect=FileExistsError('another process won')):
                trials.write_report(root / 'collision.json', report)
        self.assertEqual(list(root.iterdir()), [destination])


if __name__ == '__main__':
    unittest.main()
