import contextlib
import io
import json
import subprocess
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

import judgments as j
import observation


class ObservationTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.root = Path(self.temp.name)
        self.db = self.root / 'operational-fixture.sqlite3'
        j.connect(self.db, create=True).close()
        self.trace = 'a' * 24

    def tearDown(self): self.temp.cleanup()

    def cli(self, *args, packet=None):
        output = io.StringIO()
        with patch.object(j, 'DEFAULT_DB', self.db), patch.object(observation, 'ROOT', self.root / 'events'), \
                patch('sys.stdin', io.StringIO(json.dumps(packet) if packet else '')), contextlib.redirect_stdout(output):
            j.main(['--db', str(self.db), '--trace-id', self.trace, *args])
        return json.loads(output.getvalue())

    def test_save_readback_and_intentional_skip_are_distinct_without_source_data(self):
        sid = self.cli('source', '--input', '-', packet=dict(project='projectut', role='user',
            origin='SECRET_ORIGIN', text='SECRET_SOURCE', observed_at='unknown'))['id']
        pending = observation.status(self.trace, self.root / 'events')
        self.assertEqual(pending['awaiting_readback'], [sid])
        self.cli('show', sid)
        self.assertEqual(self.cli('observe-skip', '--reason', 'no_new_judgment')['observation'], 'recorded')
        status = self.cli('observation-status')
        self.assertEqual(status['saved_records'], 1)
        self.assertEqual(status['readback_records'], 1)
        self.assertEqual(status['counts']['intentional_skip:skipped'], 1)
        raw = (self.root / 'events/events.jsonl').read_text(encoding='utf-8')
        self.assertNotIn('SECRET', raw)
        self.assertNotIn(str(self.db), raw)

    def test_operation_failure_is_recorded_without_exception_contents(self):
        with self.assertRaises(ValueError): self.cli('show', 'SECRET_BAD_ID')
        raw = (self.root / 'events/events.jsonl').read_text(encoding='utf-8')
        self.assertNotIn('SECRET_BAD_ID', raw)
        self.assertEqual(self.cli('observation-status')['counts']['readback:failure'], 1)

    def test_missing_trace_and_partial_line_never_imply_success(self):
        self.assertEqual(observation.status(self.trace, self.root)['observation'], 'no_observed_events')
        (self.root / 'events.jsonl').write_text('{partial\n', encoding='utf-8')
        self.assertEqual(observation.status(self.trace, self.root)['saved_records'], 0)
        with self.assertRaises(ValueError): observation.emit('save', 'success', trace_id='SECRET', root=self.root)
        with self.assertRaises(ValueError): observation.emit('save', 'success', code='SECRET', root=self.root)

    def test_readback_before_save_does_not_count_as_a_verified_sequence(self):
        rid = 'aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa'
        def emit(stage): observation.emit(stage, 'success', trace_id=self.trace, record_ids=[rid], root=self.root)
        emit('readback'); emit('save')
        self.assertEqual(observation.status(self.trace, self.root)['awaiting_readback'], [rid])
        emit('readback')
        self.assertEqual(observation.status(self.trace, self.root)['readback_records'], 1)
        emit('save')
        self.assertEqual(observation.status(self.trace, self.root)['readback_records'], 0)

    def test_telemetry_io_failure_preserves_primary_saved_result(self):
        blocker = self.root / 'file'; blocker.write_text('x', encoding='utf-8')
        with patch.object(j, 'DEFAULT_DB', self.db), patch.object(observation, 'ROOT', blocker), \
                patch('sys.stdin', io.StringIO(json.dumps(dict(project='projectut', role='user', text='valid', origin='fixture', observed_at='unknown')))), \
                contextlib.redirect_stdout(io.StringIO()), contextlib.redirect_stderr(io.StringIO()) as errors:
            j.main(['--db', str(self.db), 'source', '--input', '-'])
        db = j.connect(self.db, read_only=True)
        self.assertEqual(db.execute('SELECT count(*) FROM records').fetchone()[0], 1); db.close()
        self.assertIn('observation unavailable', errors.getvalue())

    def test_nonoperational_cli_does_not_emit_and_silence_is_not_intentional_skip(self):
        with patch.object(observation, 'ROOT', self.root / 'unused'), contextlib.redirect_stdout(io.StringIO()):
            j.main(['--db', str(self.db), 'observe-skip', '--reason', 'no_feedback'])
        self.assertFalse((self.root / 'unused').exists())
        self.assertEqual(observation.status(self.trace, self.root)['counts'], {})

    def test_hook_to_cli_save_to_readback_share_one_trace(self):
        hooks = Path(j.__file__).parents[3] / 'hooks/personal-workflows'
        # Installed and staged layouts both retain skills/ and hooks/ under the same root.
        code = "const o=require(process.argv[1]); const d=require(process.argv[2]).dispatch; const input={hook_event_name:'UserPromptSubmit',session_id:'fixture-session',turn_id:'fixture-turn',prompt:'SECRET_SOURCE'}; o.run(input,d,process.argv[3]); process.stdout.write(o.trace(input));"
        result = subprocess.run(['node', '-e', code, str(hooks/'judgment-observation.cjs'),
            str(hooks/'dispatch.cjs'), str(self.root/'events')], capture_output=True, encoding='utf-8')
        self.assertEqual(result.returncode, 0, result.stderr)
        self.trace = result.stdout
        sid = self.cli('source', '--input', '-', packet=dict(project='projectut', role='user',
            origin='synthetic-hook-cli-flow', text='SECRET_SOURCE', observed_at='unknown'))['id']
        self.cli('show', sid)
        state = self.cli('observation-status')
        self.assertEqual(state['counts']['hook_received:success'], 1)
        self.assertEqual(state['counts']['hook_context:success'], 1)
        self.assertEqual(state['readback_records'], 1)
        self.assertEqual(state['awaiting_readback'], [])
        self.assertNotIn('SECRET', (self.root/'events/events.jsonl').read_text(encoding='utf-8'))


if __name__ == '__main__': unittest.main()
