"""Outcome and suggestion safety gates; all records live in disposable databases."""
import copy
import json
import subprocess
import sys
import unittest
from datetime import datetime, timezone

import judgments as j
import learning
import test_learning as fixtures


class OutcomeTests(unittest.TestCase):
    setUp = fixtures.LearningTests.setUp
    tearDown = fixtures.LearningTests.tearDown
    prediction_data = fixtures.LearningTests.prediction_data
    predict = fixtures.LearningTests.predict
    source = fixtures.LearningTests.source
    feedback = fixtures.LearningTests.feedback
    state = fixtures.LearningTests.state
    change = fixtures.LearningTests.change

    def outcome(self, iid, **updates):
        data = dict(improvement_id=iid, task='blur-v1', revised_task='blur-v2',
            before_artifact='fixture://failed-v1', after_artifact='fixture://revision-v2',
            required_modes=['still', 'motion'], checks={
                'still':dict(status='passed', note='Synthetic still observation', evidence=['fixture://still-v2'],
                    observed_at=datetime.now(timezone.utc).isoformat()),
                'motion':dict(status='unverified', note='Motion not observed')})
        data.update(updates)
        return data

    def test_legacy_resolved_is_not_artifact_success_and_no_backfill(self):
        iid = self.change(self.feedback())
        original = j.get(self.db, iid)
        result = self.state()
        self.assertEqual(result['counts']['resolved'], 1)
        self.assertEqual(result['pending'], [])  # existing CLI consumer semantics
        self.assertEqual(result['outcome_counts']['unverified'], 1)
        self.assertEqual(result['outcome_counts']['passed'], 0)
        self.assertIsNone(result['outcome_pending'][0]['validation_id'])
        self.assertIsNone(original['payload']['validation'])  # retrieval validation stays separate
        self.assertEqual(original, j.get(self.db, iid))
        self.assertEqual(self.db.execute('PRAGMA user_version').fetchone()[0], 1)

    def test_still_pass_cannot_complete_motion_then_actual_observation_can(self):
        iid = self.change(self.feedback())
        before = j.get(self.db, iid)
        data = self.outcome(iid)
        vid = learning.validate_outcome(self.db, data)
        self.assertEqual(vid, learning.validate_outcome(self.db, data))
        self.assertEqual(j.get(self.db, vid)['status'], 'unverified')
        self.assertEqual(self.state()['outcome_counts']['passed'], 0)
        data['supersedes'] = vid
        data['checks']['motion'].update(status='passed', evidence=['fixture://motion-v2'],
            observation='normal_speed', observed_at=datetime.now(timezone.utc).isoformat())
        new = learning.validate_outcome(self.db, data)
        self.assertEqual(self.state()['outcome_counts']['passed'], 1)
        self.assertEqual(self.state()['outcome_pending'], [])
        self.assertEqual(j.get(self.db, new)['payload']['improvement_id'], iid)
        self.assertEqual(j.get(self.db, iid), before)

    def test_missing_stale_future_or_wrong_motion_evidence_rejected(self):
        iid = self.change(self.feedback())
        for mode, update in [('still', dict(evidence=[])), ('still', dict(observed_at='unknown')),
                ('still', dict(observed_at='2000-01-01T00:00:00Z')),
                ('still', dict(observed_at='2999-01-01T00:00:00Z')),
                ('motion', dict(status='passed', evidence=['fixture://still'], observation='still'))]:
            data = self.outcome(iid)
            data['checks'][mode].update(update)
            with self.subTest(update=update), self.assertRaises(ValueError):
                learning.validate_outcome(self.db, data)
        self.assertEqual(self.state()['outcome_counts']['unverified'], 1)

    def test_prospective_motion_requirement_cannot_be_dropped_on_first_validation(self):
        pid = self.predict(validation_modes=['still', 'motion'])
        iid = self.change(self.feedback(pid))
        data = self.outcome(iid, required_modes=['still'])
        data['checks'].pop('motion')
        with self.assertRaises(ValueError): learning.validate_outcome(self.db, data)
        with self.assertRaises(ValueError): self.predict(task='bad', turn_id='bad', validation_modes=['video'])

    def test_validation_requires_correct_task_revision_and_current_links(self):
        fid = self.feedback(); iid = self.change(fid)
        for changes in [dict(task='other'), dict(revised_task='blur-v1'), dict(before_artifact=''),
                        dict(required_modes=['still', 'still']), dict(checks={})]:
            with self.subTest(changes=changes), self.assertRaises(ValueError):
                learning.validate_outcome(self.db, self.outcome(iid, **changes))
        self.change(fid, disposition='needs_context', cause='ambiguous', supersedes=iid)
        with self.assertRaises(ValueError): learning.validate_outcome(self.db, self.outcome(iid))
        self.assertEqual(sum(self.state()['outcome_counts'].values()), 0)

    def test_exclusion_preserves_unverified_and_requires_user_waiver(self):
        iid = self.change(self.feedback())
        data = self.outcome(iid)
        data['checks']['motion'].update(status='excluded')
        with self.assertRaises(ValueError): learning.validate_outcome(self.db, data)
        sid = self.source(text='이번 동작 검증은 생략해.', message_id='waiver')
        data['checks']['motion']['waiver'] = dict(source_id=sid, quote='이번 동작 검증은 생략해.')
        vid = learning.validate_outcome(self.db, data)
        self.assertEqual(j.get(self.db, vid)['status'], 'unverified')
        self.assertEqual(self.state()['outcome_counts']['passed'], 0)

    def test_failed_result_and_explicit_revision_without_dropping_motion(self):
        iid = self.change(self.feedback())
        data = self.outcome(iid)
        data['checks']['still']['status'] = 'failed'
        vid = learning.validate_outcome(self.db, data)
        self.assertEqual(j.get(self.db, vid)['status'], 'failed')
        with self.assertRaises(ValueError): learning.validate_outcome(self.db, self.outcome(iid))
        data = self.outcome(iid, supersedes=vid, required_modes=['still'])
        data['checks'].pop('motion')
        with self.assertRaises(ValueError): learning.validate_outcome(self.db, data)

    def test_suggestions_never_link_or_write_and_same_chat_is_insufficient(self):
        first = self.predict()
        second = self.predict(task='blur-v2', turn_id='turn-2')
        sid = self.source(text='좋아 보여', task='blur-v1')
        before = self.db.total_changes
        result = learning.status(self.db, 'projectut', 'fixture-chat', feedback_source=sid)
        found = {r['prediction_id']: r for r in result['feedback_review']['candidates']}
        self.assertEqual(found[first]['issues'], [])
        self.assertTrue(found[second]['issues'])
        self.assertTrue(all(r['review_required'] and not r['automatic_link'] and
                            r['outcome'] == 'undetermined' for r in found.values()))
        self.assertEqual(self.db.total_changes, before)
        with self.assertRaises(ValueError): self.feedback(second, sid, task='blur-v2', outcome='matched')

    def test_approval_silence_ambiguous_version_and_wrong_target_never_pass(self):
        pid = self.predict()
        for text in ['진행해', '진행해줘.', '응', 'go ahead', '']:
            if not text:
                with self.assertRaises(ValueError): self.source(text=text)
                continue
            sid = self.source(text=text)
            with self.subTest(text=text), self.assertRaises(ValueError): self.feedback(pid, sid, outcome='matched')
            self.assertTrue(learning.feedback_candidates(self.db, 'projectut', 'fixture-chat', sid)['candidates'][0]['issues'])
            self.feedback(pid, sid, outcome='undetermined')
        sid = self.source(target='different-object')
        with self.assertRaises(ValueError): self.feedback(pid, sid)
        sid = self.source()
        self.assertIn('output_version_requires_review', learning.feedback_candidates(
            self.db, 'projectut', 'fixture-chat', sid)['candidates'][0]['issues'])

    def test_cli_batch_write_show_suggestions_and_old_reader_compatibility(self):
        iid = self.change(self.feedback())
        data = self.outcome(iid)
        sid = self.source(task='blur-v1')
        self.db.commit()
        def cli(*args, packet=None):
            result = subprocess.run([sys.executable, '-B', '-X', 'utf8', j.__file__, '--db', str(self.path), *args],
                input=json.dumps(packet) if packet else None, capture_output=True, encoding='utf-8')
            self.assertEqual(result.returncode, 0, result.stderr)
            return json.loads(result.stdout)
        vid = cli('validate-outcome', '--input', '-', packet=data)['id']
        saved = cli('show', vid, '--summary')
        self.assertEqual(saved['payload']['revised_task'], 'blur-v2')
        self.assertEqual(saved['payload']['checks']['motion']['status'], 'unverified')
        replay = cli('batch', '--input', '-', packet=dict(operations=[dict(ref='validation', command='validate_outcome', data=data)]))
        self.assertEqual(replay['results'][0]['id'], vid)
        before = self.path.read_bytes()
        found = cli('learning-status', '--project', 'projectut', '--conversation', 'fixture-chat', '--feedback-source', sid)
        self.assertFalse(found['feedback_review']['automatic_link'])
        self.assertEqual(before, self.path.read_bytes())
        # A schema-v1 reader can still read/write its old record kinds after new checks exist.
        self.assertEqual(j.get(self.db, iid)['status'], 'resolved')
        self.assertEqual(self.predict(task='legacy-after-new', turn_id='legacy-2'),
                         self.predict(task='legacy-after-new', turn_id='legacy-2'))

    def test_batch_failure_rolls_back_new_validation(self):
        iid = self.change(self.feedback())
        before = self.db.execute('SELECT count(*) FROM records').fetchone()[0]
        good = self.outcome(iid)
        bad = copy.deepcopy(good); bad['improvement_id'] = 'missing'
        with self.assertRaises(ValueError): j.save_batch(self.db, dict(operations=[
            dict(ref='first', command='validate_outcome', data=good),
            dict(ref='second', command='validate_outcome', data=bad)]))
        self.assertEqual(before, self.db.execute('SELECT count(*) FROM records').fetchone()[0])


if __name__ == '__main__':
    unittest.main()
