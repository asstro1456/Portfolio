import json
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

import judgments as j
from evaluation import compare, check_retrieval
from test_batch import packet


class EvaluationTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.path = Path(self.temp.name) / 'evaluation.sqlite3'
        self.db = j.connect(self.path, create=True)
        self.rid = j.save_batch(self.db, packet())['results'][-1]['id']

    def tearDown(self):
        self.db.close()
        self.temp.cleanup()

    def prediction(self, variant, **changes):
        data = dict(project='projectut', domain='vfx', target='vision-blur', task='same-task',
                    comparison_id='pair-1', variant=variant, prediction='미리 기록한 '+variant,
                    judgment_ids=[self.rid] if variant=='harness' else [])
        data.update(changes)
        return j.predict(self.db, data)

    def pair(self, outcomes=('missed', 'matched')):
        baseline, harness = self.prediction('baseline'), self.prediction('harness')
        sid = j.add_source(self.db, dict(project='projectut', origin='synthetic-feedback', role='user',
                                        observed_at='unknown', text='움직임이 유지되는 쪽으로 해줘'))
        for rid, outcome in zip((baseline,harness), outcomes):
            if outcome:
                j.feedback(self.db, dict(prediction_id=rid, source_id=sid, quote='움직임이 유지되는 쪽으로 해줘',
                                        outcome=outcome, analysis='합성 테스트 결과 비교'))
        return baseline,harness,sid

    def cases(self):
        return dict(evaluation_kind='retrieval_regression', expected_by='agent_source_review',
            record_fingerprints={self.rid:j.get(self.db,self.rid)['fingerprint']}, cases=[
            dict(name='applicable',query=dict(project='projectut',target='vision-blur'),must_be_eligible=[self.rid]),
            dict(name='other-project',query=dict(project='portfolio',target='vision-blur'),must_not_be_eligible=[self.rid]),
            dict(name='other-domain',query=dict(project='projectut',domain='writing',target='vision-blur'),must_not_be_eligible=[self.rid]),
            dict(name='other-object',query=dict(project='projectut',target='another-effect'),must_not_be_eligible=[self.rid])])

    def test_no_data_returns_no_invented_rates(self):
        result=compare(self.db,'projectut')
        self.assertEqual(result['evidence_status'],'insufficient_data')
        self.assertIsNone(result['harness_match_rate'])
        self.assertIsNone(result['baseline_match_rate'])

    def test_paired_improvement_regression_and_unchanged(self):
        for outcomes, expected in [(('missed','matched'),'improved'),(('matched','missed'),'regressed'),(('matched','matched'),'unchanged')]:
            with self.subTest(expected=expected):
                self.db.execute('SAVEPOINT scenario')
                self.pair(outcomes)
                result=compare(self.db,'projectut')
                self.assertEqual(result['counts'][expected],1)
                self.assertEqual(result['counts']['determinate'],1)
                self.assertEqual(result['harness_match_rate'],int(outcomes[1]=='matched'))
                self.assertEqual(result['measurement'],'paired_feedback_agreement_not_model_accuracy')
                self.assertEqual(compare(self.db,'portfolio')['pairs_total'],0)
                self.assertEqual(compare(self.db,'projectut',domain='writing')['pairs_total'],0)
                self.db.execute('ROLLBACK TO scenario');self.db.execute('RELEASE scenario')

    def test_missing_or_uncertain_feedback_not_counted_as_failure(self):
        self.pair(('missed',None))
        result=compare(self.db,'projectut')
        self.assertEqual(result['counts']['incomplete'],1)
        self.assertIsNone(result['harness_match_rate'])

    def test_undetermined_outcome_is_excluded_from_denominator(self):
        self.pair(('undetermined','matched'))
        result=compare(self.db,'projectut')
        self.assertEqual(result['counts']['undetermined'],1)
        self.assertIsNone(result['harness_match_rate'])

    def test_conflicting_feedback_is_ambiguous_not_cherry_picked(self):
        baseline,_,sid=self.pair()
        j.feedback(self.db,dict(prediction_id=baseline,source_id=sid,quote='움직임이 유지되는 쪽으로 해줘',
                               outcome='matched',analysis='다른 해석'))
        result=compare(self.db,'projectut')
        self.assertEqual(result['counts']['ambiguous'],1)
        self.assertEqual(result['counts']['determinate'],0)

    def test_repeated_same_verdict_does_not_inflate_pair_count(self):
        baseline,_,sid=self.pair()
        j.feedback(self.db,dict(prediction_id=baseline,source_id=sid,quote='움직임이 유지되는 쪽으로 해줘',
                               outcome='missed',analysis='같은 평가 재확인'))
        result=compare(self.db,'projectut')
        self.assertEqual(result['pairs_total'],1)
        self.assertEqual(result['counts']['determinate'],1)
        self.assertEqual(result['counts']['improved'],1)

    def test_comparison_requires_same_task_and_immutable_predictions(self):
        baseline=self.prediction('baseline')
        self.assertEqual(baseline,self.prediction('baseline'))
        with self.assertRaises(ValueError):self.prediction('baseline',prediction='수정된 예상')
        with self.assertRaises(ValueError):self.prediction('harness',task='other-task')
        with self.assertRaises(ValueError):self.prediction('baseline',judgment_ids=[self.rid])
        with self.assertRaises(ValueError):self.prediction('harness',judgment_ids=[])
        with self.assertRaises(ValueError):self.prediction('baseline',comparison_id='')

    def test_harness_prediction_cannot_use_blocked_rule(self):
        original=j.get(self.db,self.rid)
        j.add_judgment(self.db,dict(original['payload'],status='rejected',supersedes=self.rid,change_reason='철회'))
        with self.assertRaises(ValueError):self.prediction('harness')

    def test_feedback_requires_both_predictions_before_same_user_source(self):
        baseline=self.prediction('baseline')
        sid=j.add_source(self.db,dict(project='projectut',role='user',origin='early',observed_at='unknown',text='피드백'))
        self.prediction('harness')
        with self.assertRaises(ValueError):
            j.feedback(self.db,dict(prediction_id=baseline,source_id=sid,quote='피드백',outcome='matched',analysis='뒤늦은 예상'))

    def test_pair_cannot_use_different_feedback_sources(self):
        baseline,harness,sid=self.pair(('matched',None))
        other=j.add_source(self.db,dict(project='projectut',role='user',origin='other',observed_at='unknown',text='다른 평가'))
        with self.assertRaises(ValueError):
            j.feedback(self.db,dict(prediction_id=harness,source_id=other,quote='다른 평가',outcome='matched',analysis='비교 불가'))

    def test_curated_positive_and_negative_cases_are_read_only(self):
        before=self.db.total_changes
        result=check_retrieval(self.db,self.cases())
        self.assertTrue(result['passed'])
        self.assertEqual(result['cases_passed'],4)
        self.assertFalse(result['semantic_accuracy_measured'])
        self.assertEqual(before,self.db.total_changes)

    def test_retrieval_case_detects_false_positive_and_false_negative(self):
        data=self.cases();data['cases'][0]['must_be_eligible']=[]
        data['cases'][0]['must_not_be_eligible']=[self.rid]
        data['cases'][1]['must_be_eligible']=[self.rid]
        result=check_retrieval(self.db,data)
        self.assertFalse(result['passed'])
        self.assertEqual(result['results'][0]['forbidden_candidates'],[self.rid])
        self.assertEqual(result['results'][1]['missing_candidates'],[self.rid])

    def test_eligibility_cases_check_all_expected_ids_beyond_display_limit(self):
        ids=[]
        for n in range(40):
            data=packet('공통 마스크 합성 기준 '+str(n))
            data['operations'][1]['data'].update(scope_level='project',scope_basis='프로젝트 공통')
            for operation in data['operations'][1:]:
                operation['data']['target']='mask-policy-'+str(n)
            ids.append(j.save_batch(self.db,data)['results'][-1]['id'])
        data=dict(evaluation_kind='retrieval_regression',expected_by='agent_source_review',
            record_fingerprints={rid:j.get(self.db,rid)['fingerprint'] for rid in ids},cases=[
            dict(name='all-40',query=dict(project='projectut',domain='vfx',target='any-mask'),
                 must_be_eligible=ids[:20],must_not_be_eligible=ids[20:])])
        before=self.db.total_changes
        result=check_retrieval(self.db,data)
        self.assertFalse(result['passed'])
        self.assertEqual(result['results'][0]['missing_candidates'],[])
        self.assertEqual(result['results'][0]['forbidden_candidates'],sorted(ids[20:]))
        data['cases'][0]['must_not_be_eligible']=[]
        self.assertTrue(check_retrieval(self.db,data)['passed'])
        self.assertEqual(self.db.total_changes,before)

    def test_unknown_ids_or_unreviewed_versions_cannot_pass_silently(self):
        for change in ('id','fingerprint','name','label'):
            data=self.cases()
            if change=='id':data['cases'][1]['must_not_be_eligible']=['does-not-exist']
            elif change=='fingerprint':data['record_fingerprints'][self.rid]='stale'
            elif change=='name':data['cases'][1]['name']='applicable'
            else:data['evaluation_kind']='held-out-accuracy'
            with self.subTest(change=change),self.assertRaises(ValueError):check_retrieval(self.db,data)

    def test_cli_compare_and_regression_do_not_write(self):
        self.pair();self.db.commit()
        before=self.db.execute('SELECT count(*) FROM records').fetchone()[0]
        commands=[(['compare','--project','projectut'],None),(['check-retrieval','--input','-'],self.cases())]
        for args,data in commands:
            result=subprocess.run([sys.executable,'-X','utf8',j.__file__,'--db',str(self.path),*args],
                input=json.dumps(data) if data else None,capture_output=True,text=True,encoding='utf-8')
            self.assertEqual(result.returncode,0,result.stderr)
            self.assertFalse(json.loads(result.stdout)['database_writes'])
        bad=self.cases();bad['cases'][0]['must_be_eligible']=[];bad['cases'][0]['must_not_be_eligible']=[self.rid]
        result=subprocess.run([sys.executable,'-X','utf8',j.__file__,'--db',str(self.path),'check-retrieval','--input','-'],
            input=json.dumps(bad),capture_output=True,text=True,encoding='utf-8')
        self.assertEqual(result.returncode,1)
        self.assertFalse(json.loads(result.stdout)['passed'])
        self.assertEqual(before,self.db.execute('SELECT count(*) FROM records').fetchone()[0])


if __name__=='__main__':
    unittest.main()
