"""Isolated fixtures only: these tests never write operational feedback."""
import copy
import json
import subprocess
import sys
import tempfile
import unittest
from datetime import datetime, timezone
from pathlib import Path

import judgments as j
import learning
from test_batch import packet


class LearningTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.path = Path(self.temp.name) / 'learning.sqlite3'
        self.db = j.connect(self.path, create=True)
        self.scope = dict(project='projectut', domain='vfx', target='vision-blur')

    def tearDown(self):
        self.db.close()
        self.temp.cleanup()

    def prediction_data(self, **changes):
        data = dict(**self.scope, evaluation_version=1, conversation_id='fixture-chat',
                    turn_id='fixture-turn', task='blur-v1', prediction='움직임 유지가 필요하다.', judgment_ids=[])
        data.update(changes)
        return data

    def predict(self, **changes):
        return j.predict(self.db, self.prediction_data(**changes))

    def source(self, **changes):
        data = dict(project='projectut', role='user', origin='synthetic-regression-only',
                    observed_at=datetime.now(timezone.utc).isoformat(), text='블러 중에도 캐릭터나 배경 움직임은 유지되게 해줘.',
                    conversation_id='fixture-chat', message_id='fixture-message-'+str(self.db.execute('SELECT count(*) FROM records').fetchone()[0]))
        data.update(changes)
        return j.add_source(self.db, data)

    def feedback(self, prediction=None, source=None, **changes):
        prediction = prediction or self.predict()
        source = source or self.source()
        data = dict(prediction_id=prediction, source_id=source, quote=j.get(self.db, source)['payload']['text'],
                    task='blur-v1', outcome='missed', analysis='임시 테스트 원문과 사전 판단 비교')
        data.update(changes)
        return j.feedback(self.db, data)

    def state(self, **kwargs):
        return learning.status(self.db, 'projectut', 'fixture-chat', **kwargs)

    def change(self, fid, **changes):
        data = dict(feedback_id=fid, disposition='keep', cause='execution_defect', analysis='기준은 유지하고 구현을 고친다.')
        data.update(changes)
        return learning.improve(self.db, data)

    def rule(self, sid):
        data = packet(j.get(self.db, sid)['payload']['text'])
        data['operations'].pop(0)
        data['operations'][0]['data']['source_id'] = sid
        data['operations'][1]['data']['source_id'] = sid
        return j.save_batch(self.db, data)['results'][-1]['id']

    def regression(self, rid):
        return dict(evaluation_kind='retrieval_regression', expected_by='agent_source_review',
            record_fingerprints={rid:j.get(self.db, rid)['fingerprint']}, cases=[
                dict(name='this-task', query=self.scope, must_be_eligible=[rid]),
                dict(name='other-project', query=dict(self.scope, project='crack'), must_not_be_eligible=[rid]),
                dict(name='other-target', query=dict(self.scope, target='different-effect'), must_not_be_eligible=[rid])])

    def test_lifecycle_keeps_execution_error_separate_and_readback_has_links(self):
        pid = self.predict()
        self.assertEqual(self.state()['counts']['awaiting_feedback'], 1)
        self.assertEqual(self.state()['pending'][0]['target'], 'vision-blur')
        fid = self.feedback(pid)
        self.assertEqual(self.state()['counts']['awaiting_improvement'], 1)
        iid = self.change(fid)
        self.assertEqual(iid, self.change(fid))
        self.assertEqual(self.state()['counts']['resolved'], 1)
        self.assertEqual(self.state()['pending'], [])
        summary = j.select_fields(j.get(self.db, iid), summary=True)
        self.assertEqual(summary['payload']['feedback_id'], fid)
        self.assertIn('not_accuracy', self.state()['measurement'])

    def test_prediction_frozen_but_new_turn_is_new_work(self):
        pid = self.predict()
        self.assertEqual(pid, self.predict())
        for changes in [dict(prediction='뒤늦게 바꾼 예상'), dict(domain='ui'), dict(target='other')]:
            with self.subTest(changes=changes), self.assertRaises(ValueError): self.predict(**changes)
        self.assertNotEqual(pid, self.predict(turn_id='new-turn'))
        with self.assertRaises(ValueError): self.predict(project='portfolio')

    def test_old_reimport_and_preexisting_source_rejected(self):
        sid = self.source()
        pid = self.predict()
        with self.assertRaises(ValueError): self.feedback(pid, sid)

    def test_known_message_cannot_be_laundered_with_new_time_or_future_date(self):
        self.source(message_id='known-before')
        pid = self.predict()
        sid = self.source(message_id='known-before')
        with self.assertRaises(ValueError): self.feedback(pid, sid)
        sid = self.source(observed_at='2999-01-01T00:00:00Z')
        with self.assertRaises(ValueError): self.feedback(pid, sid)
        sid = self.source(observed_at='2020-01-01T00:00:00Z')
        with self.assertRaises(ValueError): self.feedback(pid, sid)

    def test_missing_time_cannot_become_determinate(self):
        pid = self.predict()
        for value in ['unknown', '2026-10-22', '2026-10-22T12:00:00']:
            sid = self.source(observed_at=value)
            with self.assertRaises(ValueError): self.feedback(pid, sid)
            fid = self.feedback(pid, sid, outcome='undetermined')
            with self.assertRaises(ValueError): self.change(fid)

    def test_conversation_task_role_project_message_must_match(self):
        pid = self.predict()
        for changes in [dict(conversation_id='other-chat'), dict(message_id=''), dict(role='assistant'), dict(project='crack')]:
            sid = self.source(**changes)
            with self.subTest(changes=changes), self.assertRaises(ValueError): self.feedback(pid, sid)
        sid = self.source()
        with self.assertRaises(ValueError): self.feedback(pid, sid, task='another-task')

    def test_rule_updated_requires_this_feedback_and_actual_regression(self):
        pid = self.predict()
        sid = self.source()
        fid = self.feedback(pid, sid)
        rid = self.rule(sid)
        iid = self.change(fid, disposition='rule_updated', cause='rule_gap', criterion_id=rid, regression=self.regression(rid))
        saved = j.select_fields(j.get(self.db, iid), summary=True)['payload']
        self.assertEqual(saved['criterion_id'], rid)
        self.assertTrue(saved['validation']['passed'])
        self.assertFalse(saved['validation']['semantic_accuracy_measured'])
        self.assertEqual(self.state()['counts']['resolved'], 1)

    def test_regression_missing_negative_stale_version_and_bad_shape_fail(self):
        pid = self.predict(); sid = self.source(); fid = self.feedback(pid, sid); rid = self.rule(sid)
        cases = []
        missing = self.regression(rid); missing['cases'].pop(); cases.append(missing)
        stale = self.regression(rid); stale['record_fingerprints'][rid] = 'stale'; cases.append(stale)
        malformed = self.regression(rid); malformed['cases'] = [42]; cases.append(malformed)
        wrong = self.regression(rid); wrong['cases'][0]['query'] = dict(self.scope, target='other'); cases.append(wrong)
        for regression in cases:
            with self.subTest(regression=regression), self.assertRaises(ValueError):
                self.change(fid, disposition='rule_updated', cause='rule_gap', criterion_id=rid, regression=regression)
        self.assertEqual(self.state()['counts']['awaiting_improvement'], 1)

    def test_unrelated_old_rule_or_implementation_error_cannot_claim_rule_improvement(self):
        old = j.save_batch(self.db, packet())['results'][-1]['id']
        pid = self.predict(); sid = self.source(); fid = self.feedback(pid, sid)
        with self.assertRaises(ValueError):
            self.change(fid, disposition='rule_updated', cause='rule_gap', criterion_id=old, regression=self.regression(old))
        rid = self.rule(sid)
        with self.assertRaises(ValueError):
            self.change(fid, disposition='rule_updated', criterion_id=rid, regression=self.regression(rid))

    def test_scope_probe_cannot_hide_leak_with_search_filters(self):
        pid = self.predict(); sid = self.source(); fid = self.feedback(pid, sid); rid = self.rule(sid)
        regression = self.regression(rid)
        regression['cases'][2]['query']['query'] = 'never-find-this-criterion'
        with self.assertRaises(ValueError):
            self.change(fid, disposition='rule_updated', cause='rule_gap', criterion_id=rid, regression=regression)
        original = j.get(self.db,rid)
        with self.assertRaises(ValueError):
            j.add_judgment(self.db, dict(original['payload'], scope_level='project'))

    def test_one_off_feedback_is_retained_without_becoming_rule(self):
        pid = self.predict(); sid = self.source(); fid = self.feedback(pid, sid)
        data = packet(j.get(self.db,sid)['payload']['text'])
        data['operations'] = data['operations'][1:2]
        data['operations'][0]['data'].update(source_id=sid, scope_level='task', reuse='task_only')
        cid = j.save_batch(self.db,data)['results'][0]['id']
        iid = self.change(fid, disposition='case_only', candidate_id=cid)
        self.assertEqual(j.get(self.db,iid)['payload']['candidate_id'],cid)
        self.assertEqual(j.search(self.db,'projectut',target='vision-blur')['results'],[])

    def test_new_criterion_and_real_regression_are_one_atomic_packet(self):
        pid = self.predict(); sid = self.source(); fid = self.feedback(pid,sid)
        data = packet(j.get(self.db,sid)['payload']['text'])
        data['operations'].pop(0)
        for operation in data['operations']: operation['data']['source_id'] = sid
        regression = dict(evaluation_kind='retrieval_regression', expected_by='agent_source_review',
            record_fingerprints={'$ref:rule':{'$fingerprint':'rule'}}, cases=[
                dict(name='positive',query=self.scope,must_be_eligible=[{'$ref':'rule'}]),
                dict(name='other-project',query=dict(self.scope,project='crack'),must_not_be_eligible=[{'$ref':'rule'}]),
                dict(name='other-target',query=dict(self.scope,target='different'),must_not_be_eligible=[{'$ref':'rule'}])])
        data['operations'].append(dict(ref='improvement',command='improve',data=dict(feedback_id=fid,
            disposition='rule_updated',cause='rule_gap',analysis='원문 검토 후 기준 보완',
            criterion_id={'$ref':'rule'},regression=regression)))
        failed = copy.deepcopy(data)
        failed['operations'][-1]['data']['regression']['cases'][0]['must_not_be_eligible']=[{'$ref':'rule'}]
        before = self.db.execute('SELECT count(*) FROM records').fetchone()[0]
        with self.assertRaises(ValueError): j.save_batch(self.db,failed)
        self.assertEqual(before,self.db.execute('SELECT count(*) FROM records').fetchone()[0])
        result = j.save_batch(self.db,data)
        self.assertTrue(j.get(self.db,result['results'][-1]['id'])['payload']['validation']['passed'])

    def test_current_rule_only_and_no_scope_expansion(self):
        pid = self.predict(); sid = self.source(); fid = self.feedback(pid, sid); rid = self.rule(sid)
        with self.assertRaises(ValueError):
            self.change(fid, disposition='case_only', candidate_id=j.get(self.db,rid)['payload']['candidate_id'])
        # Withdraw through the existing reviewed API; no direct test mutation of records.
        old = j.get(self.db, rid)
        j.add_judgment(self.db, dict(old['payload'], status='rejected', supersedes=rid, change_reason='테스트 철회'))
        with self.assertRaises(ValueError): self.predict(turn_id='second', judgment_ids=[rid])
        with self.assertRaises(ValueError):
            self.change(fid, disposition='rule_updated', cause='rule_gap', criterion_id=rid, regression=self.regression(rid))

    def test_prediction_reuses_reviewed_project_scope_without_target_aliases(self):
        data = packet('카메라 연출이 추가된 VFX는 카메라 기준으로 검토해줘.')
        data['operations'][1]['data'].update(scope_level='project', scope_basis='프로젝트 VFX 공통 검토 조건')
        rid = j.save_batch(self.db, data)['results'][-1]['id']
        pid = self.predict(target='ultimate-presentation', judgment_ids=[rid])
        self.assertEqual(j.get(self.db, pid)['payload']['judgment_ids'], [rid])
        for changes in (dict(project='crack'), dict(domain='art')):
            with self.subTest(changes=changes), self.assertRaises(ValueError):
                self.predict(target='ultimate-presentation', judgment_ids=[rid], **changes)

    def test_prediction_keeps_object_target_boundary(self):
        rid = j.save_batch(self.db, packet())['results'][-1]['id']
        self.predict(judgment_ids=[rid])
        with self.assertRaises(ValueError):
            self.predict(target='ultimate-presentation', judgment_ids=[rid])

    def test_prediction_reuses_explicit_global_scope_within_domain(self):
        data = packet('공통 VFX 검토에서는 움직임을 확인해줘.')
        for operation in data['operations']:
            operation['data']['project'] = 'global'
        data['operations'][1]['data'].update(scope_level='global', scope_basis='공통 VFX 검토 기준')
        rid = j.save_batch(self.db, data)['results'][-1]['id']
        for project in ('projectut', 'crack'):
            self.predict(project=project, target='another-vfx', judgment_ids=[rid])
        with self.assertRaises(ValueError):
            self.predict(domain='art', target='another-vfx', judgment_ids=[rid])

    def test_existing_scope_mismatch_cannot_expand_reviewed_candidate(self):
        from retrieval import retrieve
        rid = j.save_batch(self.db, packet())['results'][-1]['id']
        original = j.get(self.db, rid)
        # Model an old inconsistent row in this isolated fixture, bypassing the writer.
        bad = j.put(self.db, 'judgment', 'projectut', 'vfx', 'vision-blur', 'confirmed',
                    dict(original['payload'], scope_level='project'))
        item = next(r for r in retrieve(self.db, 'projectut', domain='vfx',
                    target='vision-blur')['results'] if r['id'] == bad)
        self.assertFalse(item['rule_eligible'])
        self.assertIn('judgment_scope_mismatch', [a['reason'] for a in item['review_alerts']])
        with self.assertRaises(ValueError):
            self.predict(target='ultimate-presentation', judgment_ids=[bad])
        with self.assertRaises(ValueError):
            j.predict(self.db, dict(self.scope, task='legacy-mismatch', prediction='합성 검사', judgment_ids=[bad]))

    def test_linked_rule_is_not_rejected_by_display_ranking(self):
        from retrieval import retrieve
        from evaluation import validate_prediction as validate_comparison
        ids = [j.save_batch(self.db, packet('합성 기준 %02d: 움직임을 유지해줘.' % n))['results'][-1]['id']
               for n in range(21)]
        self.assertNotIn(ids[0], [r['id'] for r in retrieve(self.db, 'projectut',
                         domain='vfx', target='vision-blur', limit=20)['results']])
        data = self.prediction_data(judgment_ids=[ids[0]])
        comparison = dict(self.scope, task='ranking-fixture', prediction='합성 사전 판단',
                          comparison_id='ranking-fixture', variant='harness', judgment_ids=[ids[0]])
        self.predict(judgment_ids=[ids[0]])
        validate_comparison(self.db, comparison)
        change = packet('기존 움직임 기준은 쓰지 마.')
        change['operations'].pop()
        change['operations'][1]['data'].update(types=['rejection'],
            type_quotes={'rejection':'기존 움직임 기준은 쓰지 마.'})
        j.save_batch(self.db, change)
        # Unselected corrections still block both selected-ID validation paths.
        with self.assertRaises(ValueError): learning.validate_prediction(self.db, data)
        with self.assertRaises(ValueError): validate_comparison(self.db, comparison)

    def test_improvement_revisions_are_explicit_and_idempotent(self):
        fid = self.feedback()
        iid = self.change(fid, disposition='needs_context', cause='ambiguous')
        with self.assertRaises(ValueError): self.change(fid)
        new = self.change(fid, supersedes=iid)
        self.assertEqual(new, self.change(fid, supersedes=iid))
        with self.assertRaises(ValueError): self.change(fid, supersedes=iid, analysis='다른 결론')
        other = self.feedback(self.predict(task='other', turn_id='other'), task='other')
        with self.assertRaises(ValueError): self.change(other, supersedes=new)

    def test_conflicting_feedback_stays_pending_until_later_explicit_correction(self):
        pid = self.predict(); sid = self.source(); fid = self.feedback(pid, sid)
        self.change(fid)
        other = self.feedback(pid, sid, outcome='matched')
        self.assertEqual(self.state()['counts']['needs_context'], 2)
        with self.assertRaises(ValueError): self.change(other)
        with self.assertRaises(ValueError): self.feedback(pid, sid, outcome='missed', supersedes=other)
        correction = self.source(message_id='later-clarification')
        resolved = self.feedback(pid, correction, outcome='missed', supersedes=other)
        self.assertEqual(resolved, self.feedback(pid, correction, outcome='missed', supersedes=other))
        self.change(resolved)
        self.assertEqual(self.state()['counts']['resolved'], 2)
        with self.assertRaises(ValueError): self.change(other)

    def test_task_filter_and_readonly_cli(self):
        self.predict()
        self.predict(task='other', turn_id='other')
        self.assertEqual(len(self.state(task='blur-v1')['pending']), 1)
        self.assertEqual(learning.status(self.db, 'crack', 'fixture-chat')['pending'], [])
        self.db.commit()
        before = self.path.read_bytes()
        result = subprocess.run([sys.executable, '-B', '-X', 'utf8', j.__file__, '--db', str(self.path),
            'learning-status', '--project', 'projectut', '--conversation', 'fixture-chat', '--limit', '1'],
            capture_output=True, encoding='utf-8')
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertTrue(json.loads(result.stdout)['pending_truncated'])
        self.assertEqual(before, self.path.read_bytes())

    def test_batch_feedback_and_improvement_roll_back_together(self):
        pid = self.predict(); sid = self.source()
        data = dict(operations=[dict(ref='feedback', command='feedback', data=dict(prediction_id=pid,
            source_id=sid, quote=j.get(self.db,sid)['payload']['text'], task='blur-v1', outcome='missed', analysis='임시 검증')),
            dict(ref='improvement', command='improve', data=dict(feedback_id={'$ref':'feedback'},
                disposition='keep', cause='execution_defect', analysis='기준 유지'))])
        result = j.save_batch(self.db, data)
        self.assertEqual(result['results'][-1]['kind'], 'improvement')
        failed = copy.deepcopy(data)
        failed['operations'][0]['data']['analysis'] = '다른 평가'
        failed['operations'][1]['data']['cause'] = 'invalid'
        before = self.db.execute('SELECT count(*) FROM records').fetchone()[0]
        with self.assertRaises(ValueError): j.save_batch(self.db, failed)
        self.assertEqual(before, self.db.execute('SELECT count(*) FROM records').fetchone()[0])


if __name__ == '__main__':
    unittest.main()
