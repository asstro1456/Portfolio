import copy
import json
import tempfile
import unittest
from pathlib import Path

import judgments as j
from check_classification_cases import CASES, replay


class ClassificationTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.db = j.connect(Path(self.temp.name) / 'cases.sqlite3', create=True)
        case = json.loads(CASES.read_text(encoding='utf-8'))['cases'][0]
        self.base = copy.deepcopy(case['classification'])
        sid = j.add_source(self.db, dict(project='projectut', role='user', origin='test',
                                       observed_at='unknown', text=case['quote']))
        self.base.update(source_id=sid, quote=case['quote'])

    def tearDown(self):
        self.db.close()
        self.temp.cleanup()

    def promote(self, rid, **changes):
        candidate = j.get(self.db, rid)['payload']
        data = {key: candidate[key] for key in ('project', 'domain', 'target', 'source_id', 'quote')}
        data.update(status='confirmed', decision=candidate['interpretation'], reason_kind='unknown',
                    candidate_id=rid, review_note='Test-only review of scope and source')
        data.update(changes)
        return j.add_judgment(self.db, data)

    def test_real_cases_store_as_candidates_not_active_rules(self):
        report = replay(self.db)
        self.assertEqual(len(report['results']), 5)
        self.assertEqual(j.search(self.db, 'projectut', include_pending=True)['results'], [])
        self.assertEqual(self.db.execute("SELECT count(*) FROM records WHERE kind='judgment'").fetchone()[0], 0)
        again = replay(self.db)
        self.assertEqual(report, again)
        self.assertEqual(self.db.execute("SELECT count(*) FROM records WHERE kind='candidate'").fetchone()[0], 5)

    def test_missing_image_question_and_task_only_cannot_be_promoted(self):
        report = replay(self.db)
        for row in report['results'][1:]:
            with self.subTest(case=row['case']), self.assertRaises(ValueError):
                self.promote(row['id'])

    def test_explicit_reusable_candidate_can_be_reviewed_and_promoted(self):
        rid = j.add_candidate(self.db, self.base)
        approved = self.promote(rid)
        self.assertEqual(j.search(self.db, 'projectut')['results'][0]['id'], approved)
        self.assertEqual(j.get(self.db, approved)['payload']['candidate_id'], rid)

    def test_type_evidence_must_be_in_utterance(self):
        data = copy.deepcopy(self.base)
        data['type_quotes']['reason'] = '속도가 느려서'
        with self.assertRaises(ValueError):
            j.add_candidate(self.db, data)

    def test_question_only_cannot_be_explicit_decision(self):
        data = dict(self.base, types=['question'], type_quotes={'question': self.base['quote']})
        with self.assertRaises(ValueError):
            j.add_candidate(self.db, data)

    def test_selection_requires_context_even_with_correct_quote(self):
        data = dict(self.base, types=['selection'], type_quotes={'selection': self.base['quote']})
        with self.assertRaises(ValueError):
            j.add_candidate(self.db, data)

    def test_claimed_resolved_context_requires_actual_reference(self):
        with self.assertRaises(ValueError):
            j.add_candidate(self.db, dict(self.base, context_state='resolved'))

    def test_missing_context_cannot_keep_explicit_reusable_status(self):
        with self.assertRaises(ValueError):
            j.add_candidate(self.db, dict(self.base, context_state='missing', missing_context=['원본 이미지']))

    def test_other_project_context_rejected(self):
        sid = j.add_source(self.db, dict(project='crack', role='assistant', origin='test-other',
                                       observed_at='unknown', text='무관한 제안'))
        data = dict(self.base, context_state='resolved', context_refs=[
            dict(source_id=sid, quote='무관한 제안', relation='prompt')])
        with self.assertRaises(ValueError):
            j.add_candidate(self.db, data)

    def test_scope_and_task_lifetime_constraints(self):
        for changes in [dict(scope_level='global'), dict(scope_level='task'),
                        dict(scope_level='task', target='today', reuse='reusable')]:
            with self.subTest(changes=changes), self.assertRaises(ValueError):
                j.add_candidate(self.db, dict(self.base, **changes))

    def test_promotion_cannot_change_scope_or_omit_review(self):
        rid = j.add_candidate(self.db, self.base)
        for changes in [dict(target='another-effect'), dict(review_note='')]:
            with self.subTest(changes=changes), self.assertRaises(ValueError):
                self.promote(rid, **changes)

    def test_reclassification_preserves_previous_and_blocks_stale_promotion(self):
        rid = j.add_candidate(self.db, self.base)
        updated = j.add_candidate(self.db, dict(self.base, interpretation='검수 뒤 더 좁게 정리한 해석',
                                               reclassifies=rid))
        self.assertEqual(j.get(self.db, rid)['payload'], self.base)
        self.assertEqual(j.get(self.db, updated)['supersedes'], rid)
        with self.assertRaises(ValueError):
            self.promote(rid)


if __name__ == '__main__':
    unittest.main()
