"""Bounded, read-only retrieval trials; never change criteria or deploy a candidate."""
import argparse
import copy
import hashlib
import json
import os
import re
import sqlite3
import sys
import tempfile
from datetime import datetime, timezone
from pathlib import Path
from time import perf_counter

import conflicts
import evaluation
import judgments as j
import retrieval

OUTPUT_ROOT = Path('D:/CodexData/harness/outputs')
SCOPE = {'project', 'domain', 'target'}
QUERY_EDITS = {'query', 'limit', 'chars', 'full_source_review'}


def source_versions():
    return {Path(p).name: hashlib.sha256(Path(p).read_bytes()).hexdigest()
            for p in (__file__, j.__file__, evaluation.__file__, retrieval.__file__, conflicts.__file__)}


def snapshot_version(db):
    digest = hashlib.sha256()
    for table, order in (('records', 'rowid'), ('document_heads', 'project,path')):
        digest.update(table.encode())
        for row in db.execute(f'SELECT rowid,* FROM {table} ORDER BY {order}'):
            digest.update((j.canonical(list(row)) + '\n').encode('utf-8'))
    return digest.hexdigest()


def prepare(db, data):
    allowed = {'trial_version', 'trial_id', 'task', 'hypothesis', 'expected_by',
               'record_fingerprints', 'cases'}
    if not isinstance(data, dict) or set(data) - allowed or type(data.get('trial_version')) is not int or data['trial_version'] != 1:
        raise ValueError('trial_version=1인 검색 실험 객체가 필요합니다. 실행 코드·모델 설정은 받지 않습니다.')
    j.required(data, 'trial_id', 'task', 'hypothesis')
    if not re.fullmatch(r'[a-zA-Z0-9][a-zA-Z0-9_-]{0,79}', data['trial_id']):
        raise ValueError('trial_id는 영문/숫자/밑줄/하이픈 1~80자여야 합니다.')
    expected_by = data.get('expected_by')
    if expected_by not in ('agent_source_review', 'mechanical_source_delivery'):
        raise ValueError('원문 검토 또는 기계적 원문 전달 검사의 기대값이 필요합니다.')
    cases = data.get('cases')
    if not isinstance(cases, list) or not 1 <= len(cases) <= 40:
        raise ValueError('검색 사례는 1~40개여야 합니다.')
    baseline, candidate, ids, positives, guards = [], [], set(), [], []
    for case in cases:
        if not isinstance(case, dict) or set(case) - {'name', 'query', 'candidate_query', 'must_be_eligible', 'must_not_be_eligible'}:
            raise ValueError('사례에는 name/query/candidate_query와 공통 기대 ID만 사용하세요.')
        query, patch = case.get('query'), case.get('candidate_query', {})
        if not isinstance(query, dict) or not isinstance(patch, dict) or set(patch) - QUERY_EDITS:
            raise ValueError('후보는 query/limit/chars/full_source_review만 바꿀 수 있습니다. 적용 범위는 고정합니다.')
        for q in (query, dict(query, **patch)):
            if ('limit' in q and (type(q['limit']) is not int or not 1 <= q['limit'] <= 20) or
                    'chars' in q and (type(q['chars']) is not int or not 80 <= q['chars'] <= 2000) or
                    'query' in q and not isinstance(q['query'], str) or
                    'full_source_review' in q and type(q['full_source_review']) is not bool):
                raise ValueError('query는 문자열, limit는 1~20, chars는 80~2000 정수여야 합니다.')
        if expected_by == 'mechanical_source_delivery' and (set(patch) - {'chars', 'full_source_review'} or
                patch.get('chars', query.get('chars', retrieval.DEFAULT_CHARS)) < query.get('chars', retrieval.DEFAULT_CHARS) or
                ('full_source_review' in patch and patch['full_source_review'] is not True)):
            raise ValueError('기계적 복구는 키워드·결과 개수를 유지하며 원문 전달만 확대합니다.')
        yes, no = case.get('must_be_eligible', []), case.get('must_not_be_eligible', [])
        if any(not isinstance(xs, list) or len(xs) > 20 or any(not isinstance(x, str) for x in xs) for xs in (yes, no)) or not (yes or no) or set(yes) & set(no):
            raise ValueError('사례마다 서로 모순되지 않는 기대 ID 목록이 필요합니다.')
        ids.update(yes + no)
        if no:
            if patch or set(query) != SCOPE or yes:
                raise ValueError('차단 검사는 project/domain/target만 사용하며 후보별로 바꾸지 않습니다.')
            guards.append(case)
        positives.extend((rid, query) for rid in yes)
        item = {k: copy.deepcopy(v) for k, v in case.items() if k != 'candidate_query'}
        baseline.append(item)
        candidate.append(dict(item, query=dict(query, **patch)))
    fingerprints = data.get('record_fingerprints')
    if not positives or not isinstance(fingerprints, dict) or set(fingerprints) != ids:
        raise ValueError('양성 사례와 모든 기대 ID의 정확한 record_fingerprints가 필요합니다.')
    for rid, query in positives:
        rule = j.get(db, rid)
        p = rule['payload']
        linked = j.get(db, p['candidate_id'])['payload'] if p.get('candidate_id') else {}
        level = p.get('scope_level', linked.get('scope_level'))
        scope = {key: rule[key] for key in SCOPE}
        if (rule['kind'] != 'judgment' or rule['status'] != 'confirmed' or level != 'object' or
                scope['project'] == 'global' or any(not v or v == '*' for v in scope.values()) or
                any(query.get(k) != v for k, v in scope.items())):
            raise ValueError('첫 버전은 project/domain/target이 명확한 object 확정 기준의 검색만 비교합니다.')
        other_project = any(rid in g['must_not_be_eligible'] and
                            g['query'].get('project') in {'crack', 'projectut'} - {scope['project']} and
                            all(g['query'].get(k) == scope[k] for k in ('domain', 'target')) for g in guards)
        other_target = any(rid in g['must_not_be_eligible'] and
                           g['query'].get('target') not in (None, '', '*', scope['target']) and
                           all(g['query'].get(k) == scope[k] for k in ('project', 'domain')) for g in guards)
        if not (other_project and other_target):
            raise ValueError('각 양성 기준에 다른 프로젝트/다른 대상의 필터 없는 차단 검사가 필요합니다.')
        if expected_by == 'mechanical_source_delivery':
            expanded = retrieval.retrieve(db, **dict(query, limit=1, chars=2000, full_source_review=True), _selected_ids=[rid])
            if not any(x['id'] == rid and x['rule_eligible'] and x['source_review']['complete'] and
                       not x['review_alerts'] for x in expanded['results']):
                raise ValueError('기계적 기대값은 현재 원문·충돌 검증을 통과하는 동일 검색 기준만 사용합니다.')
    common = dict(evaluation_kind='retrieval_regression', expected_by=expected_by,
                  record_fingerprints=copy.deepcopy(fingerprints))
    return dict(baseline=dict(common, cases=baseline), candidate=dict(common, cases=candidate))


def run_trial(db, data):
    """Both variants see one frozen, query-only memory snapshot, including conflict evidence."""
    if db.in_transaction:
        raise ValueError('미완료 트랜잭션을 실험 입력으로 사용하지 않습니다. 원래 작업에서 먼저 확정/취소하세요.')
    data = copy.deepcopy(data)
    versions = source_versions()
    frozen = sqlite3.connect(':memory:')
    try:
        db.backup(frozen)
        frozen.row_factory = sqlite3.Row
        frozen.execute('PRAGMA query_only=ON')
        packets = prepare(frozen, data)
        snapshot = snapshot_version(frozen)
        variants = {}
        for name, packet in packets.items():
            start = perf_counter()
            result = evaluation.check_retrieval(frozen, packet)
            variants[name] = dict(result, elapsed_seconds=round(perf_counter() - start, 6))
        if versions != source_versions():
            raise ValueError('실험 도중 실행 소스가 변경됐습니다. 새 버전으로 다시 실행하세요.')
        if snapshot != snapshot_version(frozen):
            raise ValueError('실험의 고정 입력이 변경됐습니다.')
    finally:
        frozen.close()
    before = {r['name']: r['passed'] for r in variants['baseline']['results']}
    after = {r['name']: r['passed'] for r in variants['candidate']['results']}
    improved = [name for name in before if not before[name] and after[name]]
    regressed = [name for name in before if before[name] and not after[name]]
    if not variants['candidate']['passed']:
        decision, reason = 'candidate_rejected', 'Candidate fails checks; no replacement of baseline.'
    elif improved:
        decision, reason = 'candidate_supported', 'Candidate fixes curated failures without a new failure; not deployed.'
    else:
        decision, reason = 'keep_baseline', 'No demonstrated correctness gain; timing alone does not select a candidate.'
    return dict(trial_version=1, trial_id=data['trial_id'], checked_at=datetime.now(timezone.utc).isoformat(),
                execution_kind='deterministic_retrieval', input_sha256=j.digest(data),
                snapshot_sha256=snapshot, source_files_sha256=versions, input=data,
                variants=variants, improved_cases=improved, regressed_cases=regressed,
                decision=decision, reason=reason, database_writes=False, candidate_applied=False,
                model_calls=0, api_cost_usd=None, semantic_accuracy_measured=False,
                limitation='Curated retrieval checks only, not user feedback, task-output quality or general improvement. '
                           'Evidence delivery never replaces reading the exact sources before applying a rule.')


def write_report(path, report):
    """Publish one complete report without replacing an existing file, even on a name collision."""
    path = Path(path).resolve()
    if not path.is_relative_to(OUTPUT_ROOT.resolve()) or path == OUTPUT_ROOT.resolve():
        raise ValueError('실험 결과는 D:/CodexData/harness/outputs/ 아래에 저장하세요.')
    if path.exists():
        raise ValueError('기존 실험 결과는 덮어쓰지 않습니다. 새 결과 경로를 사용하세요.')
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = None
    try:
        with tempfile.NamedTemporaryFile(mode='w', encoding='utf-8', dir=path.parent, delete=False) as out:
            temporary = Path(out.name)
            json.dump(report, out, ensure_ascii=False, indent=2)
            out.write('\n')
            out.flush()
            os.fsync(out.fileno())
        os.link(temporary, path)
    finally:
        if temporary is not None:
            temporary.unlink(missing_ok=True)


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--db', default=str(j.DEFAULT_DB))
    parser.add_argument('--input', default='-', help='실험 JSON 경로 또는 표준입력 -')
    parser.add_argument('--output', help='명시할 때만 결과 파일 저장; 기존 결과는 보존')
    args = parser.parse_args(argv)
    try:
        data = json.load(sys.stdin) if args.input == '-' else json.loads(Path(args.input).read_text(encoding='utf-8'))
        db = j.connect(args.db, read_only=True)
        try:
            report = run_trial(db, data)
        finally:
            db.close()
        if args.output:
            write_report(args.output, report)
        print(json.dumps(report, ensure_ascii=False, indent=2))
        return 1 if report['decision'] == 'candidate_rejected' else 0
    except (ValueError, KeyError, TypeError, OSError, sqlite3.Error) as exc:
        print(json.dumps(dict(error=str(exc), database_writes=False, candidate_applied=False), ensure_ascii=False), file=sys.stderr)
        return 2


if __name__ == '__main__':
    sys.exit(main())
