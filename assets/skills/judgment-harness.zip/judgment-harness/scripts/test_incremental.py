import copy
import json
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch
import judgments as j
from incremental import apply


def item(n):
    text='실제 테스트 요청 '+str(n)
    return dict(source=dict(project='test',backend='codex',conversation_id='conv',message_id=str(n),role='user',text=text),
        candidate=dict(domain='workflow',target='task',quote=text,types=['request'],type_quotes=dict(request=text),
        interpretation=text,rationale='합성 테스트',decision_state='explicit',scope_level='task',scope_basis='이번 작업',
        reuse='task_only',context_state='standalone',missing_context=[],reason_kind='unknown',
        attributes=dict(conditions=[],priority=None,action_state=None,acceptance_scope=None)))


class IncrementalTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory();self.path=Path(self.temp.name)
        self.db=j.connect(self.path/'test.sqlite3',create=True);self.cp=self.path/'checkpoint.json'
    def tearDown(self):self.db.close();self.temp.cleanup()
    def test_stop_resume_and_replay(self):
        p=dict(items=[item(n) for n in range(5)])
        first=apply(self.db,p,self.cp,2);self.assertEqual(first['remaining_in_packet'],3)
        self.assertEqual(len(json.loads(self.cp.read_text(encoding='utf-8'))['pending']),3)
        second=apply(self.db,p,self.cp,20);self.assertEqual(len(second['processed']),3)
        third=apply(self.db,p,self.cp);self.assertEqual(third['new_records'],0)
        self.assertEqual(self.db.execute('SELECT count(*) FROM records').fetchone()[0],10)
        self.assertEqual(json.loads(self.cp.read_text(encoding='utf-8'))['counts']['processed'],5)
        self.assertEqual(json.loads(self.cp.read_text(encoding='utf-8'))['pending'],[])
    def test_committed_item_survives_checkpoint_write_failure(self):
        p=dict(items=[item(1)])
        with patch('incremental.save_checkpoint',side_effect=OSError('simulated interruption')):
            with self.assertRaises(OSError):apply(self.db,p,self.cp)
        self.assertEqual(self.db.execute('SELECT count(*) FROM records').fetchone()[0],2)
        result=apply(self.db,p,self.cp)
        self.assertEqual(result['new_records'],0)
        self.assertTrue(result['processed'][0]['readback_verified'])
    def test_context_change_requires_review_instead_of_duplication(self):
        p=dict(items=[item(1)]);apply(self.db,p,self.cp)
        self.cp.unlink();changed=copy.deepcopy(p);changed['items'][0]['candidate']['interpretation']='다른 해석'
        with self.assertRaises(ValueError):apply(self.db,changed,self.cp)
        self.assertEqual(self.db.execute('SELECT count(*) FROM records').fetchone()[0],2)
    def test_completed_checkpoint_does_not_silently_skip_changed_classification(self):
        p=dict(items=[item(1)]);apply(self.db,p,self.cp)
        original=self.cp.read_bytes();changed=copy.deepcopy(p)
        changed['items'][0]['candidate']['interpretation']='재개 중 달라진 해석'
        with self.assertRaises(ValueError):apply(self.db,changed,self.cp)
        self.assertEqual(self.cp.read_bytes(),original)
        self.assertEqual(self.db.execute('SELECT count(*) FROM records').fetchone()[0],2)
    def test_completed_checkpoint_does_not_silently_skip_new_record_request(self):
        a=item(1);a['candidate'].update(scope_level='object',reuse='reusable')
        apply(self.db,dict(items=[a]),self.cp);original=self.cp.read_bytes()
        a['record']=dict(status='confirmed',review_note='새로운 승격 요청')
        with self.assertRaises(ValueError):apply(self.db,dict(items=[a]),self.cp)
        self.assertEqual(self.cp.read_bytes(),original)
        self.assertEqual(self.db.execute('SELECT count(*) FROM records').fetchone()[0],2)
    def test_commit_gap_does_not_reuse_a_different_record_payload(self):
        a=item(1);a['candidate'].update(scope_level='object',reuse='reusable')
        a['record']=dict(status='confirmed',review_note='원래 검토',decision='원래 판단')
        apply(self.db,dict(items=[a]),self.cp);self.cp.unlink()
        a['record']['decision']='수정된 판단'
        with self.assertRaises(ValueError):apply(self.db,dict(items=[a]),self.cp)
        self.assertFalse(self.cp.exists())
        self.assertEqual(self.db.execute('SELECT count(*) FROM records').fetchone()[0],3)
    def test_commit_gap_rechecks_inherited_decision_when_override_is_removed(self):
        a=item(1);a['candidate'].update(scope_level='object',reuse='reusable')
        a['record']=dict(status='confirmed',review_note='원래 검토',decision='별도로 검토한 판단')
        apply(self.db,dict(items=[a]),self.cp);self.cp.unlink()
        del a['record']['decision']
        with self.assertRaises(ValueError):apply(self.db,dict(items=[a]),self.cp)
        self.assertFalse(self.cp.exists())
        self.assertEqual(self.db.execute('SELECT count(*) FROM records').fetchone()[0],3)
    def test_explicit_reason_reference_recovers_when_source_already_exists(self):
        a=item(1);a['candidate'].update(scope_level='object',reuse='reusable',reason_kind='user_stated',
            reason='테스트에서 밝힌 이유',reason_quote=a['source']['text'],reason_source_id={'$ref':'user'})
        a['record']=dict(status='confirmed',review_note='검토',reason_source_id={'$ref':'user'})
        with patch('incremental.save_checkpoint',side_effect=OSError('simulated interruption')):
            with self.assertRaises(OSError):apply(self.db,dict(items=[a]),self.cp)
        result=apply(self.db,dict(items=[a]),self.cp)
        self.assertEqual(result['new_records'],0)
        rule=j.get(self.db,result['processed'][0]['judgment_id'])
        self.assertEqual(rule['payload']['reason_source_id'],result['processed'][0]['source_id'])
    def test_reconciliation_requires_complete_classification_payload(self):
        for field in ('quote','interpretation','attributes'):
            for checkpoint_exists in (True,False):
                with self.subTest(field=field,checkpoint_exists=checkpoint_exists):
                    a=item(field+str(checkpoint_exists));apply(self.db,dict(items=[a]),self.cp)
                    if not checkpoint_exists:self.cp.unlink()
                    before=self.cp.read_bytes() if self.cp.exists() else None
                    count=self.db.execute('SELECT count(*) FROM records').fetchone()[0]
                    del a['candidate'][field]
                    with self.assertRaises(ValueError):apply(self.db,dict(items=[a]),self.cp)
                    self.assertEqual(self.cp.read_bytes() if self.cp.exists() else None,before)
                    self.assertEqual(self.db.execute('SELECT count(*) FROM records').fetchone()[0],count)
    def test_reconciliation_requires_complete_record_payload(self):
        for field in ('status','review_note'):
            for checkpoint_exists in (True,False):
                with self.subTest(field=field,checkpoint_exists=checkpoint_exists):
                    a=item(field+str(checkpoint_exists));a['candidate'].update(scope_level='object',reuse='reusable')
                    a['record']=dict(status='confirmed',review_note='원문 검토')
                    apply(self.db,dict(items=[a]),self.cp)
                    if not checkpoint_exists:self.cp.unlink()
                    before=self.cp.read_bytes() if self.cp.exists() else None
                    count=self.db.execute('SELECT count(*) FROM records').fetchone()[0]
                    del a['record'][field]
                    with self.assertRaises(ValueError):apply(self.db,dict(items=[a]),self.cp)
                    self.assertEqual(self.cp.read_bytes() if self.cp.exists() else None,before)
                    self.assertEqual(self.db.execute('SELECT count(*) FROM records').fetchone()[0],count)
    def test_same_message_id_in_another_conversation_stays_separate(self):
        a=item(1);b=copy.deepcopy(a);b['source']['conversation_id']='other'
        r=apply(self.db,dict(items=[a,b]),self.cp)
        self.assertEqual(len(r['processed']),2)
        self.assertNotEqual(r['processed'][0]['source_id'],r['processed'][1]['source_id'])
    def test_same_ids_and_text_in_different_backends_stay_separate(self):
        a=item(1);b=copy.deepcopy(a);b['source']['backend']='chatgpt'
        r=apply(self.db,dict(items=[a,b]),self.cp)
        self.assertEqual(len(r['processed']),2)
        self.assertNotEqual(r['processed'][0]['source_id'],r['processed'][1]['source_id'])
        self.assertEqual(self.db.execute("SELECT count(*) FROM records WHERE kind='source'").fetchone()[0],2)
    def test_known_legacy_backend_is_reused_only_within_its_service(self):
        a=item(1);legacy=dict(a['source'],origin='export:codex.json/conversation:conv/message:1',observed_at='unknown')
        del legacy['backend']
        original=j.add_source(self.db,legacy);self.db.commit()
        first=apply(self.db,dict(items=[a]),self.cp)
        self.assertEqual(first['processed'][0]['source_id'],original)
        b=copy.deepcopy(a);b['source']['backend']='chatgpt'
        second=apply(self.db,dict(items=[b]),self.cp)
        self.assertNotEqual(second['processed'][0]['source_id'],original)
    def test_unknown_legacy_backend_does_not_guess_or_advance_checkpoint(self):
        a=item(1);legacy=dict(a['source'],origin='current-conversation',observed_at='unknown')
        del legacy['backend']
        j.add_source(self.db,legacy);self.db.commit()
        with self.assertRaisesRegex(ValueError,'backend is unknown'):
            apply(self.db,dict(items=[a]),self.cp)
        self.assertEqual(self.db.execute('SELECT count(*) FROM records').fetchone()[0],1)
        self.assertFalse(self.cp.exists())
    def test_rule_with_self_quoted_condition_recovers_commit_gap(self):
        a=item(1);a['candidate'].update(scope_level='object',reuse='reusable')
        a['candidate']['attributes']['conditions']=[dict(source_id={'$ref':'user'},
            quote=a['source']['text'],when='테스트할 때',then='이 조건을 확인한다')]
        a['record']=dict(status='confirmed',review_note='합성 테스트의 원문과 범위를 검토했다')
        with patch('incremental.save_checkpoint',side_effect=OSError('simulated interruption')):
            with self.assertRaises(OSError):apply(self.db,dict(items=[a]),self.cp)
        r=apply(self.db,dict(items=[a]),self.cp)
        self.assertEqual(r['new_records'],0)
        self.assertIsNotNone(r['processed'][0]['judgment_id'])
        self.assertEqual(self.db.execute('SELECT count(*) FROM records').fetchone()[0],3)
    def test_invalid_quote_rolls_back_sources_without_advancing_checkpoint(self):
        a=item(1);a['candidate']['quote']='원문에 없는 인용'
        with self.assertRaises(ValueError):apply(self.db,dict(items=[a]),self.cp)
        self.assertEqual(self.db.execute('SELECT count(*) FROM records').fetchone()[0],0)
        self.assertFalse(self.cp.exists())


if __name__=='__main__':unittest.main()
