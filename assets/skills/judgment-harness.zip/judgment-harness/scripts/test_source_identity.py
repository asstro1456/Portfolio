import copy
import json
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

import judgments as j
import learning

CONVERSATION = '11111111-1111-4111-8111-111111111111'
OTHER = '22222222-2222-4222-8222-222222222222'
MESSAGE = 'msg_33333333-3333-4333-8333-333333333333'


class SourceIdentityTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.path = Path(self.temp.name)/'source.sqlite3'
        self.db = j.connect(self.path, create=True)

    def tearDown(self): self.db.close(); self.temp.cleanup()

    def data(self, **changes):
        value = dict(project='projectut', role='user', text='Synthetic exact request', observed_at='unknown',
            origin=f'conversation:{CONVERSATION}/message:{MESSAGE}', conversation_id=CONVERSATION, message_id=MESSAGE)
        value.update(changes)
        return value

    def test_new_direct_source_requires_structured_ids_and_does_not_guess_them(self):
        for field in ('conversation_id', 'message_id'):
            data = self.data(); data.pop(field)
            with self.subTest(field=field), self.assertRaises(ValueError): j.add_source(self.db, data)
        self.assertEqual(self.db.execute('SELECT count(*) FROM records').fetchone()[0], 0)

    def test_origin_conflict_empty_and_malformed_ids_are_rejected(self):
        for changes in [dict(conversation_id=OTHER), dict(message_id='msg_'+OTHER),
                        dict(message_id=''), dict(conversation_id=' '), dict(turn_id=''),
                        dict(turn_id='guessed-turn'), dict(origin='conversation:wrong/message:wrong'), dict(task='')]:
            with self.subTest(changes=changes), self.assertRaises(ValueError): j.add_source(self.db, self.data(**changes))

    def test_exact_replay_is_idempotent_and_identity_reassignment_or_version_change_fails(self):
        data = self.data(task='version-1', target='actual-object')
        sid = j.add_source(self.db, data)
        self.assertEqual(sid, j.add_source(self.db, data))
        for changes in [dict(project='crack'), dict(role='assistant'), dict(text='different text'),
                        dict(task='version-2'), dict(target='other-object'), dict(observed_at='2026-10-31T00:00:00Z')]:
            with self.subTest(changes=changes), self.assertRaises(ValueError): j.add_source(self.db, dict(data, **changes))
        self.assertEqual(self.db.execute('SELECT count(*) FROM records').fetchone()[0], 1)

    def test_origin_only_legacy_exact_replay_is_read_only_and_not_a_bulk_migration(self):
        legacy = self.data(); legacy.pop('conversation_id'); legacy.pop('message_id')
        sid = j.put(self.db, 'source', 'projectut', '*', '*', 'evidence', legacy)
        before = self.db.total_changes
        self.assertEqual(sid, j.add_source(self.db, legacy))
        self.assertEqual(before, self.db.total_changes)
        with self.assertRaises(ValueError): j.add_source(self.db, dict(legacy, text='different text'))
        with self.assertRaises(ValueError): j.add_source(self.db, self.data())  # repair must be explicit
        self.assertNotIn('conversation_id', j.get(self.db, sid)['payload'])

    def test_old_packet_reuses_repaired_structured_source_without_duplicate_or_metadata_loss(self):
        repaired = self.data(turn_id=OTHER)
        sid = j.add_source(self.db, repaired)
        old = {k:v for k,v in repaired.items() if k not in ('conversation_id', 'message_id', 'turn_id')}
        before = self.db.total_changes
        self.assertEqual(sid, j.add_source(self.db, old))
        result = j.save_batch(self.db, dict(operations=[dict(ref='legacy', command='source', data=old)]))
        self.assertEqual(result['results'][0]['id'], sid)
        self.assertEqual(j.get(self.db, sid)['payload'], repaired)
        self.assertEqual(before, self.db.total_changes)

    def test_ambiguous_legacy_duplicates_cannot_be_silently_selected(self):
        j.add_source(self.db, self.data())
        duplicate = self.data(turn_id=OTHER)
        j.put(self.db, 'source', 'projectut', '*', '*', 'evidence', duplicate)
        old = {k:v for k,v in self.data().items() if k not in ('conversation_id', 'message_id')}
        with self.assertRaises(ValueError): j.add_source(self.db, old)

    def test_assistant_context_does_not_become_feedback_and_generic_legacy_contract_is_unchanged(self):
        sid = j.add_source(self.db, self.data(role='assistant'))
        with self.assertRaises(ValueError): learning.feedback_candidates(self.db, 'projectut', CONVERSATION, sid)
        generic = dict(project='projectut', role='user', text='Generic historical source', observed_at='unknown', origin='synthetic-test')
        self.assertEqual(j.add_source(self.db,generic),j.add_source(self.db,generic))

    def test_failed_batch_rolls_back_source_and_cli_readback_preserves_identity(self):
        before = self.db.execute('SELECT count(*) FROM records').fetchone()[0]
        bad = self.data(message_id='')
        with self.assertRaises(ValueError): j.save_batch(self.db, dict(operations=[
            dict(ref='first', command='source', data=self.data()), dict(ref='bad', command='source', data=bad)]))
        self.assertEqual(before,self.db.execute('SELECT count(*) FROM records').fetchone()[0])
        self.db.commit()
        result = subprocess.run([sys.executable,'-B','-X','utf8',j.__file__,'--db',str(self.path),'source','--input','-'],
            input=json.dumps(self.data()),capture_output=True,encoding='utf-8')
        self.assertEqual(result.returncode,0,result.stderr)
        sid=json.loads(result.stdout)['id']
        self.assertEqual(j.get(self.db,sid)['payload']['conversation_id'],CONVERSATION)


if __name__=='__main__':unittest.main()
