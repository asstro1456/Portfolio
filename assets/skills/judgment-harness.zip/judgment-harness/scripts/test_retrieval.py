import copy
import json
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

import judgments as j
from retrieval import retrieve, source_review


class RetrievalTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.path = Path(self.temp.name) / 'retrieval.sqlite3'
        self.db = j.connect(self.path, create=True)

    def tearDown(self):
        self.db.close()
        self.temp.cleanup()

    def candidate(self, text='마스크 내벽 전체를 흰색으로 채워줘', date='2026-10-18T10:00:00Z',
                  project='projectut', target='glass-mask', types=None, **changes):
        source = dict(project=project, origin='synthetic-retrieval-test', role='user', observed_at=date,
                      text=text, conversation_id=changes.pop('conversation_id', 'conv-1'),
                      message_id=changes.pop('message_id', 'message-'+str(self.db.total_changes)))
        sid = j.add_source(self.db, source)
        types = types or ['request']
        p = dict(classification_version=2, project=project, domain='vfx', target=target,
                 source_id=sid, quote=text, types=types, type_quotes={t:text for t in types},
                 interpretation=text, rationale='합성 테스트', decision_state='explicit',
                 scope_level='global' if project=='global' else 'object', scope_basis='이 대상만',
                 reuse='reusable', context_state='standalone', context_refs=[], missing_context=[],
                 reason_kind='unknown', attributes=dict(conditions=[],priority=None,action_state=None,acceptance_scope=None))
        p.update(changes)
        return j.add_candidate(self.db, p), p

    def rule(self, cid, p, **changes):
        data={k:p[k] for k in ('project','domain','target','source_id','quote','attributes')}
        data.update(status='confirmed',decision=p['interpretation'],reason_kind='unknown',
                    candidate_id=cid,review_note='원문 범위 검토')
        data.update(changes)
        return j.add_judgment(self.db,data)

    def review(self, rid, cid, relation='separate', **changes):
        from conflicts import head
        rule, change = j.get(self.db, rid), j.get(self.db, cid)
        refs = []
        for row in (rule, change):
            p = row['payload']
            refs.append(dict(source_id=p['source_id'], quote=p['quote']))
            refs.extend(p.get('context_refs', []))
        linked = rule['payload'].get('candidate_id')
        if linked:
            refs.extend(head(self.db, linked)['payload'].get('context_refs', []))
        data = dict(project=change['project'], domain=rule['domain'], target=rule['target'],
                    rule_id=rid, change_id=cid, rule_candidate_id=head(self.db, linked)['id'] if linked else None,
                    relation=relation, analysis='양쪽 원문과 조건·적용 범위를 대조한 테스트 검토', evidence=refs)
        data.update(changes)
        result = j.save_batch(self.db, dict(operations=[dict(ref='review', command='conflict_review', data=data)]))
        return result['results'][0]['id']

    def test_separate_filename_change_does_not_block_format_rule_after_source_review(self):
        cid,p=self.candidate('드라이브에서 재생되면 파일 형식은 상관없음',date='unknown',target='review-delivery')
        rid=self.rule(cid,p)
        change,_=self.candidate('_최종 같은 파일명은 쓰지 마',date='unknown',target='review-delivery',types=['rejection'])
        before=next(x for x in retrieve(self.db,'projectut',target='review-delivery')['results'] if x['id']==rid)
        self.assertFalse(before['rule_eligible'])
        review=self.review(rid,change)
        item=next(x for x in retrieve(self.db,'projectut',target='review-delivery')['results'] if x['id']==rid)
        self.assertTrue(item['rule_eligible'])
        self.assertEqual(item['review_alerts'],[])
        self.assertEqual(item['related_changes'][0]['review_id'],review)
        self.assertEqual(item['related_changes'][0]['source_review']['sources'][0]['quote'],'_최종 같은 파일명은 쓰지 마')
        self.assertEqual(item['observed_at'],'unknown')

    def test_consistent_change_is_not_a_replacement(self):
        cid,p=self.candidate(date='unknown');rid=self.rule(cid,p)
        change,_=self.candidate('그 색상 변경은 필요 없어',date='unknown',types=['rejection'])
        self.review(rid,change,'consistent')
        item=next(x for x in retrieve(self.db,'projectut',target='glass-mask')['results'] if x['id']==rid)
        self.assertTrue(item['rule_eligible'])
        self.assertEqual(item['related_changes'][0]['relation'],'consistent')

    def test_common_change_blocks_object_across_conversations_until_reviewed(self):
        for project in ('projectut', 'global'):
            with self.subTest(project=project):
                self.db.execute('SAVEPOINT common_change')
                cid,p=self.candidate(conversation_id='old-task');rid=self.rule(cid,p)
                change,_=self.candidate('모든 VFX의 흰색 마스크 기준은 취소한다',
                    date='2026-10-20T00:00:00Z', project=project, target='mask-policy',
                    scope_level='global' if project=='global' else 'project',
                    types=['rejection'], conversation_id='new-task')
                item=next(x for x in retrieve(self.db,'projectut',domain='vfx',
                    target='glass-mask',conversation='old-task')['results'] if x['id']==rid)
                self.assertFalse(item['rule_eligible'])
                self.assertEqual([a['id'] for a in item['review_alerts']],[change])
                self.review(rid,change,project='projectut')
                item=next(x for x in retrieve(self.db,'projectut',domain='vfx',
                    target='glass-mask')['results'] if x['id']==rid)
                self.assertTrue(item['rule_eligible'])
                self.assertEqual(item['related_changes'][0]['id'],change)
                self.db.execute('ROLLBACK TO common_change');self.db.execute('RELEASE common_change')

    def test_common_change_keeps_project_domain_and_object_boundaries(self):
        cid,p=self.candidate();rid=self.rule(cid,p)
        self.candidate('다른 프로젝트 공통 정정', project='crack', target='mask-policy',
            scope_level='project',types=['rejection'],date='2026-10-20T00:00:00Z')
        self.candidate('다른 분야 공통 정정', domain='writing', target='mask-policy',
            scope_level='project',types=['rejection'],date='2026-10-20T00:00:00Z')
        self.candidate('다른 대상만 정정',target='other-mask',types=['rejection'],date='2026-10-20T00:00:00Z')
        item=next(x for x in retrieve(self.db,'projectut',domain='vfx',target='glass-mask')['results'] if x['id']==rid)
        self.assertTrue(item['rule_eligible'])
        self.assertEqual(item['review_alerts'],[])

    def test_project_common_change_blocks_global_rule_only_in_that_project(self):
        cid,p=self.candidate(project='global');rid=self.rule(cid,p)
        change,_=self.candidate('이 프로젝트의 모든 마스크 기준은 취소한다',target='mask-policy',
            scope_level='project',types=['rejection'],date='2026-10-20T00:00:00Z',conversation_id='new-task')
        item=next(x for x in retrieve(self.db,'projectut',domain='vfx',target='glass-mask')['results'] if x['id']==rid)
        self.assertFalse(item['rule_eligible'])
        self.assertEqual([a['id'] for a in item['review_alerts']],[change])
        other=next(x for x in retrieve(self.db,'crack',domain='vfx',target='glass-mask')['results'] if x['id']==rid)
        self.assertTrue(other['rule_eligible'])

    def test_eligibility_id_selection_preserves_normal_fallback_trigger(self):
        cid,p=self.candidate('마스크 선명도 유지');rid=self.rule(cid,p)
        other,p=self.candidate('다른 마스크 선명도 유지',target='other-mask');other_rule=self.rule(other,p)
        found=retrieve(self.db,'projectut',query='선명도',target='glass-mask',fallback_target=True,
            _eligibility_ids={other_rule})
        self.assertEqual(found['results'],[])
        self.assertNotIn('fallback',found)
        related=retrieve(self.db,'projectut',query='선명도',target='missing-mask',fallback_target=True,
            _eligibility_ids={rid,other_rule})
        self.assertIn('fallback',related)
        self.assertEqual({x['id'] for x in related['results']},{rid,other_rule})
        self.assertTrue(all(not x['rule_eligible'] for x in related['results']))

    def test_explicit_replacement_does_not_block_on_its_unchanged_predecessor(self):
        old,p=self.candidate('이전 마스크는 흰색',date='unknown',types=['rejection'])
        prior=self.rule(old,p)
        cid,p=self.candidate('마스크를 검은색으로 정정',date='unknown')
        rid=self.rule(cid,p,supersedes=prior,change_reason='사용자의 명시적 색상 정정')
        item=next(x for x in retrieve(self.db,'projectut',target='glass-mask')['results'] if x['id']==rid)
        self.assertTrue(item['rule_eligible'])
        self.assertEqual(item['review_alerts'],[])
        self.assertEqual([(h['rule_id'],h['candidate_id']) for h in item['supersession_history']],[(prior,old)])
        self.assertIn('이전 마스크는 흰색',[s['quote'] for s in item['source_review']['sources']])
        self.assertEqual(j.get(self.db,old)['payload']['interpretation'],'이전 마스크는 흰색')
        unrelated,_=self.candidate('이전 마스크는 흰색',date='unknown',types=['rejection'],message_id='independent')
        item=next(x for x in retrieve(self.db,'projectut',target='glass-mask')['results'] if x['id']==rid)
        self.assertFalse(item['rule_eligible'])
        self.assertEqual([a['id'] for a in item['review_alerts']],[unrelated])

    def test_predecessor_exemption_needs_explicit_chain_and_current_classification(self):
        old,p=self.candidate('마스크 흰색 기준',date='unknown',types=['rejection'])
        prior=self.rule(old,p)
        cid,cp=self.candidate('마스크 검은색 기준',date='unknown')
        independent=self.rule(cid,cp)
        item=next(x for x in retrieve(self.db,'projectut',target='glass-mask')['results'] if x['id']==independent)
        self.assertFalse(item['rule_eligible'])
        rid=self.rule(cid,cp,supersedes=prior,change_reason='명시적 변경')
        item=next(x for x in retrieve(self.db,'projectut',target='glass-mask')['results'] if x['id']==rid)
        self.assertTrue(item['rule_eligible'])
        p=copy.deepcopy(p);p.update(reclassifies=old,interpretation='흰색 조건을 재검토')
        revised=j.add_candidate(self.db,p)
        checked=source_review(self.db,item,1600)
        self.assertFalse(checked['complete'])
        self.assertIn('supersession_history_changed',[f['reason'] for f in checked['followup']])
        current=next(x for x in retrieve(self.db,'projectut',target='glass-mask')['results'] if x['id']==rid)
        self.assertFalse(current['rule_eligible'])
        self.assertIn(revised,[a['id'] for a in current['review_alerts']])

    def test_explicit_blocking_review_still_blocks_predecessor_pair(self):
        old,p=self.candidate('이전 마스크 방식은 안 됨',date='unknown',types=['rejection'])
        prior=self.rule(old,p)
        cid,p=self.candidate('마스크 새 기준',date='unknown')
        rid=self.rule(cid,p,supersedes=prior,change_reason='기준 변경')
        self.review(rid,old,'unresolved')
        item=next(x for x in retrieve(self.db,'projectut',target='glass-mask')['results'] if x['id']==rid)
        self.assertFalse(item['rule_eligible'])
        self.assertEqual(item['review_alerts'][0]['id'],old)
        self.assertEqual(item['review_alerts'][0]['relation'],'unresolved')

    def test_predecessor_condition_outside_primary_quote_is_delivered(self):
        text='검은색 마스크는 거부한다. 프리뷰가 일시정지된 경우에만 적용한다.'
        old,p=self.candidate(text,date='unknown',types=['rejection'],quote='검은색 마스크는 거부한다.',
            type_quotes=dict(rejection='검은색 마스크는 거부한다.'))
        # Reclassify with the real condition evidence rather than changing the source.
        p=copy.deepcopy(p)
        p.update(reclassifies=old)
        p['attributes']['conditions']=[dict(when='프리뷰 일시정지',then='검은색 마스크 거부',
            source_id=p['source_id'],quote='프리뷰가 일시정지된 경우에만 적용한다.')]
        old=j.add_candidate(self.db,p);prior=self.rule(old,p)
        cid,cp=self.candidate('흰색 마스크를 사용한다.',date='unknown')
        rid=self.rule(cid,cp,supersedes=prior,change_reason='색상 변경')
        item=next(x for x in retrieve(self.db,'projectut',target='glass-mask')['results'] if x['id']==rid)
        self.assertTrue(item['rule_eligible'])
        self.assertEqual(item['supersession_history'][0]['attributes']['conditions'],p['attributes']['conditions'])
        self.assertIn('프리뷰가 일시정지된 경우에만 적용한다.',[s['quote'] for s in item['source_review']['sources']])

    def test_current_attribute_quotes_outside_primary_quote_are_delivered(self):
        primary='흰색 마스크를 사용한다.'
        condition='프리뷰가 일시정지된 경우에만 적용한다.'
        priority='가독성을 색상보다 먼저 확인한다.'
        cid,p=self.candidate(primary+' '+condition+' '+priority,quote=primary,type_quotes=dict(request=primary))
        p=copy.deepcopy(p);p['reclassifies']=cid
        p['attributes']['conditions']=[dict(when='프리뷰 일시정지',then='흰색 마스크 사용',source_id=p['source_id'],quote=condition)]
        p['attributes']['priority']=dict(description='가독성 우선',source_id=p['source_id'],quote=priority)
        cid=j.add_candidate(self.db,p);rid=self.rule(cid,p)
        item=next(x for x in retrieve(self.db,'projectut',target='glass-mask')['results'] if x['id']==rid)
        self.assertTrue(item['source_review']['complete'])
        self.assertEqual([s['quote'] for s in item['source_review']['sources']],[primary,condition,priority])

    def test_current_action_quote_is_delivered(self):
        primary='이 작업은 보류한다.';action='다음 주에 재개 여부를 정한다.'
        cid,p=self.candidate(primary+' '+action,quote=primary,type_quotes=dict(request=primary),reuse='task_only')
        p=copy.deepcopy(p);p['reclassifies']=cid
        p['attributes']['action_state']=dict(value='pause',target='glass-mask',source_id=p['source_id'],quote=action)
        cid=j.add_candidate(self.db,p)
        item=next(x for x in retrieve(self.db,'projectut',target='glass-mask')['results'] if x['id']==cid)
        self.assertIn(action,[s['quote'] for s in item['source_review']['sources']])

    def test_attribute_source_limits_require_followup_and_focused_readback(self):
        primary='흰색 마스크를 사용한다.'
        quotes=['적용 조건 '+str(n)+'에서만 사용한다.' for n in range(4)]
        priority='가독성을 먼저 확인한다.'
        cid,p=self.candidate(' '.join([primary,*quotes,priority]),quote=primary,type_quotes=dict(request=primary))
        p=copy.deepcopy(p);p['reclassifies']=cid
        p['attributes']['conditions']=[dict(when='조건 '+str(n),then='흰색 마스크',source_id=p['source_id'],quote=q) for n,q in enumerate(quotes)]
        p['attributes']['priority']=dict(description='가독성 우선',source_id=p['source_id'],quote=priority)
        cid=j.add_candidate(self.db,p);rid=self.rule(cid,p)
        item=next(x for x in retrieve(self.db,'projectut',target='glass-mask')['results'] if x['id']==rid)
        self.assertFalse(item['rule_eligible'])
        self.assertFalse(item['source_review']['complete'])
        self.assertEqual(len(item['source_review']['sources']),5)
        self.assertIn(dict(id=p['source_id'],kind='source',reason='context_limit'),item['source_review']['followup'])
        focused=retrieve(self.db,'projectut',target='glass-mask',limit=1)['results'][0]
        self.assertEqual(focused['id'],rid)
        self.assertTrue(focused['rule_eligible'])
        self.assertEqual(len(focused['source_review']['sources']),6)

    def test_same_attribute_quote_from_different_source_is_read_back_separately(self):
        quote='흰색 마스크를 사용한다.'
        other=j.add_source(self.db,dict(project='projectut',role='user',origin='synthetic-attribute-context',
            observed_at='unknown',text='추가 맥락. '+quote))
        cid,p=self.candidate(quote,context_state='resolved',
            context_refs=[dict(source_id=other,quote='추가 맥락.',relation='previous')])
        p=copy.deepcopy(p);p['reclassifies']=cid
        p['attributes']['conditions']=[dict(when='추가 맥락',then='흰색 마스크',source_id=other,quote=quote)]
        cid=j.add_candidate(self.db,p);rid=self.rule(cid,p)
        item=next(x for x in retrieve(self.db,'projectut',target='glass-mask')['results'] if x['id']==rid)
        sources=item['source_review']['sources']
        self.assertTrue(item['rule_eligible'])
        self.assertEqual([(s['source_id'],s['quote']) for s in sources],
                         [(p['source_id'],quote),(other,'추가 맥락.'),(other,quote)])

    def test_truncated_primary_quote_does_not_hide_short_attribute_quote(self):
        condition='일시정지 상태에서만 적용한다.'
        text='긴 대표 인용문 '+('설명 '*40)+condition
        cid,p=self.candidate(text)
        p=copy.deepcopy(p);p['reclassifies']=cid
        p['attributes']['conditions']=[dict(when='일시정지',then='마스크 적용',source_id=p['source_id'],quote=condition)]
        cid=j.add_candidate(self.db,p);rid=self.rule(cid,p)
        item=next(x for x in retrieve(self.db,'projectut',target='glass-mask',chars=80)['results'] if x['id']==rid)
        self.assertFalse(item['rule_eligible'])
        self.assertFalse(item['source_review']['complete'])
        self.assertTrue(item['source_review']['sources'][0]['truncated'])
        self.assertIn(condition,[s['quote'] for s in item['source_review']['sources']])

    def test_current_attribute_quote_already_delivered_is_not_duplicated(self):
        quotes=['적용 조건 '+str(n)+'에서만 사용한다.' for n in range(4)]
        priority='가독성을 먼저 확인한다.'
        text=' '.join([*quotes,priority])
        cid,p=self.candidate(text)
        p=copy.deepcopy(p);p['reclassifies']=cid
        p['attributes']['conditions']=[dict(when='조건 '+str(n),then='흰색 마스크',source_id=p['source_id'],quote=q) for n,q in enumerate(quotes)]
        p['attributes']['priority']=dict(description='가독성 우선',source_id=p['source_id'],quote=priority)
        cid=j.add_candidate(self.db,p);rid=self.rule(cid,p)
        item=next(x for x in retrieve(self.db,'projectut',target='glass-mask')['results'] if x['id']==rid)
        self.assertTrue(item['rule_eligible'])
        self.assertEqual(len(item['source_review']['sources']),1)
        cid,cp=self.candidate('흰색 마스크를 새 기준으로 사용한다.')
        replacement=self.rule(cid,cp,supersedes=rid,change_reason='새 기준')
        item=next(x for x in retrieve(self.db,'projectut',target='glass-mask')['results'] if x['id']==replacement)
        self.assertTrue(item['rule_eligible'])
        self.assertEqual(len(item['source_review']['sources']),2)

    def test_reviewed_blocker_is_not_skipped_for_distinct_quotes_in_one_source(self):
        old_quote,new_quote='검은색 마스크는 거부한다.','흰색 마스크를 사용한다.'
        old,p=self.candidate(old_quote+' '+new_quote,date='unknown',types=['rejection'],
            quote=old_quote,type_quotes=dict(rejection=old_quote))
        prior=self.rule(old,p)
        cp=copy.deepcopy(p);cp.update(quote=new_quote,interpretation=new_quote,types=['request'],type_quotes=dict(request=new_quote))
        cid=j.add_candidate(self.db,cp)
        rid=self.rule(cid,cp,supersedes=prior,change_reason='동일 메시지의 다른 판단으로 정정')
        self.review(rid,old,'unresolved')
        item=next(x for x in retrieve(self.db,'projectut',target='glass-mask')['results'] if x['id']==rid)
        self.assertFalse(item['rule_eligible'])
        self.assertEqual(item['review_alerts'][0]['id'],old)
        self.assertEqual(item['review_alerts'][0]['relation'],'unresolved')

    def test_multi_hop_predecessor_evidence_is_delivered_and_incomplete_context_blocks(self):
        _,ctx=self.candidate('관련 맥락 '+('긴 설명 '*100),date='unknown',target='context')
        old,p=self.candidate('마스크 A',date='unknown',types=['rejection'],context_state='resolved',
            context_refs=[dict(source_id=ctx['source_id'],quote=ctx['quote'],relation='previous')])
        r0=self.rule(old,p)
        middle,p=self.candidate('마스크 B',date='unknown',types=['rejection'])
        r1=self.rule(middle,p,supersedes=r0,change_reason='A에서 B')
        cid,p=self.candidate('마스크 C',date='unknown')
        rid=self.rule(cid,p,supersedes=r1,change_reason='B에서 C')
        item=next(x for x in retrieve(self.db,'projectut',target='glass-mask',chars=2000)['results'] if x['id']==rid)
        self.assertTrue(item['rule_eligible'])
        self.assertEqual([h['candidate_id'] for h in item['supersession_history']],[middle,old])
        clipped=next(x for x in retrieve(self.db,'projectut',target='glass-mask',chars=80)['results'] if x['id']==rid)
        self.assertFalse(clipped['rule_eligible'])
        self.assertFalse(clipped['source_review']['complete'])

    def test_replacement_exception_and_unresolved_still_block(self):
        cid,p=self.candidate();rid=self.rule(cid,p)
        change,_=self.candidate('이번 마스크는 흰색으로 하지 마',date='unknown',types=['rejection'])
        for relation in ('replacement','exception','unresolved'):
            with self.subTest(relation=relation):
                args=dict(condition='이번 마스크에 한정') if relation=='exception' else {}
                if relation!='replacement':
                    args['supersedes']=previous
                previous=self.review(rid,change,relation,**args)
                item=next(x for x in retrieve(self.db,'projectut',target='glass-mask')['results'] if x['id']==rid)
                self.assertFalse(item['rule_eligible'])
                self.assertEqual(item['review_alerts'][0]['relation'],relation)
                self.assertEqual(item['review_alerts'][0]['time_relation'],'unknown')

    def test_review_does_not_hide_a_new_short_rejection(self):
        cid,p=self.candidate();rid=self.rule(cid,p)
        first,_=self.candidate('파일명에는 최종을 쓰지 마',date='2026-10-19',types=['rejection'])
        self.review(rid,first)
        later,_=self.candidate('그 방식은 쓰지 마',date='2026-10-20',types=['rejection'])
        item=next(x for x in retrieve(self.db,'projectut',target='glass-mask')['results'] if x['id']==rid)
        self.assertFalse(item['rule_eligible'])
        self.assertEqual([a['id'] for a in item['review_alerts']],[later])

    def test_review_is_invalidated_by_new_candidate_version(self):
        cid,p=self.candidate();rid=self.rule(cid,p)
        change,cp=self.candidate('그 방식은 쓰지 마',date='unknown',types=['rejection'])
        self.review(rid,change)
        cp=copy.deepcopy(cp);cp.update(reclassifies=change,interpretation='기존 기준 철회')
        revised=j.add_candidate(self.db,cp)
        item=next(x for x in retrieve(self.db,'projectut',target='glass-mask')['results'] if x['id']==rid)
        self.assertFalse(item['rule_eligible'])
        self.assertEqual(item['related_changes'],[])
        self.assertEqual(item['review_alerts'][0]['id'],revised)

    def test_review_is_invalidated_by_new_rule_or_linked_classification(self):
        cid,p=self.candidate();rid=self.rule(cid,p)
        change,_=self.candidate('그 방식은 쓰지 마',date='unknown',types=['rejection'])
        self.review(rid,change)
        cp=copy.deepcopy(p);cp.update(reclassifies=cid,interpretation='마스크를 검은색으로')
        new_cid=j.add_candidate(self.db,cp)
        item=next(x for x in retrieve(self.db,'projectut',target='glass-mask')['results'] if x['id']==rid)
        self.assertFalse(item['rule_eligible'])
        self.assertEqual(item['related_changes'],[])
        new_rid=self.rule(new_cid,cp,supersedes=rid,change_reason='새 색상')
        item=next(x for x in retrieve(self.db,'projectut',target='glass-mask')['results'] if x['id']==new_rid)
        self.assertFalse(item['rule_eligible'])
        self.assertEqual(item['related_changes'],[])

    def test_exception_does_not_invent_later_time_for_older_source(self):
        cid,p=self.candidate(date='2026-10-20');rid=self.rule(cid,p)
        change,_=self.candidate('이번 대상만은 하지 마',date='2026-10-19',types=['rejection'])
        self.review(rid,change,'exception',condition='이번 대상')
        item=next(x for x in retrieve(self.db,'projectut',target='glass-mask')['results'] if x['id']==rid)
        self.assertFalse(item['rule_eligible'])
        self.assertEqual(item['review_alerts'][0]['reason'],'reviewed_relation')
        self.assertEqual(item['review_alerts'][0]['time_relation'],'earlier_or_equal')

    def test_conflict_review_requires_both_sources_and_context(self):
        cid,p=self.candidate();rid=self.rule(cid,p)
        change,_=self.candidate('그 방식은 쓰지 마',date='unknown',types=['rejection'],context_state='resolved',
            context_refs=[dict(source_id=p['source_id'],quote=p['quote'],relation='referent')])
        with self.assertRaisesRegex(ValueError,'빠짐없이'):
            self.review(rid,change,evidence=[dict(source_id=p['source_id'],quote=p['quote'])])
        with self.assertRaises(ValueError):
            self.review(rid,change,evidence=[dict(source_id=p['source_id'],quote='원문에 없는 인용')])
        with self.assertRaises(ValueError):
            self.review(rid,change,project='crack')
        with self.assertRaises(ValueError):
            self.review(rid,change,'exception')

    def test_conflicting_review_requires_explicit_supersession(self):
        cid,p=self.candidate();rid=self.rule(cid,p)
        change,_=self.candidate('그 방식은 쓰지 마',date='unknown',types=['rejection'])
        first=self.review(rid,change)
        self.assertEqual(first,self.review(rid,change))
        with self.assertRaisesRegex(ValueError,'supersedes'):
            self.review(rid,change,'replacement')
        self.review(rid,change,'replacement',supersedes=first)

    def test_project_review_cannot_suppress_change_in_other_project(self):
        cid,p=self.candidate(project='global');rid=self.rule(cid,p)
        one,_=self.candidate('그 방식은 쓰지 마',date='unknown',types=['rejection'],context_state='resolved',
            context_refs=[dict(source_id=p['source_id'],quote=p['quote'],relation='referent')])
        two,_=self.candidate('그 방식은 쓰지 마',date='unknown',types=['rejection'],project='crack',context_state='resolved',
            context_refs=[dict(source_id=p['source_id'],quote=p['quote'],relation='referent')])
        self.review(rid,one)
        self.assertTrue(next(x for x in retrieve(self.db,'projectut',target='glass-mask')['results'] if x['id']==rid)['rule_eligible'])
        self.assertFalse(next(x for x in retrieve(self.db,'crack',target='glass-mask')['results'] if x['id']==rid)['rule_eligible'])

    def test_readback_rechecks_superseded_review(self):
        cid,p=self.candidate();rid=self.rule(cid,p)
        change,_=self.candidate('그 방식은 쓰지 마',date='unknown',types=['rejection'])
        review=self.review(rid,change)
        item=next(x for x in retrieve(self.db,'projectut',target='glass-mask')['results'] if x['id']==rid)
        self.review(rid,change,'replacement',supersedes=review)
        checked=source_review(self.db,item,480)
        self.assertFalse(checked['complete'])
        self.assertEqual(checked['followup'][0]['reason'],'stale_conflict_review')

    def test_related_source_truncation_and_limit_still_block_application(self):
        cid,p=self.candidate();rid=self.rule(cid,p)
        change,_=self.candidate('다른 파일명은 쓰지 마 '*20,date='unknown',types=['rejection'])
        self.review(rid,change)
        item=next(x for x in retrieve(self.db,'projectut',target='glass-mask',chars=80)['results'] if x['id']==rid)
        self.assertFalse(item['rule_eligible'])
        self.assertFalse(item['related_changes'][0]['source_review']['complete'])
        for n in range(4):
            change,_=self.candidate('파일명 '+str(n)+'은 쓰지 마',date='unknown',types=['rejection'])
            self.review(rid,change)
        item=next(x for x in retrieve(self.db,'projectut',target='glass-mask')['results'] if x['id']==rid)
        self.assertFalse(item['rule_eligible'])
        self.assertEqual(len(item['related_changes']),4)
        self.assertTrue(any(x['reason']=='related_change_limit' for x in item['source_review']['followup']))

    def test_focused_source_review_resolves_delivery_limit_and_prediction_checks(self):
        from evaluation import check_retrieval
        cid,p=self.candidate();rid=self.rule(cid,p)
        for n in range(5):
            change,_=self.candidate('별개 파일명 '+str(n)+'은 쓰지 마',date='unknown',types=['rejection'])
            self.review(rid,change)
        default=next(x for x in retrieve(self.db,'projectut',target='glass-mask')['results'] if x['id']==rid)
        self.assertFalse(default['rule_eligible'])
        count=self.db.execute('SELECT count(*) FROM records').fetchone()[0]
        focused=retrieve(self.db,'projectut',target='glass-mask',limit=1)
        item=focused['results'][0]
        self.assertEqual(item['id'],rid)
        self.assertTrue(item['rule_eligible'])
        self.assertEqual(len(item['related_changes']),5)
        self.assertTrue(all(x['source_review']['complete'] for x in item['related_changes']))
        self.assertEqual(self.db.execute('SELECT count(*) FROM records').fetchone()[0],count)
        check=check_retrieval(self.db,dict(evaluation_kind='retrieval_regression',expected_by='agent_source_review',
            record_fingerprints={rid:j.get(self.db,rid)['fingerprint']},cases=[dict(name='focused',
            query=dict(project='projectut',target='glass-mask',limit=1),must_be_eligible=[rid])]))
        self.assertTrue(check['passed'])
        default_check=check_retrieval(self.db,dict(evaluation_kind='retrieval_regression',expected_by='agent_source_review',
            record_fingerprints={rid:j.get(self.db,rid)['fingerprint']},cases=[dict(name='default-delivery',
            query=dict(project='projectut',target='glass-mask'),must_not_be_eligible=[rid])]))
        self.assertTrue(default_check['passed'])
        j.predict(self.db,dict(project='projectut',domain='vfx',target='glass-mask',task='focused-test',
            prediction='원문을 대조한 합성 검증',judgment_ids=[rid],evaluation_version=1,conversation_id='fixture',
            turn_id='focused',comparison_id='focused-comparison',variant='harness'))
        self.db.commit()
        result=subprocess.run([sys.executable,'-B','-X','utf8',str(Path(j.__file__)),'--db',str(self.path),
            'retrieve','--project','projectut','--target','glass-mask','--limit','1'],
            capture_output=True,text=True,encoding='utf-8')
        self.assertEqual(result.returncode,0,result.stderr)
        self.assertTrue(json.loads(result.stdout)['results'][0]['rule_eligible'])

    def test_focused_source_review_recurses_and_does_not_hide_new_rejection(self):
        refs=[]
        for n in range(6):
            _,p=self.candidate('별개 수정의 맥락 '+str(n),target='context')
            refs.append(dict(source_id=p['source_id'],quote=p['quote'],relation='previous'))
        cid,p=self.candidate();rid=self.rule(cid,p)
        change,_=self.candidate('다른 파일명은 거부',date='unknown',types=['rejection'],
            context_state='resolved',context_refs=refs)
        self.review(rid,change)
        item=retrieve(self.db,'projectut',target='glass-mask',limit=1)['results'][0]
        self.assertTrue(item['rule_eligible'])
        self.assertEqual(len(item['related_changes'][0]['source_review']['sources']),7)
        later,_=self.candidate('그 방식은 거부',date='unknown',types=['rejection'])
        checked=retrieve(self.db,'projectut',target='glass-mask',limit=20,_selected_ids=[rid])['results'][0]
        self.assertFalse(checked['rule_eligible'])
        self.assertEqual([a['id'] for a in checked['review_alerts']],[later])
        with self.assertRaises(ValueError):
            j.predict(self.db,dict(project='projectut',domain='vfx',target='glass-mask',task='negative-focused',
                prediction='통과하면 안 됨',judgment_ids=[rid],evaluation_version=1,conversation_id='fixture',turn_id='negative'))

    def test_focused_source_review_stays_bounded_and_default_remains_small(self):
        cid,p=self.candidate();rid=self.rule(cid,p)
        for n in range(21):
            change,_=self.candidate('별개 파일명 '+str(n)+'은 쓰지 마',date='unknown',types=['rejection'])
            self.review(rid,change)
        item=retrieve(self.db,'projectut',target='glass-mask',limit=1)['results'][0]
        self.assertFalse(item['rule_eligible'])
        self.assertEqual(len(item['related_changes']),20)
        self.assertTrue(any(x['reason']=='related_change_limit' for x in item['source_review']['followup']))
        self.assertEqual(item['source_review']['delivery_limits'],dict(related_changes=20,sources=20))

    def test_focused_source_review_does_not_bypass_source_or_quote_cap(self):
        refs=[]
        for n in range(20):
            _,p=self.candidate('기준 맥락 '+str(n),target='context')
            refs.append(dict(source_id=p['source_id'],quote=p['quote'],relation='previous'))
        cid,p=self.candidate(context_state='resolved',context_refs=refs);rid=self.rule(cid,p)
        item=retrieve(self.db,'projectut',target='glass-mask',limit=1)['results'][0]
        self.assertFalse(item['rule_eligible'])
        self.assertEqual(len(item['source_review']['sources']),20)
        self.assertTrue(any(x['reason']=='context_limit' for x in item['source_review']['followup']))
        cid,p=self.candidate('긴 원문 '*100,target='long-quote');long_rule=self.rule(cid,p)
        item=retrieve(self.db,'projectut',target='long-quote',limit=1,chars=80)['results'][0]
        self.assertEqual(item['id'],long_rule)
        self.assertFalse(item['rule_eligible'])
        self.assertTrue(any(x['reason']=='truncated_quote' for x in item['source_review']['followup']))

    def test_explicit_pair_review_finds_change_under_other_taxonomy(self):
        cid,p=self.candidate();rid=self.rule(cid,p)
        change,_=self.candidate('기존 방식은 쓰지 마',target='another-taxonomy',date='unknown',
                                conversation_id='another-task',types=['rejection'])
        self.review(rid,change,'replacement')
        item=next(x for x in retrieve(self.db,'projectut',target='glass-mask')['results'] if x['id']==rid)
        self.assertFalse(item['rule_eligible'])
        self.assertEqual(item['review_alerts'][0]['id'],change)

    def test_invalid_pair_review_rolls_back_whole_packet(self):
        cid,p=self.candidate();rid=self.rule(cid,p)
        change,_=self.candidate('그 방식은 쓰지 마',date='unknown',types=['rejection'])
        review=self.review(rid,change)
        bad=j.get(self.db,review)['payload'];bad=dict(bad,rule_candidate_id='invalid-version')
        count=self.db.execute('SELECT count(*) FROM records').fetchone()[0]
        with self.assertRaises(ValueError):
            j.save_batch(self.db,dict(operations=[
                dict(ref='newsource',command='source',data=dict(project='projectut',origin='synthetic',role='user',
                    observed_at='unknown',text='실패하면 남기지 않을 원문')),
                dict(ref='badreview',command='conflict_review',data=bad)]))
        self.assertEqual(self.db.execute('SELECT count(*) FROM records').fetchone()[0],count)

    def test_pair_review_cli_and_summary_roundtrip(self):
        cid,p=self.candidate();rid=self.rule(cid,p)
        change,_=self.candidate('그 방식은 쓰지 마',date='unknown',types=['rejection'])
        review=self.review(rid,change)
        payload=j.get(self.db,review)['payload'];self.db.commit()
        result=subprocess.run([sys.executable,'-X','utf8',str(Path(j.__file__)),'--db',str(self.path),
            'batch','--input','-'],input=json.dumps(dict(operations=[dict(ref='review',command='conflict_review',data=payload)])),
            text=True,capture_output=True,encoding='utf-8')
        self.assertEqual(result.returncode,0,result.stderr)
        self.assertEqual(json.loads(result.stdout)['results'][0]['id'],review)
        summary=j.select_fields(j.get(self.db,review),summary=True)
        self.assertEqual(summary['payload']['relation'],'separate')
        self.assertEqual(summary['payload']['evidence'],payload['evidence'])

    def test_project_domain_and_target_do_not_leak(self):
        good,p=self.candidate();self.rule(good,p)
        other,p=self.candidate(project='crack');self.rule(other,p)
        result=retrieve(self.db,'projectut',query='마스크',target='glass-mask',domain='vfx')
        self.assertTrue(result['results'])
        self.assertTrue(all(r['project']=='projectut' for r in result['results']))
        self.assertEqual(retrieve(self.db,'projectut',query='마스크',target='other')['results'],[])
        self.assertEqual(retrieve(self.db,'projectut',query='마스크',domain='writing')['results'],[])

    def test_named_global_and_project_rules_remain_scoped(self):
        cid,p=self.candidate(project='global',target='mask-common')
        rid=self.rule(cid,p)
        got=retrieve(self.db,'projectut',query='마스크',target='glass-mask')['results']
        self.assertIn(rid,[x['id'] for x in got])
        self.assertTrue(next(x for x in got if x['id']==rid)['rule_eligible'])
        cid,p=self.candidate(target='mask-category',scope_level='project')
        rid=self.rule(cid,p)
        self.assertIn(rid,[x['id'] for x in retrieve(self.db,'projectut',query='마스크',target='glass-mask')['results']])

    def test_purpose_selects_history_without_hiding_relevant_rules(self):
        cid,p=self.candidate();rid=self.rule(cid,p)
        evidence,p=self.candidate('마스크는 왜 필요한지 알려줘',types=['question'],decision_state='none',reuse='task_only')
        result=retrieve(self.db,'projectut',purpose='thinking',query='마스크',target='glass-mask')
        self.assertIn(rid,[r['id'] for r in result['results']])
        self.assertNotIn(evidence,[r['id'] for r in result['results']])

    def test_event_time_not_insertion_order_and_unknown_remains_unknown(self):
        recent,_=self.candidate('마스크 최근 요청',date='2026-10-19T10:00:00Z',reuse='task_only')
        older,_=self.candidate('마스크 예전 요청',date='2025-01-01',reuse='task_only')
        unknown,_=self.candidate('마스크 날짜 미상 요청',date='unknown',reuse='task_only')
        got=retrieve(self.db,'projectut',query='마스크')['results']
        self.assertEqual([r['id'] for r in got],[recent,older,unknown])
        self.assertFalse(got[-1]['event_time_known'])

    def test_explicit_supersession_hides_retired_confirmation(self):
        cid,p=self.candidate();old=self.rule(cid,p)
        cid,p=self.candidate('마스크 기존 방식을 쓰지 마',date='2026-10-19',types=['rejection'],reuse='task_only')
        new=self.rule(cid,p,status='rejected',supersedes=old,change_reason='새 거절')
        got=retrieve(self.db,'projectut',query='마스크',target='glass-mask')['results']
        self.assertNotIn(old,[r['id'] for r in got])
        item=next(r for r in got if r['id']==new)
        self.assertEqual(item['usage'],'inactive_judgment')
        self.assertFalse(item['rule_eligible'])

    def test_later_rejection_surfaces_even_with_different_purpose(self):
        cid,p=self.candidate();rid=self.rule(cid,p)
        later,_=self.candidate('마스크 방식을 거부한다',date='2026-10-19',types=['rejection'],reuse='task_only')
        got=retrieve(self.db,'projectut',purpose='wants',query='마스크',target='glass-mask')['results']
        self.assertEqual(got[0]['id'],rid)
        self.assertFalse(got[0]['rule_eligible'])
        self.assertTrue(any(x['id']==later and x['review_alerts'] for x in got))

    def test_unknown_change_date_alerts_without_inventing_recency(self):
        cid,p=self.candidate();rid=self.rule(cid,p)
        later,_=self.candidate('마스크 그 방식 거부',date='unknown',types=['rejection'],reuse='task_only')
        got=retrieve(self.db,'projectut',query='마스크',target='glass-mask')['results']
        rule=next(x for x in got if x['id']==rid)
        self.assertEqual(rule['review_alerts'][0]['reason'],'change_time_unknown')
        self.assertFalse(next(x for x in got if x['id']==later)['event_time_known'])

    def test_short_later_rejection_without_query_term_is_still_checked(self):
        cid,p=self.candidate();rid=self.rule(cid,p)
        later,_=self.candidate('그 방식은 쓰지 마',date='2026-10-19',types=['rejection'],reuse='task_only')
        got=retrieve(self.db,'projectut',query='마스크',target='glass-mask')['results']
        self.assertFalse(next(x for x in got if x['id']==rid)['rule_eligible'])
        self.assertTrue(next(x for x in got if x['id']==later)['review_alerts'])

    def test_explicit_reference_checks_change_under_different_target(self):
        cid,p=self.candidate();rid=self.rule(cid,p)
        later,_=self.candidate('그 방식은 쓰지 마',target='conversation:conv-1',date='2026-10-19',
            types=['rejection'],reuse='task_only',context_state='resolved',
            context_refs=[dict(source_id=p['source_id'],quote=p['quote'],relation='referent')])
        got=retrieve(self.db,'projectut',query='마스크',target='glass-mask')['results']
        self.assertFalse(next(x for x in got if x['id']==rid)['rule_eligible'])
        self.assertTrue(next(x for x in got if x['id']==later)['review_alerts'])

    def test_project_exception_to_global_rule_does_not_affect_other_projects(self):
        cid,p=self.candidate(project='global');rid=self.rule(cid,p)
        self.candidate('그 방식은 쓰지 마',date='2026-10-19',types=['rejection'],reuse='task_only',
            context_state='resolved',context_refs=[dict(source_id=p['source_id'],quote=p['quote'],relation='referent')])
        got=retrieve(self.db,'projectut',query='마스크',target='glass-mask')['results']
        self.assertFalse(next(x for x in got if x['id']==rid)['rule_eligible'])
        got=retrieve(self.db,'crack',query='마스크',target='glass-mask')['results']
        self.assertTrue(next(x for x in got if x['id']==rid)['rule_eligible'])

    def test_project_rule_checks_later_change_in_original_task_context(self):
        cid,p=self.candidate(target='mask-category',scope_level='project');rid=self.rule(cid,p)
        later,_=self.candidate('마스크 기준 변경',date='2026-10-19',target='conversation:conv-1',
            types=['rejection'],reuse='task_only')
        got=retrieve(self.db,'projectut',query='마스크',target='mask-category')['results']
        self.assertFalse(next(x for x in got if x['id']==rid)['rule_eligible'])
        self.assertTrue(next(x for x in got if x['id']==later)['review_alerts'])

    def test_other_object_in_same_conversation_does_not_disable_object_rule(self):
        cid,p=self.candidate();rid=self.rule(cid,p)
        self.candidate('마스크 기준 변경',date='2026-10-19',target='other-mask',types=['rejection'],reuse='task_only')
        got=retrieve(self.db,'projectut',query='마스크',target='glass-mask')['results']
        self.assertTrue(next(x for x in got if x['id']==rid)['rule_eligible'])
        self.assertEqual(len(got),2)

    def test_new_task_filter_cannot_reactivate_common_rule_with_known_change(self):
        cid,p=self.candidate(scope_level='project',conversation_id='old-task');rid=self.rule(cid,p)
        later,_=self.candidate('그 방식은 쓰지 마',date='2026-10-19',types=['rejection'],reuse='task_only',
            conversation_id='old-task',context_state='resolved',
            context_refs=[dict(source_id=p['source_id'],quote=p['quote'],relation='referent')])
        got=retrieve(self.db,'projectut',query='마스크',target='glass-mask',conversation='new-task')['results']
        self.assertFalse(next(x for x in got if x['id']==rid)['rule_eligible'])
        self.assertTrue(next(x for x in got if x['id']==later)['review_alerts'])

    def test_missing_context_opt_in_is_never_a_rule(self):
        cid,_=self.candidate('마스크 이걸로',decision_state='unresolved',reuse='uncertain',
                             context_state='missing',missing_context=['이미지 버전 미확인'])
        self.assertEqual(retrieve(self.db,'projectut',query='마스크')['results'],[])
        item=retrieve(self.db,'projectut',query='마스크',include_unresolved=True)['results'][0]
        self.assertEqual(item['id'],cid)
        self.assertFalse(item['rule_eligible'])

    def test_reclassified_rule_candidate_is_flagged(self):
        cid,p=self.candidate();rid=self.rule(cid,p)
        p=copy.deepcopy(p);p.update(reclassifies=cid,scope_level='task',reuse='task_only')
        j.add_candidate(self.db,p)
        rule=next(x for x in retrieve(self.db,'projectut',query='마스크',target='glass-mask')['results'] if x['id']==rid)
        self.assertFalse(rule['rule_eligible'])
        self.assertEqual(rule['review_alerts'][0]['reason'],'linked_classification_changed')

    def grouped(self,scope='object'):
        one,p1=self.candidate(conversation_id='a',scope_level=scope)
        two,p2=self.candidate(conversation_id='b',date='2026-10-19',scope_level=scope)
        group=dict(run_id='synthetic',group_id='D-1',project='projectut',domain='vfx',scope_level=scope,
                   representative_view_only=True,context_and_scope_reviewed=True,
                   members=[dict(source_id=p1['source_id'],candidate_id=one),dict(source_id=p2['source_id'],candidate_id=two)])
        ids=[]
        for cid,p in ((one,p1),(two,p2)):
            p=copy.deepcopy(p);p.update(reclassifies=cid,deduplication=group)
            ids.append((j.add_candidate(self.db,p),p))
        return ids

    def test_project_rule_checks_change_after_reviewed_duplicate_origin(self):
        members=self.grouped(scope='project');cid,p=members[0];rid=self.rule(cid,p)
        later,_=self.candidate('그 방식은 쓰지 마',date='2026-10-20',target='conversation:b',
            types=['rejection'],reuse='task_only',conversation_id='b')
        got=retrieve(self.db,'projectut',query='마스크',target='glass-mask',conversation='new-task')['results']
        self.assertFalse(next(x for x in got if x['id']==rid)['rule_eligible'])
        self.assertTrue(next(x for x in got if x['id']==later)['review_alerts'])

    def test_dedup_retains_sources_and_latest_event_time(self):
        self.grouped()
        got=retrieve(self.db,'projectut',query='마스크')['results']
        self.assertEqual(len(got),1)
        self.assertEqual(len(got[0]['equivalent_sources']),2)
        self.assertEqual(got[0]['latest_observed_at'],'2026-10-19')
        self.assertFalse(got[0]['rule_eligible'])

    def test_stale_group_metadata_cannot_hide_a_changed_classification(self):
        members=self.grouped();cid,p=members[0]
        p=copy.deepcopy(p);p.update(reclassifies=cid,interpretation='마스크 범위 재검토')
        j.add_candidate(self.db,p)
        self.assertEqual(len(retrieve(self.db,'projectut',query='마스크')['results']),2)

    def test_conversation_filter_does_not_expand_to_other_originals(self):
        self.grouped()
        got=retrieve(self.db,'projectut',query='마스크',conversation='a')['results']
        self.assertEqual(len(got),1)
        self.assertEqual(len(got[0]['equivalent_sources']),1)
        self.assertEqual(got[0]['source']['conversation_id'],'a')
        got=retrieve(self.db,'projectut',query='마스크',conversation='a',target='glass-mask')['results']
        self.assertEqual(len(got[0]['equivalent_sources']),1)

    def test_fallback_is_explicit_same_project_domain_and_not_rule_eligible(self):
        cid,p=self.candidate();self.rule(cid,p)
        got=retrieve(self.db,'projectut',query='마스크',domain='vfx',target='unknown',fallback_target=True)
        self.assertIn('fallback',got)
        self.assertTrue(all(r['project']=='projectut' and r['domain']=='vfx' and not r['rule_eligible'] for r in got['results']))

    def test_cli_is_read_only_and_output_is_bounded(self):
        self.candidate('마스크 '+('긴 원문 '*800))
        self.db.commit();before=self.db.execute('SELECT count(*) FROM records').fetchone()[0]
        result=subprocess.run([sys.executable,'-X','utf8',j.__file__,'--db',str(self.path),'retrieve',
             '--project','projectut','--purpose','wants','--query','마스크','--chars','100'],capture_output=True,encoding='utf-8')
        self.assertEqual(result.returncode,0,result.stderr)
        payload=json.loads(result.stdout)
        self.assertLessEqual(len(payload['results'][0]['excerpt']),100)
        self.assertFalse(payload['database_writes'])
        self.assertEqual(self.db.execute('SELECT count(*) FROM records').fetchone()[0],before)

    def test_default_query_preset_and_oversized_cli_request_do_not_need_an_error_retry(self):
        for n in range(4): self.candidate('마스크 '+str(n)+' '+('긴 원문 '*600))
        self.db.commit()
        args=[sys.executable,'-B','-X','utf8',j.__file__,'--db',str(self.path),'retrieve',
              '--project','projectut','--query','마스크']
        default=subprocess.run(args,capture_output=True,encoding='utf-8')
        self.assertEqual(default.returncode,0,default.stderr)
        payload=json.loads(default.stdout)
        self.assertEqual(payload['query_options'],{'limit':3,'chars':1600})
        self.assertEqual(len(payload['results']),3)
        oversized=subprocess.run(args+['--chars','7000'],capture_output=True,encoding='utf-8')
        self.assertEqual(oversized.returncode,0,oversized.stderr)
        payload=json.loads(oversized.stdout)
        self.assertEqual(payload['query_options']['chars'],2000)
        self.assertTrue(payload['query_options']['chars_capped'])
        self.assertEqual(payload['query_options']['requested_chars'],7000)
        self.assertFalse(payload['results'][0]['source_review']['complete'])
        self.assertTrue(payload['results'][0]['source_review']['followup'])
        invalid=subprocess.run(args+['--chars','0'],capture_output=True,encoding='utf-8')
        self.assertNotEqual(invalid.returncode,0)

    def test_retrieve_includes_exact_source_quote_not_only_interpretation(self):
        cid,p=self.candidate(interpretation='이 대상의 색을 흰색으로 유지한다');rid=self.rule(cid,p)
        item=next(x for x in retrieve(self.db,'projectut',target='glass-mask')['results'] if x['id']==rid)
        self.assertTrue(item['source_review']['complete'])
        self.assertEqual(item['source_review']['sources'][0]['quote'],p['quote'])
        self.assertNotEqual(item['excerpt'],p['quote'])
        self.assertTrue(item['rule_eligible'])

    def test_truncated_original_blocks_rule_until_additional_readback(self):
        cid,p=self.candidate(text='마스크 '+('조건을 먼저 확인한다 '*70));rid=self.rule(cid,p)
        item=next(x for x in retrieve(self.db,'projectut',target='glass-mask',chars=80)['results'] if x['id']==rid)
        self.assertFalse(item['source_review']['complete'])
        self.assertTrue(item['source_review']['sources'][0]['truncated'])
        self.assertEqual(item['source_review']['followup'][0]['id'],p['source_id'])
        self.assertFalse(item['rule_eligible'])

    def test_omitted_context_lists_exact_source_to_read_next(self):
        refs=[]
        for n in range(5):
            _,p=self.candidate('마스크 이전 맥락 '+str(n))
            refs.append(dict(source_id=p['source_id'],quote=p['quote'],relation='previous'))
        cid,p=self.candidate('마스크 기준 수정',types=['correction'],context_state='resolved',context_refs=refs)
        rid=self.rule(cid,p)
        item=next(x for x in retrieve(self.db,'projectut',target='glass-mask',limit=20)['results'] if x['id']==rid)
        self.assertFalse(item['source_review']['complete'])
        self.assertIn(dict(id=refs[-1]['source_id'],kind='source',reason='context_limit'),item['source_review']['followup'])

    def test_source_review_delivers_linked_candidate_context(self):
        old,p=self.candidate('기존 마스크 기준')
        cid,p=self.candidate('마스크 기준 수정',types=['correction'],context_state='resolved',
            context_refs=[dict(source_id=p['source_id'],quote=p['quote'],relation='previous')])
        rid=self.rule(cid,p)
        item=next(x for x in retrieve(self.db,'projectut',target='glass-mask')['results'] if x['id']==rid)
        self.assertTrue(item['source_review']['complete'])
        self.assertEqual([x['quote'] for x in item['source_review']['sources']],['마스크 기준 수정','기존 마스크 기준'])

    def test_readback_detects_replacement_after_search(self):
        cid,p=self.candidate();old=self.rule(cid,p)
        item=next(x for x in retrieve(self.db,'projectut',target='glass-mask')['results'] if x['id']==old)
        cid,p=self.candidate('마스크 변경',date='2026-10-20');new=self.rule(cid,p,supersedes=old,change_reason='새 결정')
        checked=source_review(self.db,item,480)
        self.assertFalse(checked['complete'])
        self.assertEqual(checked['superseded_by'],new)


if __name__=='__main__':
    unittest.main()
