import copy
import json
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

import harness_trials as trials
import judgments as j
import retrieval
import retrieval_recovery as recovery
from test_batch import packet


class RecoveryTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.path = Path(self.temp.name) / 'isolated.sqlite3'
        self.root = Path(self.temp.name) / 'outputs'
        self.db = j.connect(self.path, create=True)
        data = packet()
        refs = []
        for n in range(6):
            alias = 'context' + str(n); quote = '추가 맥락 ' + str(n)
            data['operations'].insert(1, dict(ref=alias, command='source', data=dict(project='projectut',
                role='user', text=quote, origin=alias, observed_at='unknown')))
            refs.append(dict(source_id={'$ref':alias}, quote=quote, relation='referent'))
        data['operations'][-2]['data'].update(context_refs=refs, context_state='resolved')
        self.rid = j.save_batch(self.db, data)['results'][-1]['id']
        self.request = dict(project='projectut', purpose='all', query='블러', domain='vfx',
            target='vision-blur', conversation=None, limit=3, chars=1600,
            include_unresolved=False, fallback_target=False, full_source_review=False)
        self.output_patch = patch.object(trials, 'OUTPUT_ROOT', self.root)
        self.output_patch.start()

    def tearDown(self):
        self.output_patch.stop()
        self.db.close()
        self.temp.cleanup()

    def call(self, request=None, **kwargs):
        return recovery.recover(self.db, request or self.request, self.path, root=self.root / 'recovery', **kwargs)

    def state_path(self):
        return next(self.root.rglob('state.json'))

    def activate(self):
        self.assertEqual(self.call()['auto_recovery']['status'], 'observed')
        answer = self.call()
        self.assertEqual(answer['auto_recovery']['status'], 'applied', answer['auto_recovery'])
        return answer

    def test_repeat_detects_compares_saves_applies_then_reuses_without_db_writes(self):
        before = trials.snapshot_version(self.db)
        baseline = retrieval.retrieve(self.db, **self.request)
        self.assertFalse(baseline['results'][0]['rule_eligible'])
        result = self.activate()
        self.assertTrue(result['results'][0]['rule_eligible'])
        self.assertEqual([r['id'] for r in baseline['results']], [r['id'] for r in result['results']])
        self.assertEqual(result['query_options']['limit'], 3)
        report = json.loads(Path(result['auto_recovery']['report']).read_text(encoding='utf-8'))
        self.assertEqual(report['input']['expected_by'], 'mechanical_source_delivery')
        self.assertEqual(report['decision'], 'candidate_supported')
        self.assertFalse(report['candidate_applied'])
        self.assertFalse(report['semantic_accuracy_measured'])
        self.assertEqual(len(report['input']['cases']), 4)
        self.assertEqual(report['input']['cases'][0]['query'], self.request)
        with patch.object(trials, 'run_trial', side_effect=AssertionError('must reuse validated proof')):
            # A separate connection represents another process/chat using the common CLI.
            other = j.connect(self.path, read_only=True)
            try:
                reused = recovery.recover(other, self.request, self.path, root=self.root / 'recovery')
            finally:
                other.close()
        self.assertEqual(reused['auto_recovery']['status'], 'reused')
        self.assertEqual(trials.snapshot_version(self.db), before)

    def test_attribute_quotes_outside_primary_quote_use_the_existing_recovery_route(self):
        primary='흰색 마스크를 사용한다.'
        conditions=['조건 '+str(n)+'에서만 적용한다.' for n in range(4)]
        priority='가독성을 먼저 확인한다.'
        data=packet(primary)
        data['operations'][0]['data']['text']=' '.join([primary,*conditions,priority])
        for operation in data['operations'][1:]:
            operation['data']['target']='mask-attribute-source'
        attrs=data['operations'][1]['data']['attributes']
        attrs['conditions']=[dict(when='조건 '+str(n),then='흰색 마스크',source_id={'$ref':'user'},quote=q)
                             for n,q in enumerate(conditions)]
        attrs['priority']=dict(description='가독성 우선',source_id={'$ref':'user'},quote=priority)
        self.rid=j.save_batch(self.db,data)['results'][-1]['id']
        self.request.update(target='mask-attribute-source',query='')
        before=trials.snapshot_version(self.db)
        result=self.activate()
        item=next(x for x in result['results'] if x['id']==self.rid)
        self.assertTrue(item['source_review']['complete'])
        self.assertEqual(len(item['source_review']['sources']),6)
        self.assertEqual(trials.snapshot_version(self.db),before)

    def test_new_db_evidence_invalidates_profile_and_requires_new_observations(self):
        self.activate()
        j.add_source(self.db, dict(project='projectut', role='user', origin='changed', observed_at='unknown', text='new evidence'))
        self.db.commit()
        result = self.call()
        self.assertEqual(result['auto_recovery']['status'], 'observed')
        self.assertFalse(result['results'][0]['rule_eligible'])
        self.assertIsNone(json.loads(self.state_path().read_text(encoding='utf-8'))['profile'])

    def test_implementation_drift_invalidates_profile(self):
        self.activate()
        real = recovery.versions
        def changed(db):
            value = real(db); value['code']['future.py'] = 'new-version'; return value
        with patch.object(recovery, 'versions', side_effect=changed):
            self.assertEqual(self.call()['auto_recovery']['status'], 'observed')

    def test_scope_and_keyword_changes_cannot_reuse_old_proof(self):
        self.activate()
        self.assertEqual(self.call(dict(self.request, query='unmatched'))['auto_recovery']['status'], 'no_delivery_gap')
        with patch.object(trials, 'run_trial', wraps=trials.run_trial) as run:
            result = self.call(dict(self.request, query='캐릭터'))
        self.assertEqual(result['auto_recovery']['status'], 'applied')
        self.assertEqual(run.call_count, 1)
        for field, value in (('project', 'crack'), ('domain', 'other'), ('target', 'other')):
            result = self.call(dict(self.request, **{field:value}))
            self.assertFalse(result['auto_recovery'].get('candidate_applied'))
            self.assertFalse(any(r['id'] == self.rid and r['rule_eligible'] for r in result['results']))

    def test_conflicts_empty_results_and_common_scope_are_never_automatic_criteria(self):
        for request in (dict(self.request, query='unmatched'), dict(self.request, target=None), dict(self.request, project='global')):
            result = self.call(request)
            self.assertFalse(result['auto_recovery'].get('candidate_applied'))
        self.assertFalse(self.root.exists())
        real = retrieval.retrieve
        def conflict(db, **request):
            value = real(db, **request)
            for item in value['results']:
                item['review_alerts'] = [dict(reason='new correction')]
                item['rule_eligible'] = False
            return value
        with patch.object(retrieval, 'retrieve', side_effect=conflict):
            self.assertEqual(self.call()['auto_recovery']['status'], 'no_delivery_gap')
        self.assertFalse(self.root.exists())

    def test_corrupt_state_and_tampered_proof_are_preserved_and_not_applied(self):
        self.call(); path = self.state_path(); path.write_text('{broken', encoding='utf-8')
        result = self.call()
        self.assertEqual(result['auto_recovery']['status'], 'recovery_unavailable')
        self.assertEqual(path.read_text(encoding='utf-8'), '{broken')
        path.unlink()
        result = self.activate()
        report_path = Path(result['auto_recovery']['report'])
        report_path.write_text('{}', encoding='utf-8')
        self.assertEqual(self.call()['auto_recovery']['status'], 'recovery_unavailable')

    def test_locked_scope_and_state_or_report_save_failure_return_ordinary_results(self):
        self.call(); path = self.state_path()
        with recovery.scope_lock(path.parent / 'scope.lock'):
            self.assertEqual(self.call()['auto_recovery']['status'], 'recovery_unavailable')
        for owner, name in ((recovery, 'save_state'), (trials, 'write_report')):
            with patch.object(owner, name, side_effect=OSError('disk failure')):
                result = self.call()
            self.assertEqual(result['auto_recovery']['status'], 'recovery_unavailable')
            self.assertFalse(result['results'][0]['rule_eligible'])
            self.assertFalse(result['auto_recovery']['candidate_applied'])

    def test_drift_after_frozen_trial_returns_current_baseline_and_never_activates(self):
        self.call()
        real = trials.write_report
        def changed(path, report):
            real(path, report)
            j.add_source(self.db, dict(project='projectut', role='user', origin='concurrent', observed_at='unknown', text='concurrent source'))
            self.db.commit()
        with patch.object(trials, 'write_report', side_effect=changed):
            result = self.call()
        self.assertEqual(result['auto_recovery']['status'], 'evidence_changed')
        self.assertFalse(result['results'][0]['rule_eligible'])
        self.assertIsNone(json.loads(self.state_path().read_text(encoding='utf-8'))['profile'])

    def test_database_lock_during_recovery_preserves_the_captured_valid_baseline(self):
        other = j.connect(self.path)
        self.db.execute('PRAGMA busy_timeout=1')
        real = recovery.versions
        def locked(db):
            other.execute('BEGIN EXCLUSIVE')
            return real(db)
        try:
            with patch.object(recovery, 'versions', side_effect=locked):
                result = self.call()
        finally:
            other.rollback(); other.close()
        self.assertEqual(result['auto_recovery']['status'], 'recovery_unavailable')
        self.assertIn('locked', result['auto_recovery']['error'])
        self.assertFalse(result['auto_recovery']['baseline_refreshed'])
        self.assertEqual(result['results'][0]['id'], self.rid)
        self.assertFalse(result['results'][0]['rule_eligible'])

    def test_char_expansion_is_the_second_bounded_candidate_and_keeps_the_query(self):
        self.request['chars'] = 80
        # Longer, valid context quotes need both count expansion and the larger quote limit.
        data = packet('블러 ' + '원문 ' * 100)
        for op in data['operations']:
            if op['command'] in ('candidate', 'record'):
                op['data']['target'] = 'longer-source'
        j.save_batch(self.db, data)
        self.request['target'] = 'longer-source'
        result = self.activate()
        self.assertEqual(result['auto_recovery']['patch'], dict(full_source_review=True, chars=2000))
        self.assertEqual(result['query_options']['chars'], 2000)
        self.assertEqual(result['query_options']['limit'], 3)

    def test_invalid_patch_and_wrong_result_order_are_not_accepted(self):
        self.call()
        state = json.loads(self.state_path().read_text(encoding='utf-8'))
        state['profile'] = dict(patch={'query':'changed'}, request_sha256='x', report='x', report_sha256='x')
        recovery.save_state(self.state_path(), state)
        self.assertEqual(self.call()['auto_recovery']['status'], 'recovery_unavailable')
        baseline = dict(results=[dict(id='a', rule_eligible=True), dict(id='b', rule_eligible=False)], total_matches=2)
        changed = copy.deepcopy(baseline); changed['results'].reverse()
        self.assertFalse(recovery.preserves(baseline, changed, []))
        changed = copy.deepcopy(baseline); changed['results'][0]['rule_eligible'] = False
        self.assertFalse(recovery.preserves(baseline, changed, []))

    def test_time_and_output_budgets_do_not_activate_or_suppress_a_later_retry(self):
        self.call()
        self.assertEqual(self.call(budget_seconds=0)['auto_recovery']['status'], 'time_budget')
        self.assertIsNone(json.loads(self.state_path().read_text(encoding='utf-8'))['last_attempt'])
        with patch.object(recovery, 'MAX_BYTES', 1):
            self.assertEqual(self.call()['auto_recovery']['status'], 'output_budget')
        self.assertEqual(self.call()['auto_recovery']['status'], 'applied')

    def test_rejected_candidate_does_not_loop_unchanged(self):
        self.call()
        with patch.object(recovery, 'preserves', return_value=False) as check:
            self.assertEqual(self.call()['auto_recovery']['status'], 'no_verified_candidate')
            count = check.call_count
            self.assertEqual(self.call()['auto_recovery']['status'], 'no_verified_candidate')
            self.assertEqual(check.call_count, count)

    def test_alternating_queries_do_not_repeat_an_unchanged_rejected_attempt(self):
        self.call()
        with patch.object(recovery, 'preserves', return_value=False) as check:
            self.assertEqual(self.call()['auto_recovery']['status'], 'no_verified_candidate')
            self.assertEqual(self.call(dict(self.request, query='캐릭터'))['auto_recovery']['status'], 'no_verified_candidate')
            count = check.call_count
            self.assertEqual(self.call()['auto_recovery']['status'], 'no_verified_candidate')
            self.assertEqual(check.call_count, count)
        state = json.loads(self.state_path().read_text(encoding='utf-8'))
        self.assertEqual(len(state['rejected_attempts']), 2)

    def test_rejection_history_budget_blocks_new_trials_without_growing_forever(self):
        self.call(); state = json.loads(self.state_path().read_text(encoding='utf-8'))
        state['failures'] = 2; state['rejected_attempts'] = [str(n) for n in range(64)]
        recovery.save_state(self.state_path(), state)
        with patch.object(trials, 'run_trial', side_effect=AssertionError('budget exhausted')):
            self.assertEqual(self.call()['auto_recovery']['status'], 'attempt_budget')

    def test_custom_database_cli_is_opted_out_and_explicit_expansion_preserves_count(self):
        args = [sys.executable, '-B', '-X', 'utf8', j.__file__, '--db', str(self.path), 'retrieve',
            '--project', 'projectut', '--domain', 'vfx', '--target', 'vision-blur', '--query', '블러']
        ordinary = subprocess.run(args, capture_output=True, encoding='utf-8')
        self.assertEqual(ordinary.returncode, 0, ordinary.stderr)
        self.assertNotIn('auto_recovery', json.loads(ordinary.stdout))
        expanded = subprocess.run(args + ['--full-source-review', '--no-auto-recovery'], capture_output=True, encoding='utf-8')
        self.assertEqual(expanded.returncode, 0, expanded.stderr)
        value = json.loads(expanded.stdout)
        self.assertTrue(value['results'][0]['rule_eligible'])
        self.assertEqual(value['query_options']['limit'], 3)
        self.assertFalse(self.root.exists())


if __name__ == '__main__':
    unittest.main()
