# Retrieval procedure trials

Use manual trials only when the user requests a harness experiment/improvement, or an existing recovery review finds evidence of a retrieval-procedure defect. The authorized [automatic source-delivery controller](automatic-retrieval-recovery.md) also invokes this comparator after two mechanically recoverable delivery gaps. Do not run semantic trials on every request, treat one ordinary search miss as a stalled task, or bypass the existing retry limit.

This is a small adaptation of Harness²'s execution-contrast principle, not an installation of its recursive agent runtime. See the [paper](https://arxiv.org/abs/2610.14224) and [upstream structure](https://github.com/google-research/harness2/tree/1cfe254e8d25b15f37048c3730134686abe60335/harness2/core). The current implementation performs two sequential deterministic retrieval evaluations. It does not call a model, generate code, edit skills/hooks, select artwork, or write user feedback.

## Scope and fixed inputs

- First version: confirmed, concrete `object` judgments only. Project/global/task-wide criteria and complete AI production runs are not supported. Both variants must retain the same project/domain/target and other query options. Only `query`, `limit`, `chars` and `full_source_review` may differ.
- Read actual source/context, conditions and conflict reviews before defining expected IDs. `expected_by=agent_source_review` is the caller's declaration, not proof that semantic review happened. Missing or contradictory evidence never becomes an active rule because an experiment needs a positive example.
- The CLI opens the source DB with `mode=ro`, copies one consistent snapshot into memory, and evaluates both variants on that snapshot with `query_only=ON`. This creates no persistent DB copy or backup. Inputs from an unfinished transaction are rejected, not silently committed.
- The result identifies the complete snapshot, input and execution source files by SHA-256. New changes in the operating DB do not alter either arm mid-trial. Recheck current source versions/conflicts before adopting a query procedure later. Changed task/cases/expectations/code/input need a new trial ID and result path; the comparator itself does not resume across versions or deploy a candidate. The automatic controller separately rechecks current versions before activating its restricted source-delivery setting.
- Candidate input is data only. Arbitrary scripts, shell commands, model settings and candidate scope overrides are rejected. This is a restricted deterministic interface, not OS isolation for an arbitrary agent or permission to execute an untrusted harness.

## Run

Use `scripts/harness_trials.py` with the existing Python runtime. Default DB is `D:/CodexData/judgment-data/judgments.sqlite3`; no new package or credentials are required. First retrieve/review the relevant judgment normally; then get its version with `judgments.py show <ID> --fields id,fingerprint`. Do not repeat the source readback when unchanged evidence has already been read.

Pass this shape as UTF-8 standard input (`--input -`). Replace IDs, fingerprints, scope and keywords with the actual reviewed case. Keep the same expected IDs for both variants:

```json
{
  "trial_version": 1,
  "trial_id": "concrete-retrieval-001",
  "task": "The actual bounded retrieval task",
  "hypothesis": "Why the proposed query or readback change might address the observed miss",
  "expected_by": "agent_source_review",
  "record_fingerprints": {"<reviewed-judgment-id>": "<actual-fingerprint>"},
  "cases": [
    {
      "name": "required-criterion",
      "query": {"project": "projectut", "domain": "vfx", "target": "actual-effect", "query": "original terms"},
      "candidate_query": {"query": "concrete object terms"},
      "must_be_eligible": ["<reviewed-judgment-id>"]
    },
    {
      "name": "other-project",
      "query": {"project": "crack", "domain": "vfx", "target": "actual-effect"},
      "must_not_be_eligible": ["<reviewed-judgment-id>"]
    },
    {
      "name": "other-target",
      "query": {"project": "projectut", "domain": "vfx", "target": "different-concrete-effect"},
      "must_not_be_eligible": ["<reviewed-judgment-id>"]
    }
  ]
}
```

For every positive criterion, include both canonical scope guards above, without keywords/purpose/other filters or candidate overrides. The other-project guard must name the other connected project (`crack`/`projectut`), not an invented empty project. Other-domain guards may also be included. The same expected ID cannot be both required and forbidden. Cases are bounded at40; each expected-ID list at20. `limit` is an integer1–20; `chars` is80–2000. For evidence-count limits only, a candidate may use `{"limit":1,"chars":2000}`. This still enforces source delivery, conflict and version checks. It does not authorize changing the default search to one result for every task.

Automatic source-delivery trials use `expected_by=mechanical_source_delivery`, retain keywords and result count, and allow only `full_source_review=true` and nondecreasing `chars`. Every positive ID must independently pass current source/conflict delivery checks in the same scope. This mechanical label never substitutes for semantic source review. It also permits preserving multiple original results while delivering up to20 sources/relations per result.

```text
<existing-python> -B -X utf8 <skill>/scripts/harness_trials.py --input -
<existing-python> -B -X utf8 <skill>/scripts/harness_trials.py --input - --output D:/CodexData/harness/outputs/retrieval-trials/<trial-id>.json
```

Without `--output`, return JSON only. When requested, a complete result is published under `D:/CodexData/harness/outputs/` without replacing an existing file. A collision or save failure is an error; do not report the artifact saved. Interrupted unpublished temporary output is not a completed report. Repeat an interrupted trial from the beginning on the reviewed input; no operating writes need recovery.

## Interpret and connect

`evaluation.check_retrieval` is reused for both arms. Existing `evaluation.compare` remains unchanged: it measures paired user-feedback agreement for DB-free/DB-backed predictions, not a comparison between two query-procedure versions. Do not disable mandatory retrieval in production to create a baseline.

| Decision | Meaning |
|---|---|
| `candidate_supported` | All candidate cases pass and at least one baseline failure is fixed. This is support on the curated cases only; the candidate was not deployed. |
| `keep_baseline` | Both pass with no demonstrated correctness gain. Timing differences alone do not justify a change. |
| `candidate_rejected` | At least one candidate case fails. Improvements elsewhere cannot hide a new failure. The baseline itself may also be failing. |

Exit0 is a completed supported/unchanged comparison; exit1 is a completed rejected candidate; exit2 is invalid input or an execution/save failure. Failed/incomplete comparisons are not fabricated passes. Elapsed times are observations, not stable performance gains; model calls are0 and API billing is not measured (`null`).

Keep the trial report separate from operating `prediction`/`feedback`/`improvement` records. The actual input, per-case failures, rejected hypotheses and version hashes are sufficient evidence for a future scoped review; do not create a second user-preference library or automatically load every old trial. Before a justified technical change, review its exact diff and current criteria, apply only the authorized fix, rerun affected cases and an independently selected relevant case where available. A tuned case set is not held-out accuracy or proof of a better whole agent. Actual user corrections still follow [learning-cycle.md](learning-cycle.md); reviewer advice does not establish user preference.

If the problem concerns produced text, images, Unity motion or user interaction, these retrieval checks are insufficient. Keep the existing production validation and real observation requirements; add a task execution adapter only under a separately established scope. Do not copy the upstream permission/sandbox bypass settings into the personal runtime.
