# GPTDB game-design references

For substantive game planning, implementation and review, automatically retrieve relevant GPTDB material even when the user has supplied few personal judgments. Camera movement/framing and level/dungeon/encounter design are priority uses. Route by the actual game task; ordinary explanations, live status, unrelated camera/photography work and character-image work do not trigger this lookup.

## Existing search paths

`judgments.py retrieve` attaches a separate `design_references` envelope for the default DB when project is `projectut`/`game-design-research` or the explicit domain is `camera`, `level-design`, `level_design`, `game-design` or `game_design`. The existing bridge invokes that same CLI and receives the added field without a server restart. `--no-design-references` skips it for one call; custom DB fixtures do not implicitly read private notes. The judgment `results` and eligibility are unchanged.

For any other game project, or when no judgment DB is needed/available, use the standalone read-only command:

```text
<existing-python> -B -X utf8 <skill>/scripts/judgments.py design-references --query "카메라 워킹 전투 가독성"
<existing-python> -B -X utf8 <skill>/scripts/judgments.py design-references --query "레벨 디자인 동선과 인카운터" --topic level
```

This command does not open the judgment DB. The optional topic is `auto` (default), `camera`, `level`, `combat`, `puzzle`, `onboarding` or `workflow`; limit1–5 defaults3; chars80–2000 defaults1600 per note's selected passages. Use actual task words; a topic explicitly chosen by the agent should match the task. Infer English/Korean related terms through these topic groups. If a needed issue has no result, try a more concrete game term at most twice, then disclose the gap. Do not claim comprehensive camera expertise or invent a preference from absent personal instructions.

## Live source boundary

Read `C:/Users/User/Documents/codex-gpt/자료 정리 문서/게임디자인_리딩_DB_인덱스.md` and its explicitly linked reading/topic notes on every query. The reader follows local Markdown links inside that folder only, validates note types and bounds the walk at120 notes/256 KB each. It does not scan unrelated vault notes, execute links, edit Obsidian settings, import article text into the judgment DB, keep a second persistent index, launch a watcher or visit source websites automatically. Adding an appropriate indexed note makes it available to the next query. Note edits are also re-read immediately.

Links with or without `.md` share one visit, using the host's filename comparison (including case-insensitive names on Windows). Alias links do not consume extra note slots. An empty passage list is not completed readback, even when the title or metadata matches the query.

Return exact selected paragraphs with original section hierarchy, line, path and file SHA-256. Preserve labels such as source summary, synthesis, portfolio application and analysis/proposal. `note_readback.complete` concerns only those selected paragraphs; omitted sections can contain conditions or limitations. Read the relevant full note via `followup_path` when the excerpt is truncated, an important condition is missing, source vs analysis is unclear or the note affects a material decision. Reuse already-read unchanged evidence.

`note_status=verified` is a saved note's metadata, not a new verification of the primary article, current software API, numeric outcome or general principle. Source URL/publication data are retained when present. Verify original/current primary sources when required by the claim or implementation; do not promote a note's application suggestion to the article author's finding. New external research is outside the automatic local retrieval; a material gap may separately use [criteria-gap research](criteria-gap-research.md) after the existing local checks.

## Application contract

1. Preserve latest user intent, project constraints and applicable confirmed user judgments. GPTDB provides general design knowledge, cases and review questions. It does not create `confirmed_rule`, `rule_eligible=true`, user feedback or new user preferences.
2. Read returned passages and inspect their conditions/limitations. Prefer relevant topic synthesis plus concrete cases. Multi-topic selection includes each requested topic when the result limit permits; explicit high priority only breaks relevance ties, so a favored collaboration article cannot displace a camera case solely because it is favored.
3. Use supported principles to propose choices, explain tradeoffs and identify missing checks in the current task. Identify source claims, note synthesis and the current application proposal separately. A material conflict with the user's current direction needs an explanation/choice, not a silent override.
4. Validate the actual implementation/design. A camera timing, motion or interactive criterion still needs normal-speed observation or interaction; a retrieved article and passing search test do not prove the camera feels good or that a level plays well. Record later actual user decisions through the existing scoped judgment/learning workflow only when that contract applies.

`coverage` reports matched notes and dedicated topic notes; it is collection coverage, not quality or completeness. Missing index/files, invalid text/type and traversal limits are explicit warnings or `status=unavailable`. Continue useful work while reporting a consequential gap. A reference-only result must never enter prediction `applied_judgments` as though it were a confirmed DB judgment.
