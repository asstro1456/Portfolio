# Independent task and skill recovery review

Use this only for stalled or materially non-compliant work, across the user's existing harnesses. It adds a conditional diagnostic step, not routine review, a watcher, or permission to collect other projects. The user's request to add separate review chats authorizes one diagnostic chat when these conditions apply; no repeated confirmation is needed. The coordinator alone manages it.

## Trigger and triage

Start when the same material acceptance failure survives two substantive attempts, or the user identifies recurring lack of progress or failure to follow their request. A user explicitly requesting this review can start it immediately. Compare the current requested outcome, observable result, and failed acceptance point first. A long task is not stalled merely because it takes time; normal processing/waiting, one easily corrected mistake, a known unavailable tool, and missing user input alone do not trigger a skill audit.

Distinguish likely instruction ambiguity/conflict, missing/retrieved-but-misapplied criteria, execution error, environment/tool failure, and missing input. Use the existing recovery procedure for a clear cause. If the cause remains uncertain or the skill may be steering repeated failure, run the separate review. Do not ask a reviewer to invent a skill defect for a known external outage.

This does not reset a project's retry limit. Preserve a stricter stop rule, including the user's three-failed-modifications limit. At an exhausted limit, diagnose and report rather than attempt another product modification.

## One fresh review chat

Create a new projectless chat through `create_thread` with a title such as `하네스 정체 검토 — <task>`. Never fork the producer, resume an old reviewer, or message an unrelated chat. Do not set a model override unless the user or an applicable model policy specifies it. There is at most one active diagnostic reviewer, and this reviewer must not launch another reviewer.

The coordinator assembles a self-contained packet containing only:

- The current user request, concrete acceptance criteria, authorized scope, and unresolved decisions.
- The actual relevant `SKILL.md` and required reference text, identified by path and content hash. Include applicable permission/stop rules. If the packet omits a required reference, mark it unavailable instead of asking the reviewer to guess it.
- Minimal raw evidence of the observed mismatch and the last relevant attempts, including exact errors or output excerpts. Redact unrelated private material. Identify images/live states not actually supplied.
- A request to identify the failing stage, separate observation from hypothesis, classify the cause, and propose only necessary minimal changes plus a check against the original acceptance point. No mandatory defect count or desired verdict.

Do not pass the producer's reasoning, suspected fix, prior review findings, full history, DB dumps, or unrelated project material. The reviewer receives its task context from the packet only; it must not retrieve filesystem content, tools, connectors, shared DB, account memories, other chats, or delegate. State these restrictions explicitly in the review prompt. This assigned review role takes precedence over ordinary retrieval/production routing. Missing evidence is a finding, not permission to fetch more context or invent a result. The reviewer returns its report in the chat and makes no edits.

Fresh chat history plus a no-lookup instruction is a contextual boundary, not physical filesystem/network isolation. A text packet cannot establish actual artwork, engine, browser, or device quality. Ask the reviewer to state what it did and did not inspect. Inspect its visible tool history where available. A reviewer that retrieves prohibited context is contaminated and does not count: archive it and replace it once with a fresh chat; if replacement is also contaminated, report the limitation and stop this review cycle.

Use compact `wait_threads` snapshots to follow the new chat. Read its complete final answer before deciding on changes; do not treat a status message as a completed review. After reading the result, archive that review chat through `set_thread_archived`. Archive a failed/contaminated review as well. Preserve the producer's chat and do not message an archived reviewer again. If chat tools are unavailable or creation fails, report that independent review was not run; do not label the producer's own analysis as an independent result.

## Repair and return to the original task

When evidence identifies a retrieval-procedure defect, use [retrieval trials](harness-trials.md) to compare one bounded candidate against the existing query on fixed input. Reuse this diagnostic's evidence; do not launch a second reviewer, disable mandatory retrieval or treat trial output as user feedback. Passing retrieval checks does not verify the original production result.

The common retrieval CLI also has an authorized [automatic source-delivery controller](automatic-retrieval-recovery.md) for repeated mechanical count/truncation gaps. Its scoped setting can activate after fixed-input comparison and current-version checks without opening a reviewer chat. It does not replace this recovery review for semantic relevance, instruction/application failures or failed task outputs.

Judge findings against the real request and evidence. A clear existing rule that was not followed needs application/execution correction, not more skill text. An outage needs environment recovery; missing facts need the specific input. Edit only the responsible skill/reference when there is a demonstrated gap or ambiguity and that edit is within the user's authorized scope. Do not rewrite unrelated skills, add speculative universal rules, lower acceptance criteria, or change the intended product to make the review pass.

For a justified skill change, use `skill-creator` and validate affected resources/references. For skills produced or revised for sharing, follow `C:/Users/User/.codex/hooks/personal-workflows/shared-skill-review.md`: its three sequential fresh-chat comprehension rounds remain separate, and this task diagnostic does not count toward them. Do not run three rounds for an ordinary private harness fix solely because this diagnostic exists.

Resume from the failed stage only and verify the original acceptance point on the actual affected output, within the remaining retry budget and execution permissions. Independent diagnosis, a changed instruction, and a passing schema/text check are not proof that the user's work now succeeds. If actual verification is unavailable, retain that specific gap; do not mark the original task complete.

Before resuming, apply the latest-correction contract in the parent SKILL.md: replace superseded acceptance/test expectations, preserve still-valid constraints, and make the observed prior failure fail a regression check. Test an invariant against its genuine pre-initialization basis rather than a state already altered by the faulty setup. Re-run affected checks for the current criteria version. For temporal/motion failures, additionally observe normal-speed actual playback; static frames and parameter changes cannot establish the intended sequence or feel. A user waiver of exported video permits actual preview observation, not a fabricated motion pass. Keep unavailable checks explicitly incomplete and respect a waiver of verification itself without calling it passed.

Run one diagnostic cycle per task/failure/skill-version combination. Reuse its findings while applying the fix rather than restarting on every follow-up. An unsuccessful cycle is reported with evidence and the next necessary action. Another cycle needs materially new evidence/a changed failure or an explicit user request; wording changes alone do not renew the allowance. Preserve real review ID, skill version/hash, finding, disposition, and actual recheck in the existing work record when one exists. Do not create routine chat summaries. New review artifacts, when needed, belong under `D:/CodexData/<project>/outputs/`.

This is harness maintenance, not synthetic user feedback or prospective learning evidence. Actual connected-project production/feedback still follows its existing learning contract; do not backfill predictions or automatically promote reviewer advice to a user judgment. Report only consequential findings and necessary remaining improvements; if no skill change is justified, say so and continue the appropriate recovery.
