# Prospective work → user feedback → reviewed improvement

This is the owner's authorized private improvement workflow for **crack/projectut**. It is mandatory for substantive work whose outcome depends on the user's creative/planning/review judgments. Skip context-only answers, live status, mechanical chores without a judgment to evaluate, unrelated projects, and maintenance of the harness itself. Do not add a watcher, a second reviewer by default, or an unsolicited baseline run. Hooks supply instructions; the agent performs and verifies each operation.

## 1. Before making the result

Retrieve and read the relevant sources using SKILL.md. Reuse unchanged evidence. Run `learning-status --project <project> --conversation <actual conversation ID>` when handling feedback/resuming the same connected work; use `--task` when known. This read-only command lists unfinished prospective evaluations, not task progress or accuracy. Absence means **no registered evaluation**, not no work done. New feedback is matched by actual task/output/version and source context, never by conversation alone, nearest row, or a short “좋아”.

Before production/revision/review decisions or delivering the result, save a `predict --input -` packet:

```json
{
  "evaluation_version": 1,
  "project": "projectut", "domain": "vfx", "target": "<actual target>",
  "conversation_id": "<actual conversation ID>", "turn_id": "<actual initiating turn ID>",
  "task": "<stable output/task version identifier>",
  "prediction": "<1–3 concrete expected acceptance points or likely defects, before seeing feedback>",
  "judgment_ids": ["<actually reviewed and applied current criterion ID>"]
}
```

Examples above are **schemas with placeholders**, never operating data. Empty judgment_ids is valid when no eligible relevant criterion exists after appropriate search. Do not invent a criterion or expected user response. The server records creation time. The same project/conversation/turn/task cannot change its prediction or scope; exact replay is idempotent. A real later task/version uses a new turn/task. Do not turn an already-seen correction into a new prospective evaluation of the old result. Existing historical cases remain source/candidate evidence only.

A reviewed project/global-scoped criterion may retain a descriptive stored target while applying to another target in its authorized project/domain. Prediction links preserve that reviewed scope; object-scoped criteria still require the exact target. This does not infer target aliases or waive source, condition, conflict, project, domain, or current-status review.

Linked IDs are validated after the full applicable conflict analysis, before display pagination. Falling outside a displayed top-20 search result does not make an otherwise eligible criterion invalid; unselected later corrections still block it.

If default retrieval stops only at evidence-count limits, focus that criterion with the same scoped query and `--limit 1` before applying it. Read the expanded exact evidence; related reviews and each source list remain capped at20, strings/attributes still have their normal limits, and conflicts/stale versions/missing evidence still block. Prediction/comparison selected-ID validation uses this same expanded check, so a fifth nonblocking pair is not a permanent refusal. This is readback, not an approval or a substitute for the agent reading the evidence.

Use the actual session/turn/message IDs available from task metadata. If native message IDs are unavailable, a verified session log and its exact user-event position may serve as a stable message locator; retain that origin. Read only the necessary current event, not all local chats. Use the event's timestamp, never the time you inserted the DB row. If essential identity is unavailable, report the recording gap and proceed with the authorized work; do not invent IDs or time. Source timestamps must be timezone-aware ISO 8601 containing T. Equal timestamp precision is allowed only with later DB row order; earlier or future-dated feedback is rejected.

## 2. When actual user feedback arrives

Check learning-status and read only the matching prediction/output/source context. One message may address several tasks, but quote and explain each link separately. An ambiguous referent remains undetermined; do not mark every pending task matched. No feedback means awaiting_feedback, never success. Check whether the user evaluated result quality, implementation, or only authorized the next action; authorization alone is not a quality verdict.

Save the real user source with project/origin/role/text/observed_at/conversation_id/message_id, then `feedback --input -` (or one atomic batch):

```json
{
  "prediction_id": "<matching prediction>", "task": "<same task identifier>",
  "source_id": "<actual later user source>", "quote": "<exact feedback excerpt>",
  "outcome": "matched|missed|undetermined",
  "analysis": "<compare this predicted acceptance point with this user feedback; separate observed facts from inference>"
}
```

The CLI checks exact quote, user role, project/conversation/task/message identity, row order, and source event time against server-written prediction/source times. A known message cannot become prospective evidence by re-importing it with changed time/text. Unknown source time permits only undetermined. These checks cannot verify the truth of caller-supplied provenance or semantic task attribution; the agent must read the actual source. Do not create synthetic feedback in the shared DB. Fixtures belong only in isolated temporary databases.

If later real clarification changes a previous outcome, save a new source and feedback with `supersedes: "<current feedback ID of this prediction>"`. It requires a different, later user source; exact replay is idempotent. Preserve the old feedback. An agent changing its mind alone is not new user evidence. Opposing active outcomes remain needs_context; never select the favorable one. Fixed-task baseline/harness comparison remains the separate legacy compare contract; do not combine it with routine prospective v1 records.

## 3. Close the loop with `improve --input -`

Required fields: feedback_id, disposition, cause, analysis. Causes:

| cause | Meaning and action |
|---|---|
| none | Feedback agrees; keep applicable criteria. |
| rule_gap | A reusable explicit user criterion is missing/wrong; review a narrowly scoped v2 candidate. |
| retrieval_miss | A valid existing criterion was not retrieved; improve the scoped query/routing only where actually needed. |
| application_miss | The reviewed criterion was not applied; fix the task/application step within authorization. |
| execution_defect | Implementation or production failed; fix that defect within authorization, without inventing a new preference. |
| ambiguous | Essential context or opposing outcomes; preserve needs_context and ask only the consequential missing question. |

`disposition`:

- `keep`: existing criteria remain valid; explain the evaluated result and, for a miss, the corrective action or remaining gap. This closes **criterion review**, not proof that a code/visual repair succeeded. Verify the actual repair separately before claiming it fixed.
- `case_only`: retain an actual one-off/uncertain **v2 candidate_id** sourced from this feedback. It must not be reusable and never becomes an active rule.
- `needs_context`: unresolved attribution, cause, or conflict. No criterion/candidate/regression fields; retain the pending item.
- `rule_updated`: cause must be rule_gap. Supply **criterion_id** of a confirmed, reviewed v2 judgment from this feedback's source, and **regression** below. Project/domain/target must equal the feedback's scope; an object/task cannot silently become project/global. Explicit wider future instructions need their own correctly scoped review, not expansion through this closure.

No new reusable judgment → no candidate/criterion write; an actual prospective feedback review still needs its feedback/improvement records. For a reusable correction, use the existing v2 source → candidate → review → record sequence, preserve conditions, task/acceptance state and reason_source_id, and use supersedes/change_reason only when the actual sources justify replacement. Otherwise keep distinct contexts or conflict-review them. Save classification/criterion/improvement together with batch when possible; failed validation rolls the whole new packet back. For a previously defined `ref: "rule"`, use `{"$ref":"rule"}` as criterion_id/in ID lists, and `"record_fingerprints":{"$ref:rule":{"$fingerprint":"rule"}}` for its server-computed version. Only earlier aliases may be referenced. A changed improvement conclusion explicitly supersedes its current improvement ID; stale/cross-feedback supersession is rejected. Unknown feedback cannot be closed as keep/rule_updated. Conflicting active feedback cannot close until a later source resolves it.

## 4. Validate the changed criterion, then read back

The `regression` field uses the real `check-retrieval` packet contract in usage.md. It must contain current record_fingerprints and cases referencing **the changed criterion itself**:

- positive: same project/domain/target, must_be_eligible includes criterion_id;
- negative: the other connected project, must_not_be_eligible includes criterion_id;
- for target-limited feedback: the same project/domain with a different concrete target, must_not_be_eligible includes criterion_id.

Required scope probes contain only project/domain/target: do not hide a scope leak with query text, purpose, conversation or limit filters. Additional condition probes may use normal retrieval options. Add relevant condition/domain/retired/one-off cases where they address the actual correction; do not pad tests. `improve` executes retrieval and rejects failed/stale cases, retired candidates and ineligible criteria. Required negatives check scope containment, not whether the new substantive judgment is correct. The agent must separately compare user intent, condition fulfillment and actual result. Curated cases are not a held-out benchmark or measured accuracy gain.

Read back returned prediction/feedback/improvement/criterion IDs with `show <IDs...> --summary`. Improvement readback includes criterion/candidate linkage and the actual validation result. Re-run scoped learning-status to distinguish awaiting_feedback, awaiting_improvement, needs_context and resolved; counts are operational entries, not unique tasks, rates or causal improvement. Reports must say what was actually predicted, what the user actually said, the cause interpretation, and whether criteria changed or stayed valid. Report meaningful missing evidence; do not expose routine bookkeeping in every answer or claim that an injected hook saved/applied anything.

## Artifact outcome and feedback review (additive schema-v1 contract)

For new direct `conversation:<UUID>/message:<actual message UUID>` source packets, explicitly include matching conversation_id/message_id; preserve verified turn_id when available. The source save path validates these fields instead of accepting origin-only new writes. Reusing the same message cannot change project/role/text/time/task version/target. Existing origin-only data is readable and exact replay only reuses an unambiguous stored packet; replay after verified metadata repair retains that metadata and the original source ID. Legacy repair is a separate source/role/time/turn verification with bounded authorization, backup and transaction; never infer missing identity or automatically migrate history. Generic export/session-log contracts stay compatible. An assistant context source remains ineligible for user feedback even if its metadata is complete.

`resolved` retains its existing meaning: the **rule review** is complete. It never certifies a fixed artifact. `validation` on an improvement remains retrieval-regression evidence. Old improvements without artifact checks stay `outcome_counts.unverified`; no historical success is inferred. `learning-status` keeps its old counts/pending fields and separately returns outcome_counts/outcome_pending.

For actual revision checks use `validate-outcome --input -` (batch command `validate_outcome`). Supply improvement_id, original task, distinct revised_task, before_artifact, after_artifact, required_modes and checks. Scope is inherited from the current resolved improvement and its current determinate feedback. Record actual artifact/version references. Still and motion are separate required modes; include motion whenever acceptance concerns time, movement or interaction. Declare required_modes from acceptance criteria before inspecting the result. This CLI cannot infer missing motion requirements from natural language. Existing required modes cannot be removed by superseding a check.

New prospective predictions should preserve `validation_modes: ["still", "motion"]` (only actually needed modes) from those acceptance criteria. These modes are frozen with the prediction and cannot be dropped even on the first outcome check. Legacy predictions without this optional field remain compatible and require source/acceptance review; they are not backfilled.

Each check has status passed/failed/unverified/excluded and note. Passed/failed requires actual evidence locators and a timezone-qualified observed_at after the improvement review and no later than now. A motion verdict additionally requires observation=normal_speed and actual normal-speed preview/interaction observation. Still images, code inspection and tests do not replace it. These are agent-supplied observations, not independent proof of viewing. Missing checks stay unverified. Excluded checks require waiver={source_id,quote} from the actual same-project/conversation user verification waiver; export-only waivers do not qualify. Any failure yields failed; only all modes passed yields passed. Partial passes/exclusions stay unverified. Checks never imply user acceptance. A revision explicitly supersedes the current outcome_validation ID, preserving prior evidence.

For follow-up matching, save/reuse the exact source, then run `learning-status --project <ID> --conversation <actual ID> --feedback-source <source ID>`; use --task only after identifying the output. Preserve source.task/source.target when actually known. The command returns bounded review candidates/issues, always outcome=undetermined, review_required=true and automatic_link=false, without writes. Conversation/order alone never establishes linkage. Review actual output/version/target/source context before feedback. Missing version context is an issue; known wrong versions/targets are rejected on write. No response creates no feedback. Known execution-only approval phrases and v2 non-quality acceptance scopes cannot become matched/missed feedback. This conservative veto is not a complete language classifier: ambiguous/untagged versions still require source review. Existing callers without source.task remain compatible, not automatically verified. Never convert an empty issues list into approval.

## Interpretation replay and minimal local observations

`check-interpretation --input -` is read-only. Each interpretation_regression case contains name, exact scope, sources (source_id/quote/fingerprint), review_note, expected structured target/actions, forbidden answers, a submitted response (or null), and a separate retrieval query/expected_ids probe. Source and scope versions are checked. Results independently count retrieval_passed and interpretation_passed/evaluated. A missing response is unmeasured, never a pass. A known wrong referent/action fails even when retrieval succeeds. `examples/interpretation-cases.json` contains two real local failure cases; response is deliberately null. Fill it only from an actual submitted structured interpretation or an explicitly labeled synthetic replay. Do not copy expected into response and report a model result. A retrieval probe may explicitly select provider=feedback_evidence for historical feedback; the default remains retrieve. The mouth-mask case uses this separate evidence search, without promoting feedback into a rule or changing normal retrieval.

`feedback-evidence --project <ID> --query <actual terms>` reads only existing current feedback from the exact connected project. Narrow by --domain/--target/--conversation/--task. This supplements a missing historical feedback context; it does not expand confirmed-rule retrieval or import conversations. Each result has kind=feedback, usage=feedback_evidence, rule_eligible=false and review_required=true. `user_quote`/source_review retain actual user evidence separately from `agent_analysis`/feedback_outcome, which remain an agent's interpretation of prediction agreement, never artifact acceptance. Invalid/inactive source evidence is skipped; truncated quotes have source_review.complete=false and require exact show. Unknown times stay unknown. Never apply these as standing criteria, automatically link them to new versions, or convert them to confirmed rules for search convenience. Any actual new reusable criterion still requires the existing source→v2 candidate→review→record procedure.

The existing dispatcher observes only SessionStart/UserPromptSubmit/SubagentStart when a session ID exists. It hashes session/turn to a 24-hex trace ID and injects that ID for this turn's CLI calls. Use global `--trace-id <ID>` before the command for save/readback; an absent trace remains unlinked, not a completed chain. Local metadata append-only log: `D:/CodexData/judgment-data/observability/events.jsonl`. Allowed fields are version/time, stage/status, hashed trace ID, random event ID, generated record UUIDs and fixed reason code. No prompt/source/query/path/exception text or arbitrary extra fields are logged. There is no watcher, new hook matcher, trust/permission change, network transmission or new collection project. CLI logging is enabled only for the operational DB; temporary --db fixtures do not emit production telemetry.

Stages distinguish hook_received, hook_context, save and readback (started/success/failure). `observe-skip --reason no_new_judgment|context_only|not_connected|missing_identity|no_feedback` records an explicit agent skip, never inferred from silence. `observation-status` with --trace-id reports saves still awaiting readback. Successful CLI readback confirms record access, not semantic source review. Missing hooks, missing IDs or agent omissions remain unknown; setting/config presence is not actual app hook delivery. I/O failures warn and preserve the primary operation; never claim logging succeeded after an unavailable receipt. Logs currently have no automatic retention/rotation; they contain only small metadata events. Inspect file size before adding future higher-frequency instrumentation.

## CLI and host boundaries

Use the existing Python/CLI paths from usage.md with UTF-8 and stdin; no new package, input-file archive or backup is required. `learning-status` is read-only. `predict`, `feedback`, `improve` support atomic batch; existing legacy commands remain compatible. This workflow is prospective: it does not train model weights, auto-approve suggestions, infer personality, or automatically import old chats.

ChatGPT's dedicated bridge judgment_retrieve/judgment_show tools stay read-only. A lookup request alone never authorizes evaluation writes. For authorized connected production/feedback, a Codex task may run this workflow through the registered `공통 판단 DB` project using the actual originating conversation/task identity. Never use the bridge executor's chat ID as a substitute for the user's source conversation. If the source context cannot be verified, record no determinate evaluation and report the gap. Do not add a generic SQLite write API.
