# 실행·입력 계약

직접 대화 출처 `conversation:<실제 대화 UUID>/message:<실제 메시지 UUID>`의 새 source에는 동일한 `conversation_id`와 `message_id`를 전용 필드로 함께 넣는다. 확인한 실제 턴이 있으면 `turn_id`도 보존한다. 출처 문자열만으로 ID를 추정해 새로 저장하지 않는다. 빈 값·출처와 다른 ID·기존 메시지의 프로젝트/화자/원문/시각/작업 버전 변경은 거절된다. 기존 origin-only 입력은 이미 저장된 정확한 원문 패킷의 재실행만 읽기/재사용하며, 검증 복구된 ID를 빼고 재실행해도 같은 source를 사용한다. 레거시 누락을 자동 일괄 복구하거나 다른 메시지로 추정 연결하지 않는다. 일반 export/session-log/document 입력 계약은 유지한다.

과거 피드백의 근거가 일반 retrieve에 없으면 `feedback-evidence --project <ID> --domain <분야> --target <대상> --query <검색어>`로 별도 조회한다. conversation/task로 실제 버전을 좁힐 수 있다. 이 명령은 읽기 전용이며 사용자 원문과 AI 평가를 구분하고 항상 rule_eligible=false다. 확정 기준 검색에 합치거나 사용자 판단으로 자동 승격하지 않는다. 상세 계약은 learning-cycle.md를 따른다.

산출물 검증·피드백 후보: [learning-cycle.md](learning-cycle.md)의 추가 계약을 따른다. `validate-outcome --input -`/batch `validate_outcome`은 검토 완료와 별개인 실제 수정본 검증을 저장한다. `learning-status --feedback-source <실제 source ID>`는 읽기 전용 연결 후보만 제공한다. 기존 `resolved`, `validation`, pending/counts의 의미는 유지하며 새 outcome_pending/outcome_counts를 함께 확인한다.

`check-interpretation --input -`은 실제 원문/대상/기대 판정/오답 조건을 검토한 구조화 응답을 검사하며 검색 성공과 해석 성공을 별도 집계한다. 응답이 null이면 미측정이다. `--trace-id <훅 제공 ID>`는 서브명령 앞에 지정한다. `observation-status`는 그 ID의 로컬 훅/저장/재조회 메타데이터를 집계하고, `observe-skip --reason <고정 사유>`는 의도적 미기록만 명시한다. 원문은 관측 로그에 복제하지 않는다. 상세 계약과 한계는 learning-cycle.md를 따른다.

Windows PowerShell 예시. 새 입력은 UTF-8 표준입력으로 전달하고 셸 인자로 본문을 삽입하지 않는다. `--input -`는 모든 기록 명령에 적용된다. 파일 입력은 호환용이며 대화마다 새 JSON 파일을 만들지 않는다. 테스트는 임시 DB만 사용한다.

```powershell
$judgmentPython = 'C:/Users/User/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/python.exe'
$judgmentTool = 'C:/Users/User/.codex/skills/judgment-harness/scripts/judgments.py'
& $judgmentPython -X utf8 $judgmentTool init
& $judgmentPython -X utf8 $judgmentTool search --project projectut --domain vfx --query '블러 대사창'
& $judgmentPython -X utf8 $judgmentTool search --project crack --query '미정 정보 공개'
& $judgmentPython -X utf8 $judgmentTool show '<검색 결과 ID>'
& $judgmentPython -X utf8 $judgmentTool source --input '<원문 JSON 절대 경로>'
& $judgmentPython -X utf8 $judgmentTool record --input '<판단 JSON 절대 경로>'
& $judgmentPython -X utf8 $judgmentTool stats
```

기본 DB는 `D:/CodexData/judgment-data/judgments.sqlite3`. 다른 DB는 **명령 앞에** `--db '<절대 경로>'`. 예전 `C:/Users/User/.codex/judgment-data/judgments.sqlite3`를 명시해도 CLI는 새 D 드라이브 DB에 연결한다. C의 기존 파일은 이전 시점 보존본이므로 sqlite3로 직접 수정하지 않는다. 요청된 백업은 `D:/CodexData/backups/`에 sqlite3의 `backup()`으로 생성한다. 검증 보고서도 `D:/CodexData/judgment-data/reports/`에 둔다. 모든 기록은 추가 방식이며 수정은 새 판단으로 남긴다. GitHub 백업은 사용자가 명시한 전용 비공개 저장소만 사용한다.

## 승인된 비공개 GitHub DB 백업

일일 실행 상태는 `D:/CodexData/judgment-data/github-backup-state.json`에 둔다. SQLite 읽기 트랜잭션에서 records와 document_heads의 전체 내용을 해시하므로 WAL 변경도 반영하며 파일 수정 시각만으로 변경을 판단하지 않는다. 이전 검증 복원본과 내용이 같으면 업로드하지 않는다. 하루 실행 상태는 검증 성공 또는 실제 무변경 확인 후에만 갱신하므로 실패 뒤에는 재시도할 수 있다. 수동·예약 모두 같은 OS 파일 잠금으로 동시 실행을 차단하고 프로세스 종료 시 잠금은 풀린다. 백업 중 추가된 기록은 다음 예약 대상으로 유지한다.

`not_due_before_22_KST`는 무변경 완료가 아니라 아직 실행 시각 전이라는 뜻이다. 응답의 `not_before`는 한국 시간 22시이며 `retry_after_seconds`는 조기 재호출을 피하도록 올림한 남은 초다. 22시 일일 예약에서만 남은 시간이 10분 이내면 60초 이하로 나누어 기다리고 기본 명령을 다시 실행한다. 재호출도 실제 현재 시각·잠금·하루 1회·변경 여부를 다시 검사한다. 10분보다 이른 예약 또는 반복 대기가 누적 10분을 넘으면 시각 불일치를 보고하고 종료한다. 실패·누락을 --force로 보충하거나 새 예약을 만들지 않는다.

`scripts/backup_github.py`를 같은 Python으로 실행한다. 최초 수동 생성에만 `--force --create-private`를 사용한다. Windows 자격 증명 관리자의 기존 GitHub 인증을 메모리에서 사용하며 인증 정보를 파일·로그에 출력하지 않는다. 각 채팅의 작업 종료 시에는 실행하지 않는다. 한국 시간 매일 밤 10시 예약으로 하루 한 번 실행하고 변경이 없으면 압축·GitHub 인증·통신 전에 생략한다. 일반 실행도 같은 정책을 따른다. 수동 즉시 백업은 사용자 명시 요청 시에만 --force를 사용한다. 전송 대상은 고정된 개인 비공개 저장소 `asstro1456/codex-judgment-backup`의 압축 DB 스냅샷·해시·복구 안내뿐이다. 로컬 스냅샷은 `D:/CodexData/backups/github-judgment-db/judgments.sqlite3`.

수동 `--force`는 시각·당일 예약 완료·무변경 생략만 우회하며 잠금과 전체 검증은 유지한다. 성공하면 검증 복원본의 revision·커밋·성공 시각을 같은 상태 파일에 기록한다. 예약 확인 날짜(`last_run_day`)는 수동 실행에서 바꾸지 않는다. 이후 예약은 수동 백업과 동일 내용이면 생략하고 새 변경이 있으면 백업한다. 실패하면 기존 성공 상태를 유지한다.

인증 실패는 저장 계정 없음·저장 인증 읽기 실패·서버 인증 거부(401)·접근 금지(403)·식별 가능한 요청 한도로 구분한다. 403은 권한·정책·요청 제한 가능성을 남기고, 404는 저장소 없음과 접근 불가를 구분할 수 없다고 보고한다. Git 인증 복구가 필요하면 `git credential-manager github login --username asstro1456 --browser`를 안내하고, 기존 인증을 서버가 거부한 401이면 이 로그인 명령에 `--force`를 붙여 재인증하도록 안내한다. 자동 로그인·토큰 출력·자격 증명 삭제는 하지 않는다.

최신 원격 파일은 `judgments.sqlite3.gz`와 `snapshot.json`이다. 예전 `judgments.sqlite3`는 보존된 구형 백업이며 최신 복원 대상으로 쓰지 않는다. SQLite backup으로 일관된 스냅샷을 만들고 gzip(mtime=0)으로 압축한다. 압축 파일·메타데이터·README를 Git 객체로 준비한 뒤 한 커밋으로 게시한다. 원격 브랜치가 달라지면 강제 갱신하지 않고 실패를 알린다. 변경이 없으면 새 커밋을 만들지 않는다.

검증은 게시한 커밋을 지정해 raw 형식으로 다운로드하고 압축 SHA-256·메타데이터·압축 해제 후 DB SHA-256·PRAGMA integrity_check·기록 수를 확인한다. 검증한 복원본은 같은 D 폴더의 `github-verified.sqlite3`에 둔다. 해시와 무결성 모두 통과해야 완료다. 압축 후에도 100MB 이상이면 파일 한도 때문에 게시 전에 실패하며 기존 원격 백업을 유지한다. 이때 분할/LFS 등 별도 보관 방식을 검토해야 한다. 훅은 실행 지침이며 상시 동기화 서비스가 아니다.

## 원문과 판단

게임 기획·구현·검수는 [GPTDB 참고자료 연결 계약](game-design-gptdb.md)을 함께 적용한다. 기본 DB의 게임 프로젝트/명시적 게임 설계 분야 retrieve에 별도 design_references가 붙으며, 다른 게임 프로젝트는 `design-references --query '<실제 설계 문제>'`로 DB 없이 조회한다. 참고자료는 사용자 확정 판단이나 applied_judgments가 아니며, 실제 원문·분석·현재 제안의 역할을 구분한다. 최신 색인/노트를 매번 읽고, `--no-design-references`로 이번 retrieve의 추가 조회를 생략할 수 있다.

### 프로젝트·목적별 최신 근거 조회

Source readback is mandatory and bundled into `retrieve`: each returned `source_review` contains the selected record's exact original quote and linked context, re-read from the DB. Read these quotes before applying. `complete=true` confirms delivery and quote membership, not semantic approval. Truncated/missing evidence or an intervening supersession sets complete=false and blocks automatic application. Increase --chars or show only the missing record/source IDs; do not repeat show for already-delivered complete evidence. Legacy search still needs explicit record/source readback. The DB remains read-only and the command does not mark a judgment as user-approved. The default-DB CLI can save scoped local recovery settings/reports through [automatic source-delivery recovery](automatic-retrieval-recovery.md); `--no-auto-recovery` skips those writes. Direct retrieval/evaluation library calls remain free of persistent writes.

Current conditions, priority and action-state attribute quotes are included in source readback, as are explicit predecessor attributes. A quote already contained in an untruncated delivered quote from the same source does not consume another source slot. Attribute evidence outside those quotes still counts toward the normal delivery limits; missing or truncated evidence keeps application blocked.

`source_review.followup` lists exact IDs, record/source kind and reason when delivery is incomplete (truncated attributes/quote, omitted context, missing evidence or supersession). Use those IDs directly; do not inspect implementation code or reload whole conversations to discover omitted context.

관계 검토나 연결 원문의 **전달 개수** 때문에 기준이 잘렸다면 `retrieve --limit 1`로 필요한 기준 하나를 집중 조회한다. 기존 프로젝트·분야·대상과 그 기준의 구체적 검색어를 유지한다. 기본 검색은 관계4개/원문5개이며 명시적인1개 조회는 각각20개까지 재귀적으로 전달한다. 예: `retrieve --project projectut --domain vfx --target dense-storm-pattern-c --query '멈춰있는' --limit 1 --chars 2000`. 브릿지 `judgment_retrieve`도 기존 `limit:1`을 그대로 사용하므로 새 도구 스키마·서버 재시작이 필요 없다. 현재 충돌·분류 버전·인용·조건 검사는 그대로 수행하며 상한 초과나 잘린 속성·인용, 근거 누락은 계속 적용을 차단한다. 임의 길이의 모든 원문 전달이나 적용 승인을 보장하지 않는다. 전달된 실제 원문과 조건을 읽은 뒤 적용한다. 집중 조회도 읽기 전용이며 기본 검색량을 늘리지 않는다.

```powershell
& $judgmentPython -X utf8 $judgmentTool retrieve --project projectut --purpose corrections --domain vfx --query '블러'
& $judgmentPython -X utf8 $judgmentTool retrieve --project crack --purpose wants --query '도입 훈련장'
& $judgmentPython -X utf8 $judgmentTool retrieve --project projectut --purpose all --domain vfx --target vision-blur --query '블러'
& $judgmentPython -X utf8 $judgmentTool show '<관련 결과 ID>' --summary
```

목적: `all` 전체, `corrections` 수정·거절·평가, `wants` 요청·선택·수용, `thinking` 제안·이유·평가, `reference` 다른 목적에 해당하지 않는 질문·정보. 목적은 과거 발언을 걸러내며 관련 확정 기준·참고문서와 정정 경고는 함께 반환한다. 프로젝트는 필수이고 검색어 또는 target이 필요하다. domain 생략은 해당 프로젝트의 모든 분야, target 생략은 여러 대상의 관련 근거를 탐색한다. 다른 프로젝트로 확대하지 않으며 global은 명시적으로 공통 적용된 기록만 함께 찾는다. 기존 `search`의 target 기본값 `*` 및 기존 호출은 바뀌지 않는다.

`--domain`/`--target`으로 기존 분류 이름을 재사용한다. 프로젝트·공통 범위의 확정 판단은 target 명칭이 달라도 함께 찾으며, 개별 대상 근거는 정확한 target으로 제한한다. `--conversation <실제 대화 ID>`는 작업별 과거 발언을 제한한다. 확정 프로젝트·공통 판단은 이 대화 제한 밖에서도 유지된다. 대상 이름이 불확실하고 결과가 없을 때만 `--fallback-target`을 쓰며 같은 프로젝트·분야의 관련 대상을 한 번 조회한다. fallback의 개별 대상 결과는 적용 가능으로 표시하지 않는다.

공통 판단의 유효성을 검사할 후속 정정은 대화 제한 밖에서도 확인하고 경고로 반환한다. 프로젝트 전체 기준은 검토된 중복 원문에 연결된 대화의 후속 정정도 확인한다. 이 연결은 정정 검토용이며 다른 대화의 일반 근거를 합치거나 같은 원문으로 덮어쓰지 않는다.

<a id="retrieval-relevance"></a>
### 검색 관련성 및 재검색

성공 종료·반환 개수·score·rule_eligible는 현재 작업과의 의미상 관련성을 보증하지 않는다. `target`, `match`, 원문·조건을 실제 작업 대상과 대조한다. 프로젝트 공통 기준은 유효 범위에서 유지하되 그것만 나왔다고 필요한 개별 기준까지 찾았다고 하지 않는다. 결과가 비었거나 무관한 결과뿐이거나 필요한 기준이 빠졌으면 다음과 같이 재검색한다.

1. 무관한 결과는 적용에서 제외하고 관련 결과는 보존한다. 같은 프로젝트 안에서 긴 혼합 검색어를 핵심 대상·기능·동의어로 바꾸고, 이미 확인된 domain/target 및 필요한 conversation으로 좁힌다. 예: 리깅 스킬 조사에서 이미지 수량 기준만 나오면 `--project crack --target animated-thumbnail-tool-comparison --query '리깅'`처럼 확인된 대상을 조회한다. 다른 프로젝트로 자동 확대하지 않는다.
2. 재검색한 결과도 원문·범위·조건과 source_review를 확인한다. 아직 찾지 못했다면 다른 핵심어 또는 확인된 관련 target으로 한 번 더 찾는다. target 이름이 불확실하고 정확한 대상 결과가 없을 때만 기존 `--fallback-target`을 사용한다. 이미 실행한 fallback도 재검색 횟수에 포함한다. 같은 쿼리 반복이나 limit/chars 확대는 의미상 재검색을 대신하지 않는다.
3. 서로 다른 재검색 최대 2회 후에도 관련 근거가 없으면 DB 재검색을 멈추고, 확인한 범위와 누락된 기준을 밝힌다. '확인한 범위에서 찾지 못함'을 'DB에 없음'으로 단정하지 않는다. 필요한 실제 문서·설치된 관련 스킬을 확인한 뒤 방법·근거가 여전히 부족하면 [기준 부족 시 자료 조사](criteria-gap-research.md)로 부족한 부분만 조사 담당에 연결한다. 사용자 취향·작품 설정·필수 입력처럼 조사로 결정할 수 없는 중요한 공백만 짧게 질문한다. 미확인 기준을 만들어 적용하지 않는다.

사용자가 '저번 VFX 스킬/파이프라인처럼'이라고 기존 자료를 지칭하면 먼저 그 자료의 이름·경로·대화/출처 ID를 확인하고 관련 원문 절차를 읽는다. 비슷한 기능의 다른 스킬을 읽은 것만으로 해당 자료를 확인했다고 하지 않는다. 사용자가 다른 프로젝트의 특정 자료를 비교 참고로 지목한 경우에만 그 자료를 좁혀 조회·읽을 수 있으며, 그 프로젝트의 판단을 현재 프로젝트의 규칙이나 실행 승인으로 가져오지 않는다. 지칭 대상이 아직 불명확하면 확인한 대체 자료와 미확인 대상을 구분한다.

retrieve 기본값은 최대 3개, 각 본문·속성 문자열 1600자이며 일반 조회에서는 `--limit`/`--chars`를 생략한다. `--limit 1~20`, `--chars 80~2000`. CLI에서 2000자보다 큰 값을 요청하면 오류로 재시도하지 않고 상한 2000자를 적용하며 `query_options`에 요청값·적용값·chars_capped를 표시한다. 80자 미만과 잘못된 limit은 여전히 거부한다. 상한에서도 원문이 잘리면 source_review.followup의 ID만 show한다. 기존 search의 기본 6개·480자와 Python retrieve 함수의 명시적 인자 검증은 유지한다. 속성 배열은 최대 4개로 제한하고 `details_truncated`이면 필요한 ID를 show로 읽는다. 검색은 등록 순서가 아닌 source의 실제 발언 시각을 사용한다. `observed_at`은 표시 원문의 시각, `latest_observed_at`은 검색 범위에 포함된 중복 원문 중 최신 시각이다. 날짜 미상은 미상으로 남긴다. 명시적 supersedes로 대체된 판단·후보는 기본 결과에서 제외하지만 show로 보존된다. 후속 후보가 확정 판단의 분류를 변경했으면 적용 전 재검토로 표시한다.

`usage=confirmed_rule` + `rule_eligible=true`만 범위 확인 후 사용할 수 있는 확정 기준 후보다. `historical_evidence`는 검수한 과거 발언이며, `reference`는 원문 문서, `inactive_judgment`는 제안·가설·거절·미정 상태다. 맥락 누락 후보는 기본 제외하고 `--include-unresolved`로 질문할 근거를 찾는다. 과거의 일회성 실행 승인·미확정 발언을 현재 허가나 일반 규칙으로 승격하지 않는다.

`review_alerts`는 미해결 정정·교체·조건부 예외의 검토 목록이다. 같은 대상·원문 대화·명시적 연결은 검토 후보를 찾는 근거이며 의미상 충돌의 확정 근거가 아니다. 미검토 관계는 `relation=unresolved`로 차단하고, 검색어가 없는 짧은 거절도 놓치지 않는다. 날짜 미상은 `time_relation=unknown`/`change_time_unknown`으로 남기며 더 최신이라고 가정하지 않는다. 검토한 관계도 판단을 자동 대체하거나 후보를 확정 기준으로 승격하지 않는다. 개별 대상 기준은 같은 대화의 다른 대상과 자동 연결하지 않는다. `equivalent_sources`는 이미 맥락·범위를 검토한 중복의 원문 연결이며 이후 분류가 달라지면 분리한다.

### 충돌 후보의 원문 검토

에이전트는 경고의 양쪽 원문·조건·연결 맥락을 읽고 `replacement`(내용의 교체), `exception`(조건부 예외), `separate`(별개 요구), `consistent`(같은 기준과 양립), `unresolved`(판단 보류) 중 하나로 검토한다. 교체 여부와 발언 순서는 별개다. 날짜가 없으면 검토만으로 최신성을 만들지 않는다. 예외는 `condition`에 적용 조건을 명시하고 작업 조건과 대조한다. 교체·예외·판단 보류는 계속 차단한다. 별개·일치만 해당 쌍의 차단을 해제하며 다른 경고나 원문 누락이 있으면 적용 불가를 유지한다.

검토는 `batch --input -`의 `command=conflict_review`로 추가한다. data 필드: `project`, 기준의 `domain`/`target`, `rule_id`, `change_id`, `rule_candidate_id`(기준에 연결된 현재 분류 ID; legacy는 null), `relation`, `analysis`, `evidence`. evidence에는 양쪽 primary 원문과 각 context_refs(기준의 연결 후보 맥락 포함)의 모든 source_id/quote를 정확하게 넣는다. `analysis`는 대상·적용 조건·수정 이유를 대조한 에이전트 해석이며 사용자 발언으로 저장하지 않는다. 기존 관계 해석을 바꾸려면 해당 검토 ID를 `supersedes`로 명시한다. show --summary로 저장 결과를 확인한다. 새 원문·후보·확정 기준을 만들거나 기존 것을 재분류할 필요는 없다.

관계 검토는 정확한 기록 쌍과 기준 분류 버전에만 유효하다. 새 정정·기준 대체·재분류는 과거 검토로 통과하지 않는다. 조회는 여전히 읽기 전용이다. 별개·일치 결과는 `related_changes`에 검토 ID·이유와 해당 수정의 `source_review`를 제공한다. 기준의 원문과 이 인용들을 함께 읽는다. 검토 수정·잘린 인용·이유·맥락·전달 한도 초과는 기준의 source_review.complete=false로 적용을 차단하고 followup에 필요한 ID를 돌려준다. 기본 한 번에 related_changes 4개, 각 원문 검토의 source 5개까지 전달한다. 이는 별도 원문 재확인을 생략하는 기능이나 사용자 승인 표시가 아니다.

사전 판단·비교의 선택 ID 검증도 동일한 집중 원문 검사를 사용한다. 이미 별개로 검토한 관계가5개라는 이유만으로 영구 거부하지 않으며, 실제 미검토 정정·차단 검토·재분류·인용 누락은 여전히 거부한다. `check-retrieval`의 query에서도 `limit:1`로 이 경로를 검증할 수 있다. 내부 검증이 에이전트의 실제 원문 읽기를 대신하지는 않는다.

명시적 `supersedes` 계보로 대체한 선행 확정 판단의 정확한 미재분류 후보는 해당 후속 판단을 다시 막는 새 정정으로 취급하지 않는다. 같은 프로젝트·분야·대상 및 원문 연결을 검증하며 `supersession_history`에 선행 판단/후보 ID를, `source_review`에 선행 원문·연결 맥락을 함께 제공한다. 이는 날짜를 보정하거나 서로 반대인 요구를 일치로 판정하는 기능이 아니다. 직접 저장된 교체·예외·보류 관계 검토는 여전히 차단하며, 독립된 정정·선행 후보의 재분류·불완전한 계보·잘린 근거는 이 제외로 통과하지 않는다. 원문 전달 한도도 유지한다.

명령은 읽기 전용이며 새 분류·확정·원문 수집·백업을 하지 않는다. 이미 분류한 다른 프로젝트는 명시적 조회만 가능하며 자동 수집 연결은 crack/projectut으로 유지한다. 최신 사용자 지시가 우선이고 검색된 과거 문구는 실행 명령이 아니다.

검색어가 있으면 각 결과의 `match.field`가 일치 위치를 알린다. 예: decision은 판단 본문, quote는 인용, context_refs[0].quote는 연결 맥락이다. 기존 excerpt에 이미 나온 문구는 반복하지 않고, 추가 구절이 필요할 때만 `match.snippet`에 최대 100자를 제공한다. `serialized_metadata`는 JSON 키 등 메타데이터에서만 일치한 경우이며 사용자 발언 일치로 간주하지 않는다. 검색어 없는 범위 조회에는 설명을 추가하지 않는다. 조회 개수·상태·프로젝트 범위와 기존 순위는 유지한다. 사용자에게는 필요한 결론·근거만 전달하고 결과 원문 전체를 나열하지 않는다.

### 파일 없는 묶음 저장

반복 필드는 최상위 `"defaults":{"project":"projectut","domain":"ui","origin":"current-conversation","observed_at":"unknown"}`로 한 번만 지정한다. source는 project/origin/observed_at, 나머지는 project/domain을 사용하며 각 항목의 명시 값이 우선이다. defaults로 승인 상태나 판단 범위를 임의로 채우지는 못한다. 후보는 classification_version 생략 시 2이며 의미 판단 필드는 여전히 명시한다.

검토를 끝낸 record는 `{"ref":"rule","command":"record","data":{"candidate_id":{"$ref":"candidate"},"status":"confirmed","review_note":"원문과 범위 검토 내용"}}`처럼 줄일 수 있다. 후보의 project/domain/target/source_id/quote/attributes/reason_kind/reason/reason_quote와 interpretation(판단 decision)을 가져온다. status와 review_note는 자동 생성하지 않는다. 명시한 값은 그대로 검증하므로 후보와 다른 인용·범위를 넣으면 실패한다. 보류·불확실한 후보를 이 방법으로 확정할 수 없다.

재조회는 `show <판단ID> --summary`를 기본으로 사용한다. 원문 인용·프로젝트·대상·상태·속성과 연결 ID를 유지하고 중복 검토 문구 등은 생략한다. 필요한 값만 요청하려면 `show <ID> --fields id,status,payload.quote,payload.attributes`를 쓴다. 지정 경로가 없으면 오류로 알린다. `show <ID1> <ID2> --summary`처럼 한 번에 여러 ID를 조회할 수도 있다. 옵션 없는 기존 show 전체 출력은 유지된다.

`batch --input -`에 다음 형태를 표준입력으로 전달한다. 각 data는 기존 source/candidate/record 검증 계약을 그대로 사용한다. 후보는 v2만 허용하며 record에는 검토한 candidate_id가 필요하다. 순서상 앞에서 정의한 ref만 `{"$ref":"user"}` 형태로 참조한다. 실제 인용·맥락·속성은 각 항목에 명시해야 한다. 후보만 저장하고 검토를 보류할 수도 있다.

```json
{"operations":[
  {"ref":"user","command":"source","data":{"project":"projectut","role":"user","origin":"current-conversation","observed_at":"unknown","text":"실제 발언"}},
  {"ref":"candidate","command":"candidate","data":{"source_id":{"$ref":"user"},"classification_version":2,"quote":"실제 발언","...":"기존 v2 필수 계약을 모두 작성"}},
  {"ref":"rule","command":"record","data":{"source_id":{"$ref":"user"},"candidate_id":{"$ref":"candidate"},"...":"검토한 판단 계약을 모두 작성"}}
]}
```

위 예시는 구조 설명용이며 `...`를 제거하고 필수 계약을 채워야 실행된다. PowerShell에서는 리터럴 here-string(`@'` / `'@`)을 Python 표준입력으로 연결하고 UTF-8을 명시한다. 프로그램 호출은 subprocess의 `input=json.dumps(packet, ensure_ascii=False)`, `encoding='utf-8'`을 쓴다. 파일·셸 인자 문자열 치환을 거치지 않는다. 전체 실패 시 종료 코드 1이며 이번 묶음 행은 남지 않는다. 성공 응답의 확정 판단 ID만 `show`로 다시 확인한다.

검색은 기존 target을 재사용한다. 이름이 불확실할 때 `search --project projectut --domain vfx --target blur-camera --query '블러' --fallback-target`처럼 요청하면 정확한 대상에 결과가 없을 때 한 번만 같은 범위의 다른 대상을 찾는다. `fallback` 표시는 관련 근거 발견일 뿐 적용 승인이 아니며 반환된 target을 확인해야 한다. 검색어 없는 확대·다른 프로젝트 검색은 하지 않는다.

`source` 입력 예시(예시는 DB에 자동 입력되지 않음):
```json
{"project":"projectut","origin":"conversation:<실제 ID>/message:<실제 ID 또는 식별 가능한 발언>","observed_at":"<실제 발언 일시; 알 수 없으면 unknown>","role":"user","text":"<실제 사용자 발언>"}
```

현재 대화에 메시지 ID가 없으면 `current-conversation`과 정확한 발언으로 식별하고 ID를 만들지 않는다. 관찰 시각과 발언 시각을 혼동하지 않는다. 도구는 role 표기의 진실 여부를 증명하지 못하므로 에이전트가 실제 화자를 확인한다.

`record` 입력:
```json
{"project":"projectut","domain":"vfx","target":"vision-blur","status":"confirmed","decision":"블러 중에도 캐릭터·배경 움직임을 유지한다.","source_id":"<source 반환 ID>","quote":"<원문에 존재하는 정확한 사용자 인용>","reason_kind":"unknown"}
```

- 상태: `confirmed / proposed / hypothesis / unresolved / rejected`. 기본 검색은 confirmed + 참고문서. 미확정 검토 시 `--include-pending`.
- `reason_kind`: `unknown / inferred / user_stated`. 뒤의 두 상태는 `reason` 필수. user_stated는 같은 사용자 원문의 `reason_quote`도 필수.
- 변경: `supersedes: <이전 판단 ID>`, `change_reason: <바뀐 이유>` 추가. 같은 프로젝트·분야·대상만 대체한다. 이전 기록은 `show`로 유지된다. 최신 거부·미정 기록도 이전 확정 판단을 대체할 수 있다.
- `target` 생략 검색은 `*` 공통 기준만 가져온다. 특정 대상에는 `--target vision-blur`처럼 지정한다. `domain`을 생략하면 해당 프로젝트 전체 분야를 검색한다.
- `context`, `media_paths`, `tags` 등 필요한 맥락을 JSON에 추가 가능. 이 값은 검증 증거가 아니며 파일 존재/미디어 내용을 확인한 사실과 구분한다.

## 기존 자료와 export

새 발언 선별에는 [분류 규격 v2](classification.md)을 사용한다. 원문과 맥락의 source ID를 먼저 확보한 뒤 실행한다. 기존 v1 기록과 호출은 유지된다.

```powershell
& $judgmentPython -X utf8 $judgmentTool candidate --input '<분류 JSON 절대 경로>'
& $judgmentPython -X utf8 $judgmentTool candidates --project projectut --limit 10
& $judgmentPython -X utf8 $judgmentTool candidates --project projectut --status unclassified --limit 10
& $judgmentPython -X utf8 $judgmentTool show '<후보 ID>'
```

candidate는 의미를 자동 분류하는 명령이 아니라 모델의 분류 결과를 검증·저장하는 명령이다. 일반 search에는 후보를 포함하지 않는다. 후보를 검토해 기준으로 채택할 때 record 입력에 `candidate_id`, `review_note`를 붙이며 source_id·quote·project·domain·target은 후보와 같아야 한다. 맥락 누락·질문만 있는 발언·일회성 작업 후보는 confirmed 재사용 기준으로 승격하지 못한다. 기존 DB와 record 호출은 유지된다.

v2 후보에는 attributes의 conditions 배열, priority/action_state/acceptance_scope(없으면 null)가 필수다. record로 승격할 때 attributes를 그대로 포함한다. 미분류는 types에 unclassified, unclassified_reason, decision_state=unresolved, reuse=uncertain으로 보존한다. 원문이 확인되지만 의미를 모르는 경우에도 임의 해석으로 채우거나 버리지 않는다.

```powershell
& $judgmentPython -X utf8 $judgmentTool import-markdown 'D:/Crack/창작_판단기준.md' --project crack --domain creative
# ID를 지정하지 않으면 제목/ID 목록만 표시하며 대화는 가져오지 않음
& $judgmentPython -X utf8 $judgmentTool import-export '<export.zip 또는 conversations.json>'
& $judgmentPython -X utf8 $judgmentTool import-export '<export.zip>' --conversation '<선택 ID>' --project crack
```

동일 입력 재실행은 중복 생성하지 않는다. Markdown 변경 시 새 스냅샷을 추가하고 기본 검색은 최신 색인만 노출한다. 현재 지원하는 export는 `conversations.json` 배열의 `mapping/current_node` 구조. 256 MiB 초과는 선별·분할 후 입력한다. ZIP은 압축을 풀지 않고 해당 JSON만 읽는다. 실제 사용자 export 수령 후 형식 확인이 필요하다. 개별 message ID는 아래 읽기 전용 조회로 찾고 `show`한다(다음 페이지는 `--offset 20`):

```powershell
& $judgmentPython -X utf8 $judgmentTool messages --project crack --conversation '<선택 ID>' --limit 20
```

## 예측과 실제 피드백

`predict --input`:
```json
{"project":"projectut","domain":"vfx","target":"vision-blur","task":"<실제 작업 ID/경로>","prediction":"<피드백을 보기 전에 예상한 결함/수용 기준>","judgment_ids":["<적용 판단 ID>"]}
```

`feedback --input`:
```json
{"prediction_id":"<predict ID>","source_id":"<새 사용자 피드백 source ID>","quote":"<실제 인용>","outcome":"missed","analysis":"<예상과 실제 차이; 추측한 심리 제외>"}
```

outcome은 `matched / missed / undetermined`. DB 등록 순서는 검사하지만 실제 피드백을 언제 읽었는지 증명하지 못한다. 과거 export로 사전 예측 성능을 주장하지 않는다. 불명확한 짧은 반응은 undetermined. verdict는 에이전트 해석이며 사용자 직접 점수가 아니다. 생산성/정확도 통계는 아직 자동 산출하지 않는다.

### 같은 작업의 하네스 미사용/사용 비교

비교 평가를 요청받았거나 실제 검증에 필요한 경우에만 기존 predict에 `comparison_id`와 `variant`를 함께 지정한다. variant는 `baseline`(판단 DB 근거 ID 없음) 또는 `harness`(원문 재확인이 완료된 적용 후보 judgment_ids 1~20개)다. 같은 comparison_id의 project/domain/target/task는 같아야 하며 양쪽 prediction은 변경하지 않는다. 실제 예측·결과를 기록하고 개선된 것처럼 예상 문장을 꾸미지 않는다. 새로운 비교는 새 ID를 사용한다. 하네스 정보를 이미 본 상태에서 만든 baseline은 독립 대조군이 아니며 별도 맥락에서 준비하지 못했으면 그 한계를 밝힌다. 정상 제작에서 필수 판단 검색을 생략할 권한은 아니다.

양쪽 예측을 실제 사용자 피드백 원문 등록 전에 기록한 뒤, 동일 source_id의 피드백으로 각각 feedback을 남긴다. source 등록 순서와 실제로 발언을 처음 본 시점은 다르므로 이 검사가 사전 예측이나 미사용 상태를 증명한다고 말하지 않는다. 과거 피드백을 새 source로 재등록해 시간 순서를 꾸미지 않는다. 비교를 위해 shared DB에 합성 예측·피드백을 만들지 않는다.

피드백이 두 예측을 판단할 근거를 주지 않으면 해당 쪽은 undetermined로 둔다. 한 결과에 대한 짧은 칭찬을 다른 결과의 실패로 바꾸지 않는다. 이유 일치는 단어 유사도가 아니라 사용자가 말한 관찰·문제·적용 조건·판단 이유를 대조해 검토하며, 근거가 없으면 이유를 추정해 점수를 채우지 않는다.

`compare --project <ID> [--domain <domain>] [--target <target>] [--limit 1~20]`는 읽기 전용이다. 같은 작업 쌍의 피드백 일치율, 개선·악화·동일 건수를 제공한다. 누락·undetermined·서로 다른 outcome이 있는 쌍은 분모에서 제외한다. 자료가 없으면 rate=null, evidence_status=insufficient_data다. 이는 사용자 피드백에 대한 에이전트 판정의 일치율이며 모델 정확도·인과적 생산성 개선이 아니다. 원문 의미 검토나 사용자 기준 확인을 숫자로 대체하지 않는다.

### 실제 검색의 적용 후보·금지 사례 회귀 검사

`check-retrieval --input <검토한 사례 JSON 또는 ->`는 DB를 수정하지 않는다. packet에는 `evaluation_kind: retrieval_regression`, `expected_by: agent_source_review`, `record_fingerprints: {검토 ID: fingerprint}`, `cases` 1~40개를 둔다. 각 case는 고유한 name, 범위를 지정한 query(retrieve 인자), must_be_eligible와 must_not_be_eligible ID 목록을 쓴다. 최소 한 기대 항목과 모든 기대 ID의 검토 버전이 필요하다. 예: 같은 기준을 해당 프로젝트에서는 찾고 다른 프로젝트·분야·대상에서는 적용 후보로 쓰지 않는 쌍. 폐기된 기준·일회성 후보·맥락 누락도 적용 금지 사례로 포함한다. 기대값을 바꾸어 실패를 숨기지 말고 원문과 범위를 재검토한다.

이 검사는 선택한 검색 사례의 누락·부적절한 적용 후보 반환을 검출한다. 기대 ID는 일반 결과의 표시 limit 밖에 있어도 모두 적격성을 검사한다. 이 선택은 query의 원문·관계 전달 한도나 chars를 확대하지 않는다. `limit:1` 또는 명시적 `full_source_review:true`의 집중 검토만 기존 집중 전달 계약을 사용한다. 조건을 실제 작업이 충족하는지, 출력 문장의 판단 이유가 맞는지, 최종 작업에 적용했는지는 별도 의미 검토다. 에이전트가 골라 검토한 사례는 회귀 자료이며 독립 정답이나 미공개 평가 자료가 아니다. 향후 사용자 기준에 맞춘 정확도 평가가 필요하면 대화·사건 단위로 분리한 새 사례의 기대 결과를 출력 확인 전에 고정하고, 개선에 사용한 사례와 섞지 않는다. 의미상 같은 중복도 분리 집단 사이에 나누지 않는다. 임베딩·미세조정은 실제 누락 또는 판단 실패를 측정한 다음 검토한다.

### 수정 이유 출처 보존

user_stated 이유가 다른 연결 사용자 발언에 있으면 candidate의 `reason_source_id`를 그 source로 지정한다. batch record는 reason_kind/reason/reason_quote/reason_source_id를 함께 상속한다. v2 승격은 이유 종류·설명·인용·출처를 임의로 바꾸거나 버리지 못한다. 이유 변경은 원문 맥락을 다시 검토해 후보를 정정한다. legacy record는 자기 발언 또는 명시적으로 연결한 사용자 원문만 이유로 사용할 수 있다. retrieve는 `user_reason_quote`/`user_reason_source_id`와 정확한 이유 인용을 source_review로 전달한다. unknown과 inferred를 사용자 이유로 바꾸지 않는다.

## 실제 작업 피드백 개선

연결된 실질 작업의 predict/learning-status/feedback/improve 순서, 실제 원문 식별·시각, 개선 원인 구분, 원자적 기준 갱신과 회귀 검사는 [learning-cycle.md](learning-cycle.md)를 따른다. compare는 별도의 동일 작업 쌍 비교이며 일상 평가 v1 기록과 섞지 않는다.

## 검증

```powershell
& $judgmentPython -X utf8 -m unittest discover -s 'C:/Users/User/.codex/skills/judgment-harness/scripts' -p 'test_*.py' -v
```
