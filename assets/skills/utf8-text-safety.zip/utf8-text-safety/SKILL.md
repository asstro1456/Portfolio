---
name: utf8-text-safety
description: Safely read, extract, and edit UTF-8 text files on Windows without mojibake or accidental encoding conversion. Use for Markdown, text, JSON, YAML, CSV, or source files containing Korean or other non-ASCII text when encoding is uncertain, characters appear broken, a tool used the system default encoding, or only one section must be read and modified accurately.
---

# UTF-8 텍스트 안전 처리

## Core Rules

1. Never trust the Windows system default encoding for UTF-8 documents.
2. Read the original file bytes again when text looks broken. Do not repair an already garbled string.
3. Specify UTF-8 explicitly before interpreting headings, paths, values, or modification scope.
4. Use strict decoding. Do not silently replace invalid bytes with `�` or `?`.
5. Do not overwrite or convert the file merely to fix terminal display.
6. Preserve the original BOM and line-ending style unless conversion is explicitly requested.
7. Use `apply_patch` for text edits. Avoid `Set-Content` and `Out-File`, which may change BOM or line endings.
8. Re-read the changed region explicitly as UTF-8 after editing.

## Safe Reading

### PowerShell

```powershell
Get-Content -Raw -Encoding UTF8 -LiteralPath 'C:\path\file.md'
Select-String -Encoding UTF8 -LiteralPath 'C:\path\file.md' -Pattern '검색어'
```

Never use `Get-Content`, `type`, or `Select-String` without an explicit encoding for a suspected UTF-8 file.

### Python

Run Python in UTF-8 mode and specify the encoding:

```powershell
python -X utf8 script.py
```

```python
text = path.read_text(encoding="utf-8-sig", errors="strict")
```

Use `utf-8-sig` for reading when a UTF-8 BOM may be present. Do not use `errors="replace"` or `errors="ignore"`.

### Node.js

```javascript
const text = fs.readFileSync(path, "utf8");
```

## Mojibake Recovery

When text appears broken:

1. Stop interpreting or editing the displayed text.
2. Return to the original file path.
3. Read it explicitly as UTF-8.
4. Confirm known Korean headings, filenames, or field names render correctly.
5. Only then determine the target section and make changes.

If strict UTF-8 decoding fails, inspect the original bytes read-only and test likely encodings such as UTF-16 or CP949. Report the detected or assumed encoding before editing. Do not guess and overwrite.

## Partial Section Workflow

For a handoff or long Markdown file:

1. Decode the entire file as UTF-8 once.
2. Locate the exact start and end headings in decoded text.
3. Read only the required logical section into working context.
4. Patch only that section.
5. Re-read the same section as UTF-8 and verify surrounding headings remain intact.

Do not use line offsets obtained from garbled output.

## Verification

After editing, confirm:

- Korean text and paths render correctly.
- No replacement character `�` was introduced.
- The target heading and adjacent headings still exist.
- Unrelated sections were not changed.
- BOM and line endings were not unintentionally converted.

Report the encoding used only when a mismatch, recovery, or conversion mattered.

## Shared Standard

- Change only the requested section, preserve unrelated bytes, and report the verification limit.
