# Crack Character Builder — current UI map

Last checked: 2026-10-17. This is a tested guide, not a promise that the product UI will stay unchanged. Inspect the current tab before acting.

## Entry point

Use **내 작품** (`/my`) → **작품 만들기** (`/builder`) → **캐릭터** in an existing safe tab. The sidebar **만들기** button on the chat/archive area creates a collection, not a character. Navigate and read fresh state in separate calls if the previous page content remains visible. Preserve unrelated editors with unsaved-change warnings.

## Builder structure

- Tabs: 캐릭터 설정 → 인트로 → 프롬프트 → 고급 기능 → 캐릭터 상세.
- `임시저장` is separate from the final registration controls. Verify the `임시저장이 완료되었어요` notice after an edit.
- A new unsaved draft can lose all entered values when navigating directly to another step URL. Use the in-app step/Previous/Next controls while editing, and temporary-save each completed nonempty section. Do not use direct navigation or reload until persistence is confirmed; never use final registration to force a save.
- If a filled textbox shows the intended value but the saved draft restores prior text, clear it and enter the approved text through the supported typing action, blur the field, save, and reopen once. Confirm the visible counter and exact reopened text. This recovered the prompt field in the 2026-10-17 creation run; it is not evidence of a general platform cause. Never treat a DOM value alone as persistence proof.
- Character drafts are independent of story drafts. `내 작품` has separate Story and Character filters.

## Character settings

- Character image is required. PNG, JPG, and WebP are accepted; current UI states 5 MB maximum and recommends a 1:1 ratio.
- Character name: required, 2–30 characters; special characters and emoji are excluded.
- One-line introduction: required, maximum 30 characters.
- Image upload and image generation are available. Do not invoke generation or random content unless requested.

## Intro and examples

- Intro is required and configured in an intro editor. The current editor shows a 1,500-character intro limit, per-message 150-character indicator, and a hidden situation/background area above the divider; inspect the live editor rather than assuming its exact composition.
- Example dialogues can be added; current aggregate indicator is 2,000 characters.
- `0/2,000` is a character counter; it does not establish a two-example limit. Check any count limit separately.
- Player guide is optional and limited to 500 characters.

## Prompt and advanced features

- Character prompt is required and limited to 2,000 characters.
- Advanced features support situation images, with a current maximum of 50. This is optional; do not add images merely because the tab exists.

## Character details and publication

- Detailed character description is required and limited to 1,000 characters.
- An associated story may be selected. Private and link-only stories are not exposed before publication; select only genuinely related stories.
- Genre and target are required. Hashtags allow up to 10.
- Visibility choices are public, private, and link-only. Comments can be toggled.
- The final `등록` / `등록하기` action publishes the character. Confirm its name and visibility immediately before clicking it.
