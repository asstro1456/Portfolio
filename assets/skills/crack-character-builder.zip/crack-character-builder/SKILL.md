---
name: crack-character-builder
description: "Create, edit, or register Crack characters using the current character-builder UI and its field limits. Use for Crack character profiles, intros, prompts, images, or character publication; not for stories."
---

# Crack Character Builder

Use this skill for Crack's **character** builder only. Stories use a separate builder and must not be changed under a character request.

Before work, read [the current character-builder map](references/character-ui.md). It records observed UI behavior; inspect the live page before changing a value because Crack can change its fields and limits.

## Efficient workflow

- Keep only a compact in-chat state: requested fields, confirmed creative choices, current tab, and unsaved changes. Reuse matching values; do not recreate source material or generate optional prose.
- Modify just the requested tab. Use the built-in auto-complete or image generation only when the user asks for it.
- When writing character prompts, intros or examples, apply [information release and conversational motivation](../crack-idea-harness/references/design-and-play-review.md#information-release) by default: keep detailed internal rules separate from visible exposition, reveal information through questions and actions, and answer direct questions or disclose necessary conditions before consequential choices.
- Save edited sections with `임시저장` and verify the completion notice. Do not save an empty exploration draft.
- Follow visible constraints over this reference. If a live control differs, state the difference and ask only for a decision the user must make.

## Registration boundary

- `등록하기` / the final `등록` button publishes the character. Use it only when the user explicitly asks to register or publish the identified character.
- Immediately before publishing, verify the character name and current visibility. Keep public, private, or link-only visibility unchanged unless requested.
- Do not treat a request about a similarly named story as authorization to publish a character, or vice versa.

## Scope

Do not claim a Crack MCP or official API is connected. Use the visible browser UI.
