# Clean Japanese 2D Anime Style Profile

## Core finish

- Clean Japanese 2D TV-anime key-visual still.
- Thin, clear, softly colored outlines; avoid harsh pure black, thick comic outlines, weak lines, and blurry edges.
- Flat cel coloring with large clean color areas, broad graphic shadows, and simple two-step shading.
- Low rendering density with readable contrast; minimal gradients and restrained highlights.
- Simple, readable silhouettes and grouped shapes. Keep materials graphic rather than physically rendered.
- Soft but clear color relationships. Avoid washed-out haze, muddy shadows, uncontrolled saturation, and harsh bloom.
- Background detail stays below the focal subject unless a detailed environment is explicitly requested.

## Content preservation

- Preserve every requested character, costume, prop, setting, pose, camera, composition, and effect, even when unusual.
- Do not interpret a requested shiny object, weapon, ornament, smoke, camera angle, or dark background as style drift. Simplify only its rendering into the locked 2D cel language.
- Do not add unrelated jewelry, mechanical parts, magical effects, objects, people, scenery, or narrative beats.
- When a background is unspecified, use simple low-detail supporting shapes without a specific real-world location.
- When pose or framing is unspecified, use a stable, character-focused pose with a clear silhouette and neutral front or three-quarter framing.
- Never generate readable text, fake letters, typography, logos, captions, watermarks, or UI unless explicitly requested.

## Character rules, only when a character is requested

- Preserve stated age, body type, face, expression, eye design, hairstyle structure, clothing layers, accessories, and props.
- Cute does not automatically mean toddler, chibi, or super-deformed. Mature does not automatically mean fashion-model proportions.
- Use round, clean facial construction and large readable anime eyes when appropriate to the requested character; avoid realistic skin, pores, glossy skin, heavy anatomy shading, and sharp adult facial modeling for young characters.
- Group hair into large soft clumps with limited strand detail and restrained highlights. Keep braids, twin-tails, ponytails, ahoge, and other defining structures readable.
- Use simple clothing folds and broad cel-shadow blocks. Avoid dense seams, wrinkles, embroidery texture, leather grain, scratches, and micro-detail unless explicitly requested.
- Keep props and weapons faithful in silhouette but restrained in surface detail. Do not turn a simple wand, staff, bag, or weapon into an ornate gacha artifact.
- For minors or youthful characters, avoid sexualized framing and body emphasis.

## Avoid profile

Avoid photorealism, semi-realism, 3D rendering, painterly brushwork, glossy mobile-game rendering, hyper-detailed gacha splash art, realistic material microtexture, dense ambient occlusion, heavy gradients, over-modeled forms, noisy particles, photographic depth of field, realistic ground shadows, gritty smoke, muddy colors, low resolution, blurred faces, and unrelated decorative additions.

## Prompt block

Use this compact block unless the user supplies a more specific style:

```text
Art direction: clean Japanese 2D TV-anime key-visual still; thin clear softly colored line art; flat cel coloring; large clean color areas; broad graphic two-step shadows; minimal gradients; restrained highlights; low texture density; simple readable silhouettes; soft but clear palette; polished animation-production finish.
Preservation: follow the written content specification exactly. Do not omit, redesign, weaken, or add unrelated elements. Keep requested props, setting, pose, camera, composition, and effects, simplifying only their rendering into the same 2D cel language.
Consistency: match the approved master image's palette, outline weight, cel-shadow count, perspective, camera, lighting direction, and pixel density. Change only the requested element; keep everything else unchanged.
Avoid: photorealism, semi-realism, 3D render, painterly finish, glossy gacha rendering, dense micro-detail, realistic material texture, heavy gradients, harsh black outlines, blurry edges, washed-out haze, readable text, fake letters, logos, captions, watermarks, and unrelated additions.
```
