---
name: anime-image-direction
description: Keep Japanese 2D anime-style image generations and edits visually consistent while preserving requested character, prop, scene, composition, and transparency. Use for anime characters, game backgrounds, layered scene parts, and revisions; do not use for photorealistic or deliberately painterly work.
---

# Anime Image Direction

Use this skill alongside `imagegen` when an image needs a clean Japanese 2D anime finish or must stay consistent with an approved anime-style asset.

## Separate content from finish

Build the prompt in two blocks:

1. **Content specification:** subject, character appearance, clothing, props, environment, pose, camera, composition, aspect ratio, and elements that must remain unchanged.
2. **Art direction:** linework, coloring, shading, texture density, lighting, palette behavior, and finish.

Do not let art-direction wording remove, weaken, redesign, or invent content. Fill unspecified content only with conservative, low-detail defaults. Do not add props, ornaments, effects, characters, readable text, logos, or specific locations unless requested.

## Consistency lock

- Treat the approved source as the immutable master. Derive every part or revision directly from it, never from a chain of generated revisions.
- Repeat the same style lock on every call: palette behavior, outline color and weight, cel-shadow count, texture density, perspective, camera, light direction, and pixel density.
- For edits, state `change only X; keep composition, silhouettes, palette, linework, lighting, shading, and texture unchanged`.

## Transparent assets

Request `true transparent pixels with alpha=0 outside the subject; do not draw a checkerboard, grid, white background, or matte color`.

## Quality review

Keep technical inspection and verdict rules out of this art-direction skill. When the user requests quality checks, submission readiness, artifact inspection, or comparison with a master image, use the generic `review-ai-generated-art` skill.

## Style profile

For the complete reusable art-direction profile and character-specific rules, read [references/style-profile.md](references/style-profile.md).
