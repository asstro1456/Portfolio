# Codex용 로컬 이미지 검토 도구 2.0.1

사용자는 `ai-boundary-tool.html`을 Edge 또는 Chrome에서 직접 연다. 브라우저의 **작업 폴더 선택**으로 Codex와 같은 실제 폴더를 지정하고 읽기와 쓰기를 허용한다.

기존 펜 조작을 유지한다. **Shift+클릭은 현재 이미지에 남아 있는 이전 선의 끝점에서 클릭 위치까지 직선으로 연결**한다. 이전 선이 없으면 현재 위치에서 시작한다. **Shift+휠은 펜 굵기를 바꾸며 확대하지 않는다.** 일반 휠은 확대와 축소다. 실행 취소로 선을 지웠다면 남은 마지막 선의 끝점이 연결 기준이다.

## 요청 등록

Codex는 승인된 작업 범위 안의 검토 폴더를 하나 정하고, 그 **절대 경로를 사용자에게 알려 준다.** 사용자가 HTML에서 바로 그 폴더를 선택해야 한다. 브라우저는 선택한 폴더의 절대 경로를 알 수 없으므로 폴더 이름만 보고 경로를 추측하지 않는다.

Codex가 Node.js를 사용할 수 있다면 동봉한 도우미를 사용할 수 있다. 이것은 Codex 측의 선택적 파일 작성 도구이며 사용자가 실행하는 프로그램이나 서버가 아니다.

```text
node codex-local.cjs request --data "작업 폴더 절대 경로" --image "원본.png" --title "머리카락 경계 확인" --question "의상과 맞닿는 경계를 빨간 선으로 표시해 주세요."
```

긴 질문은 UTF-8 파일로 적고 `--question-file "질문.txt"`를 사용한다. 반환된 `workspace_path`, `workspace_id`, `request_id`를 보존한다. 사용자는 HTML에서 같은 폴더를 선택하고 새로고침한 뒤 요청을 고른다. 원본은 사본으로 보존한다. 다른 이미지 버전에는 새 요청을 만든다.

도우미를 사용하지 않아도 아래 구조를 로컬 파일로 작성하면 된다. `source.png`를 먼저 쓰고 SHA-256을 확인한 뒤 `request.json`을 마지막에 완성한다. request schema는 `image-boundary-review-request-v1`이며 필드는 `id`(UUID v4), `title`, `question`, `created_at`(ISO 시각), `image: {name,width,height,sha256}`, `coordinate_basis`다. `workspace.json`은 `schema: codex-image-review-workspace-v2`, UUID v4인 `workspace_id`를 갖는다. 기존 ID와 사용자 파일을 덮어쓰지 않는다.

## 응답을 로컬 파일로 읽기

1. 사용자가 보낸 작업 폴더 ID와 원래 등록한 ID를 대조한다. 실제 폴더의 `codex-inbox.json`에서 자신의 `request_id`를 찾는다.
2. 목록의 모든 경로는 **작업 폴더 기준 상대 경로**다. 실제 작업 폴더에 결합한다. 절대 경로라고 취급하거나 다른 프로젝트에서 찾지 않는다.
3. `request_path`로 질문과 버전을 확인하고 `latest.annotation_path`의 JSON과 `latest.marked_png_path`의 PNG를 모두 직접 연다. `latest: null`이면 아직 제출되지 않았다.
4. JSON의 색상 뜻, 좌표, 설명, `decision`을 함께 읽는다. `marked`는 수정 방향, `approved`는 해당 질문과 버전에 대한 승인, `unsure`는 보류다. 보류를 승인으로 바꾸지 않는다.
5. 해당 작업의 승인된 범위에서 반영하고 결과물을 검수한다. 표시 선을 원본 그림의 선으로 취급하지 않는다.

무결성 검사와 편의를 위한 선택적 로컬 읽기 명령:

```text
node codex-local.cjs list --data "작업 폴더 절대 경로"
node codex-local.cjs read --data "작업 폴더 절대 경로" --request "요청ID"
```

명령은 파일만 읽고 쓰며 서버를 시작하지 않는다. `read`는 원본과 PNG/JSON의 해시 및 요청 연결을 검사한다. `list`는 완성된 요청 폴더로부터 목록을 갱신한다.

## 저장 구조

```text
선택한 작업 폴더/
  workspace.json
  codex-inbox.json
  requests/<요청ID>/
    request.json
    source.png
    latest.json
    responses/<제출ID>/
      marked.png
      annotation.json
      receipt.json
```

`receipt.json`은 해당 제출 파일의 완료 기록이다. 완성되지 않은 요청이나 제출을 읽지 않는다. 재제출은 별도 ID로 추가되며 이전 응답은 유지된다. 좌표는 저장된 원본 PNG의 왼쪽 위가 (0,0), 오른쪽이 x 증가, 아래쪽이 y 증가다. 화면 확대와 이동은 좌표를 바꾸지 않는다.

사용자는 이미지 파일을 직접 열어 요청을 만들 수도 있다. JPG와 WebP는 브라우저가 PNG 사본으로 변환해 저장하며 원래 파일은 수정하지 않는다.

## 범위와 확인 상태

실제 사용자 선 12개는 별도 예시다. 작업 요청이나 응답으로 자동 저장되지 않으며 새 이미지에 섞이지 않는다. 예시를 현재 제작물의 수정 지시로 적용하지 않는다.

이 도구는 Codex를 자동으로 깨우거나 원화를 수정하지 않는다. 제출 후 사용자가 **Codex에 보낼 파일 위치 복사**로 상대 경로와 작업 폴더 ID를 알려 주면 읽는다. 브라우저를 다시 열면 작업 폴더를 다시 선택한다. 제출 전 표시는 자동 저장되지 않는다.

저장 코드의 파일 읽기·쓰기, 실패 후 재시도, 응답 보존은 파일 핸들 시험 어댑터로 확인했다. **실제 브라우저의 폴더 선택과 권한 허용을 거친 저장은 사용자 확인 전이다.** 데스크톱 Edge/Chrome을 기준으로 하며 Firefox, Safari, 모바일은 검증 전이다.
